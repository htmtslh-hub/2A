@echo off
chcp 65001 >nul
title Film Studio - Cai Dat Ket Noi AI (MCP 1-Click)
echo ============================================================================
echo   FILM STUDIO AI - TU DONG KET NOI MCP VAO CLAUDE / CURSOR / WINDSURF
echo ============================================================================
cd /d "%~dp0reconstructed_src"
python "%~dp0reconstructed_src\film_studio_mcp_server.py" --install-1click
echo.
echo [HOAN TAT] Da tu dong gan MCP cua Film Studio vao cac phan mem AI tren may!
pause
