@echo off
chcp 65001 >nul
title Cai Dat Thu Vien Film Studio Pro v2.5.0
echo ============================================================================
echo   DANG CAI DAT THU VIEN CHO FILM STUDIO PRO v2.5.0...
echo ============================================================================
python -m pip install --upgrade pip
python -m pip install -r "%~dp0requirements.txt"
echo.
echo [HOAN TAT] Da cai dat xong thu vien! Hay chay CHAY_FILM_STUDIO.bat de mo ung dung.
pause
