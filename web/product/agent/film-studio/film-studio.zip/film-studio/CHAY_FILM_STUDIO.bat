@echo off
chcp 65001 >nul
title Film Studio Pro v2.5.0 - AI Video Production & MCP Server
cd /d "%~dp0reconstructed_src"
python run_reconstructed_app.py
if errorlevel 1 (
    echo.
    echo [!] Neu chua cai thu vien Python, vui long chay file CAI_DAT_THU_VIEN.bat truoc!
    pause
)
