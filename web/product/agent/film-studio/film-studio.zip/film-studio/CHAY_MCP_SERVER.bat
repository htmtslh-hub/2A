@echo off
chcp 65001 >nul
title Film Studio MCP Server (HTTP/SSE Port 3100)
cd /d "%~dp0reconstructed_src"
python "%~dp0reconstructed_src\film_studio_mcp_server.py" --http --port 3100
pause
