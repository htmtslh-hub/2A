// ===================================
// HT COMBINED BACKGROUND - Service Worker v3.0
// Captcha Client (alarm, settings, header capture)
// + Veo Catcher (token storage, cookie reading)
// ===================================

console.log('🔧 HT Combined Background: Started');

// ================== CAPTCHA CLIENT ==================

const DEFAULT_SETTINGS = {
    autoReload: true,
    reloadInterval: 5,
    enabled: true,
    clearGrecaptcha: false
};

async function getSettings() {
    return await chrome.storage.sync.get(DEFAULT_SETTINGS);
}

async function saveSettings(settings) {
    await chrome.storage.sync.set(settings);
}

async function createReloadAlarm() {
    const settings = await getSettings();
    await chrome.alarms.clear('autoReload');

    if (settings.enabled && settings.autoReload && settings.reloadInterval > 0) {
        await chrome.alarms.create('autoReload', {
            periodInMinutes: settings.reloadInterval
        });
        console.log(`✅ Auto reload alarm set: ${settings.reloadInterval} minutes`);
    } else {
        console.log('⏸️ Auto reload disabled');
    }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'fetchToken') { await fetchLabsToken(); return; }
    if (alarm.name === 'autoReload') {
        const settings = await getSettings();
        if (!settings.enabled || !settings.autoReload) return;

        console.log('⏰ Auto reload triggered');
        const tabs = await chrome.tabs.query({ active: true });
        for (const tab of tabs) {
            try {
                await chrome.tabs.sendMessage(tab.id, { type: 'RELOAD_PAGE' });
            } catch (e) {}
        }
    }
});

// Header capture
const WANTED_HEADERS = [
    'authorization', 'x-browser-validation', 'x-client-data',
    'x-browser-channel', 'x-browser-year', 'x-browser-copyright',
    'sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform',
    'user-agent', 'accept-language', 'priority'
];

chrome.webRequest.onSendHeaders.addListener(
    (details) => {
        try {
            const captured = {};
            for (const h of details.requestHeaders || []) {
                const name = h.name.toLowerCase();
                if (WANTED_HEADERS.includes(name)) captured[name] = h.value;
            }
            if (Object.keys(captured).length === 0) return;

            chrome.storage.local.set({ captured_headers: { headers: captured, timestamp: Date.now() } });

            chrome.tabs.query({}, (tabs) => {
                for (const tab of tabs) {
                    if (tab.url && (tab.url.includes('labs.google') || tab.url.includes('flow.google.com'))) {
                        chrome.tabs.sendMessage(tab.id, { type: 'CAPTURED_HEADERS', headers: captured }).catch(() => {});
                    }
                }
            });
        } catch (e) {
            console.error('Header capture error:', e);
        }
    },
    { urls: ['*://aisandbox-pa.googleapis.com/*'] },
    ['requestHeaders', 'extraHeaders']
);

// ================== VEO CATCHER ==================

const STORE_KEY = 'veo_captures';
const SESSION_COOKIE = '__Secure-next-auth.session-token';

async function loadStore() {
    const o = await chrome.storage.local.get(STORE_KEY);
    return o[STORE_KEY] || {};
}

async function saveStore(store) {
    await chrome.storage.local.set({ [STORE_KEY]: store });
}

async function readLabsSession() {
    try {
        const labsCookies = await chrome.cookies.getAll({ domain: 'labs.google' });
        const flowCookies = await chrome.cookies.getAll({ domain: 'flow.google.com' });
        const cookies = [...(labsCookies || []), ...(flowCookies || [])];
        if (!cookies.length) return '';

        const chunks = cookies
            .filter(c => c.name.startsWith(SESSION_COOKIE + '.'))
            .sort((a, b) => {
                const ai = parseInt(a.name.split('.').pop(), 10);
                const bi = parseInt(b.name.split('.').pop(), 10);
                return (isNaN(ai) ? 0 : ai) - (isNaN(bi) ? 0 : bi);
            });
        if (chunks.length) return chunks.map(c => c.value).join('');

        const single = cookies.find(c => c.name === SESSION_COOKIE);
        return single ? single.value : '';
    } catch (e) {
        console.warn('[Veo] readLabsSession error:', e);
        return '';
    }
}

// Token ya29 sống ~1h → coi như chết sau 55 phút
const TOKEN_TTL_MS = 55 * 60 * 1000;

function keyFor(email, token, session) {
    if (email) return email.toLowerCase();
    // Định danh theo TOKEN: cùng token = cùng 1 record. Ổn định cả trong lúc trang mới load
    // (session cookie lúc đó bị ghép nhiều mảnh, đổi liên tục → KHÔNG dùng để key).
    if (token) return 'tok_' + token.slice(-16);
    if (session) return 'sess_' + session.slice(-12);
    return 'unknown_' + Math.random().toString(36).slice(2, 10);
}

// Xoá các record đã quá hạn (token chết) → kho không phình, không lẫn token cũ
function purgeStale(store) {
    const now = Date.now();
    let changed = false;
    for (const k of Object.keys(store)) {
        if (now - (store[k].lastSeen || 0) > TOKEN_TTL_MS) { delete store[k]; changed = true; }
    }
    return changed;
}

// Gộp trùng token + dọn token chết. Dùng để làm sạch đám record cũ (bản trước key theo session
// nên cùng 1 token bị tách thành nhiều dòng) — chỉ giữ dòng mới nhất cho mỗi token.
function dedupeStore(store) {
    let changed = purgeStale(store);
    const seen = {}; // token -> key đang giữ (mới nhất)
    for (const k of Object.keys(store)) {
        const t = store[k].token;
        if (!t) continue;
        const prevKey = seen[t];
        if (prevKey == null) { seen[t] = k; continue; }
        const keep = (store[k].lastSeen || 0) >= (store[prevKey].lastSeen || 0) ? k : prevKey;
        const drop = keep === k ? prevKey : k;
        delete store[drop];
        seen[t] = keep;
        changed = true;
    }
    return changed;
}

// Chạy tuần tự: nhiều request bắn cùng lúc → xử lý lần lượt, tránh race read-modify-write
let _captureChain = Promise.resolve();
function handleCapture(data) {
    _captureChain = _captureChain.then(() => _handleCaptureInner(data)).catch((e) => {
        console.warn('[Veo] handleCapture error:', e);
    });
    return _captureChain;
}

async function _handleCaptureInner(data) {
    const store = await loadStore();
    const now = Date.now();

    if (data.token) {
        const labs_session = await readLabsSession();
        const k = keyFor(data.email, data.token, labs_session);
        // Gộp về 1 record: xoá mọi dòng KHÁC key mà trùng token (duplicate cũ) hoặc
        // trùng session (token đã bị xoay vòng, giữ token mới).
        for (const kk of Object.keys(store)) {
            if (kk === k) continue;
            const r = store[kk];
            if ((r.token && r.token === data.token) ||
                (labs_session && r.labs_session === labs_session)) {
                delete store[kk];
            }
        }
        const prev = store[k] || {};
        store[k] = {
            ...prev,
            email: data.email || prev.email || '',
            token: data.token,
            labs_session: labs_session || prev.labs_session || '',
            credits: prev.credits || '',
            expires: data.expires || prev.expires || '',   // hạn thật của ya29 (từ auth/session)
            lastSeen: now,
        };
        dedupeStore(store);
        await saveStore(store);
        return;
    }

    if (data.credits != null) {
        let k = data.email ? keyFor(data.email, null) : null;
        let target = k ? store[k] : null;
        if (!target) {
            target = Object.values(store).sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0))[0];
        }
        if (target) {
            target.credits = String(data.credits);
            target.lastSeen = now;
            await saveStore(store);
        }
    }
}

// ══════════════════════════════════════════════════════════
// LẤY TOKEN ya29 TỪ ENDPOINT AUTH SESSION
// Flow mới (Angular/batchexecute) KHÔNG còn phát ya29 qua fetch để veo-inject bắt.
// NHƯNG labs.google/fx/api/auth/session vẫn trả { user:{email}, access_token: ya29..., expires }.
// → Chủ động GET endpoint này là có token, thay vì rình fetch (giờ trống).
// ══════════════════════════════════════════════════════════
let _lastTokenFetch = 0;

async function fetchLabsToken() {
    try {
        const res = await fetch('https://labs.google/fx/api/auth/session', {
            credentials: 'include',
            cache: 'no-store',
            headers: { 'accept': 'application/json' }
        });
        if (!res.ok) { console.warn('[Veo] auth/session HTTP', res.status); return null; }
        const data = await res.json().catch(() => null);
        if (!data) return null;
        const token = data.access_token;
        const email = (data.user && data.user.email) || '';
        if (token && typeof token === 'string' && token.length >= 20) {
            const expires = data.expires || '';
            const expTs = expires ? Date.parse(expires) : NaN;
            const expired = !isNaN(expTs) ? Date.now() >= expTs : (data.error === 'ACCESS_TOKEN_REFRESH_NEEDED');
            await handleCapture({ token, email, expires, url: 'labs/auth/session', src: 'session' });
            console.log('%c[Veo] 🎯 Token từ auth/session', 'color:#00C853;font-weight:bold',
                email || '(no email)', token.slice(0, 12) + '…',
                expired ? '⚠️ HẾT HẠN — cần đăng nhập lại' : ('✅ còn hạn tới ' + expires));
            return { token, email, expires, expired };
        }
        console.warn('[Veo] auth/session không có access_token (chưa đăng nhập labs.google?)');
    } catch (e) {
        console.warn('[Veo] fetchLabsToken error:', e);
    }
    return null;
}

// Gọi có tiết chế: tối đa 1 lần / 20s (tránh spam khi popup poll liên tục)
async function maybeFetchToken(force) {
    const now = Date.now();
    if (!force && now - _lastTokenFetch < 20000) return;
    _lastTokenFetch = now;
    await fetchLabsToken();
}

// Khi 1 tab labs/flow load xong (kể cả bấm "Lấy Token" mở labs.google/fx/vi) → tự kéo token ngay
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status === 'complete' && tab && tab.url &&
        (tab.url.includes('labs.google') || tab.url.includes('flow.google.com'))) {
        fetchLabsToken();
    }
});

// ================== MESSAGE HANDLER (combined) ==================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        try {
            // Captcha Client messages
            if (msg.type === 'GET_SETTINGS') {
                const settings = await getSettings();
                const alarms = await chrome.alarms.getAll();
                const autoReloadAlarm = alarms.find(a => a.name === 'autoReload');
                settings.targetTime = autoReloadAlarm ? autoReloadAlarm.scheduledTime : null;
                sendResponse(settings);
                return;
            }
            if (msg.type === 'SAVE_SETTINGS') {
                await saveSettings(msg.settings);
                await createReloadAlarm();
                sendResponse({ success: true });
                return;
            }
            if (msg.type === 'RELOAD_NOW') {
                const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'RELOAD_PAGE' });
                sendResponse({ success: true });
                return;
            }
            if (msg.type === 'CAPTCHA_STATUS_UPDATE') {
                console.log('📊 Captcha status:', msg.data);
                sendResponse({ ok: true });
                return;
            }

            // Veo Catcher messages
            if (msg.type === 'capture') {
                await handleCapture(msg.data || {});
                sendResponse({ ok: true });
                return;
            }
            if (msg.type === 'getAll') {
                maybeFetchToken(); // không await — kéo token mới từ auth/session ở nền
                const store = await loadStore();
                if (dedupeStore(store)) await saveStore(store); // gộp trùng token + dọn token chết
                sendResponse({ captures: store });
                return;
            }
            if (msg.type === 'refreshToken') {
                const r = await fetchLabsToken();
                const store = await loadStore();
                sendResponse({ ok: !!r, token: r?.token || '', email: r?.email || '', captures: store });
                return;
            }
            if (msg.type === 'deleteOne') {
                const store = await loadStore();
                delete store[msg.key];
                await saveStore(store);
                sendResponse({ ok: true });
                return;
            }
            if (msg.type === 'clearAll') {
                await saveStore({});
                sendResponse({ ok: true });
                return;
            }

            sendResponse({ ok: false, error: 'unknown type' });
        } catch (e) {
            console.warn('[Background] onMessage error:', e);
            sendResponse({ ok: false, error: String(e) });
        }
    })();
    return true;
});

// ================== INIT ==================

chrome.runtime.onInstalled.addListener(async () => {
    const settings = await getSettings();
    await saveSettings(settings);
    await createReloadAlarm();
});

createReloadAlarm();

// Định kỳ kéo token ya29 từ auth/session (mỗi 1 phút) + lấy ngay khi service worker khởi động
try { chrome.alarms.create('fetchToken', { periodInMinutes: 1 }); } catch (e) {}
fetchLabsToken();

console.log('🎯 HT Combined Extension ready');
