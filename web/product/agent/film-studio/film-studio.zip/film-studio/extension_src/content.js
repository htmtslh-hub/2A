// ===================================
// CONTENT SCRIPT - Combined bridge + injector
// ===================================
(function() {
    const log = (msg) => console.log(`[HT-Content] ${msg}`);
    const TOKEN_TTL_MS = 55 * 60 * 1000; // chỉ auto-copy token còn sống (ya29 ~1h)

    // === Inject scripts vào page context (Captcha Client) ===
    function injectScript(file) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = chrome.runtime.getURL(file);
            script.type = 'text/javascript';
            script.onload = () => { script.remove(); resolve(); };
            script.onerror = () => reject(new Error(`Inject failed: ${file}`));
            (document.head || document.documentElement).appendChild(script);
        });
    }

    async function initDependencies() {
        try {
            await injectScript('socket.io.min.js');
            await injectScript('injected.js');
            log('✅ All scripts injected');
        } catch (e) {
            log('❌ Injection error: ' + e.message);
        }
    }

    // === Message bridge (cả Captcha Client + Veo Catcher) ===
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        const d = event.data;
        if (!d) return;

        // Veo Catcher bridge: forward token capture to background
        if (d.__veo_catcher === true) {
            const { __veo_catcher, ...data } = d;
            try {
                chrome.runtime.sendMessage({ type: 'capture', data }, () => {
                    // Khi bắt được TOKEN mới → auto-copy JSON vào clipboard
                    if (data.token) {
                        setTimeout(() => autoCopyTokens(), 500);
                    }
                });
            } catch (e) {}
            return;
        }

        // Captcha Client bridge
        if (d.type === 'CAPTCHA_LOG') log('From Injected: ' + d.message);

        if (d.type === 'CAPTCHA_STATUS') {
            try { chrome.runtime.sendMessage({ type: 'CAPTCHA_STATUS_UPDATE', data: d.data }); } catch (e) {}
        }

        if (d.type === 'GET_SETTINGS_REQUEST') {
            try {
                chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (response) => {
                    if (chrome.runtime.lastError || !response) return;
                    try { window.postMessage({ type: 'GET_SETTINGS_RESPONSE', settings: response }, '*'); } catch (e) {}
                });
            } catch (e) {}
        }
    });

    // === Auto-copy tokens to clipboard + hiện toast trên trang ===
    function autoCopyTokens() {
        chrome.runtime.sendMessage({ type: 'getAll' }, (resp) => {
            const caps = resp?.captures || {};
            const now = Date.now();
            const accounts = Object.values(caps)
                .filter(c => {
                    if (!c.token) return false;
                    if (c.expires) { const t = Date.parse(c.expires); if (!isNaN(t)) return now < t; } // hạn thật
                    return (now - (c.lastSeen || 0)) < TOKEN_TTL_MS; // fallback
                })
                .sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0))
                .map(c => ({
                    email: c.email || ('captured_' + c.token.slice(-5)),
                    profile_path: '',
                    token: c.token,
                    credits: c.credits || 'Unknown',
                    project_id: '',
                    labs_session: c.labs_session || ''
                }));
            if (!accounts.length) return;

            const json = JSON.stringify({ accounts }, null, 2);
            navigator.clipboard.writeText(json).then(() => {
                showPageToast(`✅ Token đã copy! (${accounts.length} acc)`);
                log('Auto-copied ' + accounts.length + ' accounts to clipboard');
            }).catch(() => {
                showPageToast('⚠️ Token bắt được — mở popup để copy');
            });
        });
    }

    // Toast hiện trên trang web (không cần mở popup)
    function showPageToast(msg) {
        let toast = document.getElementById('ht-page-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'ht-page-toast';
            toast.style.cssText = 'position:fixed;top:20px;right:20px;background:#e8720c;color:#fff;padding:10px 18px;border-radius:8px;font:600 13px/1.4 system-ui,sans-serif;z-index:999999;box-shadow:0 4px 20px rgba(232,114,12,0.4);opacity:0;transition:opacity .3s;pointer-events:none';
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.opacity = '1';
        clearTimeout(showPageToast._t);
        showPageToast._t = setTimeout(() => { toast.style.opacity = '0'; }, 3000);
    }

    // === Background → content → page forwarding ===
    chrome.runtime.onMessage.addListener((request) => {
        if (request.type === 'RELOAD_PAGE') {
            localStorage.removeItem('_grecaptcha');
            window.location.reload();
        }
        if (request.type === 'CAPTURED_HEADERS') {
            window.postMessage({ type: 'CAPTURED_HEADERS', headers: request.headers }, '*');
        }
    });

    // === Init ===
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDependencies);
    } else {
        initDependencies();
    }
})();
