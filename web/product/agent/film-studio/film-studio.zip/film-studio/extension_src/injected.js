// ===================================
// INJECTED SCRIPT - Chạy trong page context
// ===================================

(async function () {
    class Logger {
        constructor(context) { this.context = context; }
        log(message, data = null) { if (data) console.log(`[${this.context}] ${message}`, data); else console.log(`[${this.context}] ${message}`); }
        debug(message, data = null) { if (data) console.debug(`[${this.context}] ${message}`, data); else console.debug(`[${this.context}] ${message}`); }
        warn(message, data = null) { if (data) console.warn(`[${this.context}] ⚠️ ${message}`, data); else console.warn(`[${this.context}] ⚠️ ${message}`); }
        error(message, data = null) { if (data) console.error(`[${this.context}] ❌ ${message}`, data); else console.error(`[${this.context}] ❌ ${message}`); }
        success(message, data = null) { if (data) console.log(`[${this.context}] ✅ ${message}`, data); else console.log(`[${this.context}] ✅ ${message}`); }
    }

    const logger = new Logger('CaptchaClient');
    logger.log('🚀 Starting Captcha Client...');

    const CONFIG = {
        siteKey: '6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV',
        socketServer: 'http://localhost:3000', 
    };

    let cachedSettings = null;
    let recaptchaReadyResolve;
    const recaptchaReadyPromise = new Promise((resolve) => { recaptchaReadyResolve = resolve; });

    function sendLog(message) { window.postMessage({ type: 'CAPTCHA_LOG', message: message }, '*'); }
    function sendStatus(status, data = {}) { window.postMessage({ type: 'CAPTCHA_STATUS', data: { status, ...data } }, '*'); }

    async function getSettings() {
        if (cachedSettings) return cachedSettings;
        return await new Promise((resolve) => {
            window.postMessage({ type: 'GET_SETTINGS_REQUEST' }, '*');
            let responseReceived = false;
            const listener = (event) => {
                if (event.source !== window) return;
                if (event.data.type === 'GET_SETTINGS_RESPONSE') {
                    window.removeEventListener('message', listener);
                    responseReceived = true;
                    cachedSettings = event.data.settings;
                    resolve(cachedSettings);
                }
            };
            window.addEventListener('message', listener);
            setTimeout(() => {
                window.removeEventListener('message', listener);
                if (!responseReceived) resolve({ clearGrecaptcha: false });
            }, 2000);
        });
    }

    function createCountdownStyles() {
        const style = document.createElement('style');
        style.textContent = `
            #countdown-badge { position: fixed; bottom: 28px; right: 28px; min-width: 156px; height: 88px; border-radius: 12px; background: linear-gradient(135deg, #5b7cfa 0%, #748ffc 100%); display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif; color: white; box-shadow: 0 10px 32px rgba(91, 124, 250, 0.35), inset 0 1px 2px rgba(255, 255, 255, 0.3); z-index: 999999; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); opacity: 0.97; cursor: default; padding: 14px 16px; gap: 6px; backdrop-filter: blur(8px); border: 1px solid rgba(255, 255, 255, 0.2); }
            #countdown-badge:hover { transform: translateY(-3px); opacity: 1; box-shadow: 0 14px 40px rgba(91, 124, 250, 0.45), inset 0 1px 2px rgba(255, 255, 255, 0.3); }
            #countdown-badge.hidden { display: none; }
            #countdown-badge-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.8px; opacity: 0.85; white-space: nowrap; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); }
            #countdown-badge-time { font-size: 36px; font-weight: 700; text-align: center; line-height: 1; font-variant-numeric: tabular-nums; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.15); letter-spacing: -1px; }
            #countdown-badge-progress { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border-radius: 12px; background: linear-gradient(135deg, rgba(91, 124, 250, 0.15) 0%, rgba(116, 143, 252, 0.15) 100%); opacity: 0.5; pointer-events: none; }
        `;
        document.head.appendChild(style);
    }

    function createCountdownBadge() {
        if (document.getElementById('countdown-badge')) return;
        const badge = document.createElement('div');
        badge.id = 'countdown-badge';
        badge.className = 'hidden';
        const progress = document.createElement('div'); progress.id = 'countdown-badge-progress';
        const label = document.createElement('div'); label.id = 'countdown-badge-label'; label.textContent = 'Before Reload';
        const timeElement = document.createElement('div'); timeElement.id = 'countdown-badge-time'; timeElement.textContent = '--';
        badge.appendChild(progress); badge.appendChild(label); badge.appendChild(timeElement);
        document.body.appendChild(badge);
    }

    function updateCountdownBadge(remainingSeconds, totalSeconds) {
        const badge = document.getElementById('countdown-badge');
        if (!badge) return;
        if (remainingSeconds <= 0) { badge.classList.add('hidden'); return; }
        badge.classList.remove('hidden');
        const timeElement = document.querySelector('#countdown-badge-time');
        const seconds = Math.max(0, remainingSeconds);
        timeElement.textContent = String(seconds).padStart(2, '0') + 's';
        let bgColor;
        const percentage = remainingSeconds / totalSeconds;
        if (percentage > 0.6) bgColor = 'linear-gradient(135deg, #5b7cfa 0%, #748ffc 100%)';
        else if (percentage > 0.3) bgColor = 'linear-gradient(135deg, #ffa500 0%, #ff8c00 100%)';
        else bgColor = 'linear-gradient(135deg, #ff4757 0%, #ff6b81 100%)';
        badge.style.background = bgColor;
    }

    // 🔥 NÂNG CẤP: Tự động bơm reCAPTCHA và chờ vô hạn, không báo lỗi sau 30s nữa
    async function waitForRecaptcha() {
        // 1. Kiểm tra và ép trình duyệt tải reCAPTCHA nếu chưa có
        if (!window.grecaptcha || !window.grecaptcha.enterprise) {
            logger.log('Tự động nạp script reCAPTCHA vào trang...');
            sendLog('Auto-injecting reCAPTCHA script...');
            
            const script = document.createElement('script');
            let scriptUrl = 'https://www.google.com/recaptcha/enterprise.js?render=' + CONFIG.siteKey;
            
            // Lách luật bảo mật CSP của Google
            if (window.trustedTypes && window.trustedTypes.createPolicy) {
                try {
                    const policy = window.trustedTypes.createPolicy('force-recaptcha', {
                        createScriptURL: (url) => url
                    });
                    scriptUrl = policy.createScriptURL(scriptUrl);
                } catch (e) {
                    // Bỏ qua nếu policy đã tồn tại
                }
            }
            
            script.src = scriptUrl;
            script.async = true;
            document.head.appendChild(script);
        }

        // 2. Chờ cho đến khi reCAPTCHA sẵn sàng (auto-inject hoạt động trên mọi trang)
        logger.log('Đang chờ reCAPTCHA sẵn sàng...');
        while (true) {
            if (window.grecaptcha?.enterprise?.execute) {
                logger.success('reCAPTCHA ready!');
                sendLog('reCAPTCHA ready!');
                return true;
            }
            await new Promise(resolve => setTimeout(resolve, 500));
        }
    }

    async function solveCaptcha(action = 'VIDEO_GENERATION') {
        try {
            const token = await window.grecaptcha.enterprise.execute(CONFIG.siteKey, { action: action });
            try {
                const settings = await getSettings();
                if (settings.clearGrecaptcha === true) localStorage.removeItem('_grecaptcha');
            } catch (error) {}
            return token;
        } catch (error) {
            throw error;
        }
    }

    try {
        createCountdownStyles();
        createCountdownBadge();
        const settings = await getSettings();
        if (settings && settings.enabled && settings.autoReload && settings.targetTime) {
            const totalSeconds = (settings.reloadInterval || 0) * 60;
            setInterval(() => {
                const remainingMs = Math.max(0, settings.targetTime - Date.now());
                const remainingSeconds = Math.ceil(remainingMs / 1000);
                updateCountdownBadge(remainingSeconds, totalSeconds);
            }, 1000); 
        }

        // Lấy Socket.IO cục bộ
        logger.log('Loading Socket.IO local module...');
        if (!window.io) {
            throw new Error('Thư viện Socket.IO chưa được cài đặt từ nội bộ extension!');
        }
        const io = window.io;
        logger.success('Socket.IO local loaded successfully');

        const socket = io(CONFIG.socketServer, {
            transports: ['websocket', 'polling'],
            autoConnect: true
        });

        socket.on('connect', () => {
            logger.success('Connected to server! Socket ID', socket.id);
            // Không emit client:ready ở đây — chờ reCAPTCHA load xong đã
        });

        socket.on('disconnect', () => { logger.log('Disconnected from server'); });
        socket.on('connect_error', (error) => { logger.error('Connection error', error); });

        window.addEventListener('message', (event) => {
            if (event.source !== window) return;
            if (event.data.type === 'CAPTURED_HEADERS') {
                if (socket && socket.connected) {
                    socket.emit('client:captured-headers', { headers: event.data.headers, timestamp: new Date().toISOString() });
                }
            }
        });

        async function refreshChromeHeaders() {
            try {
                await fetch('https://aisandbox-pa.googleapis.com/v1/video:batchCheckAsyncVideoGenerationStatus', {
                    method: 'POST',
                    headers: { 'content-type': 'text/plain;charset=UTF-8' },
                    body: JSON.stringify({ operations: [{ operation: { name: 'dummy' }, sceneId: 'dummy' }] }),
                    credentials: 'include'
                });
            } catch (e) {}
        }
        setTimeout(refreshChromeHeaders, 2000);
        setInterval(refreshChromeHeaders, 4 * 60 * 1000);

        socket.on('server:request-captcha', async (data) => {
            try {
                // Chờ reCAPTCHA sẵn sàng trước khi solve (phòng race condition)
                await recaptchaReadyPromise;
                const action = data?.action || 'VIDEO_GENERATION';
                const token = await solveCaptcha(action);
                socket.emit('client:captcha-solved', { requestId: data?.requestId, token, timestamp: new Date().toISOString() });
            } catch (error) {
                socket.emit('client:captcha-error', { requestId: data?.requestId, error: error.message, timestamp: new Date().toISOString() });
            }
        });

        socket.on('server:reload-page', (data) => {
            const delay = data?.delay || 0;
            localStorage.removeItem('_grecaptcha');
            if (delay > 0) {
                setTimeout(() => { window.location.reload(); }, delay);
            } else {
                window.location.reload();
            }
        });

        // 🔥 NEW: Server ra lệnh mở trang mới (project, tool page...)
        socket.on('server:navigate', (data) => {
            if (data?.url) {
                logger.log('Navigating to:', data.url);
                window.location.href = data.url;
            }
        });

        await waitForRecaptcha();
        recaptchaReadyResolve();
        const testToken = await solveCaptcha();
        logger.success('Test successful! Token length', testToken.length);

        socket.emit('client:ready', { timestamp: new Date().toISOString() });

        window.captchaClient = {
            socket,
            solveCaptcha,
            config: CONFIG,
            solveAndSend: async () => {
                const token = await solveCaptcha();
                socket.emit('client:captcha-manual', { token, timestamp: new Date().toISOString() });
                return token;
            },
            reloadPage: (delay = 0) => {
                localStorage.removeItem('_grecaptcha');
                if (delay > 0) setTimeout(() => window.location.reload(), delay);
                else window.location.reload();
            },
            refreshHeaders: refreshChromeHeaders
        };
        logger.success('Captcha Client Ready!');

    } catch (error) {
        logger.error('Initialization failed', error);
        sendStatus('init_failed', { error: error.message });
    }
})();