// ===================================
// POPUP.JS - Combined Settings + Token Viewer
// ===================================

// ===== Helpers =====
const TOKEN_TTL_MS = 55 * 60 * 1000; // fallback khi token không có 'expires' (bắt từ veo-inject)
function $(id) { return document.getElementById(id); }

// Token HẾT HẠN thật: ưu tiên field 'expires' (từ auth/session); không có thì suy theo lastSeen
function isExpired(c) {
    if (c && c.expires) { const t = Date.parse(c.expires); if (!isNaN(t)) return Date.now() >= t; }
    return (Date.now() - ((c && c.lastSeen) || 0)) > TOKEN_TTL_MS;
}
function expiryLabel(c) {
    if (c && c.expires) {
        const t = Date.parse(c.expires);
        if (!isNaN(t)) {
            const ms = t - Date.now();
            if (ms <= 0) return { text: '⚠️ HẾT HẠN — đăng nhập lại', warn: true };
            const m = Math.floor(ms / 60000);
            if (m < 60) return { text: `✅ còn ${m} phút`, warn: false };
            const h = Math.floor(m / 60);
            return { text: `✅ còn ${h}h${m % 60}m`, warn: false };
        }
    }
    return isExpired(c) ? { text: '⚠️ có thể hết hạn', warn: true } : { text: '✅ mới bắt', warn: false };
}
function showToast(msg, color) {
    const t = $('toast'); t.textContent = msg; if (color) t.style.background = color;
    t.classList.add('show'); clearTimeout(showToast._t);
    showToast._t = setTimeout(() => { t.classList.remove('show'); t.style.background = ''; }, 1800);
}
function esc(s) { return s == null ? '' : String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function fmtAge(ms) { if (!ms) return 'vừa xong'; const s=Math.floor(ms/1000); if(s<60) return s+'s trước'; const m=Math.floor(s/60); if(m<60) return m+' phút trước'; const h=Math.floor(m/60); if(h<24) return h+' giờ trước'; return Math.floor(h/24)+' ngày trước'; }

// ===== Tab switching =====
function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');
    $('panel-' + tabName).classList.add('active');
    $('token-actions').style.display = tabName === 'tokens' ? 'flex' : 'none';
    if (tabName === 'tokens') renderTokens();
    // Lưu tab đang mở — mở lại popup sẽ hiện đúng tab này
    chrome.storage.local.set({ lastTab: tabName });
}

document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
});

// ================== SETTINGS TAB ==================

async function loadSettings() {
    const r = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
    $('enabled').checked = r.enabled;
    $('autoReload').checked = r.autoReload;
    $('reloadInterval').value = r.reloadInterval;
    $('clearGrecaptcha').checked = r.clearGrecaptcha ?? false;
    updateSettingsUI();
}

function updateSettingsUI() {
    const on = $('enabled').checked, ar = $('autoReload').checked;
    $('autoReload').disabled = !on;
    $('reloadInterval').disabled = !on || !ar;
    $('autoReloadRow').style.opacity = on ? 1 : 0.5;
    $('intervalRow').style.opacity = on && ar ? 1 : 0.5;
}

$('enabled').addEventListener('change', updateSettingsUI);
$('autoReload').addEventListener('change', updateSettingsUI);

$('saveSettings').addEventListener('click', async () => {
    const btn = $('saveSettings'); btn.disabled = true; btn.textContent = '💾 Saving...';
    await chrome.runtime.sendMessage({
        type: 'SAVE_SETTINGS',
        settings: {
            enabled: $('enabled').checked, autoReload: $('autoReload').checked,
            reloadInterval: parseInt($('reloadInterval').value), clearGrecaptcha: $('clearGrecaptcha').checked
        }
    });
    btn.textContent = '✅ Saved!';
    setTimeout(async () => {
        const tabs = await chrome.tabs.query({ active: true });
        for (const t of tabs) try { await chrome.tabs.reload(t.id); } catch(e) {}
        btn.textContent = '💾 Save & Reload'; btn.disabled = false;
    }, 1000);
});

$('reloadNow').addEventListener('click', async () => {
    const btn = $('reloadNow'); btn.disabled = true; btn.textContent = '⏳ Reloading...';
    await chrome.runtime.sendMessage({ type: 'RELOAD_NOW' });
    btn.textContent = '✅ Reloaded!';
    setTimeout(() => { btn.textContent = '🔄 Reload Page Now'; btn.disabled = false; }, 1500);
});

// ================== TOKEN TAB ==================

async function getAll() {
    return new Promise(resolve => { chrome.runtime.sendMessage({ type: 'getAll' }, r => resolve(r?.captures || {})); });
}

function buildAccountsJson(caps) {
    return Object.values(caps)
        .filter(c => c.token && !isExpired(c)) // chỉ export token CÒN HẠN (theo expires thật)
        .sort((a, b) => (b.lastSeen||0) - (a.lastSeen||0))
        .map(c => ({ email: c.email || ('captured_' + c.token.slice(-5)), profile_path: '', token: c.token, credits: c.credits || 'Unknown', project_id: '', labs_session: c.labs_session || '' }));
}

async function renderTokens() {
    const caps = await getAll();
    const keys = Object.keys(caps);
    const content = $('token-content');
    const stats = $('stats');
    const now = Date.now();

    if (!keys.length) {
        stats.innerHTML = '';
        content.innerHTML = '<div class="empty"><b>🎯</b><br>Chưa có token.<br>Mở <b>flow.google.com</b> hoặc <b>labs.google</b> để bắt.</div>';
        return;
    }

    const all = Object.values(caps);
    const withToken = all.filter(c => c.token).length;
    const fresh = all.filter(c => c.token && !isExpired(c)).length;
    const totalCredits = all.map(c => parseInt(c.credits,10)).filter(n => !isNaN(n)).reduce((a,b) => a+b, 0);

    stats.innerHTML = `
        <div class="stat"><span class="num">${withToken}</span><span class="label">Token</span></div>
        <div class="stat ${fresh<withToken?'warn':''}"><span class="num">${fresh}</span><span class="label">Fresh</span></div>
        <div class="stat"><span class="num">${totalCredits.toLocaleString('vi-VN')}</span><span class="label">Credits</span></div>`;

    const sorted = keys.sort((a,b) => (caps[b].lastSeen||0) - (caps[a].lastSeen||0));
    content.innerHTML = sorted.map(k => {
        const c = caps[k], ageMs = now - (c.lastSeen||0), expired = isExpired(c), exp = expiryLabel(c);
        return `<div class="record ${expired?'stale':'fresh'}">
            <button class="del" data-del="${esc(k)}">×</button>
            <div class="top"><div class="email">${c.email ? esc(c.email) : '(chưa xác định)'}</div><div class="age ${expired?'warn':''}">${fmtAge(ageMs)}${expired?' ⚠️':''}</div></div>
            <div class="row"><span class="rl">Token</span>${c.token ? `<span class="rv">...${esc(c.token.slice(-18))}</span> <button class="mini" data-copy="${esc(c.token)}">copy</button>` : '<span class="rv miss">(chưa có)</span>'}</div>
            <div class="row"><span class="rl">Hạn</span><span class="rv ${exp.warn?'miss':'gold'}">${exp.text}</span></div>
            <div class="row"><span class="rl">Credits</span>${c.credits ? `<span class="rv gold">${esc(c.credits)}</span>` : '<span class="rv miss">(?)</span>'}</div>
            <div class="row"><span class="rl">Session</span>${c.labs_session ? '<span class="rv gold">✅ có</span>' : '<span class="rv miss">❌ thiếu</span>'}</div>
            ${c.token && !expired ? `<div class="row-actions"><button class="mini" data-json="${esc(k)}">📋 Copy JSON</button></div>` : (c.token ? `<div class="row-actions"><span class="rv miss">Hết hạn — đăng nhập lại labs.google</span></div>` : '')}
        </div>`;
    }).join('');

    // Bind events
    content.querySelectorAll('.mini[data-copy]').forEach(b => b.addEventListener('click', async (e) => {
        e.stopPropagation(); await navigator.clipboard.writeText(b.dataset.copy);
        b.textContent = '✓'; setTimeout(() => b.textContent = 'copy', 800);
    }));
    content.querySelectorAll('.mini[data-json]').forEach(b => b.addEventListener('click', async (e) => {
        e.stopPropagation(); const all = await getAll(), c = all[b.dataset.json]; if (!c) return;
        const obj = { accounts: [{ email: c.email || 'captured_' + c.token.slice(-5), profile_path: '', token: c.token, credits: c.credits || 'Unknown', project_id: '', labs_session: c.labs_session || '' }] };
        await navigator.clipboard.writeText(JSON.stringify(obj, null, 2));
        b.textContent = '✓'; setTimeout(() => b.textContent = '📋 Copy JSON', 1000);
    }));
    content.querySelectorAll('.del').forEach(b => b.addEventListener('click', async (e) => {
        e.stopPropagation();
        await new Promise(r => chrome.runtime.sendMessage({ type: 'deleteOne', key: b.dataset.del }, r));
        renderTokens();
    }));
}

// Token action buttons
$('open-labs').addEventListener('click', async () => {
    chrome.storage.local.set({ lastTab: 'tokens' });
    // Mở labs.google/fx/vi NGAY TRONG TAB HIỆN TẠI (tạo lại phiên labs → extension tự bắt token)
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) chrome.tabs.update(tabs[0].id, { url: 'https://labs.google/fx/vi' });
    window.close();
});

$('copy-all').addEventListener('click', async () => {
    const accs = buildAccountsJson(await getAll());
    if (!accs.length) { showToast('⚠️ Chưa có token!', '#f38ba8'); return; }
    await navigator.clipboard.writeText(JSON.stringify({ accounts: accs }, null, 2));
    showToast(`✅ Đã copy ${accs.length} acc`);
});

$('export').addEventListener('click', async () => {
    const accs = buildAccountsJson(await getAll());
    if (!accs.length) { showToast('⚠️ Chưa có token!', '#f38ba8'); return; }
    const blob = new Blob([JSON.stringify({ accounts: accs }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url, filename: 'accounts.json', saveAs: true }, () => {
        setTimeout(() => URL.revokeObjectURL(url), 3000);
        showToast(`📥 Đã export ${accs.length} acc`);
    });
});

$('refresh').addEventListener('click', () => { renderTokens(); showToast('🔄 Refreshed'); });

$('clear').addEventListener('click', async () => {
    const caps = await getAll(), n = Object.keys(caps).length;
    if (!n) { showToast('Trống'); return; }
    if (!confirm(`Xóa ${n} record?`)) return;
    await new Promise(r => chrome.runtime.sendMessage({ type: 'clearAll' }, r));
    renderTokens(); showToast('🗑 Đã xóa');
});

// ===== Init =====
loadSettings();

// Khôi phục tab cuối — mở popup luôn hiện đúng tab cũ
chrome.storage.local.get('lastTab', (r) => {
    if (r.lastTab) switchTab(r.lastTab);
});

setInterval(() => { if ($('panel-tokens').classList.contains('active')) renderTokens(); }, 2000);
