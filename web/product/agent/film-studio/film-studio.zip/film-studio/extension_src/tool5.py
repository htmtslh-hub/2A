import sys
import os
import time
import json
import requests
import uuid
import threading
import subprocess
import queue
import customtkinter as ctk
import ui_tool5 as _ui5
from ui import T as _T, F as _F
from tkinter import filedialog, messagebox
from concurrent.futures import ThreadPoolExecutor
import itertools
import random
import math
import shutil
from pathlib import Path

# === curl_cffi để fake TLS fingerprint giống Chrome thật ===
# Google reCAPTCHA Enterprise check TLS handshake fingerprint, requests dùng OpenSSL → bị flag
# curl_cffi giả lập y hệt Chrome TLS → qua mặt được
# Cài: pip install curl_cffi
try:
    from curl_cffi import requests as cffi_requests
    USE_CURL_CFFI = True
    print("✅ curl_cffi loaded — TLS fingerprint sẽ giả lập Chrome thật")
except ImportError:
    cffi_requests = requests  # Fallback về requests thường nếu chưa cài
    USE_CURL_CFFI = False
    print("⚠️ curl_cffi chưa được cài → fallback requests (có thể bị 403/429)")
    print("   Cài bằng: pip install curl_cffi")

# Chrome version impersonate — đồng bộ với version trong headers (148)
# curl_cffi hiện chưa có chrome148, dùng chrome131 (mới nhất, đủ qua mặt)
CHROME_IMPERSONATE = "chrome131"

# <50KB coi như file download dở dang → thử lại, không ghi ra .mp4 rác
MIN_VIDEO_SIZE = 50 * 1024

# --- CẤU HÌNH GIAO DIỆN ---
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# Khóa an toàn
file_lock = threading.Lock()

# === HÀM TỰ ĐỘNG BẬT SERVER NESTJS ===
nestjs_process = None

def get_app_dir():
    """
    Lấy folder chứa tool5.py hoặc tool5.exe (đúng cho cả 2 chế độ).
    PyInstaller: __file__ trỏ vào TEMP folder _MEIxxxx, sai. Dùng sys.executable.
    """
    if getattr(sys, 'frozen', False):
        # Đang chạy dạng .exe đã build bằng PyInstaller
        return os.path.dirname(os.path.abspath(sys.executable))
    else:
        # Đang chạy dạng python tool5.py
        return os.path.dirname(os.path.abspath(__file__))

def start_nestjs_server():
    global nestjs_process

    base_dir = get_app_dir()
    nestjs_dir = os.path.join(base_dir, "captcha-solver-main", "captcha-solver-main")

    print(f"📁 Tool dir: {base_dir}")
    print(f"📁 NestJS dir: {nestjs_dir}")

    if not os.path.exists(nestjs_dir):
        print(f"⚠️ Không tìm thấy thư mục NestJS tại: {nestjs_dir}")
        print("👉 Hãy chắc chắn bạn đã copy thư mục 'captcha-solver-main' vào chung chỗ với tool5.py / tool5.exe")
        return

    print("🚀 Đang tự động khởi động Server NestJS...")
    try:
        kwargs = {}
        if os.name == 'nt':
            kwargs['creationflags'] = subprocess.CREATE_NEW_CONSOLE

        nestjs_process = subprocess.Popen(
            "npm run start:dev",
            cwd=nestjs_dir,
            shell=True,
            **kwargs
        )
    except Exception as e:
        print(f"❌ Lỗi tự bật Server NestJS: {e}")

# === CLASS: TOKEN RATE LIMITER ===
# FIX #1: Sửa logic tính thời gian - last_used ghi SAU khi sleep xong, không cộng wait_time vào tương lai
# ══════════════════════════════════════════════════════════════════════════════
# BỎ MÃ NHÂN VẬT Ở ĐẦU PROMPT
#   "CHAR_01,CHAR_03 | Eye-level push in shot ..." → "Eye-level push in shot ..."
#   Mã nhân vật chỉ dùng cho tab tạo ảnh đồng nhất; tab tạo video không cần.
# ══════════════════════════════════════════════════════════════════════════════
import re as _re_tag

_TAG_ONE = r"(?:[A-Za-z]{1,8}_?\d{1,3})"
_CHAR_TAG_RE = _re_tag.compile(
    r"^\s*" + _TAG_ONE + r"(?:\s*[,+/&]\s*" + _TAG_ONE + r")*\s*\|\s*")


def strip_char_tags(text):
    """Cắt phần mã nhân vật đứng trước dấu | , chỉ giữ prompt thật."""
    if not text:
        return text
    s = str(text).strip()
    for _ in range(3):                 # phòng khi lồng 2 lớp tag
        m = _CHAR_TAG_RE.match(s)
        if not m:
            break
        rest = s[m.end():].lstrip()
        if not rest:                   # cắt xong rỗng → giữ nguyên
            break
        s = rest
    return s


class TokenRateLimiter:
    def __init__(self, tokens, delay_seconds=15):
        self.tokens = tokens
        self.delay = delay_seconds
        self.lock = threading.Lock()
        self.last_used = {t: 0 for t in tokens}
        self.token_cycle = itertools.cycle(tokens)

    def get_token(self):
        with self.lock:
            token = next(self.token_cycle)
            now = time.time()
            elapsed = now - self.last_used[token]
            wait_time = max(0, self.delay - elapsed)
            # Đánh dấu thời điểm "sẽ dùng xong" để các luồng khác tính đúng
            self.last_used[token] = now + wait_time
        
        if wait_time > 0:
            time.sleep(wait_time)
        
        # FIX: Ghi lại thời gian thực tế sau khi sleep xong
        with self.lock:
            self.last_used[token] = time.time()
        
        return token

# ==============================================================================
# PHẦN 1: CORE BACKEND (ĐÃ ĐƯỢC NÂNG CẤP THEO MAIN.JS)
# ==============================================================================

class VeoBackend:
    def __init__(self, auth_token: str):
        self.auth_token = (auth_token or "").strip()
        
        # === HEADERS DEFAULT (lowercase để merge với fresh headers từ Chrome) ===
        # X-Browser-Validation / X-Client-Data sẽ được extension capture từ Chrome thật
        # và inject vào self.headers thông qua get_recaptcha() → _apply_fresh_headers()
        # → Không còn bị PUBLIC_ERROR_UNUSUAL_ACTIVITY
        self.headers = {
            "authorization": f"Bearer {self.auth_token}",
            "accept": "*/*",
            "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "text/plain;charset=UTF-8",
            "origin": "https://labs.google",
            "priority": "u=1, i",
            "referer": "https://labs.google/",
            "sec-ch-ua": '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
        }
        
        self.cookies = self._load_app_cookies()

    def _load_app_cookies(self):
        cookies_dir = Path("cookies")
        if not cookies_dir.exists():
            return {}
        
        json_files = list(cookies_dir.glob("*.json"))
        if not json_files:
            return {}
            
        try:
            selected_file = random.choice(json_files)
            with open(selected_file, 'r', encoding='utf-8') as f:
                cookie_data = json.load(f)
            cookie_dict = {}
            for c in cookie_data:
                if isinstance(c, dict) and 'name' in c and 'value' in c:
                    cookie_dict[c['name']] = c['value']
            return cookie_dict
        except Exception:
            return {}

    def _apply_fresh_headers(self, fresh: dict):
        """Merge fresh headers từ Chrome (qua extension webRequest hook).
        Lowercase wins vì HTTP case-insensitive."""
        if not fresh:
            return
        normalized = {}
        for k, v in self.headers.items():
            normalized[k.lower()] = v
        for k, v in fresh.items():
            normalized[k.lower()] = v
        self.headers = normalized

    def get_recaptcha(self):
        try:
            captcha_api_url = "http://localhost:3000/captcha"
            response = requests.get(
                captcha_api_url, 
                params={"action": "VIDEO_GENERATION"},
                timeout=65   # ⬆ 35 → 65 (match gateway 60s)
            )
            
            if response.status_code == 200:
                data = response.json()
                token = data.get("captcha")
                fresh_headers = data.get("headers", {}) or {}
                age_ms = data.get("headersAgeMs", -1)
                
                # 🔥 Merge fresh headers từ Chrome (chứa x-browser-validation, x-client-data...)
                if fresh_headers:
                    self._apply_fresh_headers(fresh_headers)
                    print(f"🎯 Áp dụng {len(fresh_headers)} fresh headers (age={age_ms}ms)")
                else:
                    print(f"⚠️ Server chưa có fresh headers — mở labs.google trên browser captcha, login Google, đợi 10s")
                
                return token
            else:
                print(f"❌ Lỗi từ server Captcha: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.Timeout:
            print("❌ Lỗi: Timeout (Trình duyệt Client chưa giải xong Captcha trong 60s).")
            return None
        except Exception as e:
            print(f"❌ Lỗi kết nối đến Server Captcha NestJS: {e}")
            return None

    def send_request(self, recaptcha, prompt, model, ratio, account_type="Ultra", project_id=None):
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoText"

        # Cấu hình theo loại tài khoản (dựa trên F12)
        ACCOUNT_CONFIG = {
            "Ultra": {
                "projectId": "7b0e3167-1e71-4be6-a4b1-b234980a3a34",
                "userPaygateTier": "PAYGATE_TIER_TWO",
            },
            "Pro": {
                "projectId": "4ec7ee56-08c8-4bfe-ba92-f5bb96888bd8",
                "userPaygateTier": "PAYGATE_TIER_NOT_PAID",
            },
        }
        cfg = ACCOUNT_CONFIG.get(account_type, ACCOUNT_CONFIG["Ultra"])
        # Ưu tiên project_id từ accounts.json, fallback hardcode
        final_pid = project_id.strip() if project_id and project_id.strip() else cfg["projectId"]

        # === OMNI FLASH paygate override (theo capture F12 thực tế từ labs.google) ===
        # Pro account hiện đang map sang PAYGATE_TIER_NOT_PAID — Omni Flash không nhận tier này.
        # Capture Chrome cho thấy:
        #   - Ultra + Omni Flash → PAYGATE_TIER_TWO  (giữ nguyên cfg, KHÔNG đụng)
        #   - Pro   + Omni Flash → PAYGATE_TIER_ONE  (ép lên, vì NOT_PAID không xài Omni được)
        paygate_tier = cfg["userPaygateTier"]
        if model.startswith("abra_t2v_") and account_type == "Pro":
            paygate_tier = "PAYGATE_TIER_ONE"
            print(f"[SEND] 🔥 Omni Flash + Pro → ép userPaygateTier=PAYGATE_TIER_ONE")

        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": paygate_tier
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS"
            },
            "requests": [
                {
                    "aspectRatio": ratio,
                    "seed": random.randint(10000, 999999),
                    "textInput": {
                        "structuredPrompt": {
                            "parts": [{"text": prompt}]
                        }
                    },
                    "videoModelKey": model,
                    "metadata": {}
                }
            ],
            "useV2ModelConfig": True
        }
        
        try:
            # Timeout 180s + curl_cffi giả TLS giống Chrome thật
            # Google reCAPTCHA Enterprise check TLS handshake — Python requests bị nhận diện
            r = cffi_requests.post(
                url, json=payload, headers=self.headers, cookies=self.cookies,
                timeout=180, impersonate=CHROME_IMPERSONATE
            )
            # === DEBUG: log mọi response để tìm lỗi ===
            print(f"\n{'='*70}")
            print(f"[SEND] status={r.status_code} | model={model} | pid={final_pid[-8:] if final_pid else 'NONE'} | acc={account_type}")
            
            if r.status_code == 200:
                d = r.json()
                
                # === SCHEMA CŨ: operations ===
                if "operations" in d:
                    op_name = d["operations"][0]["operation"]["name"]
                    scene_id = d["operations"][0].get("sceneId", "")
                    print(f"[SEND] ✅ OK (old schema) - op: {op_name[:50]}...")
                    print(f"{'='*70}\n")
                    return "OK", op_name, scene_id
                
                # === SCHEMA MỚI: workflows + media (Google đổi schema 2025-2026) ===
                if "workflows" in d and d.get("workflows"):
                    workflow_name = d["workflows"][0].get("name", "")
                    media_name = ""
                    media_pid = final_pid  # fallback
                    if d.get("media") and len(d["media"]) > 0:
                        media_name = d["media"][0].get("name", "")
                        # Lấy project_id của media (có thể khác final_pid trong payload)
                        media_pid = d["media"][0].get("projectId", final_pid)
                    remaining = d.get("remainingCredits", "?")
                    print(f"[SEND] ✅ OK (new schema)")
                    print(f"[SEND]   workflow: {workflow_name[:40]}...")
                    print(f"[SEND]   media:    {media_name[:40]}...")
                    print(f"[SEND]   pid:      {media_pid[:40]}...")
                    print(f"[SEND]   credits còn: {remaining}")
                    print(f"{'='*70}\n")
                    # Trả media_name làm op_name, media_pid làm scene_id (vì poll cần 2 cái này)
                    return "OK", media_name, media_pid
                
                # 200 nhưng không có operations cũng không workflows
                print(f"[SEND] ❌ NO operations + NO workflows | response keys: {list(d.keys())}")
                print(f"[SEND] FULL response body:")
                print(f"{r.text[:1500]}")
                print(f"{'='*70}\n")
                err_keys = list(d.keys())
                err_msg = f"Schema lạ | keys={err_keys} | {r.text[:250]}"
                return "FAIL", err_msg, ""
            
            # Status không phải 200
            print(f"[SEND] ❌ HTTP {r.status_code}")
            print(f"[SEND] response body:")
            print(f"{r.text[:1500]}")
            print(f"{'='*70}\n")
            return "FAIL", f"HTTP {r.status_code} | {r.text[:300]}", ""
        except requests.exceptions.Timeout:
            # Timeout = server chậm, KHÔNG phải lỗi auth → trả TIMEOUT để worker retry mềm
            print(f"[SEND] ⏳ Timeout sau 180s — Google server chậm, sẽ retry")
            return "FAIL", "TIMEOUT — Google API chậm, đang retry", ""
        except Exception as e:
            print(f"[SEND] ❌ Exception: {e}")
            return "FAIL", str(e), ""

    def upscale_video(self, recaptcha, media_id, ratio, resolution_key, model_key, output_path, project_id=None):
        """Upscale video lên 1080p hoặc 4K"""
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoUpsampleVideo"
        UPSCALE_PROJECT_ID_DEFAULT = "15db98c1-1b62-473e-b284-a354d46b4399"
        final_pid = project_id.strip() if project_id and project_id.strip() else UPSCALE_PROJECT_ID_DEFAULT

        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": "PAYGATE_TIER_TWO"
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS"
            },
            "requests": [
                {
                    "aspectRatio": ratio,
                    "seed": random.randint(10000, 999999),
                    "resolution": resolution_key,
                    "videoInput": {"mediaId": media_id},
                    "videoModelKey": model_key,
                    "metadata": {"workflowId": str(uuid.uuid4())}
                }
            ],
            "useV2ModelConfig": True
        }

        try:
            r = cffi_requests.post(
                url, json=payload, headers=self.headers, cookies=self.cookies,
                timeout=180, impersonate=CHROME_IMPERSONATE
            )
            if r.status_code != 200:
                print(f"[UPSCALE_VIDEO] Error: {r.status_code} | {r.text[:300]}")
                return "FAIL", f"HTTP {r.status_code} | {r.text}", ""
            d = r.json()
            if "operations" in d:
                return "OK", d["operations"][0]["operation"]["name"], d["operations"][0].get("sceneId", "")
            return "FAIL", "No operations found", ""
        except Exception as e:
            return "FAIL", str(e), ""

    def download_video(self, op_name, scene_id, save_path):
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchCheckAsyncVideoGenerationStatus"
        print(f"[POLL] Bắt đầu poll: op={op_name[:30]}... scene={scene_id}")
        
        def _find_all_urls(obj, path=""):
            found = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if isinstance(v, str) and ("http" in v.lower() or "fife" in k.lower() or "url" in k.lower()):
                        found.append((f"{path}.{k}", v))
                    found.extend(_find_all_urls(v, f"{path}.{k}"))
            elif isinstance(obj, list):
                for i, v in enumerate(obj):
                    found.extend(_find_all_urls(v, f"{path}[{i}]"))
            return found

        def _extract_status(d):
            if "operations" in d:
                return d["operations"][0].get("status", "")
            if "media" in d:
                return d["media"][0].get("mediaMetadata", {}).get("mediaStatus", {}).get("mediaGenerationStatus", "")
            return ""

        def _extract_video_url(d):
            vid_url = None
            media_id = None
            if "operations" in d:
                op = d["operations"][0]
                meta = op.get("operation", {}).get("metadata", {})
                video_meta = meta.get("video") or {}
                if isinstance(video_meta, dict):
                    vid_url = video_meta.get("fifeUrl") or video_meta.get("url") or video_meta.get("videoUrl")
                if not vid_url:
                    vid_url = op.get("videoUrl") or meta.get("videoUrl")
                if not vid_url:
                    vid_url = op.get("operation", {}).get("result", {}).get("videoUrl")
                media_id = op.get("sceneId") or (video_meta.get("mediaGenerationId") if isinstance(video_meta, dict) else None) or op.get("mediaGenerationId")
            if not vid_url and "media" in d:
                m = d["media"][0]
                vid_meta = m.get("video", {}).get("generatedVideo", {})
                vid_url = vid_meta.get("fifeUrl") or vid_meta.get("url") or vid_meta.get("videoUrl")
                if not vid_url:
                    vid_url = m.get("video", {}).get("fifeUrl") or m.get("video", {}).get("videoUrl")
                media_id = m.get("name")
            if not vid_url:
                all_urls = _find_all_urls(d)
                for path, u in all_urls:
                    if u.startswith("http") and ("video" in path.lower() or "fife" in path.lower()):
                        vid_url = u
                        break
                if not vid_url:
                    for path, u in all_urls:
                        if u.startswith("http") and "google" in u:
                            vid_url = u
                            break
            return vid_url, media_id

        delay = 5
        max_delay = 30
        # Send giờ trả NEW schema (workflows+media) → poll PHẢI gửi media payload.
        # Body chuẩn (verify F12 labs.google): {"media":[{"name": <media[0].name>, "projectId": <projectId>}]}
        # op_name = media[0].name, scene_id = projectId (send_request new-schema trả đúng 2 cái này).
        poll_shape = "media"  # thử media trước (schema 2025-2026); fallback operations nếu account còn old schema
        for attempt in range(60):
            try:
                if poll_shape == "media":
                    poll_payload = {"media": [{"name": op_name, "projectId": scene_id}]}
                else:
                    poll_payload = {"operations": [{"operation": {"name": op_name}, "sceneId": scene_id}]}

                r = cffi_requests.post(
                    url,
                    json=poll_payload,
                    headers=self.headers,
                    cookies=self.cookies,
                    timeout=90,
                    impersonate=CHROME_IMPERSONATE,
                )
                if r.status_code != 200:
                    print(f"[POLL #{attempt}] ({poll_shape}) HTTP {r.status_code}: {r.text[:300]}")
                    # media bị 400/404 ngay lần đầu → account có thể còn old schema → đổi operations, thử lại luôn
                    if r.status_code in (400, 404) and poll_shape == "media":
                        print(f"[POLL] ↩️ media payload {r.status_code} → fallback sang operations payload...")
                        poll_shape = "operations"
                        continue
                    if r.status_code in (400, 404) and attempt <= 1:
                        print(f"[POLL] ⚠️ Cả media lẫn operations đều fail → check F12 body poll thật!")
                else:
                    d = r.json()
                    # Log keys lần đầu để biết schema poll
                    if attempt == 0:
                        print(f"[POLL #0] keys: {list(d.keys())}")
                    status = _extract_status(d)
                    
                    if attempt % 3 == 0 or "SUCCESSFUL" in status or "FAILED" in status:
                        print(f"[POLL #{attempt}] Status: {status}")
                    if attempt == 0:
                        print(f"[POLL] === RAW JSON LẦN ĐẦU ===")
                        print(r.text[:3000])
                        print(f"[POLL] === HẾT ===")
                    
                    if "SUCCESSFUL" in status:
                        print(f"[POLL] ✅ SUCCESSFUL! === FULL RAW JSON ===")
                        print(r.text[:5000])
                        print(f"[POLL] === HẾT ===")
                        
                        all_urls = _find_all_urls(d)
                        if all_urls:
                            print(f"[POLL] Tất cả URL tìm thấy:")
                            for p, u in all_urls:
                                print(f"  {p}: {u[:100]}")
                        
                        vid_url, media_id = _extract_video_url(d)
                        
                        # === SCHEMA MỚI: response KHÔNG có URL → GET endpoint riêng ===
                        if not vid_url and "media" in d and len(d["media"]) > 0:
                            media_obj = d["media"][0]
                            media_name = media_obj.get("name", "")
                            workflow_id = media_obj.get("workflowId", "")
                            project_id_real = media_obj.get("projectId", "")
                            
                            if media_name:
                                redirect_url = f"https://labs.google/fx/api/trpc/media.getMediaUrlRedirect?name={media_name}"
                                print(f"[POLL] 🔗 Schema mới - lấy URL qua: {redirect_url[:100]}")
                                
                                # Lấy session cookie từ tool5.json (per-token)
                                labs_session = ""
                                if hasattr(self, 'token_session_map'):
                                    labs_session = self.token_session_map.get(self.auth_token, "")
                                
                                cookies_dict = None
                                if labs_session:
                                    cookies_dict = {"__Secure-next-auth.session-token": labs_session}
                                    print(f"[POLL] 🍪 Dùng labs_session từ tool5.json (..{labs_session[-12:]})")
                                else:
                                    print(f"[POLL] ⚠️ Token này chưa có 'labs_session' trong tool5.json!")
                                    print(f"[POLL] 💡 Vào Chrome → F12 → Application → Cookies → labs.google")
                                    print(f"[POLL] 💡 Copy value của cookie '__Secure-next-auth.session-token'")
                                    print(f"[POLL] 💡 Thêm vào tool5.json field 'labs_session'")
                                
                                try:
                                    redirect_headers = {
                                        "Accept": "*/*",
                                        "Range": "bytes=0-",
                                        "Referer": f"https://labs.google/fx/tools/flow/project/{project_id_real}/edit/{workflow_id}",
                                        "Origin": "https://labs.google",
                                        "Sec-Ch-Ua": '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
                                        "Sec-Ch-Ua-Mobile": "?0",
                                        "Sec-Ch-Ua-Platform": '"Windows"',
                                        "Sec-Fetch-Dest": "empty",
                                        "Sec-Fetch-Mode": "cors",
                                        "Sec-Fetch-Site": "same-origin",
                                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
                                    }
                                    rr = cffi_requests.get(
                                        redirect_url,
                                        headers=redirect_headers,
                                        cookies=cookies_dict,
                                        allow_redirects=False,
                                        timeout=30,
                                        impersonate=CHROME_IMPERSONATE,
                                    )
                                    if rr.status_code in (301, 302, 307, 308):
                                        vid_url = rr.headers.get("Location", "")
                                        print(f"[POLL] ✅ Got CDN URL ({rr.status_code}): {vid_url[:100]}...")
                                        media_id = media_name
                                    else:
                                        print(f"[POLL] ❌ getMediaUrlRedirect trả {rr.status_code}: {rr.text[:300]}")
                                        if rr.status_code == 401:
                                            print(f"[POLL] 💡 Cần login Google trong Chrome đang chạy!")
                                            print(f"[POLL] 💡 Hoặc cài: pip install browser_cookie3")
                                except Exception as e:
                                    print(f"[POLL] ❌ Lỗi getMediaUrlRedirect: {e}")
                        
                        if vid_url:
                            print(f"[POLL] ✅ Tải video từ: {vid_url[:100]}")
                            v = requests.get(vid_url, timeout=120)
                            # Chống .mp4 dở dang: kiểm status + size; không đạt thì
                            # KHÔNG return DONE, để vòng poll thử lại.
                            if v.status_code != 200 or len(v.content) < MIN_VIDEO_SIZE:
                                print(f"[DOWNLOAD] ❌ HTTP {v.status_code}, {len(v.content)}B "
                                      f"(<{MIN_VIDEO_SIZE}) → thử lại")
                                time.sleep(delay); delay = min(delay + 3, max_delay)
                                continue
                            # Ghi .part rồi rename nguyên tử → không bao giờ để .mp4 dở
                            part_path = save_path + ".part"
                            with open(part_path, "wb") as f:
                                f.write(v.content)
                            os.replace(part_path, save_path)
                            print(f"[DOWNLOAD] ✅ {len(v.content)} bytes → {save_path}")
                            return "DONE", media_id
                        else:
                            print(f"[RENDER] ❌ Status SUCCESSFUL nhưng KHÔNG tìm thấy video URL!")
                            return "FAILED", None
                    
                    elif "FAILED" in status or "BLOCKED" in status:
                        print(f"[RENDER] Video generation failed: {status}")
                        return ("FAILED: " + str(status))[:120], None
                        
            except Exception as e:
                print(f"⚠️ Lỗi poll lần {attempt+1}: {e}")
                import traceback; traceback.print_exc()
            
            time.sleep(delay)
            delay = min(delay + 3, max_delay)
        
        return "TIMEOUT", None


# ==============================================================================
# PHẦN 2: WORKER
# ==============================================================================

class ProcessWorker(threading.Thread):
    # Hỏng 5 lần liên tiếp → bỏ prompt, đẩy sang tab Rà soát prompt
    FAIL_LIMIT = 5

    def __init__(self, task_queue, config, logger_func, status_func, finish_func,
                 on_prompt_failed=None):
        super().__init__()
        self.on_prompt_failed = on_prompt_failed
        self.task_queue = task_queue 
        self.config = config
        self.log = logger_func
        self.update_status = status_func
        self.finish_func = finish_func
        self.is_running = True
        self.daemon = True
        self.executor = None
        self.token_pid_map = {}  # {token: project_id} từ accounts.json

    def stop(self):
        self.is_running = False

    # Lỗi do VI PHẠM CHÍNH SÁCH thì chỉ thử 2 lượt rồi đưa đi rà soát
    POLICY_LIMIT = 2
    POLICY_WORDS = ("policy", "safety", "blocked", "not allowed", "violat",
                    "unsafe", "content restriction", "harmful", "prohibited",
                    "bị chặn", "vi phạm", "gây hại", "chính sách")

    def _is_policy_block(self, msg):
        """Google báo prompt vi phạm chính sách — thử lại bao nhiêu cũng hỏng."""
        t = str(msg or "").lower()
        return any(k in t for k in self.POLICY_WORDS)

    def _pol_lim(self):
        """Số lần thử lại khi prompt bị nghi vi phạm chính sách.
        BẬT Tự rà soát → 2 lần rồi giao rà soát.
        TẮT → thử nhiều hơn (FAIL_LIMIT) vì không có ai sửa hộ."""
        try:
            v = int(self.config.get("policy_limit", self.POLICY_LIMIT))
            return max(1, v)
        except Exception:
            return self.POLICY_LIMIT

    def _sleep_stop(self, seconds):
        """Ngủ nhưng cứ 0.3s ngó cờ dừng — bấm Dừng là thoát ngay, không đợi hết giờ."""
        end = time.time() + seconds
        while time.time() < end:
            if not self.is_running:
                return
            time.sleep(0.3)

    def _give_up(self, row_id, prompt_text, reason):
        """Bỏ prompt này và đẩy sang tab Rà soát prompt."""
        self.update_status(row_id, f"🛡 Chờ rà soát ({reason})", "")
        self.log(f"[{row_id+1}] 🛡 Hỏng {self.FAIL_LIMIT} lần ({reason}) → đưa sang tab Rà soát prompt.")
        if self.on_prompt_failed:
            try:
                self.on_prompt_failed(row_id, prompt_text, reason)
            except Exception:
                pass

    def _do_upscale(self, backend, row_id, orig_filename, media_id, ratio_key, upscale_mode, account_type, video_pid=""):
        """Gửi job upscale video sau khi render xong"""
        UPSCALE_MODEL = {
            "1080p": "veo_3_1_upsampler_1080p",
            "4K":    "veo_3_1_upsampler_4k",
        }
        UPSCALE_RES = {
            "1080p": "VIDEO_RESOLUTION_1080P",
            "4K":    "VIDEO_RESOLUTION_4K",
        }
        model_key = UPSCALE_MODEL.get(upscale_mode)
        res_key   = UPSCALE_RES.get(upscale_mode)

        if not model_key or not media_id:
            self.log(f"[{row_id+1}] ⚠️ Không thể upscale: media_id={media_id}, mode={upscale_mode}")
            self.update_status(row_id, "✅ Hoàn thành (không upscale)", orig_filename)
            return

        # QUAN TRỌNG: upscale phải nhắm ĐÚNG project video đang nằm (video_pid = pid THẬT do
        # send_request trả về). Dùng pid token/mặc định → mediaId "mồ côi" → 404/lỗi.
        up_pid = (video_pid or "").strip() or self.token_pid_map.get(backend.auth_token, "")

        # Upscale chạy ngay sau poll video → token captcha dễ "nguội" → 403. Có retry: 403 thì
        # force-refresh + token mới rồi thử lại; lỗi khác (404 mediaId/project) → dừng luôn.
        st, op, sc = "FAIL", "", ""
        MAX_UP_RETRY = 3
        for attempt in range(MAX_UP_RETRY):
            self.update_status(row_id, f"⬆ Lấy Cap Upscale {upscale_mode} ({attempt+1}/{MAX_UP_RETRY})...", orig_filename)
            cap = backend.get_recaptcha()
            if not cap:
                time.sleep(4); continue

            self.update_status(row_id, f"⬆ Gửi Upscale {upscale_mode}...", orig_filename)
            st, op, sc = backend.upscale_video(cap, media_id, ratio_key, res_key, model_key, orig_filename, project_id=up_pid)
            if st == "OK":
                break

            err = str(op)
            print(f"[UPSCALE] ❌ media={str(media_id)[:16]} pid={str(up_pid)[:16]} → {err[:200]}")
            if "403" in err or "reCAPTCHA" in err or "UNUSUAL_ACTIVITY" in err:
                self.log(f"[{row_id+1}] 🐢 Upscale 403 captcha → refresh + thử lại ({attempt+1}/{MAX_UP_RETRY})")
                try: requests.post("http://localhost:3000/captcha/force-refresh", timeout=5)
                except: pass
                time.sleep(6)
                continue
            else:
                break

        if st != "OK":
            self.log(f"[{row_id+1}] ❌ Upscale lỗi: {op}")
            self.update_status(row_id, "✅ Có video gốc, lỗi upscale", orig_filename)
            return

        self.update_status(row_id, f"🔄 Render Upscale {upscale_mode}...", orig_filename)
        base, ext = os.path.splitext(orig_filename)
        up_filename = f"{base}_tmp_up{ext}"
        res, _ = backend.download_video(op, sc, up_filename)
        if res == "DONE":
            try: os.remove(orig_filename)
            except: pass
            try: os.rename(up_filename, orig_filename)
            except: pass
            self.update_status(row_id, f"✅ Xong ({upscale_mode})", orig_filename)
            self.log(f"[{row_id+1}] Xong upscale {upscale_mode}: {os.path.basename(orig_filename)}")
        else:
            self.update_status(row_id, "✅ Có video gốc, lỗi upscale", orig_filename)
            self.log(f"[{row_id+1}] ❌ Render upscale thất bại ({res})")

    def add_task(self, p_data):
        self.task_queue.put(p_data)

    def process_single_prompt(self, p_data, token, model_key, ratio_key, out_dir, account_type):
        if not self.is_running:
            return

        row_id = p_data["id"]
        prompt = p_data["text"].strip()
        force_regen = p_data.get("force_regen", False)

        filename = os.path.join(out_dir, f"{row_id + 1:04d}.mp4")

        if os.path.exists(filename) and not force_regen:
            self.update_status(row_id, "✅ Đã có file", filename)
            return

        token_label = token[-5:] if len(token) > 5 else "..."
        backend = VeoBackend(token)
        backend.token_session_map = self.token_session_map  # cookie labs.google
        project_id = self.token_pid_map.get(token, "")  # lấy pid của token này từ accounts.json

        retry_count = 0
        render_fail_count = 0
        policy_fail = 0
        MAX_RENDER_RETRIES = self.FAIL_LIMIT
        while self.is_running:
            try:
                retry_suffix = f"({retry_count})" if retry_count > 0 else ""

                self.update_status(row_id, f"⏳ [API] Đang lấy Cap {retry_suffix}...", "")
                recaptcha = backend.get_recaptcha()
                
                if not recaptcha:
                    self.update_status(row_id, "❌ Lỗi Captcha, retry 5s...", "")
                    self.log(f"[{row_id+1}] 🛑 Không lấy được Captcha.")
                    time.sleep(5)
                    continue

                self.update_status(row_id, f"📡 [..{token_label}] Gửi API...", "")
                status, op_name, scene_id = backend.send_request(recaptcha, prompt, model_key, ratio_key, account_type, project_id=project_id)

                if status == "OK":
                    self.update_status(row_id, "🔄 Đang Render...", "")
                    res, media_id = backend.download_video(op_name, scene_id, filename)
                    if res == "DONE":
                        upscale_mode = self.config.get("upscale_mode", "Không")
                        if upscale_mode != "Không":
                            # op_name = media id SẠCH (UUID) từ generate → dùng cho upscale.
                            # media_id trả từ download có thể là blob mã hoá → KHÔNG hợp lệ.
                            # scene_id = pid THẬT của video (send_request trả media_pid).
                            clean_media_id = op_name if op_name else media_id
                            self._do_upscale(backend, row_id, filename, clean_media_id, ratio_key, upscale_mode, account_type, video_pid=scene_id)
                        else:
                            self.update_status(row_id, "✅ Hoàn thành", filename)
                            self.log(f"[{row_id+1}] Xong: {os.path.basename(filename)}")
                        break
                    else:
                        # Render đã nhận request rồi mới hỏng → gần như luôn là
                        # do NỘI DUNG prompt. Chỉ thử POLICY_LIMIT lượt rồi đưa
                        # đi rà soát, khỏi phí 5 lượt.
                        render_fail_count += 1
                        _lim = self._pol_lim()
                        if render_fail_count >= _lim:
                            self._give_up(row_id, prompt,
                                          f"render hỏng {render_fail_count} lần ({res}) "
                                          f"— nhiều khả năng prompt vi phạm chính sách")
                            break
                        self.update_status(row_id, f"❌ Lỗi Render ({render_fail_count}/{_lim}) -> Thử lại...", "")
                        self.log(f"[{row_id+1}] Lỗi render ({res}), lần {render_fail_count}/{_lim}, thử lại...")
                        retry_count += 1
                        time.sleep(2)
                        continue
                else:
                    error_msg = str(op_name)

                    # ★ Veo từ chối vì chính sách nội dung → thử lại vô ích,
                    #   đẩy thẳng sang tab Rà soát prompt.
                    if self._is_policy_block(error_msg):
                        policy_fail += 1
                        _pl = self._pol_lim()
                        if policy_fail >= _pl:
                            self._give_up(row_id, prompt,
                                          f"VEO từ chối vì chính sách nội dung: {error_msg[:200]}")
                            break
                        self.update_status(
                            row_id,
                            f"🚫 Vi phạm chính sách ({policy_fail}/{_pl})…", "")
                        self.log(f"[{row_id+1}] 🚫 Vi phạm chính sách, thử lại "
                                 f"{policy_fail}/{_pl}: {error_msg[:120]}")
                        time.sleep(3)
                        continue

                    # === TIMEOUT — Google server chậm, retry sau cooldown dài hơn ===
                    if "TIMEOUT" in error_msg or "timed out" in error_msg.lower() or "timeout" in error_msg.lower():
                        self.update_status(row_id, "⏳ Timeout, đợi 15s rồi retry...", "")
                        self.log(f"[{row_id+1}] ⏳ Google API timeout (server chậm), đợi 15s...")
                        self._sleep_stop(15)
                        if not self.is_running: break
                        retry_count += 1
                        if retry_count >= self.FAIL_LIMIT:
                            self._give_up(row_id, prompt, "timeout")
                            break
                        continue

                    # === 429 TOO_MUCH_TRAFFIC — gửi quá nhanh, đợi LÂU ===
                    # Phải check 429 TRƯỚC 403 vì cả 2 đều có chữ "reCAPTCHA" trong message
                    if "429" in error_msg or "TOO_MUCH_TRAFFIC" in error_msg or "RESOURCE_EXHAUSTED" in error_msg:
                        cooldown = 45 + random.randint(0, 30)  # 45-75s ngẫu nhiên
                        self.update_status(row_id, f"🐢 Rate limit, đợi {cooldown}s...", "")
                        self.log(f"[{row_id+1}] 🐢 429 TOO_MUCH_TRAFFIC — Google bóp request, đợi {cooldown}s...")
                        self._sleep_stop(cooldown)
                        if not self.is_running: break
                        retry_count += 1
                        if retry_count >= self.FAIL_LIMIT:
                            self._give_up(row_id, prompt, "rate limit")
                            break
                        continue

                    if "403" in error_msg or "reCAPTCHA" in error_msg:
                        self.update_status(row_id, "⚠️ Lỗi 403 -> Retry...", "")
                        self.log(f"[{row_id+1}] 🛑 Lỗi 403/Captcha.")
                        try:
                            requests.post("http://localhost:3000/captcha/force-refresh", timeout=5)
                            self.log(f"[{row_id+1}] 🔄 Đã gửi lệnh refresh Captcha.")
                        except: pass
                        time.sleep(5)
                        backend = VeoBackend(token)
                        backend.token_session_map = self.token_session_map
                        continue

                    if "401" in error_msg:
                        self.update_status(row_id, "❌ Token chết!", "")
                        self.log(f"[{row_id+1}] Token ..{token_label} hết hạn!")
                        break

                    # Project full / quota exceeded → sinh pid mới, ghi vào JSON, retry
                    err_low = error_msg.lower()
                    if any(kw in err_low for kw in ["limit", "quota", "exceeded", "maximum", "max videos", "project is full"]):
                        new_pid = str(uuid.uuid4())
                        self.log(f"[{row_id+1}] 🔄 Project full → đổi pid: ...{new_pid[-12:]}")
                        self.token_pid_map[token] = new_pid
                        project_id = new_pid
                        with file_lock:
                            try:
                                af = os.path.join(get_app_dir(), "tool5.json")
                                with open(af, "r", encoding="utf-8") as f:
                                    data = json.load(f)
                                for acc in data.get("accounts", []):
                                    if (acc.get("token") or "").strip() == token:
                                        acc["project_id"] = new_pid
                                        break
                                with open(af, "w", encoding="utf-8") as f:
                                    json.dump(data, f, indent=2, ensure_ascii=False)
                            except Exception as e:
                                self.log(f"[{row_id+1}] ⚠️ Không ghi được pid mới: {e}")
                        time.sleep(1)
                        continue

                    self.update_status(row_id, f"❌ Lỗi API {status} -> Thử lại...", "")
                    self.log(f"[{row_id+1}] ❌ {error_msg[:500]}")  # Log chi tiết hơn
                    self.log(f"[{row_id+1}] 💡 Xem console (PowerShell) để có log đầy đủ!")
                    time.sleep(3)
                    retry_count += 1
                    if retry_count >= 2:
                        self.update_status(row_id, "⚠️ Lỗi API nhiều lần, retry...", "")
                        self.log(f"[{row_id+1}] 🛑 Lỗi API nhiều lần.")
                        retry_count = 0
                    continue

            except Exception as e:
                self.update_status(row_id, "❌ Lỗi Crash...", "")
                print(f"Lỗi luồng {row_id}: {e}")
                time.sleep(3)
                retry_count += 1
                if retry_count > 10:
                    self._give_up(row_id, prompt, f"lỗi lặp: {e}")
                    break

    def run(self):
        # Đọc tokens + project_ids + labs_session từ tool5.json
        accounts_file = os.path.join(get_app_dir(), "tool5.json")
        
        tokens = []
        self.token_pid_map = {}
        self.token_session_map = {}  # {token: labs_session_cookie}
        
        if os.path.exists(accounts_file):
            try:
                with open(accounts_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                # Sinh UUID v4 cho acc nào có token mà thiếu project_id
                auto_gen = 0
                for acc in data.get("accounts", []):
                    if (acc.get("token") or "").strip() and not (acc.get("project_id") or "").strip():
                        acc["project_id"] = str(uuid.uuid4())
                        auto_gen += 1
                if auto_gen:
                    with open(accounts_file, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    self.log(f"🎲 Sinh UUID làm project_id cho {auto_gen} acc thiếu pid")
                for acc in data.get("accounts", []):
                    tok = (acc.get("token") or "").strip()
                    pid = (acc.get("project_id") or "").strip()
                    session = (acc.get("labs_session") or "").strip()
                    if tok:
                        tokens.append(tok)
                        if pid:
                            self.token_pid_map[tok] = pid
                        if session:
                            self.token_session_map[tok] = session
                self.log(f"📂 Đã load {len(tokens)} token + {len(self.token_pid_map)} pid + {len(self.token_session_map)} labs_session từ tool5.json")
            except Exception as e:
                self.log(f"❌ Lỗi đọc tool5.json: {e}")
                self.finish_func()
                return
        else:
            self.log("❌ KHÔNG TÌM THẤY tool5.json!")
            self.log("   → Bấm '🔧 Quản lý tài khoản' → '➕ Thêm tài khoản'")
            self.finish_func()
            return

        if not tokens:
            self.log("❌ tool5.json không có token nào.")
            self.finish_func()
            return

        self.log(f"🔑 Đã load {len(tokens)} Token (Auth).")
        
        # Delay 12s/token để tránh 429 TOO_MUCH_TRAFFIC từ Google reCAPTCHA Enterprise
        # (3s quá nhanh → Google bóp request → 429)
        token_limiter = TokenRateLimiter(tokens, delay_seconds=6)
        
        selected_model = self.config.get("model")
        selected_ratio = self.config.get("ratio")
        account_type   = self.config.get("account_type", "Ultra")

        # Model key theo loại tài khoản + ratio
        # FIX (theo fetch thật từ Chrome của user):
        # - Quality: BỎ _ultra → "veo_3_1_t2v"
        # - Fast / Fast Lower Priority: GIỮ _ultra (Google vẫn dùng tên có _ultra)
        if account_type == "Ultra":
            if selected_ratio == "Dọc (9:16)":
                model_mapping = {
                    "Veo 3.1 - Lite":                   "veo_3_1_t2v_lite",
                    "Veo 3.1 - Lite [Lower Priority]":  "veo_3_1_t2v_lite_low_priority",
                    "Veo 3.1 - Fast":                   "veo_3_1_t2v_fast_portrait_ultra",
                    "Veo 3.1 - Quality":                "veo_3_1_t2v_portrait",
                    "Veo 4":                 "abra_t2v_10s"
                }
            else:
                model_mapping = {
                    "Veo 3.1 - Lite":                   "veo_3_1_t2v_lite",
                    "Veo 3.1 - Lite [Lower Priority]":  "veo_3_1_t2v_lite_low_priority",
                    "Veo 3.1 - Fast":                   "veo_3_1_t2v_fast_ultra",
                    "Veo 3.1 - Quality":                "veo_3_1_t2v",
                    "Veo 4":                 "abra_t2v_10s"
                }
        else:
            # Pro / Free — không có hậu tố _ultra
            if selected_ratio == "Dọc (9:16)":
                model_mapping = {
                    "Veo 3.1 - Lite":                   "veo_3_1_t2v_lite",
                    "Veo 3.1 - Lite [Lower Priority]":  "veo_3_1_t2v_lite_low_priority",
                    "Veo 3.1 - Fast":                   "veo_3_1_t2v_fast_portrait",
                    "Veo 3.1 - Quality":                "veo_3_1_t2v_portrait",
                    "Veo 4":                 "abra_t2v_10s"
                }
            else:
                model_mapping = {
                    "Veo 3.1 - Lite":                   "veo_3_1_t2v_lite",
                    "Veo 3.1 - Lite [Lower Priority]":  "veo_3_1_t2v_lite_low_priority",
                    "Veo 3.1 - Fast":                   "veo_3_1_t2v_fast",
                    "Veo 3.1 - Quality":                "veo_3_1_t2v",
                    "Veo 4":                 "abra_t2v_10s"
                }

        model_key = model_mapping.get(selected_model, "veo_3_1_t2v_lite_low_priority")

        # === Omni Flash: swap suffix theo thời lượng người dùng chọn ===
        # abra_t2v_10s → abra_t2v_4s / 6s / 8s / 10s
        if model_key.startswith("abra_t2v_"):
            duration = (self.config.get("duration") or "10s").strip().lower()
            if duration not in ("4s", "6s", "8s", "10s"):
                duration = "10s"
            model_key = f"abra_t2v_{duration}"
            self.log(f"⏱️ Veo 4 → thời lượng {duration} → model_key = {model_key}")

        ratio_map = {
            "Ngang (16:9)": "VIDEO_ASPECT_RATIO_LANDSCAPE",
            "Dọc (9:16)": "VIDEO_ASPECT_RATIO_PORTRAIT"
        }
        ratio_key = ratio_map.get(selected_ratio, "VIDEO_ASPECT_RATIO_LANDSCAPE")
        
        out_dir = self.config.get("out_dir", "Video_Result")
        os.makedirs(out_dir, exist_ok=True)
        
        self.log(f"📡 [XÁC NHẬN] Model: {selected_model}  |  Loại TK: {account_type}")

        try:
            max_workers = int(self.config.get("threads", 1))
        except:
            max_workers = 1

        self.log(f"🚀 Bắt đầu xử lý với {max_workers} luồng.")
        
        # FIX 403 lần đầu: Warm up NestJS captcha server
        self.log("🔄 Warming up captcha server (force refresh + chờ 3s)...")
        try:
            requests.post("http://localhost:3000/captcha/force-refresh", timeout=5)
        except Exception as e:
            self.log(f"⚠️ NestJS captcha server có thể chưa ready: {e}")
        time.sleep(3)
        
        self.executor = ThreadPoolExecutor(max_workers=max_workers)

        # FIX #2: Bỏ qsize() không đáng tin, dùng vòng lặp đọc đến khi Empty
        # FIX SKIP: Check file tồn tại NGAY khi lấy task, KHÔNG chiếm token + KHÔNG sleep
        #           → 100 video đã có file skip trong < 1 giây thay vì 10-15 phút
        first_batch = True
        skipped_existing = 0
        submitted = 0            # đã bơm được bao nhiêu prompt (không tính skip)
        while self.is_running:
            try:
                p_data = self.task_queue.get(block=False)
                
                # === FAST SKIP: file đã tồn tại + không phải regen → bỏ qua ngay ===
                row_id = p_data["id"]
                force_regen = p_data.get("force_regen", False)
                filename = os.path.join(out_dir, f"{row_id + 1:04d}.mp4")
                if os.path.exists(filename) and not force_regen:
                    self.update_status(row_id, "✅ Đã có file", filename)
                    skipped_existing += 1
                    continue  # Lấy task tiếp, KHÔNG đợi token, KHÔNG sleep
                
                current_token = token_limiter.get_token()
                self.executor.submit(self.process_single_prompt, p_data, current_token, model_key, ratio_key, out_dir, account_type)
                submitted += 1
                # ĐỔ ĐẦY LUỒNG TRƯỚC: khi chưa đủ số luồng thì bơm nhanh (1-2s)
                # để cả 5 luồng chạy song song ngay, khỏi ngồi đợi lâu như cũ.
                # Đầy luồng rồi mới giãn nhịp nhẹ để tránh 429.
                if submitted < max_workers:
                    time.sleep(random.uniform(1.0, 2.0))
                else:
                    time.sleep(random.uniform(2.0, 4.0))
            except queue.Empty:
                first_batch = False
                break
            except Exception as e:
                print(f"Worker Loop Error: {e}")

        if skipped_existing:
            self.log(f"⏭️  Đã skip {skipped_existing} video đã có sẵn file.")

        self.executor.shutdown(wait=True)
        self.is_running = False
        self.finish_func()


# ==============================================================================
# PHẦN 3: UI DẠNG TAB (CTkFrame)
# ==============================================================================

class VeoTextToVideoTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)

        
        self.all_prompts_data = [] 
        self.rows_ui = {} 
        self.worker = None
        # FIX #3: Giữ 1 queue duy nhất xuyên suốt vòng đời, không tạo mới khi regen
        self.task_queue = queue.Queue()
        self.current_page = 1
        self.items_per_page = 15
        self.on_prompt_failed = None   # tt.py gắn vào → đẩy prompt lỗi sang tab Rà soát

        _ui5.setup_ui(self)

    def choose_file(self):
        f = filedialog.askopenfilename(filetypes=[("Prompts", "*.txt *.json"), ("All Files", "*.*")])
        if not f: return
        self.lbl_file.configure(text=os.path.basename(f))
        content = ""
        try:
            if f.lower().endswith(".json"):
                with open(f, "r", encoding="utf-8") as file:
                    data = json.load(file)
                    found_list = None
                    if isinstance(data, list): found_list = data
                    elif isinstance(data, dict):
                        for k in ["scenes", "prompts", "data", "items", "list"]:
                            if k in data and isinstance(data[k], list):
                                found_list = data[k]; break
                    if found_list:
                        lines = []
                        for x in found_list:
                            if isinstance(x, str): lines.append(x)
                            elif isinstance(x, dict):
                                txt = x.get("prompt") or x.get("text") or str(x)
                                lines.append(txt)
                        content = "\n".join(lines)
            else:
                with open(f, "r", encoding="utf-8", errors="ignore") as file:
                    content = file.read()
            self.txt_prompt_input.delete("1.0", "end")
            self.txt_prompt_input.insert("1.0", content)
            self.scan_prompts_and_files()
        except Exception as e:
            messagebox.showerror("Lỗi đọc file", f"Không đọc được file:\n{e}")

    def choose_output_folder(self):
        d = filedialog.askdirectory()
        if d:
            self.entry_out_dir.delete(0, "end")
            self.entry_out_dir.insert(0, d)
            self.scan_prompts_and_files()

    def _on_account_type_change(self, selected):
        """Cập nhật danh sách model theo loại tài khoản"""
        if selected == "Ultra":
            models = [
                "Veo 3.1 - Lite",
                "Veo 3.1 - Fast",
                "Veo 3.1 - Quality",
                "Veo 3.1 - Lite [Lower Priority]",
                "Veo 4"
            ]
            default = "Veo 3.1 - Lite [Lower Priority]"
        else:  # Pro
            models = [
                "Veo 3.1 - Lite",
                "Veo 3.1 - Fast",
                "Veo 3.1 - Quality",
                "Veo 3.1 - Lite [Lower Priority]",
                "Veo 4"
            ]
            default = "Veo 3.1 - Lite [Lower Priority]"

        self.cbo_model.configure(values=models)
        self.cbo_model.set(default)

    def log(self, msg):
        # Throttled — batch insert, cap max lines (xem log_utils.py)
        lg = getattr(self, "_logger", None)
        if lg is None:
            try:
                from log_utils import attach_logger
                attach_logger(self, self.log_box, tk_master=self)
                lg = self._logger
            except Exception:
                # fallback: ghi ngay nếu helper lỗi
                self.after(0, lambda: self._log_ui_raw(msg))
                return
        lg.log(str(msg))

    def _log_ui_raw(self, msg):
        try:
            self.log_box.configure(state="normal")
            self.log_box.insert("end", f"{msg}\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        except Exception:
            pass

    # === Quản lý list tài khoản ===
    def _load_accounts_from_json(self):
        """Load list accounts từ tool5.json"""
        json_path = os.path.join(get_app_dir(), "tool5.json")
        if not os.path.exists(json_path):
            return []
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("accounts", [])
        except:
            return []

    def _save_accounts_to_json(self, accounts):
        """Save list accounts vào tool5.json"""
        json_path = os.path.join(get_app_dir(), "tool5.json")
        try:
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump({"accounts": accounts}, f, indent=2, ensure_ascii=False)
        except Exception as e:
            messagebox.showerror("Lỗi lưu", str(e))

    def _update_acc_count_label(self):
        """Update label hiển thị số lượng acc hiện có"""
        if not hasattr(self, 'lbl_acc_count'):
            return
        accs = self._load_accounts_from_json()
        full = sum(1 for a in accs if a.get("token") and a.get("project_id"))
        if not accs:
            self.lbl_acc_count.configure(text="Chưa có tài khoản nào.",
                                         text_color=_T.MUTED)
        else:
            self.lbl_acc_count.configure(
                text=f"{len(accs)} tài khoản · {full} cái đủ thông tin",
                text_color=_T.OK if full == len(accs) else "#e0a458"
            )

    def _render_account_list(self):
        """Render list account vào dialog frame hiện tại (nếu dialog đang mở)"""
        # Update count label trong sidebar
        self._update_acc_count_label()
        
        # Nếu dialog không mở thì thôi
        target = getattr(self, '_current_acc_list_frame', None)
        if target is None:
            return
        
        # Clear cũ
        for w in target.winfo_children():
            w.destroy()
        
        accounts = self._load_accounts_from_json()
        if not accounts:
            ctk.CTkLabel(target, text="Chưa có tài khoản nào — bấm “Thêm tài khoản mới”.",
                         text_color=_T.MUTED, font=_F.ui).pack(pady=24)
            return
        
        for i, acc in enumerate(accounts):
            _ui5.account_row(self, target, i, acc)

    def open_account_manager(self):
        """Bảng quản lý tài khoản Veo."""
        dialog = _ui5.dialog(self, "Tài khoản Veo 3", 640, 560)

        head = _ui5.row(dialog)
        head.pack(fill="x", padx=18, pady=(16, 4))
        _ui5.lbl(head, "TÀI KHOẢN VEO 3", _T.TEXT_STRONG, _F.title).pack(side="left")

        _ui5.btn(dialog, "Thêm tài khoản mới", self.on_add_account).pack(
            fill="x", padx=18, pady=10)

        box = _ui5.card(dialog)
        box.pack(fill="both", expand=True, padx=18, pady=4)
        list_frame = ctk.CTkScrollableFrame(box, fg_color="transparent", corner_radius=0,
                                            scrollbar_fg_color=_T.CARD,
                                            scrollbar_button_color="#3a3d4d",
                                            scrollbar_button_hover_color=_T.ACCENT)
        list_frame.pack(fill="both", expand=True, padx=8, pady=8)

        self._current_acc_list_frame = list_frame
        self._render_account_list()

        footer = _ui5.row(dialog)
        footer.pack(fill="x", padx=18, pady=12)
        _ui5.sbtn(footer, "Đóng", lambda: self._close_acc_mgr(dialog),
                  width=96).pack(side="right")

        dialog.protocol("WM_DELETE_WINDOW", lambda: self._close_acc_mgr(dialog))

    def _close_acc_mgr(self, dialog):
        """Cleanup khi đóng dialog quản lý"""
        self._current_acc_list_frame = None
        dialog.destroy()

    def _delete_account(self, idx):
        """Xóa account thứ idx khỏi list + tool5.json"""
        accounts = self._load_accounts_from_json()
        if 0 <= idx < len(accounts):
            removed = accounts.pop(idx)
            self._save_accounts_to_json(accounts)
            self._render_account_list()
            tail = (removed.get("token") or "")[-8:]
            self.log(f"🗑 Đã xóa acc #{idx+1} (..{tail})")

    def on_add_account(self):
        """Mở dialog popup để paste JSON 1 hoặc nhiều account"""
        dialog = _ui5.dialog(self, "Thêm tài khoản Veo", 600, 500, grab=True)

        _ui5.lbl(dialog, "Dán JSON — một hoặc nhiều tài khoản",
                 _T.TEXT_STRONG, _F.ui_sb).pack(anchor="w", padx=20, pady=(16, 6))

        txt = ctk.CTkTextbox(dialog, height=200, corner_radius=_T.RADIUS,
                             fg_color=_T.INPUT, border_color=_T.BORDER,
                             border_width=1, text_color=_T.TEXT, font=_F.mono_sm)
        txt.pack(fill="both", expand=True, padx=20, pady=4)
        txt.focus()
        
        # Hint với example
        hint_frame = _ui5.card(dialog)
        hint_frame.pack(padx=20, pady=8, fill="x")
        ctk.CTkLabel(
            hint_frame, justify="left", text_color=_T.MUTED, font=_F.mono_sm,
            text='{\n'
                 '  "accounts": [\n'
                 '    {\n'
                 '      "token": "ya29…",\n'
                 '      "project_id": "uuid…",\n'
                 '      "labs_session": "…"   ← bắt buộc, thiếu là không tải được video\n'
                 '    }\n'
                 '  ]\n'
                 '}\n\n'
                 'Lấy labs_session: F12 → Application → Cookies → https://labs.google\n'
                 '→ cookie "__Secure-next-auth.session-token"'
        ).pack(padx=12, pady=10, anchor="w")
        
        def on_save():
            text = txt.get("1.0", "end").strip()
            if not text:
                messagebox.showwarning("Trống", "Hãy paste JSON!", parent=dialog)
                return
            try:
                data = json.loads(text)
                new_accs = data.get("accounts", [])
                if not isinstance(new_accs, list) or not new_accs:
                    messagebox.showerror("Lỗi", "JSON phải có key 'accounts' là list không rỗng!", parent=dialog)
                    return
                
                # Validate từng acc
                valid = []
                for a in new_accs:
                    tok = (a.get("token") or "").strip()
                    if tok:
                        item = {
                            "email": a.get("email", ""),
                            "token": tok,
                            "project_id": (a.get("project_id") or "").strip(),
                            "credits": a.get("credits", "Unknown"),
                        }
                        # Field bắt buộc cho download video schema mới
                        labs_session = (a.get("labs_session") or "").strip()
                        if labs_session:
                            item["labs_session"] = labs_session
                        valid.append(item)
                if not valid:
                    messagebox.showerror("Lỗi", "Không có acc nào có token hợp lệ!", parent=dialog)
                    return
                
                # Append vào list hiện có (tránh duplicate token)
                existing = self._load_accounts_from_json()
                existing_tokens = {a.get("token") for a in existing}
                added = 0
                skipped = 0
                for v in valid:
                    if v["token"] in existing_tokens:
                        skipped += 1
                    else:
                        existing.append(v)
                        existing_tokens.add(v["token"])
                        added += 1
                
                self._save_accounts_to_json(existing)
                self._render_account_list()
                self.log(f"➕ Đã thêm {added} acc (skip {skipped} trùng) — tổng {len(existing)} acc")
                dialog.destroy()
                
                msg = f"Đã thêm {added} tài khoản!"
                if skipped:
                    msg += f"\nBỏ qua {skipped} acc trùng token."
                messagebox.showinfo("OK", msg)
            except json.JSONDecodeError as e:
                messagebox.showerror("JSON không hợp lệ", f"{e}", parent=dialog)
            except Exception as e:
                messagebox.showerror("Lỗi", f"{e}", parent=dialog)
        
        btn_frame = _ui5.row(dialog)
        btn_frame.pack(fill="x", padx=20, pady=14)
        _ui5.btn_primary(btn_frame, "Lưu tài khoản", on_save, width=126).pack(side="right")
        _ui5.sbtn(btn_frame, "Huỷ", dialog.destroy, width=86).pack(side="right", padx=(0, 6))

    def start_process(self):
        self.scan_prompts_and_files()
        
        if not self.all_prompts_data:
            messagebox.showerror("Lỗi", "Chưa có prompt nào!")
            return

        # FIX #3: Tạo queue mới chỉ khi bắt đầu, không tạo trong regen
        self.task_queue = queue.Queue()
        for p in self.all_prompts_data:
            self.task_queue.put(p)

        try: thread_count = int(self.entry_thread.get())
        except: thread_count = 1

        config = {
            "token_file": "token.txt",
            "model": self.cbo_model.get(),
            "ratio": self.cbo_ratio.get(),
            "duration": self.cbo_duration.get(),
            "account_type": self.cbo_account_type.get(),
            "upscale_mode": self.cbo_upscale.get(),
            "out_dir": self.entry_out_dir.get(),
            "threads": thread_count,
            # BẬT Tự rà soát (tt gắn _review_on): prompt nghi vi phạm → 2 lần rồi
            # giao rà soát. TẮT / chạy lẻ: thử tới FAIL_LIMIT lần, không giao ai.
            "policy_limit": (2 if (getattr(self, "_review_on", None) is not None
                                   and self._review_on.get())
                             else ProcessWorker.FAIL_LIMIT),
        }

        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.log(f"🚀 Bắt đầu với {thread_count} luồng (Không ẩn Browser)...")

        self.worker = ProcessWorker(self.task_queue, config, self.log, self.update_row_status,
                                    self.on_process_finish, on_prompt_failed=self._prompt_failed)
        self.worker.start()

    def _prompt_failed(self, row_id, text, reason=""):
        cb = getattr(self, "on_prompt_failed", None)
        if cb:
            try: cb(row_id, text, reason)
            except Exception: pass

    def stop_process(self):
        if self.worker:
            self.worker.stop()
            self.log("🛑 Đang dừng...")
        self.log("✅ Đã ngắt hàng đợi API.")

    def on_process_finish(self):
        self.after(0, self._finish_ui)

    def _finish_ui(self):
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.log("🏁 Đã hoàn thành hàng đợi.")

    def get_total_pages(self):
        return math.ceil(len(self.all_prompts_data) / self.items_per_page)

    def render_pagination(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.rows_ui.clear()

        total_pages = self.get_total_pages()
        if total_pages == 0: total_pages = 1
        if self.current_page > total_pages: self.current_page = total_pages
        if self.current_page < 1: self.current_page = 1

        self.lbl_page_info.configure(text=f"Trang {self.current_page}/{total_pages}")

        start_idx = (self.current_page - 1) * self.items_per_page
        end_idx = start_idx + self.items_per_page
        page_items = self.all_prompts_data[start_idx:end_idx]

        for item in page_items:
            self.create_result_row(item)

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.render_pagination()

    def next_page(self):
        if self.current_page < self.get_total_pages():
            self.current_page += 1
            self.render_pagination()

    def create_result_row(self, item):
        _ui5.result_row(self, item)

    def _set_status_color(self, lbl, text):
        _ui5.status_color(lbl, text)

    def on_edit_prompt(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item: return

        dialog = _ui5.dialog(self, f"Sửa prompt #{row_id+1}", 560, 320, grab=True)

        txt_edit = ctk.CTkTextbox(dialog, height=200, corner_radius=_T.RADIUS,
                                  fg_color=_T.INPUT, border_color=_T.BORDER,
                                  border_width=1, text_color=_T.TEXT, font=_F.ui,
                                  wrap="word")
        txt_edit.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        txt_edit.insert("1.0", item["text"])

        def save_edit():
            new_text = txt_edit.get("1.0", "end").strip()
            if new_text:
                item["text"] = new_text
                self.render_pagination()
                self.log(f"Đã sửa prompt #{row_id+1}")
            dialog.destroy()
        _bar = _ui5.row(dialog)
        _bar.pack(fill="x", padx=16, pady=(0, 14))
        _ui5.btn_primary(_bar, "Lưu thay đổi", save_edit, width=126).pack(side="right")
        _ui5.sbtn(_bar, "Huỷ", dialog.destroy, width=86).pack(side="right", padx=(0, 6))

    def on_regen_prompt(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item: return
        item["status"] = "Waiting Regen..."
        item["force_regen"] = True 
        if item["file_path"] and os.path.exists(item["file_path"]):
            try: os.remove(item["file_path"])
            except: pass
        item["file_path"] = ""
        if row_id in self.rows_ui:
            self._set_status_color(self.rows_ui[row_id]["status_lbl"], "Waiting Regen...")
            self.rows_ui[row_id]["view_btn"].configure(state="disabled")

        if not self.worker or not self.worker.is_running:
            self.log(f"♻️ Khởi động worker để chạy lại #{row_id+1}...")
            # FIX #3: Dùng lại self.task_queue, KHÔNG tạo queue mới → tránh race condition
            # Xóa sạch queue cũ trước khi add task mới (chỉ khi worker đã dừng hẳn)
            while not self.task_queue.empty():
                try: self.task_queue.get_nowait()
                except queue.Empty: break
            self.task_queue.put(item)
            try: thread_count = int(self.entry_thread.get())
            except: thread_count = 1
            config = {
                "token_file": "token.txt",
                "model": self.cbo_model.get(),
                "ratio": self.cbo_ratio.get(),
                "duration": self.cbo_duration.get(),
                "out_dir": self.entry_out_dir.get(),
                "threads": thread_count,
                "policy_limit": (2 if (getattr(self, "_review_on", None) is not None
                                       and self._review_on.get())
                                 else ProcessWorker.FAIL_LIMIT),
            }
            # FIX #3: Truyền self.task_queue vào worker → worker và UI dùng chung 1 queue
            self.worker = ProcessWorker(self.task_queue, config, self.log, self.update_row_status,
                                    self.on_process_finish, on_prompt_failed=self._prompt_failed)
            self.worker.start()
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        else:
            self.log(f"♻️ Thêm #{row_id+1} vào hàng đợi xử lý lại.")
            # Worker đang chạy → add thẳng vào queue đang dùng, worker tự nhận
            self.task_queue.put(item)

    def on_delete_video(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item: return
        if not item["file_path"] or not os.path.exists(item["file_path"]):
            messagebox.showinfo("Thông báo", "Chưa có video để xóa!")
            return
        if messagebox.askyesno("Xác nhận", f"Bạn muốn xóa video #{row_id+1}?"):
            try:
                os.remove(item["file_path"])
                item["file_path"] = ""
                item["status"] = "Đã xóa file"
                if row_id in self.rows_ui:
                    self._set_status_color(self.rows_ui[row_id]["status_lbl"], "Đã xóa file")
                    self.rows_ui[row_id]["view_btn"].configure(state="disabled")
                self.log(f"Đã xóa video #{row_id+1}")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def update_row_status(self, row_id, status_text, file_path):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if item:
            item["status"] = status_text
            if file_path: item["file_path"] = file_path
        self.after(0, lambda: self._update_row_ui_safe(row_id, status_text, file_path))

    def _update_row_ui_safe(self, row_id, status_text, file_path):
        if row_id not in self.rows_ui: return
        widgets = self.rows_ui[row_id]
        self._set_status_color(widgets["status_lbl"], status_text)
        if ("Hoàn thành" in status_text or "Đã có" in status_text or "Xong" in status_text):
            if file_path and os.path.exists(file_path):
                widgets["view_btn"].configure(state="normal", command=lambda fp=file_path: os.startfile(fp))

    # FIX #4: scan_prompts_and_files tách 2 phần:
    # - Luôn cho phép cập nhật UI (hiển thị danh sách prompt)
    # - Chỉ chặn khi worker đang chạy VÀ có thay đổi data thực sự (tránh reset UI giữa chừng)
    def scan_prompts_and_files(self, *args):
        raw_txt = self.txt_prompt_input.get("1.0", "end").strip()
        lines = [strip_char_tags(l) for l in raw_txt.split("\n") if l.strip()]
        
        if not lines:
            self.all_prompts_data = []
            self.render_pagination()
            return

        out_dir = self.entry_out_dir.get()
        new_data = []
        pending_count = 0

        for i, text in enumerate(lines):
            filename = os.path.join(out_dir, f"{i + 1:04d}.mp4")

            # Nếu worker đang chạy: giữ nguyên status cũ của item đó, không reset về Waiting
            existing = next((x for x in self.all_prompts_data if x["id"] == i), None)
            if self.worker and self.worker.is_running and existing:
                new_data.append(existing)
                if not existing["file_path"]:
                    pending_count += 1
                continue

            status = "Waiting..."
            f_path = ""
            if os.path.exists(filename):
                status = "✅ Đã có file"
                f_path = filename
            else:
                pending_count += 1

            new_data.append({
                "id": i,
                "text": text,
                "status": status,
                "file_path": f_path,
                "force_regen": False
            })

        self.all_prompts_data = new_data
        self.render_pagination()

        if pending_count == 0 and lines:
            self.log("✨ Dự án này đã đầy đủ video.")

    def merge_video(self):
        folder = self.entry_out_dir.get()
        if not os.path.exists(folder): return
        videos = sorted([f for f in os.listdir(folder) if f.endswith(".mp4") and "merged" not in f])
        
        if len(videos) < 2:
            messagebox.showwarning("Chú ý", "Cần ít nhất 2 video.")
            return
        list_file = os.path.join(folder, "list.txt")
        with open(list_file, "w", encoding="utf-8") as f:
            for vid in videos:
                # FIX #9: Dùng absolute path để ffmpeg không bị lỗi do sai working directory
                f.write(f"file '{os.path.join(os.path.abspath(folder), vid)}'\n")
        output = os.path.join(folder, f"merged_{int(time.time())}.mp4")
        try:
            cmd = f'ffmpeg -f concat -safe 0 -i "{list_file}" -c copy "{output}" -y'
            subprocess.run(cmd, shell=True, check=True)
            messagebox.showinfo("Thành công", f"Đã ghép: {output}")
            os.startfile(folder)
        except Exception as e:
            messagebox.showerror("Lỗi", f"Cần cài FFmpeg.\n{e}")
        finally:
            if os.path.exists(list_file): os.remove(list_file)

# ══════════════════════════════════════════════════════════════════════════════
# ĐIỂM VÀO CHO ALL-TOOL-YOUTUBE
#   alltool gọi:  mod.build_tab(frame, openai_client, gemini_model)
# ══════════════════════════════════════════════════════════════════════════════
_app_instance = None


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Điểm vào cho All-Tool-Youtube. parent là CTkFrame do alltool cấp."""
    global _app_instance
    try:
        start_nestjs_server()          # captcha server, cần cho VEO
    except Exception:
        pass
    _app_instance = VeoTextToVideoTab(parent)
    _app_instance.pack(fill="both", expand=True)
    return _app_instance


if __name__ == "__main__":
    print("=" * 50)
    print("📡 Veo 3 Pro - Đọc từ accounts.json")
    print("=" * 50)
    
    start_nestjs_server()
    
    root = ctk.CTk()
    root.title("Veo 3 Pro (accounts.json mode)")
    root.geometry("1280x800")
    ui = VeoTextToVideoTab(root)
    ui.pack(fill="both", expand=True)
    root.mainloop()