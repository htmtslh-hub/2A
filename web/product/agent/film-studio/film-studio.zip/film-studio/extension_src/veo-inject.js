// ===================================
// VEO INJECT - Hook fetch/XHR để bắt Bearer token (MAIN world)
// ===================================
(function () {
    'use strict';

    console.log('%c[Veo Catcher] Injected ✅', 'color:#00C853;font-weight:bold');
    try { window.__VEO_CATCHER_ACTIVE = true; window.__veoCount = window.__veoCount || 0; } catch (e) {}

    function postToBridge(payload) {
        try { window.postMessage({ __veo_catcher: true, ...payload }, '*'); } catch (e) {}
    }

    function extractToken(headersObj) {
        if (!headersObj) return null;
        let auth = null;
        if (headersObj instanceof Headers) {
            auth = headersObj.get('authorization') || headersObj.get('Authorization');
        } else if (Array.isArray(headersObj)) {
            const found = headersObj.find(h => h[0] && String(h[0]).toLowerCase() === 'authorization');
            if (found) auth = found[1];
        } else if (typeof headersObj === 'object') {
            auth = headersObj.authorization || headersObj.Authorization;
        }
        if (!auth || typeof auth !== 'string') return null;
        const tok = auth.replace(/^Bearer\s+/i, '').trim();
        // Bắt MỌI access token Google trên các endpoint này (ya29... hoặc định dạng mới),
        // miễn là đủ dài — KHÔNG còn ép buộc phải chứa 'ya29'.
        return tok.length >= 20 ? tok : null;
    }

    function isVeoUrl(url) {
        if (!url) return false;
        return url.includes('aisandbox-pa.googleapis.com')
            || url.includes('labs.google/fx/api')
            || url.includes('flow.google.com');
    }

    function getEmailFromDOM() {
        try {
            const sel = 'a[aria-label*="@"], button[aria-label*="@"], div[aria-label*="@"], [data-email]';
            for (const el of document.querySelectorAll(sel)) {
                const al = el.getAttribute('aria-label') || el.getAttribute('data-email') || '';
                const m = al.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/);
                if (m) return m[0];
            }
            const meta = document.querySelector('meta[name="email"], meta[property="email"]');
            if (meta) return meta.content;
        } catch (e) {}
        return null;
    }

    // Gọi khi bắt được token: log rõ + lưu biến để kiểm tra nhanh + đẩy về extension
    function onToken(token, url, src) {
        try { window.__veoLastToken = token; window.__veoCount = (window.__veoCount || 0) + 1; } catch (e) {}
        console.log('%c[Veo Catcher] 🎯 Token bắt được', 'color:#00C853;font-weight:bold',
            token.slice(0, 12) + '…', '| ' + src + ' | ' + (url || '').slice(0, 45));
        postToBridge({ token, email: getEmailFromDOM(), url, src });
    }

    // === PATCH FETCH ===
    const origFetch = window.fetch;
    window.fetch = async function (...args) {
        try {
            let url = '', headers = null;
            const a0 = args[0];
            if (typeof a0 === 'string') { url = a0; headers = args[1] && args[1].headers; }
            else if (a0 instanceof Request) { url = a0.url; headers = a0.headers; }
            else if (typeof URL !== 'undefined' && a0 instanceof URL) { url = a0.href; headers = args[1] && args[1].headers; }
            else if (a0 && typeof a0 === 'object') { url = a0.url || a0.href || ''; headers = (args[1] && args[1].headers) || a0.headers; }
            if (isVeoUrl(url)) {
                const token = extractToken(headers);
                if (token) onToken(token, url, 'fetch');
                else console.debug('[Veo Catcher] URL khớp nhưng KHÔNG thấy Bearer:', (url || '').slice(0, 60));
            }
        } catch (e) {}

        const response = await origFetch.apply(this, args);

        try {
            const a0 = args[0];
            const url = typeof a0 === 'string' ? a0 : (a0?.url || a0?.href || '');
            if (url.includes('aisandbox-pa.googleapis.com/v1/credits')) {
                const cloned = response.clone();
                cloned.json().then(data => {
                    const credits = data?.remainingCredits || data?.credits || data?.balance
                        || data?.user?.remainingCredits || data?.user?.credits;
                    if (credits != null) postToBridge({ credits: String(credits), email: getEmailFromDOM(), src: 'credits-response' });
                }).catch(() => {});
            }
        } catch (e) {}
        return response;
    };

    // === PATCH XHR ===
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

    XMLHttpRequest.prototype.open = function (method, url) {
        this._veo_url = url; this._veo_headers = {};
        return origOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
        if (this._veo_headers) this._veo_headers[String(name).toLowerCase()] = value;
        return origSetHeader.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
        try {
            if (isVeoUrl(this._veo_url)) {
                const token = extractToken(this._veo_headers);
                if (token) onToken(token, this._veo_url, 'xhr');
                else console.debug('[Veo Catcher] (XHR) URL khớp nhưng KHÔNG thấy Bearer:', (this._veo_url || '').slice(0, 60));
            }
        } catch (e) {}
        return origSend.apply(this, arguments);
    };
})();
