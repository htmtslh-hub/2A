import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger } from '@nestjs/common';
import { CaptchaAction } from 'src/constant';

@WebSocketGateway({
  cors: {
    origin: '*',
  },
})
export class CaptchaGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private logger = new Logger(CaptchaGateway.name);
  private connectedClients = new Map<string, Socket>();
  private readyClients = new Set<string>(); // Track clients đã emit client:ready
  private pendingRequests = new Map<string, any>();

  handleConnection(client: Socket) {
    this.logger.log(`✅ Client connected: ${client.id}`);
    this.connectedClients.set(client.id, client);
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`❌ Client disconnected: ${client.id}`);
    this.connectedClients.delete(client.id);
    this.readyClients.delete(client.id);
  }

  @SubscribeMessage('client:ready')
  handleClientReady(client: Socket, data: any) {
    this.logger.log(`🎉 Client ready: ${client.id}`);
    this.readyClients.add(client.id);
  }

  @SubscribeMessage('client:captcha-solved')
  handleCaptchaSolved(client: Socket, data: any) {
    this.logger.log(`✅ Captcha solved: ${data.token.substring(0, 50)}...`);

    if (data.requestId && this.pendingRequests.has(data.requestId)) {
      const { resolve, timer } = this.pendingRequests.get(data.requestId);
      clearTimeout(timer); // Dọn timer tránh memory leak
      resolve(data.token);
      this.pendingRequests.delete(data.requestId);
    }
  }

  @SubscribeMessage('client:captcha-error')
  handleCaptchaError(client: Socket, data: any) {
    this.logger.error(`❌ Captcha error: ${data.error}`);

    if (data.requestId && this.pendingRequests.has(data.requestId)) {
      const { reject, timer } = this.pendingRequests.get(data.requestId);
      clearTimeout(timer);
      reject(new Error(data.error));
      this.pendingRequests.delete(data.requestId);
    }
  }

  @SubscribeMessage('client:captcha-manual')
  handleCaptchaManual(client: Socket, data: any) {
    this.logger.log(`📨 Manual captcha: ${data.token.substring(0, 50)}...`);
  }

  // Chờ cho đến khi có ít nhất 1 client ready (tối đa waitMs)
  private async waitForReadyClient(waitMs = 60000): Promise<Socket> {
    const start = Date.now();
    while (Date.now() - start < waitMs) {
      // Tìm client vừa connected vừa ready
      for (const [id, socket] of this.connectedClients) {
        if (this.readyClients.has(id)) return socket;
      }
      await new Promise((r) => setTimeout(r, 500));
    }
    throw new Error('No ready browser clients (reCAPTCHA chưa load xong)');
  }

  // Method để request captcha từ service khác
  async requestCaptcha(
    action: CaptchaAction,
    timeout = 90000, // Tăng lên 90s (reCAPTCHA có thể mất 30-40s load)
  ): Promise<string> {
    // Chờ client ready thay vì lấy client bất kỳ
    const client = await this.waitForReadyClient(timeout);
    const requestId = `req_${Date.now()}_${crypto.randomUUID()}`;

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        if (this.pendingRequests.has(requestId)) {
          this.pendingRequests.delete(requestId);
          reject(new Error('Captcha request timeout'));
        }
      }, timeout);

      // Lưu cả timer để clearTimeout khi resolve
      this.pendingRequests.set(requestId, { resolve, reject, timer });

      console.log('Sending captcha request with action:', action);
      client.emit('server:request-captcha', { requestId, action });

      this.logger.log(`📤 Sent captcha request: ${requestId}`);
    });
  }

  async forceRefresh() {
    this.logger.log('🔄 Forcing captcha refresh on all clients...');
    this.connectedClients.forEach((client) => {
      client.emit('server:reload-page');
    });
  }
}
