import { Controller, Get, Post, Query, Body } from '@nestjs/common';
import { CaptchaService } from './captcha.service';
import { ApiResponse, ApiTags } from '@nestjs/swagger';
import { GetCaptchaQuery } from './captcha.dto';
import { randomUUID } from 'crypto';

@Controller('captcha')
@ApiTags('Captcha')
export class CaptchaController {
  constructor(private readonly captchaService: CaptchaService) {}

  @Get('')
  @ApiResponse({
    status: 200,
    description: 'Get captcha solution',
    schema: {
      type: 'object',
      properties: {
        captcha: { type: 'string' },
      },
    },
  })
  async getCaptcha(
    @Query() query: GetCaptchaQuery,
  ): Promise<{ captcha: string }> {
    const { action } = query;
    const captcha = await this.captchaService.getCaptcha(action, query.isDebug);
    return { captcha };
  }

  @Post('force-refresh')
  async forceRefresh() {
    await this.captchaService.forceRefresh();
  }

  // Mở trang project mới trên browser — reCAPTCHA sẽ load ở đó
  @Post('open-project')
  async openProject() {
    const projectId = randomUUID();
    const url = `https://flow.google.com/project/${projectId}`;
    await this.captchaService.navigate(url);
    return { url, projectId };
  }

  // Mở bất kỳ URL nào trên browser
  @Post('navigate')
  async navigate(@Query('url') url: string) {
    if (!url) {
      url = 'https://labs.google/fx/tools/video-fx';
    }
    await this.captchaService.navigate(url);
    return { url };
  }
}
