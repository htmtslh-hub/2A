import { Injectable, Logger } from '@nestjs/common';
import { CaptchaGateway } from './captcha.gateway';
import { CaptchaAction } from 'src/constant';

@Injectable()
export class CaptchaService {
  constructor(private readonly captchaGateway: CaptchaGateway) {}
  private logger = new Logger(CaptchaService.name);

  async getCaptcha(
    action: CaptchaAction = CaptchaAction.VIDEO_GENERATION,
    isDebug: boolean = false,
  ): Promise<string> {
    const maxRetries = 3;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        this.logger.log(`Requesting captcha (attempt ${attempt}/${maxRetries})...`);
        const token = await this.captchaGateway.requestCaptcha(action);
        return token;
      } catch (error) {
        this.logger.error(`Attempt ${attempt} failed: ${error.message}`);

        if (attempt === maxRetries) {
          throw error;
        }

        // Đợi 5s trước khi retry — cho client kịp load reCAPTCHA
        this.logger.log(`Retrying in 5 seconds...`);
        await new Promise((r) => setTimeout(r, 5000));
      }
    }
  }

  async forceRefresh() {
    this.logger.log('Forcing captcha refresh...');
    await this.captchaGateway.forceRefresh();
  }

  async navigate(url: string) {
    this.logger.log(`Navigating browser to: ${url}`);
    await this.captchaGateway.navigateClients(url);
  }
}
