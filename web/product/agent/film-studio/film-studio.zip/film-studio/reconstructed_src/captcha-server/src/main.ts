import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['log', 'error', 'warn'],
  });
  app.enableCors({ origin: '*' });
  await app.listen(3000);

  console.log('');
  console.log('  ╔══════════════════════════════════════════╗');
  console.log('  ║      🛡️   HT CAPTCHA SERVER v1.1.0      ║');
  console.log('  ║          Powered by NestJS               ║');
  console.log('  ╚══════════════════════════════════════════╝');
  console.log('');
  console.log('  🚀 HTTP    : http://localhost:3000');
  console.log('  📡 Socket  : ws://localhost:3000');
  console.log('  ⏳ Status  : Waiting for browser captcha...');
  console.log('');
  console.log('  💡 Mở Chrome captcha → labs.google → login Google');
  console.log('');
}
bootstrap();
