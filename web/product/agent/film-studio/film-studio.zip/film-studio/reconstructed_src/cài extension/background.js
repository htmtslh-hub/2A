// ===================================
// HT COMBINED BACKGROUND - Service Worker v3.0
// Captcha Client (alarm, settings, header capture)
// + Veo Catcher (token storage, cookie reading)
// ===================================

console.log('🔧 HT Combined Background: Started');

// ================== CAPTCHA CLIENT ==================

const DEFAULT_SETTINGS = {
    autoReload: false,
    reloadInterval: 0,
    enabled: true,
    clearGrecaptcha: false
};

async function getSettings() {
    return await chrome.storage.sync.get(DEFAULT_SETTINGS);
}

async function saveSettings(settings) {
    await chrome.storage.sync.set(settings);
}

async function createReloadAlarm() {
    const settings = await getSettings();
    await chrome.alarms.clear('autoReload');

    if (settings.enabled && settings.autoReload && settings.reloadInterval > 0) {
        await chrome.alarms.create('autoReload', {
            periodInMinutes: settings.reloadInterval
        });
        console.log(`✅ Auto reload alarm set: ${settings.reloadInterval} minutes`);
    } else {
        console.log('⏸️ Auto reload disabled');
    }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
    // ★ kéo token + TỰ ĐĂNG NHẬP LẠI khi token chết (trước chỉ fetchLabsToken → labs.google
    //   cứ trả lại đúng token cũ đã hết hạn, autoHealToken viết sẵn mà không ai gọi)
    if (alarm.name === 'fetchToken') { await autoHealToken(); return; }
    if (alarm.name === 'autoReload') {
        const settings = await getSettings();
        if (!settings.enabled || !settings.autoReload) return;

        console.log('⏰ Auto reload triggered');
        const tabs = await chrome.tabs.query({ active: true });
        for (const tab of tabs) {
            try {
                await chrome.tabs.sendMessage(tab.id, { type: 'RELOAD_PAGE' });
            } catch (e) {}
        }
    }
});

// Header capture
const WANTED_HEADERS = [
    'authorization', 'x-browser-validation', 'x-client-data',
    'x-browser-channel', 'x-browser-year', 'x-browser-copyright',
    'sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform',
    'user-agent', 'accept-language', 'priority'
];

chrome.webRequest.onSendHeaders.addListener(
    (details) => {
        try {
            const captured = {};
            for (const h of details.requestHeaders || []) {
                const name = h.name.toLowerCase();
                if (WANTED_HEADERS.includes(name)) captured[name] = h.value;
            }
            if (Object.keys(captured).length === 0) return;

            chrome.storage.local.set({ captured_headers: { headers: captured, timestamp: Date.now() } });

            chrome.tabs.query({}, (tabs) => {
                for (const tab of tabs) {
                    if (tab.url && (tab.url.includes('labs.google') || tab.url.includes('flow.google.com'))) {
                        chrome.tabs.sendMessage(tab.id, { type: 'CAPTURED_HEADERS', headers: captured }).catch(() => {});
                    }
                }
            });
        } catch (e) {
            console.error('Header capture error:', e);
        }
    },
    { urls: ['*://aisandbox-pa.googleapis.com/*'] },
    ['requestHeaders', 'extraHeaders']
);

// ================== VEO CATCHER ==================

const STORE_KEY = 'veo_captures';
const SESSION_COOKIE = '__Secure-next-auth.session-token';

async function loadStore() {
    const o = await chrome.storage.local.get(STORE_KEY);
    return o[STORE_KEY] || {};
}

async function saveStore(store) {
    await chrome.storage.local.set({ [STORE_KEY]: store });
}

async function readLabsSession() {
    try {
        const labsCookies = await chrome.cookies.getAll({ domain: 'labs.google' });
        const flowCookies = await chrome.cookies.getAll({ domain: 'flow.google.com' });
        const cookies = [...(labsCookies || []), ...(flowCookies || [])];
        if (!cookies.length) return '';

        const chunks = cookies
            .filter(c => c.name.startsWith(SESSION_COOKIE + '.'))
            .sort((a, b) => {
                const ai = parseInt(a.name.split('.').pop(), 10);
                const bi = parseInt(b.name.split('.').pop(), 10);
                return (isNaN(ai) ? 0 : ai) - (isNaN(bi) ? 0 : bi);
            });
        if (chunks.length) return chunks.map(c => c.value).join('');

        const single = cookies.find(c => c.name === SESSION_COOKIE);
        return single ? single.value : '';
    } catch (e) {
        console.warn('[Veo] readLabsSession error:', e);
        return '';
    }
}

// Token ya29 sống ~1h → coi như chết sau 55 phút
const TOKEN_TTL_MS = 55 * 60 * 1000;

function keyFor(email, token, session) {
    if (email) return email.toLowerCase();
    // Định danh theo TOKEN: cùng token = cùng 1 record. Ổn định cả trong lúc trang mới load
    // (session cookie lúc đó bị ghép nhiều mảnh, đổi liên tục → KHÔNG dùng để key).
    if (token) return 'tok_' + token.slice(-16);
    if (session) return 'sess_' + session.slice(-12);
    return 'unknown_' + Math.random().toString(36).slice(2, 10);
}

// Xoá các record đã quá hạn (token chết) → kho không phình, không lẫn token cũ
function purgeStale(store) {
    const now = Date.now();
    let changed = false;
    for (const k of Object.keys(store)) {
        if (now - (store[k].lastSeen || 0) > TOKEN_TTL_MS) { delete store[k]; changed = true; }
    }
    return changed;
}

// Gộp trùng token + dọn token chết. Dùng để làm sạch đám record cũ (bản trước key theo session
// nên cùng 1 token bị tách thành nhiều dòng) — chỉ giữ dòng mới nhất cho mỗi token.
function dedupeStore(store) {
    let changed = purgeStale(store);
    const seen = {}; // token -> key đang giữ (mới nhất)
    for (const k of Object.keys(store)) {
        const t = store[k].token;
        if (!t) continue;
        const prevKey = seen[t];
        if (prevKey == null) { seen[t] = k; continue; }
        const keep = (store[k].lastSeen || 0) >= (store[prevKey].lastSeen || 0) ? k : prevKey;
        const drop = keep === k ? prevKey : k;
        delete store[drop];
        seen[t] = keep;
        changed = true;
    }
    return changed;
}

// Chạy tuần tự: nhiều request bắn cùng lúc → xử lý lần lượt, tránh race read-modify-write
let _captureChain = Promise.resolve();
function handleCapture(data) {
    _captureChain = _captureChain.then(() => _handleCaptureInner(data)).catch((e) => {
        console.warn('[Veo] handleCapture error:', e);
    });
    return _captureChain;
}

async function _handleCaptureInner(data) {
    const store = await loadStore();
    const now = Date.now();

    if (data.token) {
        const labs_session = await readLabsSession();
        const k = keyFor(data.email, data.token, labs_session);
        // Gộp về 1 record: xoá mọi dòng KHÁC key mà trùng token (duplicate cũ) hoặc
        // trùng session (token đã bị xoay vòng, giữ token mới).
        for (const kk of Object.keys(store)) {
            if (kk === k) continue;
            const r = store[kk];
            if ((r.token && r.token === data.token) ||
                (labs_session && r.labs_session === labs_session)) {
                delete store[kk];
            }
        }
        const prev = store[k] || {};
        store[k] = {
            ...prev,
            email: data.email || prev.email || '',
            token: data.token,
            labs_session: labs_session || prev.labs_session || '',
            credits: prev.credits || '',
            expires: data.expires || prev.expires || '',   // hạn thật của ya29 (từ auth/session)
            lastSeen: now,
        };
        dedupeStore(store);
        await saveStore(store);
        return;
    }

    if (data.credits != null) {
        let k = data.email ? keyFor(data.email, null) : null;
        let target = k ? store[k] : null;
        if (!target) {
            target = Object.values(store).sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0))[0];
        }
        if (target) {
            target.credits = String(data.credits);
            target.lastSeen = now;
            await saveStore(store);
        }
    }
}

// ══════════════════════════════════════════════════════════
// LẤY TOKEN ya29 TỪ ENDPOINT AUTH SESSION
// Flow mới (Angular/batchexecute) KHÔNG còn phát ya29 qua fetch để veo-inject bắt.
// NHƯNG labs.google/fx/api/auth/session vẫn trả { user:{email}, access_token: ya29..., expires }.
// → Chủ động GET endpoint này là có token, thay vì rình fetch (giờ trống).
// ══════════════════════════════════════════════════════════
let _lastTokenFetch = 0;

async function fetchLabsToken() {
    try {
        const res = await fetch('https://labs.google/fx/api/auth/session', {
            credentials: 'include',
            cache: 'no-store',
            headers: { 'accept': 'application/json' }
        });
        if (!res.ok) { console.warn('[Veo] auth/session HTTP', res.status); return null; }
        const data = await res.json().catch(() => null);
        if (!data) return null;
        const token = data.access_token;
        const email = (data.user && data.user.email) || '';
        if (token && typeof token === 'string' && token.length >= 20) {
            const expires = data.expires || '';
            const expTs = expires ? Date.parse(expires) : NaN;
            const expired = !isNaN(expTs) ? Date.now() >= expTs : (data.error === 'ACCESS_TOKEN_REFRESH_NEEDED');
            await handleCapture({ token, email, expires, url: 'labs/auth/session', src: 'session' });
            console.log('%c[Veo] 🎯 Token từ auth/session', 'color:#00C853;font-weight:bold',
                email || '(no email)', token.slice(0, 12) + '…',
                expired ? '⚠️ HẾT HẠN — cần đăng nhập lại' : ('✅ còn hạn tới ' + expires));
            return { token, email, expires, expired };
        }
        console.warn('[Veo] auth/session không có access_token (chưa đăng nhập labs.google?)');
    } catch (e) {
        console.warn('[Veo] fetchLabsToken error:', e);
    }
    return null;
}

// Gọi có tiết chế: tối đa 1 lần / 20s (tránh spam khi popup poll liên tục)
async function maybeFetchToken(force) {
    const now = Date.now();
    if (!force && now - _lastTokenFetch < 20000) return;
    _lastTokenFetch = now;
    await fetchLabsToken();
}

// Khi 1 tab labs/flow load xong (kể cả bấm "Lấy Token" mở labs.google/fx/vi) → tự kéo token ngay
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status === 'complete' && tab && tab.url &&
        (tab.url.includes('labs.google') || tab.url.includes('flow.google.com'))) {
        autoHealToken();   // token vẫn chết sau khi mở trang → tự đăng nhập lại
    }
});

// ══════════════════════════════════════════════════════════
// TỰ ĐĂNG NHẬP LẠI IM LẶNG (silent re-auth) — lấy ya29 TƯƠI khi token chết
// mà GET auth/session không refresh được. User vẫn đăng nhập Google → Google
// tự duyệt (không cần gõ gì). Nếu Google bắt chọn tài khoản/xác nhận → đưa tab ra cho user.
// ══════════════════════════════════════════════════════════
let _reauthRunning = false;

// Số lần thử / lần thử gần nhất LƯU vào storage: service worker MV3 bị Chrome tắt khi
// rảnh ~30s, biến trong bộ nhớ mất → nếu để biến thường thì mỗi lần alarm đánh thức là
// "chưa thử lần nào" → mở tab đăng nhập MỖI PHÚT. Lưu storage thì giới hạn giữ được.
async function getHealState() {
    const o = await chrome.storage.local.get('heal_state');
    return o.heal_state || { lastReauth: 0, fails: 0 };
}
async function setHealState(s) {
    await chrome.storage.local.set({ heal_state: s });
}

// Chờ tab điều hướng về labs/flow (callback OAuth xong) trong waitMs
function waitForTabLanding(tabId, waitMs) {
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => {
            if (done) return; done = true;
            try { chrome.tabs.onUpdated.removeListener(onUpd); } catch (e) {}
            clearTimeout(timer); resolve(v);
        };
        const onUpd = (id, info, tab) => {
            if (id !== tabId) return;
            const u = (tab && tab.url) || '';
            if (info.status === 'complete' && (u.includes('labs.google') || u.includes('flow.google.com'))) finish(true);
        };
        chrome.tabs.onUpdated.addListener(onUpd);
        const timer = setTimeout(() => finish(false), waitMs);
    });
}

async function silentReauth() {
    if (_reauthRunning) return { ok: false, reason: 'đang chạy' };
    _reauthRunning = true;
    let tabId = null;
    try {
        // 1) Lấy CSRF token của NextAuth
        const csrfRes = await fetch('https://labs.google/fx/api/auth/csrf', { credentials: 'include', cache: 'no-store' });
        const csrf = (await csrfRes.json().catch(() => ({}))).csrfToken;
        if (!csrf) return { ok: false, reason: 'không lấy được csrf (chưa đăng nhập Google?)' };

        // 2) Khởi tạo signin Google, xin URL OAuth (không redirect, trả JSON)
        const body = new URLSearchParams({ csrfToken: csrf, callbackUrl: 'https://labs.google/fx/vi', json: 'true' });
        const signinRes = await fetch('https://labs.google/fx/api/auth/signin/google', {
            method: 'POST', credentials: 'include', cache: 'no-store',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Auth-Return-Redirect': '1' },
            body
        });
        const oauthUrl = (await signinRes.json().catch(() => ({}))).url;
        if (!oauthUrl) return { ok: false, reason: 'không lấy được URL OAuth (NextAuth đổi?)' };

        // 3) Mở tab NGẦM chạy qua luồng OAuth (Google tự duyệt vì đã đăng nhập)
        const created = await chrome.tabs.create({ url: oauthUrl, active: false });
        tabId = created.id;

        // 4) Chờ tab quay về labs/flow (callback xong) — tối đa 25s
        const landed = await waitForTabLanding(tabId, 25000);
        if (!landed) {
            // Kẹt ở màn Google (chọn tài khoản/xác nhận) → đưa tab ra cho user tự làm, KHÔNG đóng
            try { await chrome.tabs.update(tabId, { active: true }); } catch (e) {}
            tabId = null; // đừng đóng ở finally
            return { ok: false, needUser: true, reason: 'Google cần bạn chọn tài khoản/xác nhận — đã mở tab, làm xong rồi bấm lại' };
        }

        // 5) Lấy token tươi
        const r = await fetchLabsToken();
        const ok = !!(r && !r.expired);
        return { ok, reason: r ? (r.expired ? 'vẫn hết hạn (refresh_token có thể đã hỏng → đăng nhập tay)' : 'OK tươi') : 'không có token', expires: r?.expires || '' };
    } catch (e) {
        return { ok: false, reason: String(e) };
    } finally {
        if (tabId != null) {
            try {
                const t = await chrome.tabs.get(tabId);
                if (t && t.url && (t.url.includes('labs.google') || t.url.includes('flow.google.com'))) {
                    await chrome.tabs.remove(tabId); // đóng tab ngầm khi đã về labs/flow
                }
            } catch (e) {}
        }
        _reauthRunning = false;
    }
}

// Alarm / mở trang labs gọi: kéo token; nếu chết thì tự silent re-auth (tiết chế, dừng sau 3 lần fail)
async function autoHealToken() {
    const r = await fetchLabsToken();
    if (r && !r.expired) {
        const st = await getHealState();
        if (st.fails || st.lastReauth) await setHealState({ lastReauth: 0, fails: 0 });
        return;
    }
    if (r && r.expired) await reauthIfAllowed();
}

// Tự đăng nhập lại nếu còn được phép: tối đa 3 lần thất bại liên tiếp, mỗi lần cách ≥ 5 phút.
// Thành công (có token còn hạn) là đếm lại từ đầu.
async function reauthIfAllowed() {
    if (_reauthRunning) return;
    const st = await getHealState();
    const now = Date.now();
    if (st.fails >= 3 || now - (st.lastReauth || 0) < 5 * 60 * 1000) return;
    await setHealState({ lastReauth: now, fails: st.fails || 0 });
    console.log('[Veo] Token hết hạn → tự đăng nhập lại (silent)…');
    const rr = await silentReauth();
    if (rr.ok) {
        await setHealState({ lastReauth: 0, fails: 0 });
        console.log('%c[Veo] ✅ Silent re-auth OK — token tươi', 'color:#00C853');
    } else {
        const fails = (st.fails || 0) + 1;
        await setHealState({ lastReauth: now, fails });
        console.warn('[Veo] silent reauth chưa được:', rr.reason, '(lần', fails + ')');
    }
}

// Có ít nhất 1 token CÒN HẠN không (cùng tiêu chí với popup: ưu tiên 'expires' từ auth/session)
function isFreshRecord(c) {
    if (!c || !c.token) return false;
    if (c.expires) { const t = Date.parse(c.expires); if (!isNaN(t)) return Date.now() < t; }
    return (Date.now() - (c.lastSeen || 0)) < TOKEN_TTL_MS;
}
function hasFreshToken(store) {
    return Object.values(store || {}).some(isFreshRecord);
}

// ================== CDP HARDWARE-LEVEL INPUT ==================
const attachedTabs = new Set();
if (chrome.debugger && chrome.debugger.onDetach) {
    chrome.debugger.onDetach.addListener((source) => {
        if (source?.tabId) attachedTabs.delete(source.tabId);
    });
}

async function attachDebugger(tabId) {
    if (!chrome.debugger) {
        throw new Error('chrome.debugger API is undefined. Extension needs reload in coccoc://extensions.');
    }
    if (attachedTabs.has(tabId)) return;
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            attachedTabs.add(tabId);
            resolve();
        }, 3000);
        chrome.debugger.attach({ tabId }, '1.3', () => {
            clearTimeout(timer);
            if (chrome.runtime.lastError) {
                const err = chrome.runtime.lastError.message || '';
                if (err.includes('already attached') || err.includes('Another debugger')) {
                    attachedTabs.add(tabId);
                    resolve();
                } else {
                    reject(new Error(err));
                }
            } else {
                attachedTabs.add(tabId);
                resolve();
            }
        });
    });
}

async function sendCdp(tabId, method, params = {}) {
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            reject(new Error(`sendCdp timeout (${method})`));
        }, 3000);
        chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
            clearTimeout(timer);
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(result);
        });
    });
}

async function cdpClick(tabId, x, y) {
    await attachDebugger(tabId);
    await sendCdp(tabId, 'Input.dispatchMouseEvent', {
        type: 'mouseMoved',
        x: Math.round(x),
        y: Math.round(y),
        pointerType: 'mouse'
    }).catch(() => {});
    await new Promise(r => setTimeout(r, 30));
    await sendCdp(tabId, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        x: Math.round(x),
        y: Math.round(y),
        button: 'left',
        buttons: 1,
        clickCount: 1,
        pointerType: 'mouse'
    });
    await new Promise(r => setTimeout(r, 60));
    await sendCdp(tabId, 'Input.dispatchMouseEvent', {
        type: 'mouseReleased',
        x: Math.round(x),
        y: Math.round(y),
        button: 'left',
        buttons: 0,
        clickCount: 1,
        pointerType: 'mouse'
    });
}

// ========= CDP UPLOAD FILE (nạp ảnh ref vào input tạo-động của Flow) =========
// Input file của Flow chỉ sinh ra khi bấm "Tệp tải lên". Nên ta CHẶN hộp thoại
// chọn file (setInterceptFileChooserDialog) rồi bơm file bằng DOM.setFileInputFiles.
const pendingFileUpload = new Map();   // tabId -> filePath
let _fileChooserHooked = false;
function ensureFileChooserListener() {
    if (_fileChooserHooked || !chrome.debugger || !chrome.debugger.onEvent) return;
    _fileChooserHooked = true;
    chrome.debugger.onEvent.addListener(async (source, method, params) => {
        if (method !== 'Page.fileChooserOpened') return;
        const tabId = source && source.tabId;
        if (tabId == null) return;
        const filePath = pendingFileUpload.get(tabId);
        if (!filePath) return;
        pendingFileUpload.delete(tabId);
        try {
            await sendCdp(tabId, 'DOM.setFileInputFiles', {
                files: [filePath],
                backendNodeId: params.backendNodeId
            });
            console.log('[CDP] đã bơm file vào input:', filePath);
        } catch (e) {
            console.warn('[CDP] setFileInputFiles lỗi:', e);
        }
        try { await sendCdp(tabId, 'Page.setInterceptFileChooserDialog', { enabled: false }); } catch (e) {}
    });
}

async function armFileUpload(tabId, filePath) {
    await attachDebugger(tabId);
    ensureFileChooserListener();
    try { await sendCdp(tabId, 'Page.enable', {}); } catch (e) {}
    try { await sendCdp(tabId, 'DOM.enable', {}); } catch (e) {}
    pendingFileUpload.set(tabId, filePath);
    await sendCdp(tabId, 'Page.setInterceptFileChooserDialog', { enabled: true });
    // tự huỷ sau 25s nếu không có hộp thoại nào bật (tránh kẹt intercept)
    setTimeout(async () => {
        if (pendingFileUpload.get(tabId) === filePath) {
            pendingFileUpload.delete(tabId);
            try { await sendCdp(tabId, 'Page.setInterceptFileChooserDialog', { enabled: false }); } catch (e) {}
        }
    }, 25000);
}

// ================== ĐA LUỒNG: QUẢN LÝ CỬA SỔ FLOW THEO SLOT ==================
// Mỗi luồng của tool = 1 cửa sổ Flow riêng (cùng profile, cùng tài khoản) → không giành ô prompt.
let _htSlotMapMem = {};
async function htLoadSlotMap() {
    try {
        const r = await chrome.storage.session.get('htSlotMap');
        return Object.assign({}, _htSlotMapMem, (r && r.htSlotMap) || {});
    } catch (e) { return Object.assign({}, _htSlotMapMem); }
}
async function htSaveSlotMap(map) {
    _htSlotMapMem = Object.assign({}, map);
    try { await chrome.storage.session.set({ htSlotMap: map }); } catch (e) {}
}
async function htListSlots() {
    const tabs = await chrome.tabs.query({ url: '*://flow.google.com/*' });
    const map = await htLoadSlotMap();
    const byTab = {};
    for (const [s, id] of Object.entries(map)) byTab[id] = s;
    return await Promise.all(tabs.map(async (t) => {
        let slot = '';
        try {
            const r = await Promise.race([
                chrome.tabs.sendMessage(t.id, { type: 'HT_GET_SLOT' }),
                new Promise((res) => setTimeout(() => res(null), 1500))
            ]);
            slot = String((r && r.slot) || '');
        } catch (e) {}
        if (!slot && byTab[t.id]) slot = String(byTab[t.id]);
        return { tabId: t.id, windowId: t.windowId, slot, url: t.url, status: t.status };
    }));
}
async function htFindSlotTab(slot, list = null, map = null) {
    if (!slot) return null;
    map = map || await htLoadSlotMap();
    const mid = map[slot];
    if (mid) {
        try {
            const t = await chrome.tabs.get(mid);
            if (t && /flow\.google\.com/.test(t.url || t.pendingUrl || '')) return mid;
        } catch (e) {}
    }
    list = list || await htListSlots();
    const hit = list.find((x) => x.slot === slot);
    if (hit) {
        map[slot] = hit.tabId;
        await htSaveSlotMap(map);
        return hit.tabId;
    }
    return null;
}
async function htEnsureSlots(msg) {
    const n = Math.max(1, Math.min(9, parseInt(msg.n, 10) || 1));
    // base: slot thực = base + 1..n (tool ảnh dùng 1..9, tool video dùng 11..19 → 2 tool chạy cùng lúc không giành cửa sổ)
    const base = Math.max(0, Math.min(90, parseInt(msg.base, 10) || 0));
    const wantMin = !!msg.minimized;
    const pid = String(msg.pid || '').trim();
    const sc = msg.screen || {};
    const W = sc.w || 1920, H = sc.h || 1040, L = sc.l || 0, T = sc.t || 0;
    const cols = Math.ceil(Math.sqrt(n)), rows = Math.ceil(n / cols);
    const w = Math.floor(W / cols), h = Math.floor(H / rows);
    const list = await htListSlots();
    const map = await htLoadSlotMap();
    const out = [];
    for (let k = 1; k <= n; k++) {
        const i = base + k;
        const b = { left: L + ((k - 1) % cols) * w, top: T + Math.floor((k - 1) / cols) * h, width: w, height: h };
        let tabId = await htFindSlotTab(String(i), list, map);
        if (tabId) {
            try {
                const tab = await chrome.tabs.get(tabId);
                const win = await chrome.windows.get(tab.windowId, { populate: true });
                // chỉ xếp lại cửa sổ riêng của slot (1 tab) — không đụng cửa sổ chính của người dùng
                if (win.tabs && win.tabs.length === 1) {
                    if (wantMin) {
                        if (win.state !== 'minimized') await chrome.windows.update(win.id, { state: 'minimized' });
                    } else {
                        if (win.state !== 'normal') await chrome.windows.update(win.id, { state: 'normal' });
                        await chrome.windows.update(win.id, b);
                    }
                }
                out.push({ slot: i, tabId, created: false });
                continue;
            } catch (e) { tabId = null; }
        }
        if (!pid) { out.push({ slot: i, tabId: null, error: 'thiếu project id' }); continue; }
        const url = 'https://flow.google.com/project/' + pid + '#htslot=' + i;
        try {
            const win = await chrome.windows.create(Object.assign({ url, type: 'normal', focused: false }, b));
            const t = win.tabs && win.tabs[0];
            if (t) map[String(i)] = t.id;
            if (wantMin) { try { await chrome.windows.update(win.id, { state: 'minimized' }); } catch (e) {} }
            out.push({ slot: i, tabId: t ? t.id : null, created: true });
        } catch (e) {
            out.push({ slot: i, tabId: null, error: String(e && e.message || e) });
        }
    }
    await htSaveSlotMap(map);
    return { ok: true, slots: out, grid: { cols, rows, w, h } };
}

// ================== MESSAGE HANDLER (combined) ==================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        try {
            // Captcha Client messages
            if (msg.type === 'GET_SETTINGS') {
                const settings = await getSettings();
                const alarms = await chrome.alarms.getAll();
                const autoReloadAlarm = alarms.find(a => a.name === 'autoReload');
                settings.targetTime = autoReloadAlarm ? autoReloadAlarm.scheduledTime : null;
                sendResponse(settings);
                return;
            }
            if (msg.type === 'SAVE_SETTINGS') {
                await saveSettings(msg.settings);
                await createReloadAlarm();
                sendResponse({ success: true });
                return;
            }
            if (msg.type === 'RELOAD_NOW') {
                const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'RELOAD_PAGE' });
                sendResponse({ success: true });
                return;
            }
            if (msg.type === 'RELOAD_EXTENSION') {
                sendResponse({ success: true });
                chrome.runtime.reload();
                return;
            }
            if (msg.type === 'CAPTCHA_STATUS_UPDATE') {
                console.log('📊 Captcha status:', msg.data);
                sendResponse({ ok: true });
                return;
            }

            // Veo Catcher messages
            if (msg.type === 'capture') {
                await handleCapture(msg.data || {});
                sendResponse({ ok: true });
                return;
            }
            if (msg.type === 'getAll') {
                let store = await loadStore();
                if (!hasFreshToken(store)) {
                    // ★ Không còn token CÒN HẠN → CHỜ lấy token mới xong rồi mới trả. Trước: trả
                    //   ngay token cũ đã chết rồi mới kéo ở nền (không chờ, chặn 20s/lần) → bấm
                    //   mãi vẫn hiện cái cũ. Chặn nhẹ 3s để trang bắn nhiều request không gọi dồn.
                    if (Date.now() - _lastTokenFetch >= 3000) {
                        _lastTokenFetch = Date.now();
                        const r = await fetchLabsToken();
                        if (r && r.expired) reauthIfAllowed(); // labs vẫn trả token chết → tự đăng nhập lại ở nền
                        store = await loadStore();
                    }
                } else {
                    maybeFetchToken(); // còn hạn → trả ngay, kéo token mới ở nền như cũ
                }
                if (dedupeStore(store)) await saveStore(store); // gộp trùng token + dọn token chết
                sendResponse({ captures: store });
                return;
            }
            if (msg.type === 'refreshToken') {
                const r = await fetchLabsToken();
                const store = await loadStore();
                sendResponse({ ok: !!r, token: r?.token || '', email: r?.email || '', captures: store });
                return;
            }
            if (msg.type === 'deleteOne') {
                const store = await loadStore();
                delete store[msg.key];
                await saveStore(store);
                sendResponse({ ok: true });
                return;
            }
            if (msg.type === 'clearAll') {
                await saveStore({});
                sendResponse({ ok: true });
                return;
            }
            if (msg.type === 'RELOAD_EXTENSION') {
                sendResponse({ ok: true });
                setTimeout(() => { chrome.runtime.reload(); }, 100);
                return;
            }
            if (msg.type === 'GET_COOKIES') {
                const c1 = await chrome.cookies.getAll({ domain: '.google.com' });
                const c2 = await chrome.cookies.getAll({ url: 'https://flow.google.com' });
                const dict = {};
                for (const c of (c1 || [])) dict[c.name] = c.value;
                for (const c of (c2 || [])) dict[c.name] = c.value;
                sendResponse({ ok: true, cookies: dict });
                return;
            }
            if (msg.type === 'CDP_ARM_FILE') {
                let tabId = sender.tab ? sender.tab.id : msg.tabId;
                if (!tabId) {
                    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
                    tabId = tabs[0]?.id;
                }
                if (!tabId) {
                    const flowTabs = await chrome.tabs.query({ url: '*://flow.google.com/*' });
                    tabId = flowTabs[0]?.id;
                }
                if (!tabId) { sendResponse({ ok: false, error: 'no tabId for upload' }); return; }
                if (!msg.filePath) { sendResponse({ ok: false, error: 'thiếu filePath' }); return; }
                try {
                    await armFileUpload(tabId, msg.filePath);
                    sendResponse({ ok: true, armed: true });
                } catch (e) {
                    sendResponse({ ok: false, error: String(e) });
                }
                return;
            }
            if (msg.type === 'CDP_SET_FILE') {
                // Bơm file thẳng vào <input type=file> (tìm theo selector) — KHÔNG cần click thật / user activation
                // → chạy được cả khi tab Flow đang ẩn/bị che (click CDP vào trang ẩn không ăn).
                const tabId = sender.tab ? sender.tab.id : msg.tabId;
                if (!tabId) { sendResponse({ ok: false, error: 'no tabId' }); return; }
                if (!msg.filePath || !msg.selector) { sendResponse({ ok: false, error: 'thiếu filePath/selector' }); return; }
                try {
                    await attachDebugger(tabId);
                    try { await sendCdp(tabId, 'DOM.enable', {}); } catch (e) {}
                    const doc = await sendCdp(tabId, 'DOM.getDocument', { depth: 0 });
                    const q = await sendCdp(tabId, 'DOM.querySelector', { nodeId: doc.root.nodeId, selector: msg.selector });
                    if (!q || !q.nodeId) { sendResponse({ ok: false, error: 'không thấy input: ' + msg.selector }); return; }
                    await sendCdp(tabId, 'DOM.setFileInputFiles', { files: [msg.filePath], nodeId: q.nodeId });
                    sendResponse({ ok: true });
                } catch (e) {
                    sendResponse({ ok: false, error: String(e && e.message || e) });
                }
                return;
            }
            if (msg.type === 'CDP_CLICK' || msg.type === 'CDP_ENTER' || msg.type === 'CDP_ENTER_CTRL' || msg.type === 'CDP_TYPE_AND_CLICK') {
                let tabId = sender.tab ? sender.tab.id : msg.tabId;
                if (!tabId) {
                    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
                    tabId = tabs[0]?.id;
                }
                if (!tabId) {
                    const flowTabs = await chrome.tabs.query({ url: '*://flow.google.com/*' });
                    tabId = flowTabs[0]?.id;
                }
                if (!tabId) {
                    sendResponse({ ok: false, error: 'no tabId found for CDP' });
                    return;
                }

                try {
                    const tab = await chrome.tabs.get(tabId);
                    if (tab && tab.windowId && msg.quiet) {
                        // Chế độ âm thầm (cửa sổ thu nhỏ dưới taskbar): KHÔNG bật/focus cửa sổ, bấm thẳng qua CDP
                        if (!tab.active) await chrome.tabs.update(tabId, { active: true }).catch(() => {});
                    } else if (tab && tab.windowId) {
                        await chrome.tabs.update(tabId, { active: true }).catch(() => {});
                        const win = await chrome.windows.get(tab.windowId);
                        if (win.state === 'minimized') {
                            await chrome.windows.update(tab.windowId, { state: 'normal', focused: true }).catch(() => {});
                            await new Promise(r => setTimeout(r, 400));
                        } else if (!win.focused) {
                            await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
                            await new Promise(r => setTimeout(r, 200));
                        }
                    }
                } catch(e) {}
                if (msg.type === 'CDP_CLICK') {
                    await cdpClick(tabId, msg.x, msg.y);
                    sendResponse({ ok: true });
                    return;
                }
                if (msg.type === 'CDP_ENTER' || msg.type === 'CDP_ENTER_CTRL') {
                    await attachDebugger(tabId);
                    const modifiers = msg.type === 'CDP_ENTER_CTRL' ? 2 : 0;
                    await sendCdp(tabId, 'Input.dispatchKeyEvent', {
                        type: 'rawKeyDown',
                        windowsVirtualKeyCode: 13,
                        nativeVirtualKeyCode: 13,
                        code: 'Enter',
                        key: 'Enter',
                        modifiers: modifiers,
                        text: '\r',
                        unmodifiedText: '\r'
                    });
                    await new Promise(r => setTimeout(r, 40));
                    await sendCdp(tabId, 'Input.dispatchKeyEvent', {
                        type: 'keyUp',
                        windowsVirtualKeyCode: 13,
                        nativeVirtualKeyCode: 13,
                        code: 'Enter',
                        key: 'Enter',
                        modifiers: modifiers
                    });
                    sendResponse({ ok: true });
                    return;
                }
                // CDP_TYPE_AND_CLICK
                await attachDebugger(tabId);
                if (msg.pmX && msg.pmY) {
                    await cdpClick(tabId, msg.pmX, msg.pmY);
                    await new Promise(r => setTimeout(r, 100));
                }
                await sendCdp(tabId, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', windowsVirtualKeyCode: 65, modifiers: 2 });
                await sendCdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: 65, modifiers: 2 });
                await sendCdp(tabId, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', windowsVirtualKeyCode: 8 });
                await sendCdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: 8 });
                await new Promise(r => setTimeout(r, 100));

                if (msg.prompt) {
                    await sendCdp(tabId, 'Input.insertText', { text: msg.prompt });
                    await new Promise(r => setTimeout(r, 400));
                }
                if (msg.btnX && msg.btnY) {
                    await cdpClick(tabId, msg.btnX, msg.btnY);
                }
                sendResponse({ ok: true });
                return;
            }

            // ===== ĐA LUỒNG: mỗi luồng = 1 cửa sổ Flow riêng (slot) =====
            if (msg.type === 'HT_LIST_SLOTS') {
                sendResponse({ ok: true, slots: await htListSlots() });
                return;
            }
            if (msg.type === 'HT_RELAY') {
                const slot = String(msg.slot || '');
                const tabId = await htFindSlotTab(slot);
                if (!tabId) { sendResponse({ ok: false, error: 'NO_SLOT' }); return; }
                try {
                    const tmo = Math.max(5000, Math.min(120000, msg.timeout || 55000));
                    const r = await Promise.race([
                        chrome.tabs.sendMessage(tabId, { type: 'HT_EXEC', action: msg.action, timeout: tmo - 1000 }),
                        new Promise((_, rej) => setTimeout(() => rej(new Error('relay timeout')), tmo))
                    ]);
                    sendResponse(r || { ok: false, error: 'slot ' + slot + ' không trả lời' });
                } catch (e) {
                    sendResponse({ ok: false, error: 'slot ' + slot + ': ' + String(e && e.message || e) });
                }
                return;
            }
            if (msg.type === 'HT_ENSURE_SLOTS') {
                sendResponse(await htEnsureSlots(msg));
                return;
            }
            if (msg.type === 'HT_WINDOW') {
                // thu nhỏ / bật lại cửa sổ chứa tab gửi lệnh
                const wid = sender.tab ? sender.tab.windowId : msg.windowId;
                if (!wid) { sendResponse({ ok: false, error: 'no window' }); return; }
                try {
                    if (msg.state === 'minimized') {
                        await chrome.windows.update(wid, { state: 'minimized' });
                    } else {
                        // chỉ state:'normal' thì trang vẫn 'hidden' (Flow vẫn ngủ) → phải focus luôn
                        await chrome.windows.update(wid, { state: 'normal', focused: true });
                        if (sender.tab && sender.tab.id) await chrome.tabs.update(sender.tab.id, { active: true }).catch(() => {});
                    }
                    const w = await chrome.windows.get(wid);
                    sendResponse({ ok: true, state: w.state });
                } catch (e) { sendResponse({ ok: false, error: String(e) }); }
                return;
            }

            sendResponse({ ok: false, error: 'unknown type' });
        } catch (e) {
            console.warn('[Background] onMessage error:', e);
            sendResponse({ ok: false, error: String(e) });
        }
    })();
    return true;
});

// ================== INIT ==================

chrome.runtime.onInstalled.addListener(async () => {
    const settings = await getSettings();
    await saveSettings(settings);
    await createReloadAlarm();
});

createReloadAlarm();

// Định kỳ kéo token ya29 từ auth/session (mỗi 1 phút) + lấy ngay khi service worker khởi động
try { chrome.alarms.create('fetchToken', { periodInMinutes: 1 }); } catch (e) {}
autoHealToken();

console.log('🎯 HT Combined Extension ready');
