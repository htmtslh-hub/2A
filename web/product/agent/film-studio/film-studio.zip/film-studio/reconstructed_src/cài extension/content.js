// ===================================
// CONTENT SCRIPT - Combined bridge + injector
// ===================================
(function() {
    const log = (msg) => console.log(`[HT-Content] ${msg}`);
    const TOKEN_TTL_MS = 55 * 60 * 1000; // chỉ auto-copy token còn sống (ya29 ~1h)

    // === ĐA LUỒNG: mỗi cửa sổ Flow do tool mở có số thứ tự (slot) qua #htslot=N ===
    //   Lưu vào sessionStorage → giữ nguyên khi F5 / Flow đổi URL trong cùng tab.
    try {
        const m = String(location.hash || '').match(/htslot=(\d+)/);
        if (m) sessionStorage.setItem('htSlot', m[1]);
    } catch (e) {}
    const getSlot = () => { try { return sessionStorage.getItem('htSlot') || ''; } catch (e) { return ''; } };

    // === Inject scripts vào page context (Captcha Client) ===
    function injectScript(file) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = chrome.runtime.getURL(file);
            script.type = 'text/javascript';
            script.onload = () => { script.remove(); resolve(); };
            script.onerror = () => reject(new Error(`Inject failed: ${file}`));
            (document.head || document.documentElement).appendChild(script);
        });
    }

    async function initDependencies() {
        try {
            await injectScript('socket.io.min.js');
            await injectScript('injected.js');
            log('✅ All scripts injected');
        } catch (e) {
            log('❌ Injection error: ' + e.message);
        }
    }

    // === Message bridge (cả Captcha Client + Veo Catcher) ===
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        const d = event.data;
        if (!d) return;

        // Veo Catcher bridge: forward token capture to background
        if (d.__veo_catcher === true) {
            const { __veo_catcher, ...data } = d;
            try {
                chrome.runtime.sendMessage({ type: 'capture', data }, () => {
                    // Khi bắt được TOKEN mới → auto-copy JSON vào clipboard
                    if (data.token) {
                        setTimeout(() => autoCopyTokens(), 500);
                    }
                });
            } catch (e) {}
            return;
        }

        // Captcha Client bridge
        if (d.type === 'CAPTCHA_LOG') log('From Injected: ' + d.message);

        if (d.type === 'CAPTCHA_STATUS') {
            try { chrome.runtime.sendMessage({ type: 'CAPTCHA_STATUS_UPDATE', data: d.data }); } catch (e) {}
        }

        if (d.type === 'GET_SETTINGS_REQUEST') {
            try {
                chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (response) => {
                    if (chrome.runtime.lastError || !response) return;
                    try { window.postMessage({ type: 'GET_SETTINGS_RESPONSE', settings: response }, '*'); } catch (e) {}
                });
            } catch (e) {}
            return;
        }

        if (d.type === 'CDP_REQUEST') {
            try {
                chrome.runtime.sendMessage(d.payload, (response) => {
                    const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
                    window.postMessage({ type: 'CDP_RESPONSE', reqId: d.reqId, response: response || { ok: false, error: err || 'no response from background' } }, '*');
                });
            } catch (e) {
                window.postMessage({ type: 'CDP_RESPONSE', reqId: d.reqId, response: { ok: false, error: String(e) } }, '*');
            }
            return;
        }

        // ĐA LUỒNG: trang nhận lệnh của slot khác → nhờ background chuyển sang đúng cửa sổ
        if (d.type === 'HT_RELAY_REQUEST') {
            try {
                chrome.runtime.sendMessage({ type: 'HT_RELAY', slot: d.slot, action: d.action, timeout: d.timeout }, (response) => {
                    const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
                    window.postMessage({ type: 'HT_RELAY_RESPONSE', reqId: d.reqId, response: response || { ok: false, error: err || 'no response from background' } }, '*');
                });
            } catch (e) {
                window.postMessage({ type: 'HT_RELAY_RESPONSE', reqId: d.reqId, response: { ok: false, error: String(e) } }, '*');
            }
            return;
        }
    });

    // ĐA LUỒNG: background hỏi slot / giao lệnh cho cửa sổ này
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.type === 'HT_GET_SLOT') {
            sendResponse({ slot: getSlot(), url: location.href });
            return;
        }
        if (request.type === 'HT_EXEC') {
            const reqId = 'exec_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
            let done = false;
            const handler = (e) => {
                if (e.source !== window || e.data?.type !== 'HT_EXEC_RESPONSE' || e.data?.reqId !== reqId) return;
                window.removeEventListener('message', handler);
                if (done) return; done = true;
                sendResponse({ ok: true, result: e.data.result, error: e.data.error || null });
            };
            window.addEventListener('message', handler);
            window.postMessage({ type: 'HT_EXEC_REQUEST', reqId, action: request.action }, '*');
            setTimeout(() => {
                window.removeEventListener('message', handler);
                if (done) return; done = true;
                sendResponse({ ok: false, error: 'trang slot ' + getSlot() + ' không phản hồi (chưa tải xong?)' });
            }, request.timeout || 55000);
            return true; // trả lời bất đồng bộ
        }
    });

    // === Auto-copy tokens to clipboard + hiện toast trên trang ===
    function autoCopyTokens() {
        chrome.runtime.sendMessage({ type: 'getAll' }, (resp) => {
            const caps = resp?.captures || {};
            const now = Date.now();
            const accounts = Object.values(caps)
                .filter(c => {
                    if (!c.token) return false;
                    if (c.expires) { const t = Date.parse(c.expires); if (!isNaN(t)) return now < t; } // hạn thật
                    return (now - (c.lastSeen || 0)) < TOKEN_TTL_MS; // fallback
                })
                .sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0))
                .map(c => ({
                    email: c.email || ('captured_' + c.token.slice(-5)),
                    profile_path: '',
                    token: c.token,
                    credits: c.credits || 'Unknown',
                    project_id: '',
                    labs_session: c.labs_session || ''
                }));
            if (!accounts.length) return;

            const json = JSON.stringify({ accounts }, null, 2);
            navigator.clipboard.writeText(json).then(() => {
                showPageToast(`✅ Token đã copy! (${accounts.length} acc)`);
                log('Auto-copied ' + accounts.length + ' accounts to clipboard');
            }).catch(() => {
                showPageToast('⚠️ Token bắt được — mở popup để copy');
            });
        });
    }

    // Toast hiện trên trang web (không cần mở popup)
    function showPageToast(msg) {
        let toast = document.getElementById('ht-page-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'ht-page-toast';
            toast.style.cssText = 'position:fixed;top:20px;right:20px;background:#e8720c;color:#fff;padding:10px 18px;border-radius:8px;font:600 13px/1.4 system-ui,sans-serif;z-index:999999;box-shadow:0 4px 20px rgba(232,114,12,0.4);opacity:0;transition:opacity .3s;pointer-events:none';
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.opacity = '1';
        clearTimeout(showPageToast._t);
        showPageToast._t = setTimeout(() => { toast.style.opacity = '0'; }, 3000);
    }

    // === Background → content → page forwarding ===
    chrome.runtime.onMessage.addListener((request) => {
        if (request.type === 'RELOAD_PAGE') {
            // đang tạo video/ảnh dở (trang tự đặt htBusyUntil) → không F5 ngang
            let busy = 0;
            try { busy = parseInt(sessionStorage.getItem('htBusyUntil') || '0', 10) || 0; } catch (e) {}
            if (busy > Date.now()) return;
            localStorage.removeItem('_grecaptcha');
            window.location.reload();
        }
        if (request.type === 'CAPTURED_HEADERS') {
            window.postMessage({ type: 'CAPTURED_HEADERS', headers: request.headers }, '*');
        }
    });

    // === Init ===
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDependencies);
    } else {
        initDependencies();
    }
})();
