// ===================================
// INJECTED SCRIPT - Chạy trong page context
// ===================================

(async function () {
    class Logger {
        constructor(context) { this.context = context; }
        log(message, data = null) { if (data) console.log(`[${this.context}] ${message}`, data); else console.log(`[${this.context}] ${message}`); }
        debug(message, data = null) { if (data) console.debug(`[${this.context}] ${message}`, data); else console.debug(`[${this.context}] ${message}`); }
        warn(message, data = null) { if (data) console.warn(`[${this.context}] ⚠️ ${message}`, data); else console.warn(`[${this.context}] ⚠️ ${message}`); }
        error(message, data = null) { if (data) console.error(`[${this.context}] ❌ ${message}`, data); else console.error(`[${this.context}] ❌ ${message}`); }
        success(message, data = null) { if (data) console.log(`[${this.context}] ✅ ${message}`, data); else console.log(`[${this.context}] ✅ ${message}`); }
    }

    const logger = new Logger('CaptchaClient');
    logger.log('🚀 Starting Captcha Client...');

    const CONFIG = {
        siteKey: '6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV',
        socketServer: 'http://localhost:3000', 
    };

    let cachedSettings = null;
    let recaptchaReadyResolve;
    const recaptchaReadyPromise = new Promise((resolve) => { recaptchaReadyResolve = resolve; });

    window.__htConsoleLogs = [];
    try {
        const _ce = console.error;
        console.error = function(...args) {
            window.__htConsoleLogs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
            return _ce.apply(this, args);
        };
        const _cw = console.warn;
        console.warn = function(...args) {
            window.__htConsoleLogs.push('[WARN] ' + args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
            return _cw.apply(this, args);
        };
    } catch(e) {}

    function sendLog(message) { window.postMessage({ type: 'CAPTCHA_LOG', message: message }, '*'); }
    function sendStatus(status, data = {}) { window.postMessage({ type: 'CAPTCHA_STATUS', data: { status, ...data } }, '*'); }

    function requestCdp(payload, timeoutMs = 3500) {
        return new Promise((resolve) => {
            const reqId = 'cdp_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
            const handler = (e) => {
                if (e.source !== window || e.data?.type !== 'CDP_RESPONSE' || e.data?.reqId !== reqId) return;
                window.removeEventListener('message', handler);
                resolve(e.data.response || { ok: false });
            };
            window.addEventListener('message', handler);
            window.postMessage({ type: 'CDP_REQUEST', reqId, payload }, '*');
            setTimeout(() => {
                window.removeEventListener('message', handler);
                resolve({ ok: false, error: 'CDP timeout (' + (timeoutMs / 1000) + 's)' });
            }, timeoutMs);
        });
    }

    try {
        const _origAEL = EventTarget.prototype.addEventListener;
        EventTarget.prototype.addEventListener = function(type, listener, options) {
            try {
                this.__htListeners = this.__htListeners || [];
                this.__htListeners.push({ type, listener, fnStr: String(listener).slice(0, 100) });
            } catch(e) {}
            return _origAEL.apply(this, arguments);
        };
    } catch(e) {}

    // ★ BẮT ACTION reCAPTCHA THẬT: hook sớm để tóm lệnh grecaptcha của chính Flow
    //   khi người dùng bấm nút Tạo thật. In ra console + nhớ ở window.__HT_ACTION.
    (function hookRealAction() {
        let n = 0;
        const iv = setInterval(() => {
            const gr = window.grecaptcha && window.grecaptcha.enterprise;
            if (gr && gr.execute && !gr.__htHooked) {
                gr.__htHooked = true;
                const _ex = gr.execute.bind(gr);
                gr.execute = function (k, o) {
                    try {
                        window.__HT_LAST_RECAPTCHA = Date.now();
                        if (o && o.action) {
                            window.__HT_ACTION = o.action;
                            console.log('%c[HT] reCAPTCHA action THẬT = ' + o.action, 'color:lime;font-weight:bold', '| key:', k);
                        }
                    } catch (e) {}
                    return _ex(k, o);
                };
                clearInterval(iv);
            }
            if (++n > 120) clearInterval(iv);
        }, 400);
    })();

    // ★ BẪY HỨNG ẢNH: hook fetch + XHR để tóm link ảnh từ response batchexecute
    //   của CHÍNH Flow (khi bấm nút Tạo thật). Gọi window.__htOnImages(urls) nếu đang chờ.
    (function hookImageResponses() {
        const extract = (t) => {
            const rawUrls = (String(t).match(/https:\\?\/\\?\/flow-content\.google\/[^"\s]+/g) || [])
                .map(u => u.replace(/\\u003d/g, '=').replace(/\\u0026/g, '&').replace(/\\\//g, '/').replace(/\\/g, ''));
            const seen = {}, uniq = [];
            for (const u of rawUrls) {
                const b = u.split('?')[0];
                if (!seen[b]) { seen[b] = 1; uniq.push(u); }
            }
            return uniq;
        };
        window.__htRecentUrls = window.__htRecentUrls || [];
        window.__htOutbound = window.__htOutbound || [];
        window.__htSeenBases = window.__htSeenBases || new Set(); // mọi base-path ảnh đã từng thấy
        window.__htUrlMap = window.__htUrlMap || {};              // base-path → link đầy đủ (có chữ ký) mới nhất
        window.__htVidStatus = window.__htVidStatus || {};        // mediaId video → { s: mã trạng thái, t, err }
        // ★ VIDEO: YhhmEf = lệnh tạo video, jwpduf = Flow tự hỏi trạng thái. Mỗi video 1 mảng:
        //   [mediaId, projectId, workflowId, null, null, [ts, prompt, ..., cấu hình model, null, [mã], ...]]
        //   mã: 6/2 = đang tạo, 3 = xong (thực nghiệm). Trả về danh sách {id, s, err}.
        const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        const parseVidRpc = (text, rpc) => {
            const found = [];
            const walk = (a, depth) => {
                if (!Array.isArray(a) || depth > 12) return;
                if (typeof a[0] === 'string' && UUID_RE.test(a[0]) && typeof a[2] === 'string' && UUID_RE.test(a[2]) && Array.isArray(a[5])) {
                    const b = a[5];
                    let s = null;
                    if (Array.isArray(b[8]) && typeof b[8][0] === 'number') s = b[8][0];
                    else { for (let k = 7; k < b.length; k++) if (Array.isArray(b[k]) && b[k].length === 1 && typeof b[k][0] === 'number') { s = b[k][0]; break; } }
                    const js = JSON.stringify(a);
                    const em = js.match(/PUBLIC_ERROR_[A-Z_]+|UNUSUAL_ACTIVITY|[A-Z]+_[A-Z_]*(?:UNSAFE|POLICY|FILTERED)[A-Z_]*/);
                    found.push({ id: a[0], s, err: em ? em[0] : null, rpc });
                    return;
                }
                for (const x of a) walk(x, depth + 1);
            };
            for (const line of String(text).split('\n')) {
                if (!line.startsWith('[[')) continue;
                let arr; try { arr = JSON.parse(line); } catch (e) { continue; }
                for (const e of arr) {
                    if (!Array.isArray(e) || e[0] !== 'wrb.fr' || typeof e[2] !== 'string') continue;
                    try { walk(JSON.parse(e[2]), 0); } catch (er) {}
                }
            }
            return found;
        };
        const feed = (t, u) => {
            try {
                const sUrl = String(u);
                const sText = String(t);
                window.__htRecentUrls.push(sUrl + ' | len=' + sText.length);
                const isGen = sUrl.includes('ogiZ0b');
                if (isGen) {
                    window.__htLastOgi = sText.slice(0, 500);
                }
                if (sUrl.includes('SPrCad')) {
                    const mB64 = sText.match(/\/9j\/[A-Za-z0-9+/=\\]+/);
                    if (mB64) {
                        window.__htLastUpscaledB64 = mB64[0].replace(/\\/g, '');
                    }
                }
                const urls = extract(sText);
                // LUÔN ghi nhận link ảnh đã thấy (kể cả khi không đang tạo) để lần sau coi là ảnh cũ
                for (const uu of urls) { try { window.__htSeenBases.add(uu.split('?')[0]); if (uu.includes('?')) window.__htUrlMap[uu.split('?')[0]] = uu; } catch (e) {} }
                // VIDEO: cập nhật trạng thái từng mediaId (lệnh tạo YhhmEf / MZZa6b (có ảnh thành phần) + poll jwpduf)
                const vCreate = /rpcids=(YhhmEf|MZZa6b)/.test(sUrl);
                const vRpc = vCreate ? 'create' : (sUrl.includes('jwpduf') ? 'jwpduf' : '');
                if (vRpc) {
                    const list = parseVidRpc(sText, vRpc);
                    for (const v of list) {
                        const old = window.__htVidStatus[v.id] || {};
                        window.__htVidStatus[v.id] = { s: v.s, t: Date.now(), since: (old.s === v.s && old.since) ? old.since : Date.now(), err: v.err || old.err || null, first: old.first || Date.now() };
                    }
                    if (vCreate) {
                        window.__htLastYhh = sUrl.slice(0, 200) + '\n' + sText.slice(0, 1500);
                        if (window.__htOnVideoCreate) window.__htOnVideoCreate(list, sText);
                    }
                }
                // ★ CHỈ response của RPC tạo ảnh (ogiZ0b) mới được coi là kết quả.
                //   Các RPC khác (as29s list asset, upload...) cũng chứa link flow-content (ảnh ref, ảnh cũ) → bỏ qua.
                if (isGen && window.__htOnImages) {
                    if (sText.includes('UNUSUAL_ACTIVITY')) {
                        window.__htOnImages('ERR|UNUSUAL_ACTIVITY: ' + sText.slice(0, 300));
                        return;
                    }
                    if (sText.includes('PUBLIC_ERROR_')) {
                        const m = sText.match(/PUBLIC_ERROR_[A-Z_]+/);
                        const err = m ? m[0] : 'PUBLIC_ERROR';
                        window.__htOnImages('ERR|' + err);
                        return;
                    }
                    if (urls.length) window.__htOnImages(urls);
                }
            } catch (e) {}
        };
        try {
            const _f = window.fetch;
            window.fetch = function (...a) {
                try {
                    let u = a[0]; if (u && u.url) u = u.url;
                    window.__htOutbound.push({ type: 'fetch', url: String(u).slice(0, 120), time: Date.now() });
                    if (String(u).indexOf('ogiZ0b') >= 0) {
                        window.__htOgiSentAt = Date.now();
                        try { window.__htLastOgiReq = decodeURIComponent(String((a[1] && a[1].body) || '')).slice(0, 4000); } catch (e) {}
                    }
                    if (/rpcids=(YhhmEf|MZZa6b)/.test(String(u))) window.__htVidSentAt = Date.now();
                    window.dispatchEvent(new CustomEvent('__ht_net_req', { detail: u }));
                } catch (e) {}
                const p = _f.apply(this, a);
                try {
                    let u = a[0]; if (u && u.url) u = u.url;
                    if (String(u).indexOf('batchexecute') >= 0) p.then(r => { try { r.clone().text().then(t => feed(t, u)).catch(() => {}); } catch (e) {} }).catch(() => {});
                    // API JSON khác (googleapis / fx api) có thể chứa link video có chữ ký → chỉ nhớ link, không coi là kết quả
                    else if (/googleapis\.com|\/fx\/api\//.test(String(u))) p.then(r => { try { const ct = r.headers.get('content-type') || ''; if (/json|text/.test(ct)) r.clone().text().then(t => { for (const uu of extract(t)) { if (uu.includes('?')) window.__htUrlMap[uu.split('?')[0]] = uu; } }).catch(() => {}); } catch (e) {} }).catch(() => {});
                } catch (e) {}
                return p;
            };
        } catch (e) {}
        try {
            const _open = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function (m, u) { 
                this.__htUrl = u; 
                try { window.__htOutbound.push({ type: 'xhr', url: String(u).slice(0, 120), time: Date.now() }); } catch(e){}
                return _open.apply(this, arguments); 
            };
            const _send = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.send = function () {
                try {
                    window.dispatchEvent(new CustomEvent('__ht_net_req', { detail: this.__htUrl }));
                    if (/rpcids=(YhhmEf|MZZa6b)/.test(String(this.__htUrl))) window.__htVidSentAt = Date.now();
                    if (String(this.__htUrl).indexOf('ogiZ0b') >= 0) {
                        window.__htOgiSentAt = Date.now();
                        try { window.__htLastOgiReq = decodeURIComponent(String(arguments[0] || '')).slice(0, 4000); } catch (e) {}
                    }
                    const self = this;
                    this.addEventListener('load', function () {
                        try { if (String(self.__htUrl).indexOf('batchexecute') >= 0) feed(self.responseText, self.__htUrl); } catch (e) {}
                    });
                } catch (e) {}
                return _send.apply(this, arguments);
            };
        } catch (e) {}
    })();

    async function getSettings() {
        if (cachedSettings) return cachedSettings;
        return await new Promise((resolve) => {
            window.postMessage({ type: 'GET_SETTINGS_REQUEST' }, '*');
            let responseReceived = false;
            const listener = (event) => {
                if (event.source !== window) return;
                if (event.data.type === 'GET_SETTINGS_RESPONSE') {
                    window.removeEventListener('message', listener);
                    responseReceived = true;
                    cachedSettings = event.data.settings;
                    resolve(cachedSettings);
                }
            };
            window.addEventListener('message', listener);
            setTimeout(() => {
                window.removeEventListener('message', listener);
                if (!responseReceived) resolve({ clearGrecaptcha: false });
            }, 2000);
        });
    }

    function createCountdownStyles() {
        const style = document.createElement('style');
        style.textContent = `
            #countdown-badge { pointer-events: none; position: fixed; bottom: 28px; right: 28px; min-width: 156px; height: 88px; border-radius: 12px; background: linear-gradient(135deg, #5b7cfa 0%, #748ffc 100%); display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif; color: white; box-shadow: 0 10px 32px rgba(91, 124, 250, 0.35), inset 0 1px 2px rgba(255, 255, 255, 0.3); z-index: 999999; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); opacity: 0.97; cursor: default; padding: 14px 16px; gap: 6px; backdrop-filter: blur(8px); border: 1px solid rgba(255, 255, 255, 0.2); }
            #countdown-badge:hover { transform: translateY(-3px); opacity: 1; box-shadow: 0 14px 40px rgba(91, 124, 250, 0.45), inset 0 1px 2px rgba(255, 255, 255, 0.3); }
            #countdown-badge.hidden { display: none; }
            #countdown-badge-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.8px; opacity: 0.85; white-space: nowrap; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); }
            #countdown-badge-time { font-size: 36px; font-weight: 700; text-align: center; line-height: 1; font-variant-numeric: tabular-nums; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.15); letter-spacing: -1px; }
            #countdown-badge-progress { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border-radius: 12px; background: linear-gradient(135deg, rgba(91, 124, 250, 0.15) 0%, rgba(116, 143, 252, 0.15) 100%); opacity: 0.5; pointer-events: none; }
        `;
        document.head.appendChild(style);
    }

    function createCountdownBadge() {
        if (document.getElementById('countdown-badge')) return;
        const badge = document.createElement('div');
        badge.id = 'countdown-badge';
        badge.className = 'hidden';
        const progress = document.createElement('div'); progress.id = 'countdown-badge-progress';
        const label = document.createElement('div'); label.id = 'countdown-badge-label'; label.textContent = 'Before Reload';
        const timeElement = document.createElement('div'); timeElement.id = 'countdown-badge-time'; timeElement.textContent = '--';
        badge.appendChild(progress); badge.appendChild(label); badge.appendChild(timeElement);
        document.body.appendChild(badge);
    }

    function updateCountdownBadge(remainingSeconds, totalSeconds) {
        const badge = document.getElementById('countdown-badge');
        if (!badge) return;
        if (remainingSeconds <= 0) { badge.classList.add('hidden'); return; }
        badge.classList.remove('hidden');
        const timeElement = document.querySelector('#countdown-badge-time');
        const seconds = Math.max(0, remainingSeconds);
        timeElement.textContent = String(seconds).padStart(2, '0') + 's';
        let bgColor;
        const percentage = remainingSeconds / totalSeconds;
        if (percentage > 0.6) bgColor = 'linear-gradient(135deg, #5b7cfa 0%, #748ffc 100%)';
        else if (percentage > 0.3) bgColor = 'linear-gradient(135deg, #ffa500 0%, #ff8c00 100%)';
        else bgColor = 'linear-gradient(135deg, #ff4757 0%, #ff6b81 100%)';
        badge.style.background = bgColor;
    }

    // 🔥 NÂNG CẤP: Tự động bơm reCAPTCHA và chờ vô hạn, không báo lỗi sau 30s nữa
    async function waitForRecaptcha() {
        // 1. Kiểm tra và ép trình duyệt tải reCAPTCHA nếu chưa có
        if (!window.grecaptcha || !window.grecaptcha.enterprise) {
            logger.log('Tự động nạp script reCAPTCHA vào trang...');
            sendLog('Auto-injecting reCAPTCHA script...');
            
            const script = document.createElement('script');
            let scriptUrl = 'https://www.google.com/recaptcha/enterprise.js?render=' + CONFIG.siteKey;
            
            // Lách luật bảo mật CSP của Google
            if (window.trustedTypes && window.trustedTypes.createPolicy) {
                try {
                    const policy = window.trustedTypes.createPolicy('force-recaptcha', {
                        createScriptURL: (url) => url
                    });
                    scriptUrl = policy.createScriptURL(scriptUrl);
                } catch (e) {
                    // Bỏ qua nếu policy đã tồn tại
                }
            }
            
            script.src = scriptUrl;
            script.async = true;
            document.head.appendChild(script);
        }

        // 2. Chờ cho đến khi reCAPTCHA sẵn sàng (auto-inject hoạt động trên mọi trang)
        logger.log('Đang chờ reCAPTCHA sẵn sàng...');
        while (true) {
            if (window.grecaptcha?.enterprise?.execute) {
                logger.success('reCAPTCHA ready!');
                sendLog('reCAPTCHA ready!');
                return true;
            }
            await new Promise(resolve => setTimeout(resolve, 500));
        }
    }

    async function warmUpTelemetry() {
        try {
            const x0 = Math.floor(window.innerWidth / 2) + Math.floor(Math.random() * 200 - 100);
            const y0 = Math.floor(window.innerHeight / 2) + Math.floor(Math.random() * 200 - 100);
            for (let i = 0; i < 6; i++) {
                const x = x0 + Math.floor(Math.random() * 40 - 20);
                const y = y0 + Math.floor(Math.random() * 40 - 20);
                document.dispatchEvent(new MouseEvent('mousemove', {
                    bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y
                }));
                await new Promise(r => setTimeout(r, 25 + Math.floor(Math.random() * 25)));
            }
        } catch(e) {}
    }

    async function solveCaptcha(action = 'VIDEO_GENERATION') {
        try {
            await warmUpTelemetry();
            const token = await window.grecaptcha.enterprise.execute(CONFIG.siteKey, { action: action });
            try {
                const settings = await getSettings();
                if (settings.clearGrecaptcha === true) localStorage.removeItem('_grecaptcha');
            } catch (error) {}
            return token;
        } catch (error) {
            throw error;
        }
    }

    // ================================================================================
    // ★ TẠO VIDEO TRONG FLOW (tool5) — YhhmEf = lệnh tạo, jwpduf = Flow tự poll trạng thái.
    //   Bấm Tạo bằng phím ENTER qua CDP (sự kiện bàn phím thật, isTrusted) → KHÔNG cần hiện/focus
    //   cửa sổ (click chuột CDP cần trang đang hiện, phím thì không) → cửa sổ nằm yên dưới taskbar.
    //   sleep dùng MessageChannel: trang ẩn/thu nhỏ bị Chrome bóp setTimeout, MessageChannel thì không.
    // ================================================================================
    const htSleep = (ms) => new Promise(res => {
        const end = Date.now() + ms;
        const ch = new MessageChannel();
        ch.port1.onmessage = () => { if (Date.now() >= end) { ch.port1.close(); res(); } else ch.port2.postMessage(0); };
        ch.port2.postMessage(0);
    });
    const htNgClick = (el) => {
        const l = el && el.__htListeners ? el.__htListeners.find(x => x.type === 'click') : null;
        const raw = l && l.listener ? l.listener('__ngUnwrap__') : null;
        if (raw) { try { raw(new MouseEvent('click', { bubbles: true })); return; } catch (e) {} }
        el.click();
    };
    const htSetBusy = (ms) => { try { if (ms > 0) sessionStorage.setItem('htBusyUntil', String(Date.now() + ms)); else sessionStorage.removeItem('htBusyUntil'); } catch (e) {} };

    // Model trong tool → tên trên menu Flow
    // Lite có 2 bản: "Veo 3.1 - Lite" (tốn credit) và "Veo 3.1 - Lite [Lower Priority]" (0 credit)
    const HT_LOWPRI_RE = /lower\s*priority|low[\s_-]*priority|ưu\s*tiên\s*thấp/i;
    const HT_LITE_LOWPRI = 'Veo 3.1 - Lite [Lower Priority]';
    function htVideoModelName(model) {
        const m = String(model || '').toLowerCase();
        if (m.includes('omni') || m.includes('veo 4') || m.includes('abra')) return 'Omni 1.1 Flash';
        if (m.includes('quality')) return 'Veo 3.1 - Quality';
        if (m.includes('fast')) return 'Veo 3.1 - Fast';
        if (m.includes('lite')) return HT_LOWPRI_RE.test(m) ? HT_LITE_LOWPRI : 'Veo 3.1 - Lite';
        return '';
    }
    // Chữ trên menu/nút có khớp model muốn chọn không (Lite thường KHÔNG được khớp nhầm bản Lower Priority và ngược lại)
    function htModelMatch(text, want) {
        const t = String(text || '').replace(/\s+/g, ' ');
        if (want === HT_LITE_LOWPRI) return /Lite/i.test(t) && HT_LOWPRI_RE.test(t);
        if (want === 'Veo 3.1 - Lite') return t.includes(want) && !HT_LOWPRI_RE.test(t);
        return t.includes(want);
    }

    async function applyVideoSettings({ model, ratio, duration, count, resolution, refs }) {
        const toggles = (ov) => Array.from(ov.querySelectorAll('mat-button-toggle'));
        const tText = (t) => (t.innerText || '').trim().replace(/\s+/g, ' ');
        const isOn = (t) => t.classList.contains('mat-button-toggle-checked');
        const press = async (t) => { (t.querySelector('button') || t).click(); await htSleep(350); };
        let ov = document.querySelector('flow-prompt-box-settings');
        if (!ov) {
            document.querySelector('button.settings-trigger-button')?.click();
            for (let i = 0; i < 15 && !ov; i++) { await htSleep(150); ov = document.querySelector('flow-prompt-box-settings'); }
        }
        if (!ov) return 'không mở được bảng cài đặt';
        // 1. Chế độ Video
        const vt = toggles(ov).find(t => /videocam|Video/.test(tText(t)) && !/Khung|Thành phần/.test(tText(t)));
        if (!vt) return 'không thấy nút Video';
        if (!isOn(vt)) { await press(vt); await htSleep(600); ov = document.querySelector('flow-prompt-box-settings') || ov; }
        // 1b. Có ảnh tham chiếu → bật chế độ "Thành phần" (ingredients)
        if (Array.isArray(refs) && refs.length) {
            const it = toggles(ov).find(t => /Thành phần/.test(tText(t)));
            if (it && !isOn(it)) { await press(it); await htSleep(500); ov = document.querySelector('flow-prompt-box-settings') || ov; }
            const it2 = toggles(ov).find(t => /Thành phần/.test(tText(t)));
            if (it2 && !isOn(it2)) return 'không bật được chế độ Thành phần';
        }
        // 2. Model
        const want = htVideoModelName(model);
        if (want) {
            const mb = () => ov.querySelector('button[aria-label="Chọn nhóm mô hình"]');
            if (mb() && !htModelMatch(mb().innerText, want)) {
                mb().click();
                let it = null, seen = [];
                for (let i = 0; i < 15 && !it; i++) {
                    await htSleep(150);
                    const items = Array.from(document.querySelectorAll('.flow-model-picker-panel [role=menuitem], .mat-mdc-menu-panel [role=menuitem]'));
                    if (items.length) seen = items.map(m => (m.innerText || '').replace(/\s+/g, ' ').trim());
                    it = items.find(m => htModelMatch(m.innerText, want));
                }
                if (it) { htNgClick(it); await htSleep(600); }
                document.querySelector('.cdk-overlay-backdrop')?.click();
                await htSleep(300);
                ov = document.querySelector('flow-prompt-box-settings') || ov;
                if (!mb() || !htModelMatch(mb().innerText, want)) {
                    const lst = seen.length ? ' — menu Flow đang có: ' + seen.join(' | ').slice(0, 300) : '';
                    return 'không chọn được model ' + want + (it ? '' : ' (tài khoản này không có model đó)') + lst;
                }
            }
        }
        // 3. Khung hình, thời lượng, độ phân giải (Omni), số video
        const r = String(ratio || '').toLowerCase();
        const wantRatio = (r.includes('9:16') || r.includes('portrait') || r.includes('dọc')) ? '9:16' : '16:9';
        let wantDur = (String(duration || '').match(/\d+/) || [''])[0];
        // Veo 3.1 (Lite/Fast) chỉ nhận ảnh thành phần ở 8 giây (4/6 giây → chip ảnh bị khóa)
        if (Array.isArray(refs) && refs.length && !/Omni/.test(want) && wantDur !== '8') {
            logger.warn('Có ảnh thành phần: Veo 3.1 chỉ hỗ trợ 8 giây → dùng 8 giây');
            wantDur = '8';
        }
        const wantCount = 'x' + Math.max(1, Math.min(4, parseInt(count, 10) || 1));
        const pick = async (label, exact) => {
            ov = document.querySelector('flow-prompt-box-settings') || ov;
            const t = toggles(ov).find(x => exact ? tText(x) === label : tText(x).endsWith(label));
            if (!t) return false;
            if (!isOn(t)) await press(t);
            return true;
        };
        await pick(wantRatio, false);
        if (wantDur && !(await pick(wantDur + ' giây', false))) logger.warn('Model này không có thời lượng ' + wantDur + 's → giữ mặc định');
        if (resolution) await pick(String(resolution).replace(/\s+/g, ''), false);
        await pick(wantCount, true);
        // đóng bảng cài đặt
        document.querySelector('button.settings-trigger-button')?.click();
        await htSleep(300);
        document.querySelector('.cdk-overlay-backdrop')?.click();
        await htSleep(200);
        const trig = (document.querySelector('button.settings-trigger-button')?.innerText || '');
        if (!/Video/i.test(trig)) return 'Flow chưa chuyển sang chế độ Video (' + trig.replace(/\s+/g, ' ').slice(0, 60) + ')';
        return '';
    }

    // Tìm link video có chữ ký của 1 mediaId (mạng đã bắt hoặc thẻ <video> trên trang)
    function htFindVideoUrl(id) {
        const base = 'https://flow-content.google/video/' + id;
        if (window.__htUrlMap && window.__htUrlMap[base]) return window.__htUrlMap[base];
        for (const v of document.querySelectorAll('video, video source')) {
            const s = v.currentSrc || v.src || '';
            if (s.includes(id)) return s;
        }
        return '';
    }

    // Chèn 1 chip @ vào cuối ô prompt: kind 'asset' (ảnh đã có trong project, so khớp đúng tên file bỏ đuôi)
    //   hoặc 'voice' (giọng nói trong tab "Giọng nói"). Chạy được cả khi cửa sổ đang ẩn/thu nhỏ.
    async function htInsertMention(name, kind) {
        const n = String(name || '').trim().toLowerCase();
        if (!n) return false;
        const ed = () => document.querySelector('.ProseMirror');
        const chipN = () => (ed() ? ed().querySelectorAll('.mention-chip').length : 0);
        const caretEnd = () => {
            const e = ed(); if (!e) return;
            e.focus();
            const ps = e.querySelectorAll('p'); const pEl = ps.length ? ps[ps.length - 1] : e;
            const rg = document.createRange(); rg.selectNodeContents(pEl); rg.collapse(false);
            const s = window.getSelection(); s.removeAllRanges(); s.addRange(rg);
        };
        const typeTxt = (t) => { document.execCommand('insertText', false, t); ed()?.dispatchEvent(new Event('input', { bubbles: true })); };
        const title = (b) => (b.querySelector('.asset-title')?.innerText || b.innerText || '').trim().toLowerCase();
        const findItem = () => {
            if (kind === 'voice') {
                return Array.from(document.querySelectorAll('.cdk-overlay-pane button')).find(b => {
                    const t = (b.innerText || '').trim().toLowerCase().replace(/\s+/g, ' ');
                    return t.startsWith('voice_selection ' + n + ' ') || t === 'voice_selection ' + n;
                });
            }
            return Array.from(document.querySelectorAll('button.asset-item')).find(b => title(b).replace(/\.[a-z0-9]{2,5}$/, '') === n);
        };
        const stripAt = () => {
            const e = ed(); if (!e) return;
            const ps = e.querySelectorAll('p'); const pEl = ps.length ? ps[ps.length - 1] : e;
            const last = pEl.lastChild;
            if (!last || last.nodeType !== 3) return;
            const m = last.textContent.match(/@[^\s@]*$/);
            if (!m) return;
            e.focus();
            const r = document.createRange();
            r.setStart(last, last.textContent.length - m[0].length); r.setEnd(last, last.textContent.length);
            const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
            document.execCommand('delete', false, null);
        };
        for (let attempt = 1; attempt <= 3; attempt++) {
            const before = chipN();
            caretEnd();
            typeTxt('@');
            let target = null;
            for (let i = 0; i < 8 && !document.querySelector('.cdk-overlay-pane mat-list-item, button.asset-item'); i++) await htSleep(150);
            if (kind === 'voice') {
                const li = Array.from(document.querySelectorAll('.cdk-overlay-pane mat-list-item')).find(x => /Giọng nói|voice_selection/.test(x.innerText || ''));
                if (li) { htNgClick(li); await htSleep(900); }
            }
            for (let i = 0; i < 8 && !target; i++) { await htSleep(150); target = findItem(); }
            if (!target) {
                typeTxt(String(name).trim());     // gõ tên để tìm (danh sách chỉ hiện các mục gần đây)
                for (let i = 0; i < 25 && !target; i++) { await htSleep(200); target = findItem(); }
            }
            if (target) {
                htNgClick(target);
                let addBtn = null;
                for (let i = 0; i < 15 && !addBtn; i++) { await htSleep(150); addBtn = document.querySelector('button.detail-add-to-prompt-btn'); }
                if (addBtn) { htNgClick(addBtn); }
                for (let i = 0; i < 10 && chipN() <= before; i++) await htSleep(150);
            }
            logger.log('📎 Chip', kind, name, '→', chipN() > before ? 'OK' : ('lỗi (lần ' + attempt + ', thấy mục: ' + !!target + ')'));
            if (chipN() > before) return true;
            document.querySelector('.cdk-overlay-backdrop')?.click();
            await htSleep(300);
            stripAt();
            await htSleep(300);
        }
        return false;
    }

    async function flowVideoGenerate(p) {
        const st = window.__htVidState;
        const setStage = (s) => { if (st) st.stage = s; };
        try {
            let prompt = String(p.prompt || '').trim();
            if (!prompt) return 'ERR|thiếu prompt';
            const pathMatch = location.pathname.match(/project\/([0-9a-f-]{8,})/i);
            if (!pathMatch) {
                if (p.projectId) location.href = 'https://flow.google.com/project/' + p.projectId + location.hash;
                return 'ERR|Cửa sổ chưa mở project Flow (đang tự mở, thử lại sau)';
            }
            setStage('chờ ô prompt');
            let pm = document.querySelector('.ProseMirror');
            for (let i = 0; i < 60 && !pm; i++) { await htSleep(250); pm = document.querySelector('.ProseMirror'); }
            if (!pm) return 'ERR|Không tìm thấy ô nhập prompt (.ProseMirror)';

            setStage('cài đặt');
            document.querySelector('.cdk-overlay-backdrop')?.click();
            const setErr = await applyVideoSettings(p);
            if (setErr) return 'ERR|Cài đặt video lỗi: ' + setErr;

            // Gõ prompt (xóa sạch cũ)
            setStage('gõ prompt');
            pm = document.querySelector('.ProseMirror') || pm;
            pm.focus();
            document.execCommand('selectAll', false, null);
            document.execCommand('delete', false, null);
            // Ảnh tham chiếu (Thành phần) + giọng nói → chip @ đứng đầu prompt
            const refs = Array.isArray(p.refs) ? p.refs.filter(Boolean) : [];
            let wantChips = 0;
            if (refs.length || p.voice) {
                setStage('gắn ảnh tham chiếu');
                const missing = [];
                for (const r of refs) {
                    if (await htInsertMention(r, 'asset')) wantChips++;
                    else missing.push(r);
                }
                if (missing.length) {
                    document.querySelector('.cdk-overlay-backdrop')?.click();
                    return 'ERR|REF_MISSING|Không gắn được ảnh tham chiếu: ' + missing.join(', ');
                }
                if (p.voice) {
                    if (await htInsertMention(p.voice, 'voice')) wantChips++;
                    else { if (st) st.warn = 'không chọn được giọng ' + p.voice; logger.warn('Không chọn được giọng', p.voice); }
                }
                document.querySelector('.cdk-overlay-backdrop')?.click();
                await htSleep(250);
                // cài lại sau khi đã có chip (Flow đổi danh sách thời lượng / khóa chip theo model)
                if (refs.length) {
                    setStage('cài đặt (thành phần)');
                    const e2 = await applyVideoSettings(p);
                    if (e2) return 'ERR|Cài đặt video lỗi: ' + e2;
                }
            }
            setStage('gõ prompt');
            pm = document.querySelector('.ProseMirror') || pm;
            pm.focus();
            {
                const ps = pm.querySelectorAll('p'); const pEl = ps.length ? ps[ps.length - 1] : pm;
                const rg = document.createRange(); rg.selectNodeContents(pEl); rg.collapse(false);
                const s = window.getSelection(); s.removeAllRanges(); s.addRange(rg);
            }
            // '@' trong nội dung sẽ bật menu chọn thành phần → đổi sang ký tự '＠'
            document.execCommand('insertText', false, (wantChips ? ' ' : '') + prompt.replace(/@/g, '＠'));
            pm.dispatchEvent(new Event('input', { bubbles: true }));
            await htSleep(500);
            document.querySelector('.cdk-overlay-backdrop')?.click();
            const typed = (document.querySelector('.ProseMirror')?.innerText || '').trim();
            if (typed.length < Math.min(10, prompt.length)) return 'ERR|Không gõ được prompt vào Flow';
            if (wantChips) {
                const nChip = document.querySelector('.ProseMirror').querySelectorAll('.mention-chip').length;
                if (nChip < wantChips) return 'ERR|REF_MISSING|Chip ảnh tham chiếu bị mất khi gõ prompt (' + nChip + '/' + wantChips + ')';
            }
            // Nút Tạo phải sáng (chip bị khóa / thiếu prompt → Flow khóa nút; bấm Enter lúc đó vô ích)
            {
                const genBtn = () => document.querySelector('flow-generate-icon-button button, button.generate-icon-button');
                const off = () => { const b = genBtn(); return !b || b.disabled || b.classList.contains('mat-mdc-button-disabled'); };
                for (let i = 0; i < 25 && off(); i++) await htSleep(200);
                if (off()) {
                    const dis = document.querySelectorAll('flow-ingredient-bar .chip-container-disabled, .mention-chip-invalid').length;
                    if (dis) return 'ERR|Ảnh tham chiếu bị Flow khóa với model này (' + (htVideoModelName(p.model) || p.model) + ') — Veo 3.1 Quality không hỗ trợ Thành phần, Lite/Fast chỉ 8 giây';
                    return 'ERR|Nút Tạo đang bị khóa (hết tín dụng hoặc prompt không hợp lệ?)';
                }
                const trig = document.querySelector('button.settings-trigger-button')?.innerText || '';
                if (!/Video/i.test(trig)) return 'ERR|Cài đặt video lỗi: Flow bị chuyển khỏi chế độ Video (' + trig.replace(/\s+/g, ' ').slice(0, 50) + ')';
            }

            // Chờ phản hồi YhhmEf (mediaId của video vừa tạo)
            let created = null;
            window.__htOnVideoCreate = (list, raw) => {
                if (created) return;
                if (list && list.length) created = { ids: list.map(x => x.id), raw };
                else {
                    const em = String(raw).match(/PUBLIC_ERROR_[A-Z_]+|UNUSUAL_ACTIVITY|RESOURCE_EXHAUSTED|PERMISSION_DENIED/);
                    created = { ids: [], err: em ? em[0] : ('Flow từ chối: ' + String(raw).slice(0, 200)) };
                }
            };
            const tGen = Date.now();
            const sent = () => (window.__htVidSentAt || 0) >= tGen;
            setStage('bấm Tạo');
            const placeCaret = () => {
                const ed = document.querySelector('.ProseMirror'); if (!ed) return;
                ed.focus();
                const ps = ed.querySelectorAll('p'); const pEl = ps.length ? ps[ps.length - 1] : ed;
                const rg = document.createRange(); rg.selectNodeContents(pEl); rg.collapse(false);
                const s = window.getSelection(); s.removeAllRanges(); s.addRange(rg);
            };
            for (let k = 1; k <= 5 && !sent(); k++) {
                if (k <= 2) {
                    placeCaret();
                    logger.log('🎬 Enter (CDP) để tạo video, lần', k);
                    await requestCdp({ type: 'CDP_ENTER' }, 5000);
                } else if (k === 3) {
                    // bấm nút Tạo qua handler Angular (không cần cửa sổ hiện)
                    const gb = document.querySelector('flow-generate-icon-button button, button.generate-icon-button');
                    if (gb) { logger.log('🎬 Bấm nút Tạo (Angular)'); htNgClick(gb); }
                } else if (k === 4) {
                    // dự phòng: click chuột CDP vào nút Tạo (chỉ ăn khi cửa sổ đang hiện)
                    const hb = document.querySelector('flow-generate-icon-button');
                    if (hb) {
                        const rr = hb.getBoundingClientRect();
                        await requestCdp({ type: 'CDP_CLICK', x: Math.round(rr.left + rr.width / 2), y: Math.round(rr.top + rr.height / 2) }, 5000);
                    }
                } else {
                    // cuối cùng: bật cửa sổ lên 1 nhịp → Enter → thu nhỏ lại
                    logger.warn('🎬 Enter không ăn khi cửa sổ ẩn → bật cửa sổ lên 1 nhịp');
                    await requestCdp({ type: 'HT_WINDOW', state: 'normal' }, 5000);
                    await htSleep(700);
                    placeCaret();
                    await requestCdp({ type: 'CDP_ENTER' }, 5000);
                    for (let w = 0; w < 20 && !sent(); w++) await htSleep(100);
                    let quiet = false; try { quiet = sessionStorage.getItem('htQuiet') === '1' || /htslot=(1|2)\d/.test(location.hash); } catch (e) {}
                    if (quiet) requestCdp({ type: 'HT_WINDOW', state: 'minimized' }, 5000);
                }
                for (let w = 0; w < 30 && !sent(); w++) await htSleep(100);
            }
            if (!sent()) {
                window.__htOnVideoCreate = null;
                return 'ERR|Không bấm được nút Tạo (Flow chưa gửi lệnh tạo video)';
            }
            if (st) st.submitted = true;
            setStage('đã gửi lệnh, chờ Flow nhận');
            for (let w = 0; w < 300 && !created; w++) await htSleep(100);     // ≤ 30s
            window.__htOnVideoCreate = null;
            if (!created) return 'ERR|Flow không trả lời lệnh tạo video (30s)';
            if (!created.ids.length) return 'ERR|' + (created.err || 'Flow không tạo video');
            const ids = created.ids;
            if (st) st.ids = ids;
            logger.success('Flow đã nhận lệnh tạo video:', ids);

            // Chờ từng video xong (mã 3). Video chạy vài phút → giới hạn theo model.
            setStage('đang render');
            const maxMs = /quality/i.test(String(p.model || '')) ? 600000 : 420000;
            const tW = Date.now();
            const failCode = (s) => typeof s === 'number' && ![1, 2, 3, 6].includes(s);
            while (Date.now() - tW < maxMs) {
                const sts = ids.map(id => window.__htVidStatus[id] || {});
                const bad = sts.find(x => x.err || (failCode(x.s) && Date.now() - (x.since || Date.now()) > 30000));
                if (bad) return 'ERR|Video lỗi (mã ' + bad.s + ')' + (bad.err ? ': ' + bad.err : '');
                if (sts.every(x => x.s === 3)) break;
                const snack = document.querySelector('.mat-mdc-snack-bar-label, [role="alert"]');
                const stx = snack ? (snack.innerText || '').trim() : '';
                if (stx && /lỗi|error|chặn|policy|vi phạm|không thể|failed/i.test(stx)) return 'ERR|Flow thông báo: ' + stx;
                if (st) st.stage = 'đang render ' + Math.round((Date.now() - tW) / 1000) + 's (mã ' + sts.map(x => x.s).join(',') + ')';
                htSetBusy(120000);
                await htSleep(1000);
            }
            if (!ids.every(id => (window.__htVidStatus[id] || {}).s === 3)) return 'ERR|Quá thời gian chờ render video (' + Math.round(maxMs / 60000) + ' phút)';

            // Lấy link có chữ ký (Flow vẽ thẻ <video> / RPC trả link ngay sau khi xong)
            setStage('lấy link video');
            const out = [];
            for (const id of ids) {
                let u = '';
                for (let w = 0; w < 40 && !(u = htFindVideoUrl(id)); w++) await htSleep(500);   // ≤ 20s
                out.push({ mediaId: id, url: u });
            }
            if (!out.some(x => x.url)) return 'ERR|Video đã xong nhưng không lấy được link tải (mediaId ' + ids.join(',') + ')';
            return 'OK|' + JSON.stringify(out);
        } catch (e) {
            return 'ERR|' + (e && e.message ? e.message : String(e));
        }
    }

    // ★ LỆNH VIDEO TỪ TOOL5: FLOWVID_START (chạy ngầm) + FLOWVID_POLL (hỏi tiến độ, trả ngay)
    async function flowVideoAction(actionStr) {
        // FLOWVID_POLL → OK|PENDING_UI (đang cài/gõ/bấm) | OK|PENDING|<giai đoạn> | OK|[{mediaId,url}] | ERR|...
        if (actionStr.startsWith('FLOWVID_POLL')) {
            const s = window.__htVidState;
            if (!s) return 'OK|IDLE';
            if (s.status === 'error') return 'ERR|' + s.error;
            if (s.status === 'done') return 'OK|' + JSON.stringify(s.result || []);
            if (!s.submitted) return 'OK|PENDING_UI|' + (s.stage || '');
            return 'OK|PENDING|' + (s.stage || '');
        }
        if (actionStr.startsWith('FLOWVID_START|')) {
            let p = {};
            try { p = JSON.parse(actionStr.slice('FLOWVID_START|'.length)); } catch (e) { return 'ERR|tham số FLOWVID_START sai'; }
            const cur = window.__htVidState;
            if (cur && cur.status === 'generating' && Date.now() - cur.tStart < 660000) return 'ERR|Cửa sổ này đang tạo video khác';
            const st = { status: 'generating', submitted: false, stage: 'bắt đầu', tStart: Date.now(), ids: [], result: null, error: null };
            window.__htVidState = st;
            htSetBusy(180000);
            (async () => {
                let res;
                try { res = await flowVideoGenerate(p); } catch (e) { res = 'ERR|' + String(e); }
                if (window.__htVidState !== st) return;
                if (String(res).startsWith('OK|')) {
                    try { st.result = JSON.parse(res.slice(3)); } catch (e) { st.result = []; }
                    st.status = 'done';
                } else {
                    st.status = 'error';
                    st.error = String(res).replace(/^ERR\|/, '');
                }
                htSetBusy(0);
            })();
            return 'OK|STARTED';
        }
        return 'ERR|lệnh video lạ: ' + actionStr.slice(0, 40);
    }

    // ★ CÀI ĐẶT MODEL, KHUNG HÌNH (RATIO), SỐ ẢNH TRÊN GIAO DIỆN FLOW
    async function applyFlowSettings({ model, ratio, count }) {
        try {
            let overlay = document.querySelector('flow-prompt-box-settings');
            if (!overlay) {
                const btn = document.querySelector('button.settings-trigger-button');
                if (btn) btn.click();
                await new Promise(r => setTimeout(r, 400));
                overlay = document.querySelector('flow-prompt-box-settings');
            }
            if (!overlay) return false;

            // 0. Chế độ Hình ảnh (cửa sổ có thể vừa được tool video chuyển sang Video)
            const imgT = Array.from(overlay.querySelectorAll('mat-button-toggle')).find(t => /Hình ảnh/.test(t.innerText || ''));
            if (imgT && !imgT.classList.contains('mat-button-toggle-checked')) {
                (imgT.querySelector('button') || imgT).click();
                await new Promise(r => setTimeout(r, 700));
                overlay = document.querySelector('flow-prompt-box-settings') || overlay;
            }

            // 1. Khung hình (ratio): 16:9, 9:16, 1:1, 4:3, 3:4
            if (ratio) {
                const rNorm = String(ratio).replace('IMAGE_ASPECT_RATIO_', '').toLowerCase();
                let targetText = '16:9';
                if (rNorm.includes('portrait') || rNorm === '9:16') targetText = '9:16';
                else if (rNorm.includes('square') || rNorm === '1:1') targetText = '1:1';
                else if (rNorm.includes('4:3')) targetText = '4:3';
                else if (rNorm.includes('3:4')) targetText = '3:4';

                const rBtns = Array.from(overlay.querySelectorAll('mat-button-toggle, button'));
                const rBtn = rBtns.find(b => b.innerText && b.innerText.includes(targetText));
                if (rBtn) {
                    const el = rBtn.tagName === 'BUTTON' ? rBtn : rBtn.querySelector('button') || rBtn;
                    el.click();
                }
            }

            // 2. Số lượng ảnh (count): x1, x2, x3, x4
            if (count) {
                const cText = 'x' + String(count);
                const cBtns = Array.from(overlay.querySelectorAll('mat-button-toggle, button'));
                const cBtn = cBtns.find(b => b.innerText && b.innerText.trim() === cText);
                if (cBtn) {
                    const el = cBtn.tagName === 'BUTTON' ? cBtn : cBtn.querySelector('button') || cBtn;
                    el.click();
                }
            }

            // 3. Model: Nano Banana Pro / 2 Lite / 2.1
            if (model) {
                const mNorm = String(model).toLowerCase();
                let shouldPick = null;
                if (mNorm.includes('pro') || mNorm.includes('gem_pix')) shouldPick = 'Pro';
                else if (mNorm.includes('2.1')) shouldPick = '2.1';
                else if (mNorm.includes('lite') || mNorm.includes('harbor')) shouldPick = 'Lite';
                else if (mNorm.includes('banana 2') || mNorm.includes('beluga')) shouldPick = 'Lite';

                if (shouldPick) {
                    const curModelBtn = overlay.querySelector('button[aria-label="Chọn nhóm mô hình"]');
                    const curText = curModelBtn ? curModelBtn.innerText : '';
                    if (!curText.includes(shouldPick) && curModelBtn) {
                        curModelBtn.click();
                        await new Promise(r => setTimeout(r, 500));
                        const menuItems = Array.from(document.querySelectorAll('.mat-mdc-menu-item, [role="menuitem"]'));
                        const targetItem = menuItems.find(m => m.innerText && m.innerText.includes(shouldPick));
                        if (targetItem) {
                            targetItem.click();
                            await new Promise(r => setTimeout(r, 400));
                        }
                    }
                }
            }

            // Đóng popup cài đặt
            const settingsBtn = document.querySelector('button.settings-trigger-button');
            if (settingsBtn) settingsBtn.click();
            await new Promise(r => setTimeout(r, 300));
            return true;
        } catch (e) {
            console.warn('[FLOW] Lỗi applyFlowSettings:', e);
            return false;
        }
    }

    // ★ TẠO ẢNH TRỰC TIẾP TRONG FLOW.GOOGLE.COM (batchexecute ogiZ0b)
    //   Chạy ở MAIN world của trang Flow: cookie + at + bl + fsid + grecaptcha đều là THẬT
    // ★ ĐÍNH ẢNH REF (đồng nhất): upload 1 ảnh từ máy qua UI Flow thật.
    //   Mở menu "+" → "Tệp tải lên" → background bơm file qua CDP (chặn hộp thoại).
    //   Flow tự upload (maseQ) bằng token thật → thành ingredient. Trả 'OK' / 'ERR|...'.
    async function attachIngredient(filePath) {
        try {
            if (!filePath) return 'ERR|thiếu đường dẫn ref';
            const baseName = String(filePath).split(/[\\/]/).pop();
            const countChips = () => document.querySelectorAll(
                '.chip-container, mat-chip, .mat-mdc-chip, [class*="ingredient" i]').length;
            const before = countChips();

            // Đã đính rồi (chip mang tên file đang có) → khỏi upload lại (tránh trùng)
            try {
                if (baseName && (document.body.innerText || '').includes(baseName)) {
                    logger.log('Ref đã có sẵn, bỏ qua upload: ' + baseName);
                    return 'OK';
                }
            } catch (e) {}

            // 1. Arm CDP: chặn hộp thoại chọn file + chuẩn bị bơm file này
            const armed = await requestCdp({ type: 'CDP_ARM_FILE', filePath: filePath });
            if (!armed || !armed.ok) return 'ERR|CDP arm lỗi: ' + (armed && armed.error || '?');

            // 2. Mở menu "+" thêm nội dung nghe nhìn
            let plusBtn = document.querySelector('button[aria-label="Trình đơn thêm nội dung nghe nhìn"]')
                || document.querySelector('button[aria-label*="thêm nội dung" i]')
                || document.querySelector('button[aria-label*="Thêm thành phần" i]');
            if (!plusBtn) return 'ERR|không thấy nút "+" thêm ảnh';
            plusBtn.click();
            await new Promise(r => setTimeout(r, 650));

            // 3. Chọn mục "Tệp tải lên"
            const items = Array.from(document.querySelectorAll(
                '[role="menuitem"], .mat-mdc-menu-item, .mat-mdc-list-item, button, a'));
            const upItem = items.find(el => /tệp tải lên|drive_folder_upload|upload/i.test(el.textContent || ''));
            if (!upItem) {
                document.querySelector('.cdk-overlay-backdrop')?.click();
                return 'ERR|không thấy mục "Tệp tải lên"';
            }
            upItem.click();   // → bật file chooser → background bơm file vào input

            // 4. Chờ ingredient mới hiện (upload maseQ xong), tối đa 25s
            const t0 = Date.now();
            while (Date.now() - t0 < 25000) {
                await new Promise(r => setTimeout(r, 700));
                try {
                    if (document.body && (document.body.innerText || '').includes(baseName)) return 'OK';
                    if (countChips() > before) return 'OK';
                } catch (e) {}
            }
            return 'ERR|chờ upload ref quá 25s (' + baseName + ')';
        } catch (e) {
            return 'ERR|' + (e && e.message ? e.message : String(e));
        }
    }

    async function flowGenerate(actionArg) {
        try {
            let projectId = '', prompt = '', model = '', ratio = '', count = 1, quality = '';
            let refs = [];
            let actionStr = '';
            if (typeof actionArg === 'object' && actionArg !== null) {
                projectId = actionArg.projectId || '';
                prompt = actionArg.prompt || '';
                model = actionArg.model || '';
                ratio = actionArg.ratio || '';
                count = actionArg.count || 1;
                quality = actionArg.quality || '';
                refs = Array.isArray(actionArg.refs) ? actionArg.refs : [];
                actionStr = 'FLOWGEN|' + projectId + '|' + prompt;
            } else {
                actionStr = String(actionArg);
                const parts = actionStr.split('|');
                projectId = parts[1] || '';
                prompt = parts.slice(2).join('|');
            }
            const parts = actionStr.split('|');

            // 1. POLLING TRẠNG THÁI TẠO ẢNH (phản hồi siêu nhanh 0.05s, không lo timeout 30s)
            if (parts[0] === 'FLOWGEN_POLL' || actionStr === 'FLOWGEN_POLL') {
                const s = window.__htFlowState || { status: 'idle' };
                if (s.error) return 'ERR|' + s.error;
                if (s.urls && s.urls.length > 0) return 'OK|' + JSON.stringify(s.urls);
                if (s.status === 'generating') {
                    // Không tự quét DOM ở đây nữa (trước đây vớ nhầm thumbnail menu @ / ảnh ref).
                    // Kết quả do flowGenerate() ghi vào s.urls khi đã xác thực đúng ảnh mới.
                    if (Date.now() - (s.tStart || 0) > 90000) {
                        return 'ERR|Quá thời gian chờ tạo ảnh (90s)';
                    }
                    // v2: còn đang gõ prompt / gắn chip / bấm nút → PENDING_UI; đã gửi lệnh tạo → PENDING
                    if (parts[1] === 'v2' && !s.submitted) return 'OK|PENDING_UI';
                    return 'OK|PENDING';
                }
                return 'OK|IDLE';
            }

            // 1b. NÂNG CẤP CHẤT LƯỢNG ẢNH (2K / 4K) QUA FLOW SPrCad NATIVE
            if (parts[0] === 'FLOWGEN_UPSCALE') {
                let params = {};
                try {
                    params = JSON.parse(actionStr.slice(actionStr.indexOf('|') + 1));
                } catch(e) {}
                const mediaId = params.mediaId || '';
                const targetRes = (params.resolution || '2K').includes('4K') ? '4K' : '2K';
                window.__htLastUpscaledB64 = null;
                
                try {
                    let tile = null;
                    if (mediaId) {
                        tile = document.querySelector(`flow-image-tile img[data-media-id="${mediaId}"]`);
                    }
                    if (!tile) {
                        tile = document.querySelector('flow-image-tile img');
                    }
                    if (!tile) return 'ERR|Không tìm thấy ảnh trên Flow để upscale';
                    
                    tile.click();
                    await new Promise(r => setTimeout(r, 600));

                    const dlBtn = document.querySelector('button[aria-label="Tải nội dung nghe nhìn xuống"]');
                    if (!dlBtn) {
                        document.querySelector('.cdk-overlay-backdrop')?.click();
                        document.querySelector('button[aria-label*="quay lại" i]')?.click();
                        return 'ERR|Không tìm thấy nút tải xuống';
                    }
                    dlBtn.click();
                    await new Promise(r => setTimeout(r, 500));

                    const menuItems = Array.from(document.querySelectorAll('[role="menuitem"], .mat-mdc-menu-item'));
                    const item = menuItems.find(m => m.innerText && m.innerText.includes(targetRes));
                    if (!item) {
                        document.querySelector('.cdk-overlay-backdrop')?.click();
                        document.querySelector('button[aria-label*="quay lại" i]')?.click();
                        return 'ERR|Không tìm thấy menu ' + targetRes;
                    }
                    item.click();
                    logger.success('Đã kích hoạt tải ảnh chất lượng cao ' + targetRes);
                    await new Promise(r => setTimeout(r, 2500));

                    document.querySelector('.cdk-overlay-backdrop')?.click();
                    document.querySelector('button[aria-label*="quay lại" i]')?.click();

                    return 'OK|TRIGGERED';
                } catch(e) {
                    document.querySelector('.cdk-overlay-backdrop')?.click();
                    document.querySelector('button[aria-label*="quay lại" i]')?.click();
                    return 'ERR|' + String(e);
                }
            }

            // 2. KHỞI ĐỘNG TẠO ẢNH BẤT ĐỒNG BỘ (trả OK|STARTED ngay trong 0.5s)
            if (parts[0] === 'FLOWGEN_START') {
                let startParams = {};
                try {
                    const jsonStr = actionStr.slice(actionStr.indexOf('|') + 1);
                    startParams = JSON.parse(jsonStr);
                } catch(e) {
                    startParams = {
                        projectId: parts[1] || '',
                        prompt: parts.slice(2).join('|')
                    };
                }
                const pId = startParams.projectId || parts[1] || '';
                const pPrompt = startParams.prompt !== undefined ? startParams.prompt : parts.slice(2).join('|');
                const pModel = startParams.model || '';
                const pRatio = startParams.ratio || '';
                const pCount = startParams.count || 1;
                const pQuality = startParams.quality || '';
                const pRefs = Array.isArray(startParams.refs) ? startParams.refs : [];

                window.__htFlowState = {
                    status: 'generating',
                    urls: [],
                    error: null,
                    tStart: Date.now(),
                    baseline: new Set()
                };
                const baseOf = (u) => String(u).split('?')[0];
                Array.from(document.querySelectorAll('flow-image-tile img, img[src*="flow-content.google"], img[src*="/asb/"]')).forEach(i => window.__htFlowState.baseline.add(baseOf(i.src)));
                (window.__htSeenBases ? Array.from(window.__htSeenBases) : []).forEach(b => window.__htFlowState.baseline.add(b));

                // Bắt đầu chạy ngầm quy trình tạo ảnh thật
                (async () => {
                    // Chế độ taskbar: cửa sổ đang thu nhỏ → bật lên trong lượt gõ/bấm (trang bị thu nhỏ thì Flow "ngủ")
                    let quiet = false;
                    try { quiet = sessionStorage.getItem('htQuiet') === '1'; } catch (e) {}
                    if (quiet) {
                        for (let tryN = 0; tryN < 2 && document.visibilityState !== 'visible'; tryN++) {
                            await requestCdp({ type: 'HT_WINDOW', state: 'normal' }, 5000);
                            for (let w = 0; w < 20 && document.visibilityState !== 'visible'; w++) await new Promise(r => setTimeout(r, 100));
                        }
                        await new Promise(r => setTimeout(r, 500));
                        // bấm Tạo xong (Flow đã gửi lệnh) → thu nhỏ lại ngay, phần chờ ảnh chạy ngầm
                        //   (2K/4K phải bấm menu tải về sau khi có ảnh → giữ cửa sổ tới lúc xong hẳn)
                        const needUp = /2K|4K/.test(String(pQuality || ''));
                        const iv = setInterval(() => {
                            const st = window.__htFlowState || {};
                            if ((st.submitted && !needUp) || st.status !== 'generating') {
                                clearInterval(iv);
                                requestCdp({ type: 'HT_WINDOW', state: 'minimized' }, 5000);
                            }
                        }, 300);
                    }
                    try {
                        const res = await flowGenerate({
                            projectId: pId,
                            prompt: pPrompt,
                            model: pModel,
                            ratio: pRatio,
                            count: pCount,
                            quality: pQuality,
                            refs: pRefs
                        });
                        if (res.startsWith('OK|')) {
                            window.__htFlowState.status = 'done';
                            window.__htFlowState.urls = JSON.parse(res.slice(3));
                        } else if (res.startsWith('ERR|')) {
                            window.__htFlowState.status = 'error';
                            window.__htFlowState.error = res.slice(4);
                        }
                    } catch (err) {
                        window.__htFlowState.status = 'error';
                        window.__htFlowState.error = String(err);
                    }
                })();

                return 'OK|STARTED';
            }

            if (prompt === '__RELOAD_EXT__') {
                const res = await requestCdp({ type: 'RELOAD_EXTENSION' });
                return 'OK|' + JSON.stringify(res);
            }

            // ===== ĐA LUỒNG =====
            if (prompt === '__SLOTS__') {
                const res = await requestCdp({ type: 'HT_LIST_SLOTS' }, 15000);
                return 'OK|' + JSON.stringify({ me: (sessionStorage.getItem('htSlot') || ''), ...res });
            }
            if (prompt.startsWith('__SLOTS_ENSURE__|')) {
                let p = {};
                try { p = JSON.parse(prompt.slice('__SLOTS_ENSURE__|'.length)); } catch (e) {}
                const scr = { w: screen.availWidth, h: screen.availHeight, l: screen.availLeft || 0, t: screen.availTop || 0 };
                const res = await requestCdp({ type: 'HT_ENSURE_SLOTS', n: p.n, pid: p.pid, base: p.base || 0, minimized: !!p.minimized, screen: scr }, 30000);
                return (res && res.ok ? 'OK|' : 'ERR|') + JSON.stringify(res);
            }
            if (prompt === '__RELOAD_PAGE__') {
                setTimeout(() => { try { localStorage.removeItem('_grecaptcha'); } catch (e) {} location.reload(); }, 150);
                return 'OK|RELOADING';
            }
            if (prompt.startsWith('__WIN__|')) {
                // min = thu nhỏ xuống taskbar + bật chế độ âm thầm; normal = hiện lại bình thường
                const want = prompt.split('|')[1] === 'min' ? 'minimized' : 'normal';
                try { sessionStorage.setItem('htQuiet', want === 'minimized' ? '1' : '0'); } catch (e) {}
                const res = await requestCdp({ type: 'HT_WINDOW', state: want }, 5000);
                return 'OK|' + JSON.stringify(res);
            }

            if (prompt === '__GET_AUTH_INFO__') {
                const cdpRes = await requestCdp({ type: 'GET_COOKIES' });
                const wiz = window.WIZ_global_data || {};
                let at = wiz.SNlM0e || null;
                let bl = wiz.cfb2h || null;
                let sid = wiz.FdrFJe || null;
                if (!at) {
                    const html = document.documentElement.innerHTML;
                    const mAt = html.match(/"SNlM0e":"([^"]+)"/);
                    if (mAt) at = mAt[1];
                    const mBl = html.match(/"cfb2h":"([^"]+)"/);
                    if (mBl) bl = mBl[1];
                    const mSid = html.match(/"FdrFJe":"([^"]+)"/);
                    if (mSid) sid = mSid[1];
                }
                return 'OK|' + JSON.stringify({
                    cookies: cdpRes?.cookies || {},
                    at, bl, sid
                });
            }

            if (prompt.startsWith('__TEST_FETCH_RPC__|')) {
                const subPrompt = prompt.replace('__TEST_FETCH_RPC__|', '');
                const rcToken = await solveCaptcha('IMAGE_GENERATION');
                const wiz = window.WIZ_global_data || {};
                const at = wiz.SNlM0e || '';
                const bl = wiz.cfb2h || '';
                const sid = wiz.FdrFJe || '';
                const pid = projectId || 'e4af9426-7259-4a23-8495-307da7740d23';
                const seed = Math.floor(Math.random() * 1000000000);
                const u1 = crypto.randomUUID().toUpperCase();
                const u2 = crypto.randomUUID().toUpperCase();
                const u3 = crypto.randomUUID().toUpperCase();

                const ctx = [null, 22, null, null, null, pid, null, null, null, null, [rcToken, 1]];
                const inner = [
                    null,
                    [[ null, null, null, seed, 3, "BELUGA", null, ctx, [[[ subPrompt ]]], null, null, null, u1, u2 ]],
                    1,
                    ctx,
                    [ u3 ]
                ];
                const freq = JSON.stringify([[["ogiZ0b", JSON.stringify(inner), null, "generic"]]]);
                const body = 'f.req=' + encodeURIComponent(freq) + '&at=' + encodeURIComponent(at) + '&';
                const qs = new URLSearchParams({
                    rpcids: 'ogiZ0b',
                    'source-path': '/project/' + pid,
                    bl: bl,
                    'f.sid': sid,
                    hl: 'vi',
                    _reqid: String(Math.floor(Math.random() * 900000) + 100000),
                    rt: 'c'
                }).toString();
                const url = 'https://flow.google.com/_/AiSandboxAngularFrontend/data/batchexecute?' + qs;

                logger.log('Sending In-Page Fetch RPC for:', subPrompt);
                const resp = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'content-type': 'application/x-www-form-urlencoded;charset=utf-8',
                        'x-same-domain': '1'
                    },
                    body: body
                });
                const respText = await resp.text();
                return 'OK|' + respText.slice(0, 500);
            }

            if (prompt.startsWith('__EVAL__||')) {
                try {
                    const code = prompt.slice(10);
                    const res = await eval(code);
                    return 'OK|' + JSON.stringify(res);
                } catch(e) {
                    return 'ERR|' + String(e);
                }
            }

            if (prompt === '__PING__' || prompt === '__DIAGNOSE__') {
                const btn = document.querySelector('button.generate-icon-button');
                const pm = document.querySelector('.ProseMirror');
                const allInputs = Array.from(document.querySelectorAll('input, textarea, [contenteditable="true"]')).map(el => (el.tagName + (el.className ? '.' + el.className.split(' ').join('.') : '')));
                const alerts = Array.from(document.querySelectorAll('[role="alert"], .mat-mdc-snack-bar-label, dialog, [role="dialog"], .cdk-overlay-pane'))
                    .map(el => el.innerText?.trim()).filter(Boolean);
                const domImgs = Array.from(document.querySelectorAll('img[src*="flow-content.google"]')).map(i => i.src);
                return 'OK|' + JSON.stringify({
                    url: location.href,
                    title: document.title,
                    hasPm: !!pm,
                    hasBtn: !!btn,
                    allInputs,
                    alerts,
                    domImgsCount: domImgs.length,
                    domImgs: domImgs.slice(-5),
                    outboundLen: (window.__htOutbound || []).length,
                    outbound: (window.__htOutbound || []).slice(-10),
                    recentUrls: (window.__htRecentUrls || []).slice(-10),
                    lastOgi: window.__htLastOgi || null,
                    lastAction: window.__HT_ACTION || null
                });
            }

            if (prompt.startsWith('__TEST_UI_')) {
                const target = prompt.replace('__TEST_UI_', '');
                const pm = document.querySelector('.ProseMirror');
                if (!pm) return 'ERR|no_pm';
                pm.focus();
                const p = pm.querySelector('p') || pm;
                const range = document.createRange();
                range.selectNodeContents(p);
                const sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
                p.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: 'con meo', bubbles: true, cancelable: true, composed: true }));
                document.execCommand('selectAll', false, null);
                document.execCommand('insertText', false, 'con meo');
                p.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: 'con meo', bubbles: true, composed: true }));
                pm.dispatchEvent(new Event('input', { bubbles: true }));

                let btn = null;
                for (let i = 0; i < 30; i++) {
                    btn = document.querySelector('button.generate-icon-button');
                    if (btn && !btn.disabled && !btn.classList.contains('mat-mdc-button-disabled')) break;
                    await new Promise(r => setTimeout(r, 100));
                }

                const btnHost = document.querySelector('flow-generate-icon-button');
                const t0_rc = window.__HT_LAST_RECAPTCHA || 0;
                const n_urls = (window.__htRecentUrls || []).length;
                const n_out = (window.__htOutbound || []).length;

                const clickSeq = (el) => {
                    const rect = el.getBoundingClientRect();
                    const cx = rect.left + rect.width / 2;
                    const cy = rect.top + rect.height / 2;
                    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(evtName => {
                        el.dispatchEvent(new MouseEvent(evtName, {
                            bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, buttons: 1
                        }));
                    });
                };

                let callRes = null, callErr = null;

                if (target === 'PM_ENTER') {
                    pm.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
                    pm.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
                    pm.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
                } else if (target === 'BTN_CLICK') {
                    if (btn) btn.click();
                } else if (target === 'BTN_MOUSE') {
                    if (btn) clickSeq(btn);
                } else if (target === 'HOST_MOUSE') {
                    if (btnHost) clickSeq(btnHost);
                } else if (target === 'ICON_MOUSE') {
                    const icon = btn?.querySelector('mat-icon') || btn;
                    if (icon) clickSeq(icon);
                } else if (target === 'UNWRAP_CLICK') {
                    const btnClick = btn?.__htListeners?.find(l => l.type === 'click');
                    const raw = btnClick?.listener ? btnClick.listener('__ngUnwrap__') : null;
                    try { if (raw) callRes = raw(new MouseEvent('click', { bubbles: true })); } catch(e) { callErr = String(e); }
                } else if (target === 'UNWRAP_HOST') {
                    const btnHostGen = btnHost?.__htListeners?.find(l => l.type === 'generate');
                    const raw = btnHostGen?.listener ? btnHostGen.listener('__ngUnwrap__') : null;
                    try { if (raw) callRes = raw(new CustomEvent('generate', { bubbles: true })); } catch(e) { callErr = String(e); }
                } else if (target === 'UNWRAP_SUBMIT') {
                    const editor = document.querySelector('flow-rich-text-editor');
                    const editorSub = editor?.__htListeners?.find(l => l.type === 'submit');
                    const raw = editorSub?.listener ? editorSub.listener('__ngUnwrap__') : null;
                    try { if (raw) callRes = raw(new CustomEvent('submit', { bubbles: true })); } catch(e) { callErr = String(e); }
                }

                await new Promise(r => setTimeout(r, 2000));

                const t1_rc = window.__HT_LAST_RECAPTCHA || 0;
                const rc_fired = t1_rc > t0_rc;
                const new_urls = (window.__htRecentUrls || []).slice(n_urls);
                const new_out = (window.__htOutbound || []).slice(n_out);

                return 'OK|' + JSON.stringify({
                    target,
                    callRes,
                    callErr,
                    btnDisabled: btn?.disabled,
                    btnClasses: btn ? Array.from(btn.classList) : [],
                    rc_fired,
                    lastAction: window.__HT_ACTION || null,
                    new_out
                });
            }

            if (!prompt) return 'ERR|thiếu prompt';

            // 1. Kiểm tra project đang mở trên tab
            let pathMatch = location.pathname.match(/project\/([0-9a-f-]{8,})/i);
            if (!pathMatch) {
                const targetPid = projectId || 'd1e7ba9a-4275-4dd3-a679-9641e5206476';
                logger.log('Đang tự chuyển tab vào project:', targetPid);
                location.href = 'https://flow.google.com/project/' + targetPid;
                return 'ERR|Đang tự mở project (' + targetPid.slice(0, 8) + '...). Đợi 5 giây rồi bấm lại là được!';
            }
            projectId = pathMatch[1];

            // 2. Chờ ô nhập ProseMirror xuất hiện (Angular Ivy cần 2-10s mount DOM)
            let pm = document.querySelector('.ProseMirror, [contenteditable="true"]');
            if (!pm) {
                logger.log('Đang chờ ô nhập prompt (.ProseMirror) xuất hiện...');
                for (let i = 0; i < 30; i++) {
                    await new Promise(r => setTimeout(r, 500));
                    pm = document.querySelector('.ProseMirror, [contenteditable="true"]');
                    if (pm) break;
                }
            }
            if (!pm) return 'ERR|Không tìm thấy ô nhập prompt (.ProseMirror) trên trang sau 15s!';

            // 2a. ĐỒNG NHẤT: chuyển refs thành @mention nếu prompt chưa có
            if (refs && refs.length) {
                for (const refItem of refs) {
                    const base = String(refItem).split(/[\\/]/).pop().replace(/\.[^/.]+$/, '');
                    if (base && !prompt.includes('@' + base)) {
                        prompt = '@' + base + ' ' + prompt;
                    }
                }
                logger.log('📎 Prompt sau khi gắn ref:', prompt);
            }

            // MỐC ẢNH CŨ (base-path, bỏ query): gồm ảnh đang hiện trên DOM + mọi ảnh mạng đã thấy.
            // Chỉ ảnh có base-path KHÔNG nằm trong mốc này mới được coi là ảnh vừa tạo.
            const baseOf = (u) => String(u).split('?')[0];
            const baseline = new Set();
            Array.from(document.querySelectorAll('flow-image-tile img, img[src*="flow-content.google"], img[src*="/asb/"]')).forEach(i => baseline.add(baseOf(i.src)));
            (window.__htSeenBases ? Array.from(window.__htSeenBases) : []).forEach(b => baseline.add(b));

            // 2b. Áp dụng Model, Khung hình (Ratio), Số lượng ảnh (Count)
            if (model || ratio || count) {
                logger.log('⚙️ Đang áp dụng cài đặt Flow:', { model, ratio, count });
                await applyFlowSettings({ model, ratio, count });
            }

            // Đóng bất kỳ menu popover nào đang mở dở từ trước để tránh che chắn
            document.querySelector('.cdk-overlay-backdrop')?.click();
            await new Promise(r => setTimeout(r, 200));

            // 3. Focus ô nhập và đưa prompt vào DOM
            // ★ Lấy lại ô nhập: applyFlowSettings / đóng menu có thể làm Angular render lại ProseMirror → pm cũ bị tách khỏi DOM
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            const freshPm = () => document.querySelector('.ProseMirror') || pm;
            pm = freshPm();
            const placeCaretEnd = () => {
                pm = freshPm();
                pm.focus();
                const ps = pm.querySelectorAll('p');
                const pEl = ps.length ? ps[ps.length - 1] : pm;
                const last = pEl.lastChild;
                const r = document.createRange();
                if (last && last.nodeType === 3) r.setStart(last, last.textContent.length);
                else if (last && last.nodeName === 'BR') r.setStartBefore(last);
                else { r.selectNodeContents(pEl); r.collapse(false); }
                r.collapse(true);
                const s = window.getSelection();
                s.removeAllRanges();
                s.addRange(r);
            };
            const stripTrailingAt = () => {
                // xoá chữ '@' / '@CHAR_01' gõ dở còn sót nếu chèn chip hỏng
                pm = freshPm();
                const ps = pm.querySelectorAll('p');
                const pEl = ps.length ? ps[ps.length - 1] : pm;
                const last = pEl.lastChild;
                if (!last || last.nodeType !== 3) return;
                const m = last.textContent.match(/@[^\s@]*$/);
                if (!m) return;
                pm.focus();
                const r = document.createRange();
                r.setStart(last, last.textContent.length - m[0].length);
                r.setEnd(last, last.textContent.length);
                const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
                document.execCommand('delete', false, null);
            };
            const assetTitle = (b) => (b.querySelector('.asset-title')?.innerText || b.innerText || '').trim().toLowerCase();
            const findAsset = (name) => {
                const n = name.toLowerCase();
                const items = Array.from(document.querySelectorAll('button.asset-item'));
                // ưu tiên khớp CHÍNH XÁC tên (bỏ đuôi .png/.jpg), sau đó mới khớp chứa
                return items.find(b => assetTitle(b).replace(/\.[a-z0-9]{2,5}$/, '') === n)
                    || items.find(b => assetTitle(b).includes(n));
            };
            const ngClick = async (el) => {
                const l = el.__htListeners?.find(x => x.type === 'click');
                const raw = l?.listener ? l.listener('__ngUnwrap__') : null;
                if (raw) { try { raw(new MouseEvent('click', { bubbles: true })); return; } catch (e) {} }
                el.click();
            };
            const chipDbg = [];
            window.__htChipDbg = chipDbg;
            const insertChip = async (assetName) => {
                for (let attempt = 1; attempt <= 3; attempt++) {
                    pm = freshPm();
                    const before = pm.querySelectorAll('.mention-chip').length;
                    const dbg = { name: assetName, attempt };
                    placeCaretEnd();
                    document.execCommand('insertText', false, '@');
                    pm.dispatchEvent(new Event('input', { bubbles: true }));
                    let target = null;
                    for (let i = 0; i < 25 && !target; i++) { await sleep(150); target = findAsset(assetName); }
                    dbg.menuItems = document.querySelectorAll('button.asset-item').length;
                    if (!target && dbg.menuItems) {
                        // menu có nhưng chưa thấy → gõ tên để lọc
                        document.execCommand('insertText', false, assetName);
                        pm.dispatchEvent(new Event('input', { bubbles: true }));
                        for (let i = 0; i < 20 && !target; i++) { await sleep(150); target = findAsset(assetName); }
                    }
                    dbg.found = target ? assetTitle(target) : null;
                    if (target) {
                        await ngClick(target);
                        let addBtn = null;
                        for (let i = 0; i < 15 && !addBtn; i++) { await sleep(150); addBtn = document.querySelector('button.detail-add-to-prompt-btn'); }
                        dbg.addBtn = !!addBtn;
                        if (addBtn) {
                            await ngClick(addBtn);
                            await sleep(500);
                            if (freshPm().querySelectorAll('.mention-chip').length <= before) {
                                // click JS không ăn → click phần cứng CDP vào nút "Thêm vào câu lệnh"
                                const r = addBtn.getBoundingClientRect();
                                if (r.width) await requestCdp({ type: 'CDP_CLICK', x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) });
                                await sleep(600);
                            }
                        }
                    }
                    pm = freshPm();
                    dbg.chips = pm.querySelectorAll('.mention-chip').length;
                    dbg.html = pm.innerHTML.slice(0, 160);
                    chipDbg.push(dbg);
                    logger.log('📎 Gắn chip:', dbg);
                    if (dbg.chips > before) return true;
                    document.querySelector('.cdk-overlay-backdrop')?.click();
                    await sleep(300);
                    stripTrailingAt();
                    await sleep(300);
                }
                return false;
            };

            pm.focus();
            const p = pm.querySelector('p') || pm;
            const range = document.createRange();
            range.selectNodeContents(p);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            document.execCommand('selectAll', false, null);
            document.execCommand('delete', false, null);

            if (prompt.includes('@')) {
                const parts = prompt.split(/(@[a-zA-Z0-9_.-]+)/g);
                for (const part of parts) {
                    if (part.startsWith('@')) {
                        await insertChip(part.slice(1).trim());
                    } else if (part && part.trim()) {
                        placeCaretEnd();
                        document.execCommand('insertText', false, ' ' + part.trim());
                        pm.dispatchEvent(new Event('input', { bubbles: true }));
                        await sleep(300);
                    }
                }
            } else {
                p.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: prompt, bubbles: true, cancelable: true, composed: true }));
                document.execCommand('insertText', false, prompt);
                p.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: prompt, bubbles: true, composed: true }));
            }
            pm = freshPm();
            pm.dispatchEvent(new Event('input', { bubbles: true }));

            // 3b. ĐỒNG NHẤT: bắt buộc chip @nhân vật đã nằm trong ô prompt, nếu không thì KHÔNG tạo
            const wantRefs = (prompt.match(/@[a-zA-Z0-9_.-]+/g) || []).length;
            if (wantRefs > 0) {
                const chips = Array.from(pm.querySelectorAll('.mention-chip')).map(c => c.innerText.trim());
                logger.log('📎 Chip nhân vật trong prompt:', chips, '| cần:', wantRefs);
                if (chips.length < wantRefs) {
                    document.querySelector('.cdk-overlay-backdrop')?.click();
                    return 'ERR|Không gắn được ảnh nhân vật vào prompt (chip ' + chips.length + '/' + wantRefs +
                           '). Chẩn đoán: ' + JSON.stringify(chipDbg).slice(0, 700);
                }
            }
            // Đóng mọi menu/panel còn mở (menu @, chi tiết asset) để không che nút Tạo
            document.querySelector('.cdk-overlay-backdrop')?.click();
            await new Promise(r => setTimeout(r, 200));

            // 4. Đợi nút Tạo kích hoạt
            let btn = null;
            for (let i = 0; i < 50; i++) {
                btn = document.querySelector('flow-generate-icon-button button, button.generate-icon-button, button[aria-label="Bắt đầu tạo"], button[aria-label="Generate"]');
                if (btn && !btn.disabled && !btn.classList.contains('mat-mdc-button-disabled')) break;
                await new Promise(r => setTimeout(r, 100));
            }

            if (!btn) {
                return 'ERR|Không tìm thấy nút tạo ảnh trên trang!';
            }

            // 5. Lấy tọa độ nút và ô nhập trên màn hình (ưu tiên flow-generate-icon-button host)
            const hostBtn = document.querySelector('flow-generate-icon-button') || btn;
            const btnRect = hostBtn.getBoundingClientRect();
            const btnX = Math.round(btnRect.left + btnRect.width / 2);
            const btnY = Math.round(btnRect.top + btnRect.height / 2);

            const pmRect = pm.getBoundingClientRect();
            const pmX = Math.round(pmRect.left + pmRect.width / 2);
            const pmY = Math.round(pmRect.top + pmRect.height / 2);

            // Hàm chuyển đổi URL sang base64 dataUrl qua in-page fetch
            const fetchAsDataUrl = async (urlStr) => {
                try {
                    const r = await fetch(urlStr, { credentials: 'include' });
                    if (r.ok) {
                        const blob = await r.blob();
                        if (blob && blob.size > 500) {
                            return await new Promise(res => {
                                const rd = new FileReader();
                                rd.onloadend = () => res(rd.result);
                                rd.readAsDataURL(blob);
                            });
                        }
                    }
                } catch (e) {}
                return null;
            };

            const packageImgs = async (items) => {
                const list = [];
                for (const it of items) {
                    const u = typeof it === 'string' ? it : (it.url || '');
                    const mid = (typeof it === 'object' && it.mediaId) ? it.mediaId : null;
                    const dUrl = await fetchAsDataUrl(u);
                    list.push({ url: u, dataUrl: dUrl, mediaId: mid });
                }
                return list;
            };

            // Ảnh kết quả hợp lệ = ảnh trong flow-image-tile trên canvas, KHÔNG nằm trong overlay (menu @, panel chi tiết)
            const genTileImgs = () => Array.from(document.querySelectorAll('flow-image-tile img'))
                .filter(i => i.src && !i.closest('.cdk-overlay-container') && !i.closest('.ProseMirror'));
            // Chụp lại mốc NGAY TRƯỚC khi bấm Tạo: mọi ảnh đang có trên trang (kể cả thumbnail ref vừa hiện) đều là cũ
            Array.from(document.querySelectorAll('img')).forEach(i => { if (i.src) baseline.add(baseOf(i.src)); });
            const tGen = Date.now();
            const ogiSent = () => (window.__htOgiSentAt || 0) >= tGen;

            // 6. Chuẩn bị Promise chờ ảnh từ Google Flow (hook mạng ogiZ0b + quét tile canvas)
            const waitResult = new Promise((resolve) => {
                let resolved = false;
                const timer = setTimeout(() => {
                    if (resolved) return;
                    resolved = true;
                    window.__htOnImages = null;
                    resolve(ogiSent() ? 'ERR|Quá thời gian chờ tạo ảnh (80s)'
                                      : 'ERR|Không bấm được nút Tạo (Flow chưa gửi request tạo ảnh ogiZ0b)');
                }, 80000);

                window.__htOnImages = async (res) => {
                    if (resolved) return;
                    // Lỗi từ response (UNUSUAL_ACTIVITY / PUBLIC_ERROR...) -> trả lỗi thật ngay
                    if (typeof res === 'string' && res.startsWith('ERR|')) {
                        resolved = true;
                        clearTimeout(timer);
                        clearInterval(pollIv);
                        window.__htOnImages = null;
                        resolve(res);
                        return;
                    }
                    // Chỉ nhận link CHƯA có trong mốc (ảnh thật sự vừa tạo). Toàn ảnh cũ -> bỏ qua, chờ tiếp.
                    const fresh = (Array.isArray(res) ? res : []).filter(u => !baseline.has(baseOf(u)));
                    if (!fresh.length) return;
                    resolved = true;
                    clearTimeout(timer);
                    clearInterval(pollIv);
                    window.__htOnImages = null;
                    logger.success('Link ảnh MỚI từ mạng Flow:', fresh);
                    // Chờ Angular render thẻ ảnh mới lên DOM (tối đa 8s) để lấy link /asb/ và fetch dataUrl
                    //   (cửa sổ đang thu nhỏ → trang không render, dùng luôn link từ mạng)
                    let domTile = null;
                    for (let w = 0; w < 16 && document.visibilityState === 'visible'; w++) {
                        await new Promise(r => setTimeout(r, 500));
                        domTile = genTileImgs().find(i => !baseline.has(baseOf(i.src)));
                        if (domTile) break;
                    }
                    const toPack = domTile ? [{ url: domTile.src }] : fresh.map(u => ({ url: u }));
                    const packed = await packageImgs(toPack);
                    logger.success('Đã đóng gói ảnh:', packed.map(p => ({ url: p.url.slice(0, 60), hasData: !!p.dataUrl })));
                    resolve('OK|' + JSON.stringify(packed.length ? packed : fresh));
                };

                const pollIv = setInterval(async () => {
                    if (resolved) { clearInterval(pollIv); return; }
                    // Chỉ tin DOM khi request tạo ảnh đã thật sự được gửi sau khi bấm Tạo
                    const currentImgs = ogiSent() ? genTileImgs()
                        .map(i => i.src)
                        .filter(s => !baseline.has(baseOf(s))) : [];
                    if (currentImgs.length > 0) {
                        resolved = true;
                        clearTimeout(timer);
                        clearInterval(pollIv);
                        window.__htOnImages = null;
                        logger.success('Ảnh MỚI trên DOM Flow:', currentImgs);
                        const packed = await packageImgs(currentImgs);
                        resolve('OK|' + JSON.stringify(packed));
                    }
                    const snack = document.querySelector('.mat-mdc-snack-bar-label, [role="alert"]');
                    if (snack && snack.innerText?.trim()) {
                        const txt = snack.innerText.trim();
                        if (/lỗi|error|chặn|policy|vi phạm|không thể/i.test(txt)) {
                            resolved = true;
                            clearTimeout(timer);
                            clearInterval(pollIv);
                            window.__htOnImages = null;
                            resolve('ERR|Flow thông báo: ' + txt);
                        }
                    }
                }, 1000);
            });

            // 7. Gửi Hardware Click (CDP Input) qua Chrome Debugger
            // Chỉ gửi click phần cứng CDP (Input.dispatchMouseEvent) để đảm bảo event.isTrusted=true và reCAPTCHA không chặn.
            // ★ Đo lại tọa độ trước MỖI lần bấm: lần CDP đầu tiên kéo cửa sổ lên/focus → layout đổi, tọa độ cũ bị lệch.
            let blockedBy = '';
            for (let clickTry = 1; clickTry <= 4 && !ogiSent(); clickTry++) {
                const hb = document.querySelector('flow-generate-icon-button') || btn;
                const rr = hb.getBoundingClientRect();
                const cx = Math.round(rr.left + rr.width / 2), cy = Math.round(rr.top + rr.height / 2);
                // Có thứ gì đè lên nút Tạo (menu/overlay/badge)? → đóng overlay của Flow, ghi lại để chẩn đoán
                const topEl = document.elementFromPoint(cx, cy);
                if (topEl && !hb.contains(topEl) && !topEl.contains(hb)) {
                    blockedBy = (topEl.tagName || '') + (topEl.id ? '#' + topEl.id : '') + (topEl.className && typeof topEl.className === 'string' ? '.' + topEl.className.split(' ')[0] : '');
                    logger.log('⚠️ Nút Tạo bị che bởi', blockedBy);
                    document.querySelector('.cdk-overlay-backdrop')?.click();
                    await new Promise(r => setTimeout(r, 250));
                }
                logger.log('🚀 Click CDP nút Tạo lần', clickTry, 'tại', cx, cy);
                await requestCdp({ type: 'CDP_CLICK', x: cx, y: cy });
                for (let w = 0; w < 25 && !ogiSent(); w++) await new Promise(r => setTimeout(r, 100));
            }
            if (!ogiSent()) {
                logger.log('⚠️ Đã bấm 4 lần mà Flow chưa gửi request tạo ảnh');
                window.__htOnImages = null;
                return 'ERR|Không bấm được nút Tạo (4 lần, Flow chưa gửi request tạo ảnh)' + (blockedBy ? ' [nút bị che bởi ' + blockedBy + ']' : '') + ' — để cửa sổ Cốc Cốc không bị thu nhỏ/che';
            }
            // Đã gửi lệnh tạo → báo cho tool nhả "khoá thao tác" để cửa sổ khác gõ/bấm trong lúc chờ Google vẽ
            if (window.__htFlowState && window.__htFlowState.status === 'generating') window.__htFlowState.submitted = true;
            const finalResult = await waitResult;
            if (finalResult && finalResult.startsWith('OK|') && quality && (quality.includes('2K') || quality.includes('4K'))) {
                const targetQuality = quality.includes('4K') ? '4K' : '2K';
                logger.log('🚀 Đang thực hiện nâng chất lượng ảnh lên:', targetQuality);
                try {
                    await new Promise(r => setTimeout(r, 1200));
                    const tileImg = document.querySelector('flow-image-tile img');
                    if (tileImg) {
                        tileImg.click();
                        await new Promise(r => setTimeout(r, 600));
                        const dlBtn = document.querySelector('button[aria-label="Tải nội dung nghe nhìn xuống"]');
                        if (dlBtn) {
                            dlBtn.click();
                            await new Promise(r => setTimeout(r, 500));
                            const menuItems = Array.from(document.querySelectorAll('[role="menuitem"], .mat-mdc-menu-item'));
                            const itemQ = menuItems.find(m => m.innerText && m.innerText.includes(targetQuality));
                            if (itemQ) {
                                itemQ.click();
                                logger.success('Đã kích hoạt tải ảnh chất lượng cao ' + targetQuality);
                                await new Promise(r => setTimeout(r, 2500));
                            }
                        }
                        document.querySelector('.cdk-overlay-backdrop')?.click();
                        document.querySelector('button[aria-label*="quay lại" i]')?.click();
                    }
                } catch(e) {
                    logger.warn('Lỗi khi kích hoạt nâng chất lượng ảnh:', e);
                }
            }
            return finalResult;
        } catch (e) {
            return 'ERR|' + (e && e.message ? e.message : String(e));
        }
    }

    // ===== XỬ LÝ 1 LỆNH TỪ SERVER (dùng chung cho lệnh trực tiếp và lệnh được chuyển từ cửa sổ khác) =====
    async function handleAction(action) {
        action = action || 'VIDEO_GENERATION';
        if (action.startsWith('FLOWVID_')) return await flowVideoAction(action);
        if (action.startsWith('FLOWGEN|') || action.startsWith('FLOWGEN_')) {
            if (action.includes('__PING__') || action.includes('__DIAGNOSE__') || action.includes('__EVAL__') || action.includes('__RELOAD_EXT__') ||
                action.includes('__SLOTS') || action.includes('__RELOAD_PAGE__') || action.includes('__WIN__|') ||
                action.startsWith('FLOWGEN_POLL') || action.startsWith('FLOWGEN_START') || action.startsWith('FLOWGEN_UPSCALE')) {
                return await flowGenerate(action);
            }
            // KHÓA TUẦN TỰ với timeout an toàn 45s
            const runTask = () => Promise.race([
                flowGenerate(action),
                new Promise(res => setTimeout(() => res('ERR|Quá thời gian chờ tạo ảnh (45s)'), 45000))
            ]);
            window.__htFlowLock = Promise.resolve(window.__htFlowLock).catch(() => {}).then(runTask);
            return await window.__htFlowLock;
        }
        if (!window.grecaptcha?.enterprise?.execute) {
            await Promise.race([
                recaptchaReadyPromise,
                new Promise(r => setTimeout(r, 4000))
            ]);
        }
        return await solveCaptcha(action);     // mint token captcha như cũ
    }

    // ĐA LUỒNG: lệnh dạng "@S<n>@<action>" → chỉ cửa sổ slot n chạy. Server luôn gửi cho 1 tab bất kỳ,
    //   tab đó nhờ background chuyển sang đúng cửa sổ (không cần sửa CaptchaServer.exe).
    const mySlot = () => { try { return sessionStorage.getItem('htSlot') || ''; } catch (e) { return ''; } };
    function relayToSlot(slot, action, timeoutMs = 55000) {
        return new Promise((resolve) => {
            const reqId = 'relay_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
            const handler = (e) => {
                if (e.source !== window || e.data?.type !== 'HT_RELAY_RESPONSE' || e.data?.reqId !== reqId) return;
                window.removeEventListener('message', handler);
                resolve(e.data.response || { ok: false, error: 'empty relay response' });
            };
            window.addEventListener('message', handler);
            window.postMessage({ type: 'HT_RELAY_REQUEST', reqId, slot, action, timeout: timeoutMs }, '*');
            setTimeout(() => {
                window.removeEventListener('message', handler);
                resolve({ ok: false, error: 'relay timeout' });
            }, timeoutMs + 3000);
        });
    }
    async function dispatchAction(rawAction) {
        let action = rawAction || 'VIDEO_GENERATION';
        const m = action.match(/^@S(\d+)@/);
        if (!m) return await handleAction(action);
        action = action.slice(m[0].length);
        if (m[1] === mySlot()) return await handleAction(action);
        const r = await relayToSlot(m[1], action);
        if (r && r.ok) {
            if (r.error) throw new Error(r.error);
            return r.result;
        }
        const err = (r && r.error) || 'relay failed';
        if (/^FLOW(GEN|VID)/.test(action)) return (err === 'NO_SLOT' ? 'ERR|NO_SLOT|' + m[1] : 'ERR|SLOT_' + m[1] + ': ' + err);
        throw new Error(err);
    }
    // Nhận lệnh được chuyển tới cửa sổ này (content.js → page)
    window.addEventListener('message', async (e) => {
        if (e.source !== window || e.data?.type !== 'HT_EXEC_REQUEST') return;
        const reqId = e.data.reqId;
        try {
            const result = await handleAction(String(e.data.action || ''));
            window.postMessage({ type: 'HT_EXEC_RESPONSE', reqId, result }, '*');
        } catch (err) {
            window.postMessage({ type: 'HT_EXEC_RESPONSE', reqId, error: String(err && err.message || err) }, '*');
        }
    });

    try {
        createCountdownStyles();
        createCountdownBadge();
        const settings = await getSettings();
        if (settings && settings.enabled && settings.autoReload && settings.targetTime) {
            const totalSeconds = (settings.reloadInterval || 0) * 60;
            setInterval(() => {
                const remainingMs = Math.max(0, settings.targetTime - Date.now());
                const remainingSeconds = Math.ceil(remainingMs / 1000);
                updateCountdownBadge(remainingSeconds, totalSeconds);
            }, 1000); 
        }

        // Lấy Socket.IO cục bộ
        logger.log('Loading Socket.IO local module...');
        if (!window.io) {
            throw new Error('Thư viện Socket.IO chưa được cài đặt từ nội bộ extension!');
        }
        const io = window.io;
        logger.success('Socket.IO local loaded successfully');

        const socket = io(CONFIG.socketServer, {
            transports: ['websocket', 'polling'],
            autoConnect: true
        });

        socket.on('connect', () => {
            logger.success('Connected to server! Socket ID', socket.id);
            if (window.grecaptcha?.enterprise?.execute) {
                socket.emit('client:ready', { timestamp: new Date().toISOString() });
            }
        });

        socket.on('disconnect', () => { logger.log('Disconnected from server'); });
        socket.on('connect_error', (error) => { logger.error('Connection error', error); });

        window.addEventListener('message', (event) => {
            if (event.source !== window) return;
            if (event.data.type === 'CAPTURED_HEADERS') {
                if (socket && socket.connected) {
                    socket.emit('client:captured-headers', { headers: event.data.headers, timestamp: new Date().toISOString() });
                }
            }
        });

        async function refreshChromeHeaders() {
            try {
                await fetch('https://aisandbox-pa.googleapis.com/v1/video:batchCheckAsyncVideoGenerationStatus', {
                    method: 'POST',
                    headers: { 'content-type': 'text/plain;charset=UTF-8' },
                    body: JSON.stringify({ operations: [{ operation: { name: 'dummy' }, sceneId: 'dummy' }] }),
                    credentials: 'include'
                });
            } catch (e) {}
        }
        setTimeout(refreshChromeHeaders, 2000);
        setInterval(refreshChromeHeaders, 4 * 60 * 1000);

        socket.on('server:request-captcha', async (data) => {
            try {
                const token = await dispatchAction(data?.action || 'VIDEO_GENERATION');
                socket.emit('client:captcha-solved', { requestId: data?.requestId, token, timestamp: new Date().toISOString() });
            } catch (error) {
                socket.emit('client:captcha-error', { requestId: data?.requestId, error: error.message, timestamp: new Date().toISOString() });
            }
        });

        socket.on('server:reload-page', (data) => {
            // Đang tạo ảnh dở (đa luồng: cửa sổ khác vẫn chạy) → không F5 ngang, tránh hỏng ảnh đang chờ
            const st = window.__htFlowState;
            if (st && st.status === 'generating' && Date.now() - (st.tStart || 0) < 100000) {
                logger.log('Bỏ qua reload: đang tạo ảnh');
                return;
            }
            let busy = 0;
            try { busy = parseInt(sessionStorage.getItem('htBusyUntil') || '0', 10) || 0; } catch (e) {}
            if (busy > Date.now()) { logger.log('Bỏ qua reload: đang tạo video'); return; }
            const delay = data?.delay || 0;
            localStorage.removeItem('_grecaptcha');
            if (delay > 0) {
                setTimeout(() => { window.location.reload(); }, delay);
            } else {
                window.location.reload();
            }
        });

        // Bỏ qua lệnh navigate tự động từ NestJS vì NestJS gửi random UUID fake gây 404
        socket.on('server:navigate', (data) => {
            logger.log('Bỏ qua server:navigate:', data?.url || data);
        });

        await waitForRecaptcha();
        recaptchaReadyResolve();
        socket.emit('client:ready', { timestamp: new Date().toISOString() });
        logger.success('reCAPTCHA Ready & client:ready emitted!');

        window.captchaClient = {
            socket,
            solveCaptcha,
            config: CONFIG,
            solveAndSend: async () => {
                const token = await solveCaptcha();
                socket.emit('client:captcha-manual', { token, timestamp: new Date().toISOString() });
                return token;
            },
            reloadPage: (delay = 0) => {
                localStorage.removeItem('_grecaptcha');
                if (delay > 0) setTimeout(() => window.location.reload(), delay);
                else window.location.reload();
            },
            refreshHeaders: refreshChromeHeaders
        };
        logger.success('Captcha Client Ready!');

    } catch (error) {
        logger.error('Initialization failed', error);
        sendStatus('init_failed', { error: error.message });
    }
})();