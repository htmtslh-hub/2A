"""
film_studio_mcp_server.py — Máy Chủ Model Context Protocol (MCP) & Điều Phối Tự Động Hóa cho Film Studio
────────────────────────────────────────────────────────────────────────────────────────────────────────
Cho phép mọi AI Agent bên ngoài (Claude Desktop, Cursor, Windsurf, ChatGPT Desktop, Cline, OpenClaw, n8n...)
điều khiển trực tiếp toàn bộ dây chuyền sản xuất video của Film Studio:
  1. film_studio_doctor                    : Kiểm tra sức khỏe hệ thống, tài khoản Ultra/Vids/Muse, API Key & GPU FFmpeg.
  2. film_studio_write_storyboard          : Biên kịch phân cảnh 8s chuẩn FlowKit + Hồ sơ nhân vật + Lọc từ cấm Google Policy.
  3. film_studio_clone_video_prompts       : Phân tích video mẫu (.mp4) bằng OpenCV + Vision AI -> Bóc tách bộ Prompt phân cảnh.
  4. film_studio_generate_character_images : Tạo ảnh tham chiếu nhân vật/bối cảnh (Bước 1) & ảnh phân cảnh đồng nhất (Bước 2).
  5. film_studio_render_videos_async       : Quay video hàng loạt bất đồng bộ (Veo 3.1 T2V/I2V/Đồng nhất, Google Vids, Muse.ai) + Upscale 1080p.
  6. film_studio_synthesize_voice          : Tổng hợp giọng đọc AI đa nhân vật (Edge Neural miễn phí / HaThanh / Google Vids 23 giọng) + Xuất .SRT.
  7. film_studio_post_production_merge     : Dựng hậu kỳ FFmpeg GPU (Ghép Video/Ảnh Ken Burns + Giọng đọc + 58 hiệu ứng chuyển cảnh xfade).
  8. film_studio_job_status                : Kiểm tra tiến độ (0-100%), danh sách file đầu ra hoặc hủy tiến trình render bất đồng bộ.
  9. film_studio_auto_pipeline             : Đạo diễn tự hành 1 chạm (Từ Ý tưởng -> Kịch bản -> Giọng đọc -> Hình ảnh/Video -> Dựng MP4 hoàn chỉnh).

Hỗ trợ song song 2 giao thức kết nối:
  • Giao thức 1 — STDIO JSON-RPC 2.0 (Chuẩn MCP 2024-11-05 / 2025-03-26 cho Claude Desktop, Cursor, Windsurf, Cline):
      python film_studio_mcp_server.py --stdio
  • Giao thức 2 — HTTP / SSE / Streamable HTTP Server (Chạy ngầm tại http://127.0.0.1:3100 cho n8n, Make, Web Agent & Đồng bộ GUI):
      python film_studio_mcp_server.py --http --port 3100
"""

from __future__ import annotations

import argparse
import base64
import datetime
import json
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
import urllib.parse
import urllib.request

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

MCP_SERVER_NAME = "film-studio-mcp"
MCP_SERVER_VERSION = "3.1.0"
MCP_PROTOCOL_VERSION = "2024-11-05"
DEFAULT_MCP_HTTP_PORT = 3100

MCP_OUTPUT_ROOT = os.path.join(SRC_DIR, "MCP_Output")
MCP_JOBS_FILE = os.path.join(MCP_OUTPUT_ROOT, "mcp_jobs_state.json")
MCP_EVENT_LOG_FILE = os.path.join(MCP_OUTPUT_ROOT, "mcp_activity.log")
os.makedirs(MCP_OUTPUT_ROOT, exist_ok=True)


def _now_iso() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _safe_slug(text: str, max_len: int = 36) -> str:
    s = re.sub(r"[^a-zA-Z0-9_\-]+", "_", (text or "project").strip())
    s = re.sub(r"_+", "_", s).strip("_")
    return (s[:max_len] or "project").lower()


def _format_srt_timestamp(seconds: float) -> str:
    ms_total = max(0, int(round(float(seconds) * 1000)))
    hrs = ms_total // 3_600_000
    rem = ms_total % 3_600_000
    mins = rem // 60_000
    rem %= 60_000
    secs = rem // 1000
    ms = rem % 1000
    return f"{hrs:02d}:{mins:02d}:{secs:02d},{ms:03d}"


def _write_srt_file(entries: List[Tuple[float, float, str]], srt_path: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(srt_path)), exist_ok=True)
    blocks = []
    for idx, (t_start, t_end, line_txt) in enumerate(entries, start=1):
        blocks.append(
            f"{idx}\n{_format_srt_timestamp(t_start)} --> {_format_srt_timestamp(t_end)}\n{(line_txt or '').strip()}\n"
        )
    with open(srt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(blocks))
    return srt_path


# ═════════════════════════════════════════════════════════════════════════════
# 1. TRÌNH QUẢN LÝ TIẾN TRÌNH BẤT ĐỒNG BỘ (ASYNC JOB QUEUE & IPC STATE)
# ═════════════════════════════════════════════════════════════════════════════
class MCPJobManager:
    """Quản lý các tác vụ render dài hạn (Video / Ảnh / Pipeline) chống timeout 60s của MCP Client."""

    def __init__(self):
        self._lock = threading.Lock()
        self.jobs: Dict[str, Dict[str, Any]] = {}
        self.activity_logs: List[Dict[str, Any]] = []
        self.gui_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None
        self._load_persisted_jobs()

    def _load_persisted_jobs(self):
        if os.path.isfile(MCP_JOBS_FILE):
            try:
                with open(MCP_JOBS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict) and isinstance(data.get("jobs"), dict):
                    self.jobs = data["jobs"]
            except Exception:
                self.jobs = {}

    def _save_persisted_jobs(self):
        try:
            os.makedirs(MCP_OUTPUT_ROOT, exist_ok=True)
            # Chỉ giữ 50 job gần nhất để file nhẹ
            keys = sorted(self.jobs.keys(), key=lambda k: self.jobs[k].get("created_at", ""), reverse=True)[:50]
            slim_jobs = {k: self.jobs[k] for k in keys}
            tmp_path = MCP_JOBS_FILE + ".tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump({"updated_at": _now_iso(), "jobs": slim_jobs}, f, ensure_ascii=False, indent=2)
            os.replace(tmp_path, MCP_JOBS_FILE)
        except Exception:
            pass

    def log_event(self, tool_name: str, message: str, extra: Optional[Dict[str, Any]] = None):
        entry = {
            "time": _now_iso(),
            "tool": tool_name,
            "message": message,
            "extra": extra or {},
        }
        with self._lock:
            self.activity_logs.append(entry)
            if len(self.activity_logs) > 200:
                self.activity_logs = self.activity_logs[-200:]
            try:
                with open(MCP_EVENT_LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(f"[{entry['time']}] [{tool_name}] {message}\n")
            except Exception:
                pass
        if self.gui_callback:
            try:
                self.gui_callback("log", entry)
            except Exception:
                pass

    def create_job(self, job_type: str, title: str, total_steps: int = 1, meta: Optional[Dict[str, Any]] = None) -> str:
        job_id = f"job_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        job_obj = {
            "job_id": job_id,
            "job_type": job_type,
            "title": title,
            "status": "RUNNING",
            "progress": 0,
            "total_steps": max(1, int(total_steps)),
            "completed_steps": 0,
            "created_at": _now_iso(),
            "updated_at": _now_iso(),
            "CancelRequested": False,
            "logs": [f"[{_now_iso()}] Khởi tạo tiến trình: {title}"],
            "outputs": [],
            "result": {},
            "meta": meta or {},
        }
        with self._lock:
            self.jobs[job_id] = job_obj
            self._save_persisted_jobs()
        self.log_event(job_type, f"Khởi chạy {job_id}: {title}", {"job_id": job_id})
        return job_id

    def update_job(
        self,
        job_id: str,
        status: Optional[str] = None,
        progress: Optional[int] = None,
        completed_steps: Optional[int] = None,
        log_line: Optional[str] = None,
        add_output: Optional[str] = None,
        result: Optional[Dict[str, Any]] = None,
    ):
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return
            if status:
                job["status"] = status
            if progress is not None:
                job["progress"] = max(0, min(100, int(progress)))
            if completed_steps is not None:
                job["completed_steps"] = int(completed_steps)
            if log_line:
                job["logs"].append(f"[{_now_iso()}] {log_line}")
                if len(job["logs"]) > 120:
                    job["logs"] = job["logs"][-120:]
            if add_output and add_output not in job["outputs"]:
                job["outputs"].append(add_output)
            if result is not None:
                job["result"].update(result)
            job["updated_at"] = _now_iso()
            self._save_persisted_jobs()
        if log_line:
            self.log_event(job.get("job_type", "job"), f"[{job_id}] {log_line}", {"job_id": job_id})

    def is_cancelled(self, job_id: str) -> bool:
        with self._lock:
            self._load_persisted_jobs()
            job = self.jobs.get(job_id)
            return bool(job and job.get("CancelRequested"))

    def cancel_job(self, job_id: str) -> bool:
        with self._lock:
            self._load_persisted_jobs()
            job = self.jobs.get(job_id)
            if not job:
                return False
            job["CancelRequested"] = True
            if job.get("status") == "RUNNING":
                job["status"] = "CANCELLING"
            job["logs"].append(f"[{_now_iso()}] ⏹ Đã nhận lệnh yêu cầu dừng tiến trình.")
            job["updated_at"] = _now_iso()
            self._save_persisted_jobs()
            return True

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            self._load_persisted_jobs()
            return self.jobs.get(job_id)

    def list_jobs(self, limit: int = 15) -> List[Dict[str, Any]]:
        with self._lock:
            self._load_persisted_jobs()
            items = sorted(self.jobs.values(), key=lambda x: x.get("created_at", ""), reverse=True)
            return items[:limit]


JOB_MANAGER = MCPJobManager()


# ═════════════════════════════════════════════════════════════════════════════
# 2. ĐỊNH NGHĨA SCHEMA 9 MCP TOOLS CHUẨN MODEL CONTEXT PROTOCOL
# ═════════════════════════════════════════════════════════════════════════════
MCP_TOOLS_SCHEMA: List[Dict[str, Any]] = [
    {
        "name": "film_studio_doctor",
        "description": (
            "Kiểm tra toàn diện trạng thái của ứng dụng Film Studio: API Key đa hãng (Gemini/OpenAI/Claude/DeepSeek), "
            "trình duyệt Google Ultra (Veo 3.1 Credits), Cookie Google Vids, Profile Muse.ai, danh sách giọng đọc TTS "
            "và phần cứng GPU FFmpeg (NVENC/AMF/QSV). Hãy gọi tool này đầu tiên để biết hệ thống đã sẵn sàng những gì."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "check_gpu": {
                    "type": "boolean",
                    "description": "Kiểm tra chi tiết bộ mã hóa phần cứng GPU FFmpeg (mặc định: true).",
                    "default": True,
                }
            },
            "required": [],
        },
    },
    {
        "name": "film_studio_write_storyboard",
        "description": (
            "Bước 1 — Biên kịch & Tạo danh sách câu lệnh phân cảnh (Storyboard Prompts) chuẩn điện ảnh 8 giây (3 nhịp 0-3s / 3-6s / 6-8s) "
            "kèm Hồ sơ Nhân vật & Bối cảnh đồng nhất (CHAR_01, CHAR_02, LOC_01). Tự động làm sạch các từ khóa nhạy cảm dễ bị Google Veo 3 / Imagen chặn."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "idea": {
                    "type": "string",
                    "description": "Ý tưởng cốt truyện, chủ đề video hoặc tóm tắt nội dung cần làm phim.",
                },
                "num_scenes": {
                    "type": "integer",
                    "description": "Số lượng phân cảnh cần tạo (mỗi cảnh 8 giây, mặc định: 5).",
                    "default": 5,
                },
                "style": {
                    "type": "string",
                    "description": "Phong cách hình ảnh (ví dụ: '3D Pixar / Disney', 'Điện ảnh thực tế (Cinematic Photorealistic)', 'Anime Nhật Bản', 'Cổ trang / Tiên hiệp 3D', 'Cyberpunk Sci-Fi').",
                    "default": "3D Pixar / Disney",
                },
                "genre": {
                    "type": "string",
                    "description": "Thể loại phim (ví dụ: 'Phiêu lưu / Hành động', 'Hoạt hình thiếu nhi / Giáo dục', 'Kể chuyện cảm động / Gia đình', 'Quảng cáo sản phẩm / Thương mại').",
                    "default": "Phiêu lưu / Hành động",
                },
                "character_appearance": {
                    "type": "string",
                    "description": "Mô tả ngoại hình nhân vật cố định (tùy chọn — để trống AI sẽ tự thiết kế CHAR_01, CHAR_02...).",
                    "default": "",
                },
                "dialogue_lang": {
                    "type": "string",
                    "description": "Ngôn ngữ lời thoại (ví dụ: 'Tiếng Việt', 'Tiếng Anh (English)', 'Không có thoại').",
                    "default": "Tiếng Việt",
                },
                "sanitize_google_policy": {
                    "type": "boolean",
                    "description": "Tự động lọc và viết lại các từ nhạy cảm (trẻ em, bạo lực, máu me) theo chuẩn an toàn Google Flow.",
                    "default": True,
                },
                "push_to_gui": {
                    "type": "boolean",
                    "description": "Tự động đẩy kịch bản vừa tạo lên giao diện Film Studio nếu ứng dụng đang mở.",
                    "default": True,
                },
            },
            "required": ["idea"],
        },
    },
    {
        "name": "film_studio_clone_video_prompts",
        "description": (
            "Bước 1 (Phân tích Video mẫu) — Tách khung hình từ một file video có sẵn (.mp4, .mov, .mkv) và dùng Vision AI "
            "bóc tách thành Hồ sơ nhân vật + Danh sách câu lệnh phân cảnh Veo 3 để sản xuất lại video tương tự."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "video_path": {
                    "type": "string",
                    "description": "Đường dẫn tuyệt đối tới file video mẫu trên máy tính.",
                },
                "segment_seconds": {
                    "type": "number",
                    "description": "Độ dài mỗi phân đoạn cảnh cần tách (mặc định: 8 giây).",
                    "default": 8.0,
                },
                "max_segments": {
                    "type": "integer",
                    "description": "Số lượng phân cảnh tối đa cần trích xuất (mặc định: 8).",
                    "default": 8,
                },
                "style": {
                    "type": "string",
                    "description": "Phong cách hình ảnh mong muốn cho bộ Prompt đầu ra.",
                    "default": "3D Pixar / Disney",
                },
                "aspect_ratio": {
                    "type": "string",
                    "description": "Tỷ lệ khung hình ('16:9' hoặc '9:16').",
                    "default": "16:9",
                },
            },
            "required": ["video_path"],
        },
    },
    {
        "name": "film_studio_generate_character_images",
        "description": (
            "Bước 2A — Tạo bộ Ảnh Tham Chiếu Nhân Vật/Bối Cảnh (CHAR_01, LOC_01) và Ảnh Phân Cảnh Đồng Nhất (Single-Frame Keyframe) "
            "qua Google Flow (GEM_PIX_2 / NARWHAL) hoặc Gemini Imagen 3, tự động khóa media_id để dùng cho quay video đồng nhất."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "ref_lines": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách mô tả nhân vật/bối cảnh gốc, định dạng: ['CHAR_01 | Mô tả ngoại hình...', 'LOC_01 | Mô tả bối cảnh...'].",
                },
                "scene_lines": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách câu lệnh phân cảnh cần vẽ ảnh đồng nhất theo các nhân vật ở ref_lines (tùy chọn).",
                    "default": [],
                },
                "style": {
                    "type": "string",
                    "description": "Phong cách hình ảnh chủ đạo.",
                    "default": "3D Pixar / Disney",
                },
                "aspect_ratio": {
                    "type": "string",
                    "description": "Tỷ lệ khung hình ('16:9', '9:16', '1:1').",
                    "default": "16:9",
                },
                "model": {
                    "type": "string",
                    "description": "Mô hình tạo ảnh Google Flow ('GEM_PIX_2', 'NARWHAL', 'HARBOR_SEAL').",
                    "default": "GEM_PIX_2",
                },
                "output_dir": {
                    "type": "string",
                    "description": "Thư mục lưu ảnh xuất ra (bỏ trống sẽ lưu vào MCP_Output/images).",
                    "default": "",
                },
            },
            "required": ["ref_lines"],
        },
    },
    {
        "name": "film_studio_render_videos_async",
        "description": (
            "Bước 2B — Quay video AI hàng loạt ở chế độ bất đồng bộ (Async Job Queue) để không bị ngắt kết nối Timeout. "
            "Hỗ trợ 5 chế độ: 'veo_ultra_t2v' (Text to Video), 'veo_ultra_consist' (Đồng nhất nhân vật), 'veo_ultra_i2v' (Ảnh ra Video), "
            "'google_vids' (Veo qua Cookie Google Vids), và 'muse_ai' (Video đồng nhất qua Muse.ai). Trả về job_id ngay lập tức."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách câu lệnh phân cảnh cần quay video.",
                },
                "engine": {
                    "type": "string",
                    "enum": ["veo_ultra_t2v", "veo_ultra_consist", "veo_ultra_i2v", "google_vids", "muse_ai"],
                    "description": "Công cụ quay video AI muốn sử dụng.",
                    "default": "veo_ultra_t2v",
                },
                "aspect_ratio": {
                    "type": "string",
                    "enum": ["16:9", "9:16"],
                    "description": "Tỷ lệ khung hình video ('16:9' ngang hoặc '9:16' dọc).",
                    "default": "16:9",
                },
                "upscale_1080p": {
                    "type": "boolean",
                    "description": "Tự động nâng cấp chất lượng video lên Full HD 1080p (áp dụng cho Google Ultra Veo 3.1).",
                    "default": True,
                },
                "image_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách đường dẫn ảnh đầu vào (dùng cho 'veo_ultra_i2v' hoặc ảnh nhân vật cho 'muse_ai').",
                    "default": [],
                },
                "ref_media_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách media_id ảnh tham chiếu nhân vật đã tạo trên Google Flow (dùng cho 'veo_ultra_consist').",
                    "default": [],
                },
                "output_dir": {
                    "type": "string",
                    "description": "Thư mục lưu các file video .mp4.",
                    "default": "",
                },
            },
            "required": ["prompts"],
        },
    },
    {
        "name": "film_studio_synthesize_voice",
        "description": (
            "Bước 3A — Tạo giọng đọc thuyết minh / lồng tiếng AI cho danh sách các phân cảnh hoặc kịch bản dài, "
            "tự động đo thời lượng thật bằng FFprobe và xuất kèm file phụ đề .SRT khớp từng mili-giây. "
            "Hỗ trợ 3 nguồn giọng: 'edge_free' (12 giọng Neural Việt/Anh/Nhật/Hàn/Trung miễn phí 100%), "
            "'google_vids' (23 giọng Espresso Google Vids hỗ trợ thẻ cảm xúc [happy], [serious]...), và 'hathanh_api' (ElevenLabs/Minimax/Vbee)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "texts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách các câu thoại / lời thuyết minh (mỗi phần tử tương ứng với 1 cảnh quay: 0001.mp3, 0002.mp3...).",
                },
                "engine": {
                    "type": "string",
                    "enum": ["edge_free", "google_vids", "hathanh_api"],
                    "description": "Nguồn tạo giọng đọc AI ('edge_free' hoạt động ngay không cần API key).",
                    "default": "edge_free",
                },
                "voice_id": {
                    "type": "string",
                    "description": (
                        "Mã giọng đọc. Ví dụ với edge_free: 'edge_vi-VN-HoaiMyNeural' (Nữ VN), 'edge_vi-VN-NamMinhNeural' (Nam VN), "
                        "'edge_en-US-AriaNeural' (Nữ Mỹ), 'edge_en-US-ChristopherNeural' (Nam Mỹ). Với google_vids: 'Kore', 'Puck', 'Aoede', 'Fenrir'."
                    ),
                    "default": "edge_vi-VN-HoaiMyNeural",
                },
                "speed": {
                    "type": "number",
                    "description": "Tốc độ đọc (0.7 đến 1.5, mặc định: 1.0).",
                    "default": 1.0,
                },
                "export_srt": {
                    "type": "boolean",
                    "description": "Tự động sinh file phụ đề .srt khớp chính xác thời lượng âm thanh từng cảnh.",
                    "default": True,
                },
                "merge_single_audio": {
                    "type": "boolean",
                    "description": "Ghép nối toàn bộ các câu thoại thành 1 file audio tổng duy nhất (full_voiceover.mp3).",
                    "default": False,
                },
                "output_dir": {
                    "type": "string",
                    "description": "Thư mục lưu các file âm thanh và phụ đề .srt.",
                    "default": "",
                },
            },
            "required": ["texts"],
        },
    },
    {
        "name": "film_studio_post_production_merge",
        "description": (
            "Bước 3B — Dựng hậu kỳ FFmpeg GPU: Tự động đồng bộ thời lượng Video (Mode 2) hoặc Ảnh tĩnh hiệu ứng Ken Burns (Mode 3) "
            "khớp khít với từng file Giọng đọc (Audio), áp dụng 58 hiệu ứng chuyển cảnh (xfade) và kết xuất ra file phim .MP4 hoàn chỉnh."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "visual_inputs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách đường dẫn các file Video (.mp4) hoặc Ảnh (.jpg/.png), hoặc 1 phần tử là đường dẫn thư mục chứa Video/Ảnh.",
                },
                "audio_inputs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách đường dẫn các file Audio (.mp3/.wav) tương ứng từng cảnh, hoặc 1 phần tử là đường dẫn thư mục chứa Audio.",
                    "default": [],
                },
                "output_path": {
                    "type": "string",
                    "description": "Đường dẫn lưu file .mp4 thành phẩm cuối cùng (bỏ trống sẽ tự tạo trong MCP_Output/movies).",
                    "default": "",
                },
                "mode": {
                    "type": "string",
                    "enum": ["auto", "video_sync", "image_kenburns"],
                    "description": "Chế độ dựng: 'video_sync' (ghép các clip .mp4 với audio), 'image_kenburns' (biến ảnh tĩnh thành video chuyển động Ken Burns + audio), hoặc 'auto' (tự nhận diện theo đuôi file).",
                    "default": "auto",
                },
                "sync_mode": {
                    "type": "string",
                    "enum": ["speed", "loop", "freeze"],
                    "description": "Cách đồng bộ thời lượng hình và tiếng: 'speed' (co giãn tốc độ video mượt mà theo giọng đọc), 'loop' (lặp video), 'freeze' (giữ frame cuối).",
                    "default": "speed",
                },
                "kenburns_effect": {
                    "type": "string",
                    "enum": ["random", "zoom_in", "zoom_out", "pan_left", "pan_right", "pan_up", "pan_down", "combo", "classic", "static"],
                    "description": "Hiệu ứng chuyển động camera khi dựng từ ảnh tĩnh (Mode image_kenburns).",
                    "default": "random",
                },
                "resolution": {
                    "type": "string",
                    "enum": ["720p", "1080p", "2K", "4K"],
                    "description": "Độ phân giải video xuất ra.",
                    "default": "1080p",
                },
                "aspect_ratio": {
                    "type": "string",
                    "enum": ["16:9", "9:16"],
                    "description": "Tỷ lệ khung hình video thành phẩm.",
                    "default": "16:9",
                },
                "use_gpu": {
                    "type": "boolean",
                    "description": "Bật tăng tốc phần cứng GPU (NVIDIA NVENC / AMD AMF / Intel QSV), tự động fallback CPU nếu cần.",
                    "default": True,
                },
            },
            "required": ["visual_inputs"],
        },
    },
    {
        "name": "film_studio_job_status",
        "description": (
            "Kiểm tra tiến độ (0% -> 100%), nhật ký chi tiết và danh sách file đầu ra của một tiến trình bất đồng bộ (job_id), "
            "hoặc liệt kê toàn bộ các tiến trình đang chạy / đã hoàn thành trong Film Studio."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "Mã tiến trình (job_id) trả về từ film_studio_render_videos_async hoặc film_studio_auto_pipeline. Để trống nếu muốn liệt kê danh sách job.",
                    "default": "",
                },
                "action": {
                    "type": "string",
                    "enum": ["status", "list", "cancel"],
                    "description": "Hành động: 'status' (xem chi tiết 1 job), 'list' (xem danh sách các job gần nhất), 'cancel' (dừng khẩn cấp job đang chạy).",
                    "default": "status",
                },
            },
            "required": [],
        },
    },
    {
        "name": "film_studio_auto_pipeline",
        "description": (
            "Đạo Diễn Tự Hành 1 Chạm (End-to-End Autonomous Video Pipeline): Chỉ cần truyền vào 1 ý tưởng (idea), "
            "Film Studio sẽ tự động thực hiện trọn gói từ Bước 1 đến Bước 3: "
            "(1) Viết kịch bản phân cảnh & lời bình -> (2) Tổng hợp giọng đọc AI & phụ đề .SRT -> "
            "(3) Tạo hình ảnh/video cho từng phân cảnh -> (4) Ghép hậu kỳ FFmpeg ra file phim .MP4 hoàn chỉnh."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "idea": {
                    "type": "string",
                    "description": "Ý tưởng, chủ đề hoặc nội dung kịch bản muốn sản xuất thành phim hoàn chỉnh.",
                },
                "num_scenes": {
                    "type": "integer",
                    "description": "Số phân cảnh của video (mặc định: 4).",
                    "default": 4,
                },
                "style": {
                    "type": "string",
                    "description": "Phong cách hình ảnh (ví dụ: '3D Pixar / Disney', 'Anime Nhật Bản', 'Điện ảnh thực tế').",
                    "default": "3D Pixar / Disney",
                },
                "narration_lines": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Danh sách lời bình/lời thoại cho từng cảnh (tùy chọn — nếu bỏ trống AI sẽ tự viết lời bình khớp với từng cảnh).",
                    "default": [],
                },
                "voice_engine": {
                    "type": "string",
                    "enum": ["edge_free", "google_vids", "hathanh_api"],
                    "description": "Nguồn tạo giọng đọc thuyết minh.",
                    "default": "edge_free",
                },
                "voice_id": {
                    "type": "string",
                    "description": "Mã giọng đọc (mặc định: 'edge_vi-VN-HoaiMyNeural' cho Tiếng Việt).",
                    "default": "edge_vi-VN-HoaiMyNeural",
                },
                "visual_engine": {
                    "type": "string",
                    "enum": ["veo_ultra_t2v", "veo_ultra_consist", "google_vids", "muse_ai", "kenburns_storyboard"],
                    "description": (
                        "Chế độ tạo hình ảnh/video: 'veo_ultra_t2v' / 'veo_ultra_consist' / 'google_vids' / 'muse_ai' (quay video AI 8s thật), "
                        "hoặc 'kenburns_storyboard' (tạo ảnh phân cảnh + hiệu ứng chuyển động Ken Burns tốc độ cao, chạy xong ngay lập tức)."
                    ),
                    "default": "kenburns_storyboard",
                },
                "aspect_ratio": {
                    "type": "string",
                    "enum": ["16:9", "9:16"],
                    "description": "Tỷ lệ khung hình ('16:9' ngang YouTube hoặc '9:16' dọc TikTok/Shorts/Reels).",
                    "default": "16:9",
                },
                "resolution": {
                    "type": "string",
                    "enum": ["720p", "1080p"],
                    "description": "Độ phân giải video xuất ra.",
                    "default": "1080p",
                },
                "wait_for_completion": {
                    "type": "boolean",
                    "description": "Nếu true, chờ pipeline chạy xong và trả thẳng đường dẫn file .mp4 (khuyên dùng với kenburns_storyboard). Nếu false, chạy ngầm và trả về job_id.",
                    "default": True,
                },
            },
            "required": ["idea"],
        },
    },
    {
        "name": "film_studio_activate_license",
        "description": (
            "Xem Mã Máy (Machine ID / HWID: FS-XXXX-XXXX-XXXX-XXXX), kiểm tra hạn gói bản quyền, "
            "hoặc kích hoạt bản quyền bằng Mã Kích Hoạt (FZKEY-...) lấy từ Web https://forgezone.store/kich-hoat."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "license_key": {
                    "type": "string",
                    "description": "Mã Kích Hoạt (FZKEY-...) cấp trên Web theo Mã Máy. Để trống nếu chỉ muốn xem Mã Máy & trạng thái.",
                },
                "sync_from_web": {
                    "type": "boolean",
                    "description": "Nếu true, tự động kết nối lên https://forgezone.store để tải Mã Kích Hoạt đã cấp cho Mã Máy này.",
                    "default": False,
                },
            },
        },
    },
]



# ═════════════════════════════════════════════════════════════════════════════
# 3. CÁC HÀM THỰC THI NGHIỆP VỤ THẬT (100% GỌI VÀO ENGINE CỦA FILM STUDIO)
# ═════════════════════════════════════════════════════════════════════════════
def _load_veo_accounts_count() -> Tuple[int, List[str]]:
    emails = []
    count = 0
    for fname in ("veo_accounts.json", "tool5.json", "tool6.json", "tool7.json", "accounts.json"):
        fpath = os.path.join(SRC_DIR, fname)
        if os.path.isfile(fpath):
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    d = json.load(f)
                accs = d.get("accounts", []) if isinstance(d, dict) else (d if isinstance(d, list) else [])
                valid = [a for a in accs if isinstance(a, dict) and a.get("token")]
                if valid:
                    count = max(count, len(valid))
                    for a in valid:
                        em = str(a.get("email") or "").strip()
                        if em and em not in emails:
                            emails.append(em)
            except Exception:
                pass
    return count, emails


def tool_film_studio_doctor(args: Dict[str, Any]) -> Dict[str, Any]:
    import multi_llm_bridge
    import openspeaker_tts
    import tool2
    import tool_vids_voice
    import vids_backend
    import muse_backend
    from google_ultra_bridge import get_global_bridge

    check_gpu = bool(args.get("check_gpu", True))

    # 1. Kiểm tra API Đa Hãng
    llm_cfg = multi_llm_bridge.load_config()
    llm_providers_ready = {}
    for pid, pdata in (llm_cfg.get("providers") or {}).items():
        keys = pdata.get("keys") or []
        if keys:
            llm_providers_ready[pid] = {
                "keys_count": len(keys),
                "model": pdata.get("model"),
            }

    # 2. Kiểm tra Google Ultra Bridge & VEO Accounts
    veo_cnt, veo_emails = _load_veo_accounts_count()
    bridge = get_global_bridge()
    ultra_connected = list(bridge.connected_accounts.keys()) if bridge else []

    # 3. Kiểm tra Google Vids Cookies
    try:
        vids_accs = list(vids_backend.load_accounts(log=lambda _x: None).keys())
    except Exception:
        vids_accs = []

    # 4. Kiểm tra Muse.ai Profiles
    muse_profiles = []
    try:
        if muse_backend.PROFILE_ROOT.is_dir():
            muse_profiles = [
                p.name for p in muse_backend.PROFILE_ROOT.iterdir() if p.is_dir() and not p.name.startswith(".")
            ]
    except Exception:
        pass

    # 5. Kiểm tra FFmpeg & GPU
    gpu_ready = tool2.is_gpu_available() if check_gpu else bool(tool2._GPU_AVAILABLE)
    gpu_label = tool2.get_gpu_label()
    ffmpeg_exists = bool(shutil.which(tool2.FFMPEG_PATH) or os.path.isfile(tool2.FFMPEG_PATH))

    # 6. Kiểm tra Bản quyền theo Mã Máy (Hardware License Key)
    import license_manager
    lic_status = license_manager.get_license_status()

    report = {
        "status": "READY" if lic_status.get("valid") else "LICENSE_REQUIRED",
        "server": f"{MCP_SERVER_NAME} v{MCP_SERVER_VERSION}",
        "workspace_dir": SRC_DIR,
        "output_dir": MCP_OUTPUT_ROOT,
        "license": {
            "valid": lic_status.get("valid", False),
            "status": lic_status.get("status", "UNACTIVATED"),
            "machine_id": lic_status.get("machine_id", ""),
            "plan": lic_status.get("plan", ""),
            "plan_name": lic_status.get("plan_name", "Chưa kích hoạt"),
            "expires_at_str": lic_status.get("expires_at_str", "—"),
            "remaining_text": lic_status.get("remaining_text", "Chưa kích hoạt"),
            "activation_portal": license_manager.WEB_ACTIVATION_PORTAL_URL,
        },
        "components": {

            "llm_scriptwriter": {
                "active_provider": llm_cfg.get("active_provider", "auto"),
                "configured_providers": llm_providers_ready,
                "builtin_flowkit_fallback": True,
                "status": "✅ Sẵn sàng (Có API Key + Built-in FlowKit 3-Beat Engine)"
                if llm_providers_ready
                else "✅ Sẵn sàng (Chế độ Built-in FlowKit 3-Beat Engine — Có thể thêm API Key để dùng GPT/Gemini/Claude)",
            },
            "google_ultra_veo3": {
                "saved_accounts_count": veo_cnt,
                "saved_emails": veo_emails,
                "live_cdp_accounts": ultra_connected,
                "status": f"🟢 Đã kết nối ({max(veo_cnt, len(ultra_connected))} tài khoản)"
                if (veo_cnt > 0 or ultra_connected)
                else "🟡 Chưa đăng nhập Chrome Google Ultra (Bấm '🌐 Đăng Nhập Google Ultra' trên app khi cần quay Veo 3.1)",
            },
            "google_vids_engine": {
                "cookie_accounts": vids_accs,
                "espresso_voices_count": len(tool_vids_voice.VOICES),
                "sample_voices": tool_vids_voice.VOICES[:8],
                "status": f"🟢 Đã nạp {len(vids_accs)} Cookie Google Vids"
                if vids_accs
                else "🟡 Chưa nạp Cookie Google Vids",
            },
            "muse_ai_engine": {
                "profiles": muse_profiles,
                "status": f"🟢 Đã có {len(muse_profiles)} Profile Muse.ai"
                if muse_profiles
                else "🟡 Chưa đăng nhập Profile Muse.ai",
            },
            "voice_tts_studio": {
                "free_edge_neural_voices": [v["voice_id"] for v in openspeaker_tts.BUILTIN_EDGE_VOICES],
                "hathanh_config_exists": os.path.isfile(openspeaker_tts.CONFIG_FILE),
                "status": "✅ Sẵn sàng ngay lập tức (12 giọng Edge-TTS Neural miễn phí + Google TTS fallback)",
            },
            "ffmpeg_post_production": {
                "ffmpeg_path": tool2.FFMPEG_PATH,
                "ffmpeg_ready": ffmpeg_exists,
                "gpu_accelerated": gpu_ready,
                "gpu_encoder": gpu_label,
                "xfade_transitions_count": len(tool2.TransitionFX.TRANSITION_ALL),
                "status": f"✅ FFmpeg sẵn sàng ({gpu_label})" if ffmpeg_exists else "❌ Thiếu FFmpeg",
            },
        },
        "active_jobs_count": sum(1 for j in JOB_MANAGER.list_jobs(30) if j.get("status") == "RUNNING"),
    }
    JOB_MANAGER.log_event("film_studio_doctor", f"Kiểm tra hệ thống: GPU={gpu_label}, VeoAcc={veo_cnt}")
    return report


def tool_film_studio_write_storyboard(args: Dict[str, Any]) -> Dict[str, Any]:
    import flowkit_engine
    import prompt_review
    import veo3_prompt_tool2

    idea = str(args.get("idea") or "").strip()
    if not idea:
        raise ValueError("Tham số 'idea' (ý tưởng cốt truyện) không được để trống.")

    num_scenes = max(1, min(50, int(args.get("num_scenes", 5))))
    style = str(args.get("style") or "3D Pixar / Disney").strip()
    genre = str(args.get("genre") or "Phiêu lưu / Hành động").strip()
    char_appearance = str(args.get("character_appearance") or "").strip()
    dialogue_lang = str(args.get("dialogue_lang") or "Tiếng Việt").strip()
    voice_lang = str(args.get("voice_lang") or dialogue_lang).strip()
    do_sanitize = bool(args.get("sanitize_google_policy", True))
    push_to_gui = bool(args.get("push_to_gui", True))

    master_prompt = veo3_prompt_tool2.create_gemini_prompt(
        idea=idea,
        style=style,
        num_prompts=num_scenes,
        genre=genre,
        Character_Appearance=char_appearance,
        dialogue_lang=dialogue_lang,
        voice_lang=voice_lang,
    )

    mgr = veo3_prompt_tool2.GeminiAPIManager()
    raw_response = mgr.generate(master_prompt)

    # Bóc tách danh sách câu lệnh Prompt X: ...
    raw_prompt_lines = []
    for ln in raw_response.splitlines():
        s = ln.strip()
        if re.match(r"^(?:\*\*)?(?:Prompt|Scene|Cảnh)\s*\d+\s*(?:\*\*)?\s*:", s, flags=re.I):
            clean_ln = re.sub(r"^\*\*|\*\*$", "", s).strip()
            raw_prompt_lines.append(clean_ln)

    if len(raw_prompt_lines) < num_scenes:
        fallback_txt = veo3_prompt_tool2._local_storyboard_fallback(master_prompt)
        for ln in fallback_txt.splitlines():
            s = ln.strip()
            if re.match(r"^Prompt\s*\d+\s*:", s, flags=re.I) and len(raw_prompt_lines) < num_scenes:
                raw_prompt_lines.append(s)

    if do_sanitize:
        sanitized_lines = []
        for ln in raw_prompt_lines:
            s1 = flowkit_engine.sanitize_prompt_for_google_flow(ln, aggressive=False)
            s2 = prompt_review._local_policy_sanitize(s1).get("fixed_prompt", s1)
            sanitized_lines.append(s2)
        raw_prompt_lines = sanitized_lines

    analysis = flowkit_engine.analyze_prompts_and_extract_entities(
        raw_lines_or_text=raw_prompt_lines,
        character_bible_text=raw_response,
    )

    # Lưu kết quả ra file JSON & Excel (.xlsx) trong MCP_Output/storyboards
    sb_dir = os.path.join(MCP_OUTPUT_ROOT, "storyboards")
    os.makedirs(sb_dir, exist_ok=True)
    ts_slug = f"{int(time.time())}_{_safe_slug(idea, 24)}"
    json_path = os.path.join(sb_dir, f"storyboard_{ts_slug}.json")
    xlsx_path = os.path.join(sb_dir, f"storyboard_{ts_slug}.xlsx")

    video_rows = [["STT", "Nhân vật tham chiếu", "Prompt Video 8s (3-Beat)", "Prompt Ảnh Phân Cảnh (1 Khung)"]]
    for idx, (vid_ln, img_ln) in enumerate(
        zip(analysis["video_scene_lines"], analysis["scene_lines"]), start=1
    ):
        uid_part = vid_ln.split("|", 1)[0].strip() if "|" in vid_ln else "CHAR_01"
        video_rows.append([idx, uid_part, vid_ln, img_ln])

    char_rows = [["Mã Nhận Diện", "Loại", "Mô Tả Ngoại Hình / Bối Cảnh Chuẩn"]]
    for ent in analysis["unique_entities"]:
        char_rows.append([ent["uid"], ent["type"], ent["desc"]])

    try:
        veo3_prompt_tool2._write_xlsx_native(xlsx_path, video_rows, char_rows)
    except Exception:
        xlsx_path = ""

    result_payload = {
        "status": "OK",
        "idea": idea,
        "style": style,
        "genre": genre,
        "num_characters": analysis["num_chars"],
        "num_locations": analysis["num_locs"],
        "num_scenes": analysis["num_scenes"],
        "unique_entities": analysis["unique_entities"],
        "ref_lines": analysis["ref_lines"],
        "image_keyframe_prompts": analysis["scene_lines"],
        "video_motion_prompts": analysis["video_scene_lines"],
        "saved_json_path": json_path,
        "saved_xlsx_path": xlsx_path,
    }
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result_payload, f, ensure_ascii=False, indent=2)

    if push_to_gui and JOB_MANAGER.gui_callback:
        try:
            JOB_MANAGER.gui_callback("push_storyboard", result_payload)
        except Exception:
            pass

    JOB_MANAGER.log_event(
        "film_studio_write_storyboard",
        f"Đã viết kịch bản '{idea[:40]}' ({analysis['num_scenes']} cảnh, {analysis['num_chars']} nhân vật)",
    )
    return result_payload


def tool_film_studio_clone_video_prompts(args: Dict[str, Any]) -> Dict[str, Any]:
    import videopromt

    video_path = os.path.abspath(str(args.get("video_path") or "").strip())
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Không tìm thấy file video mẫu tại: {video_path}")

    segment_seconds = max(2.0, float(args.get("segment_seconds", 8.0)))
    max_segments = max(1, min(30, int(args.get("max_segments", 8))))
    style = str(args.get("style") or "3D Pixar / Disney").strip()
    aspect_ratio = str(args.get("aspect_ratio") or "16:9").strip()

    mgr = videopromt.GeminiAPIManager()
    prompts_out: List[str] = []
    char_sheet_text = ""

    cv2_mod = getattr(videopromt, "cv2", None)
    pil_img_mod = getattr(videopromt, "Image", None)

    if cv2_mod is not None and pil_img_mod is not None:
        cap = cv2_mod.VideoCapture(video_path)
        if not cap.isOpened():
            raise RuntimeError(f"OpenCV không thể mở file video: {video_path}")
        try:
            fps = cap.get(cv2_mod.CAP_PROP_FPS) or 25.0
            total_frames = int(cap.get(cv2_mod.CAP_PROP_FRAME_COUNT) or 0)
            duration = total_frames / max(fps, 1.0)
            num_segs = min(max_segments, max(1, int(duration // segment_seconds) or 1))

            # Lấy 2 frame đầu để phân tích Hồ sơ nhân vật
            sample_frames = []
            for f_idx in (int(fps * 0.5), int(min(total_frames - 1, fps * 2.5))):
                cap.set(cv2_mod.CAP_PROP_POS_FRAMES, max(0, f_idx))
                ok_f, frame = cap.read()
                if ok_f and frame is not None:
                    rgb = cv2_mod.cvtColor(frame, cv2_mod.COLOR_BGR2RGB)
                    sample_frames.append(pil_img_mod.fromarray(rgb))

            char_resp = mgr.generate(
                ["Hãy lập Bảng Mô Tả Nhân Vật (CHAR_01) và Bối Cảnh Chủ Đạo từ các khung hình sau:", *sample_frames]
            )
            char_sheet_text = getattr(char_resp, "text", str(char_resp)).strip()

            for seg_i in range(1, num_segs + 1):
                t_mid = (seg_i - 0.5) * segment_seconds
                frame_pos = min(max(0, int(t_mid * fps)), max(0, total_frames - 1))
                cap.set(cv2_mod.CAP_PROP_POS_FRAMES, frame_pos)
                ok_f, frame = cap.read()
                seg_frames = []
                if ok_f and frame is not None:
                    rgb = cv2_mod.cvtColor(frame, cv2_mod.COLOR_BGR2RGB)
                    seg_frames.append(pil_img_mod.fromarray(rgb))
                p_query = (
                    f"Segment {seg_i} [Aspect Ratio: {aspect_ratio}] [Style: {style}]\n"
                    f"PROVIDED CHARACTER SHEET:\n{char_sheet_text}\n"
                    f"{videopromt.META_PROMPT_V_SINGLE_LINE.format(segment_num=seg_i, aspect_ratio_str=aspect_ratio, selected_style=style)}"
                )
                resp = mgr.generate([p_query, *seg_frames])
                line = " ".join(getattr(resp, "text", str(resp)).strip().splitlines())
                prompts_out.append(line)
        finally:
            cap.release()
    else:
        import tool2

        dur = tool2.get_duration(video_path)
        num_segs = min(max_segments, max(1, int(dur // segment_seconds) or 1))
        for seg_i in range(1, num_segs + 1):
            line = videopromt._analyze_frames_locally(
                [f"Segment {seg_i} [Aspect Ratio: {aspect_ratio}] [Style: {style}]"]
            )
            prompts_out.append(line)

    JOB_MANAGER.log_event(
        "film_studio_clone_video_prompts",
        f"Đã tách {len(prompts_out)} prompt từ video {os.path.basename(video_path)}",
    )
    return {
        "status": "OK",
        "source_video": video_path,
        "segments_extracted": len(prompts_out),
        "character_sheet": char_sheet_text,
        "cloned_prompts": prompts_out,
    }


def _render_cinematic_keyframe_fallback(prompt: str, out_path: str, aspect_ratio: str = "16:9", idx: int = 1) -> str:
    """Tạo khung hình Keyframe chất lượng cao bằng PIL khi người dùng chạy Offline / chưa mở trình duyệt Google Flow."""
    from PIL import Image, ImageDraw, ImageFont

    w, h = (1080, 1920) if "9:16" in str(aspect_ratio) else ((1080, 1080) if "1:1" in str(aspect_ratio) else (1920, 1080))
    img = Image.new("RGB", (w, h), (12, 20, 34))
    draw = ImageDraw.Draw(img)

    # Bảng màu điện ảnh theo từng cảnh để hiệu ứng Ken Burns / Video sinh động
    palettes = [
        ((15, 32, 67), (34, 87, 122), (56, 189, 248)),
        ((42, 20, 58), (104, 42, 115), (244, 114, 182)),
        ((14, 46, 44), (24, 98, 86), (52, 211, 153)),
        ((58, 28, 18), (138, 66, 26), (251, 191, 36)),
    ]
    c_top, c_mid, c_glow = palettes[(idx - 1) % len(palettes)]

    for y in range(0, h, 4):
        ratio = y / max(1, h)
        if ratio < 0.55:
            t = ratio / 0.55
            r = int(c_top[0] * (1 - t) + c_mid[0] * t)
            g = int(c_top[1] * (1 - t) + c_mid[1] * t)
            b = int(c_top[2] * (1 - t) + c_mid[2] * t)
        else:
            t = (ratio - 0.55) / 0.45
            r = int(c_mid[0] * (1 - t) + 10 * t)
            g = int(c_mid[1] * (1 - t) + 14 * t)
            b = int(c_mid[2] * (1 - t) + 22 * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b), width=4)

    # Vẽ ánh sáng điện ảnh (Volumetric Horizon Glow)
    cx, cy = int(w * (0.35 + 0.1 * (idx % 3))), int(h * 0.42)
    for rad in range(360, 20, -25):
        alpha_f = (380 - rad) / 380.0
        col = (
            min(255, int(c_mid[0] + (c_glow[0] - c_mid[0]) * alpha_f * 0.65)),
            min(255, int(c_mid[1] + (c_glow[1] - c_mid[1]) * alpha_f * 0.65)),
            min(255, int(c_mid[2] + (c_glow[2] - c_mid[2]) * alpha_f * 0.65)),
        )
        draw.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], outline=col, width=3)

    # Khung cinema letterbox & thông tin cảnh
    bar_h = int(h * 0.07)
    draw.rectangle([0, 0, w, bar_h], fill=(6, 10, 16))
    draw.rectangle([0, h - bar_h, w, h], fill=(6, 10, 16))

    try:
        font_title = ImageFont.truetype("segoeui.ttf", 34)
        font_body = ImageFont.truetype("segoeui.ttf", 24)
    except Exception:
        font_title = ImageFont.load_default()
        font_body = font_title

    draw.text((48, int(bar_h * 0.22)), f"FILM STUDIO AI  ·  SCENE {idx:02d}", fill=c_glow, font=font_title)
    clean_p = re.sub(r"\s+", " ", (prompt or "").strip())
    wrapped = [clean_p[i : i + 88] for i in range(0, min(len(clean_p), 264), 88)]
    y_txt = h - bar_h - 38 * len(wrapped) - 24
    for ln in wrapped:
        draw.text((52, y_txt), ln, fill=(240, 248, 255), font=font_body)
        y_txt += 34

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    img.save(out_path, format="JPEG", quality=92)
    return out_path


def tool_film_studio_generate_character_images(args: Dict[str, Any]) -> Dict[str, Any]:
    import flowkit_engine
    from google_ultra_bridge import get_global_bridge, init_global_bridge

    ref_lines = [str(x).strip() for x in (args.get("ref_lines") or []) if str(x).strip()]
    scene_lines = [str(x).strip() for x in (args.get("scene_lines") or []) if str(x).strip()]
    style = str(args.get("style") or "3D Pixar / Disney").strip()
    aspect_ratio = str(args.get("aspect_ratio") or "16:9").strip()
    model = str(args.get("model") or "GEM_PIX_2").strip()
    out_dir = str(args.get("output_dir") or "").strip() or os.path.join(
        MCP_OUTPUT_ROOT, "images", f"batch_{int(time.time())}"
    )
    refs_dir = os.path.join(out_dir, "Refs")
    os.makedirs(refs_dir, exist_ok=True)

    bridge = get_global_bridge() or init_global_bridge(SRC_DIR)
    has_live_flow_tab = bool(bridge and bridge._ensure_ready_flow_tab(auto_open_browser=False))

    ref_results = []
    ref_media_map: Dict[str, str] = {}

    for idx, rln in enumerate(ref_lines, start=1):
        if "|" in rln[:35]:
            uid_raw, desc = rln.split("|", 1)
        elif ":" in rln[:25]:
            uid_raw, desc = rln.split(":", 1)
        else:
            uid_raw, desc = f"CHAR_{idx:02d}", rln
        uid = flowkit_engine._normalize_entity_uid(uid_raw)
        desc = desc.strip()
        ref_path = os.path.join(refs_dir, f"REF_{uid}.jpg")
        full_prompt = (
            f"[{style}] Single full-body standing character reference portrait of {desc}. "
            f"Clear 3/4 front-facing view showing exact facial features and complete outfit on a clean studio background, "
            f"ONE single character only in a single undivided frame, 8k masterpiece."
        )
        safe_p = flowkit_engine.sanitize_prompt_for_google_flow(full_prompt, aggressive=False)

        ok_gen = False
        media_id = ""
        engine_used = ""
        if has_live_flow_tab and bridge is not None:
            ok_gen, media_id, engine_used = bridge.cdp_generate_image(
                prompt=safe_p,
                model_key=model,
                aspect_ratio=aspect_ratio,
                seed=777000 + idx,
                ref_media_ids=None,
                save_path=ref_path,
            )
        if not ok_gen or not os.path.isfile(ref_path):
            _render_cinematic_keyframe_fallback(safe_p, ref_path, aspect_ratio=aspect_ratio, idx=idx)
            media_id = f"local_{uid}_{int(time.time())}"
            engine_used = "Local Cinematic Keyframe Generator (Chưa mở trình duyệt Google Flow)"

        ref_media_map[uid] = media_id
        ref_results.append(
            {
                "uid": uid,
                "desc": desc,
                "image_path": ref_path,
                "media_id": media_id,
                "engine": engine_used,
            }
        )

    scene_results = []
    flow_ref_ids = [mid for mid in ref_media_map.values() if mid and not mid.startswith("local_")]
    for s_idx, sln in enumerate(scene_lines, start=1):
        single_p = flowkit_engine.to_single_frame_image_prompt(sln)
        safe_sp = flowkit_engine.sanitize_prompt_for_google_flow(single_p, aggressive=False)
        sc_path = os.path.join(out_dir, f"Scene_{s_idx:03d}.jpg")

        ok_sc = False
        sc_mid = ""
        sc_eng = ""
        if has_live_flow_tab and bridge is not None:
            ok_sc, sc_mid, sc_eng = bridge.cdp_generate_image(
                prompt=safe_sp,
                model_key=model,
                aspect_ratio=aspect_ratio,
                seed=202600 + s_idx,
                ref_media_ids=flow_ref_ids or None,
                save_path=sc_path,
            )
        if not ok_sc or not os.path.isfile(sc_path):
            _render_cinematic_keyframe_fallback(safe_sp, sc_path, aspect_ratio=aspect_ratio, idx=s_idx)
            sc_mid = f"local_scene_{s_idx:03d}"
            sc_eng = "Local Cinematic Keyframe Generator"

        scene_results.append(
            {
                "scene_index": s_idx,
                "prompt": single_p,
                "image_path": sc_path,
                "media_id": sc_mid,
                "engine": sc_eng,
            }
        )

    JOB_MANAGER.log_event(
        "film_studio_generate_character_images",
        f"Đã tạo {len(ref_results)} ảnh Ref & {len(scene_results)} ảnh phân cảnh tại {out_dir}",
    )
    return {
        "status": "OK",
        "output_dir": out_dir,
        "reference_images": ref_results,
        "scene_images": scene_results,
    }


def tool_film_studio_render_videos_async(args: Dict[str, Any]) -> Dict[str, Any]:
    import flowkit_engine
    from google_ultra_bridge import get_global_bridge, init_global_bridge

    prompts = [str(p).strip() for p in (args.get("prompts") or []) if str(p).strip()]
    if not prompts:
        raise ValueError("Danh sách 'prompts' không được để trống.")

    engine = str(args.get("engine") or "veo_ultra_t2v").strip()
    aspect_ratio = str(args.get("aspect_ratio") or "16:9").strip()
    upscale_1080p = bool(args.get("upscale_1080p", True))
    image_paths = [str(p).strip() for p in (args.get("image_paths") or []) if str(p).strip()]
    ref_media_ids = [str(m).strip() for m in (args.get("ref_media_ids") or []) if str(m).strip()]
    out_dir = str(args.get("output_dir") or "").strip() or os.path.join(
        MCP_OUTPUT_ROOT, "videos", f"render_{int(time.time())}"
    )
    os.makedirs(out_dir, exist_ok=True)

    job_id = JOB_MANAGER.create_job(
        job_type="render_videos",
        title=f"Quay {len(prompts)} cảnh video bằng [{engine}] ({aspect_ratio})",
        total_steps=len(prompts),
        meta={"engine": engine, "aspect_ratio": aspect_ratio, "output_dir": out_dir},
    )

    def _bg_worker():
        bridge = get_global_bridge() or init_global_bridge(SRC_DIR)
        completed = 0
        output_files = []
        failed_scenes = []

        for idx, raw_p in enumerate(prompts, start=1):
            if JOB_MANAGER.is_cancelled(job_id):
                JOB_MANAGER.update_job(job_id, status="CANCELLED", log_line="Đã dừng theo yêu cầu.")
                return

            motion_p = flowkit_engine.to_video_motion_prompt(raw_p)
            save_mp4 = os.path.join(out_dir, f"{idx:04d}.mp4")
            JOB_MANAGER.update_job(
                job_id,
                progress=int(((idx - 1) / len(prompts)) * 100),
                log_line=f"🎬 Bắt đầu quay cảnh {idx}/{len(prompts)}: {motion_p[:70]}...",
            )

            try:
                if engine.startswith("veo_ultra"):
                    start_mid = None
                    if engine == "veo_ultra_i2v" and idx - 1 < len(image_paths):
                        img_p = image_paths[idx - 1]
                        if os.path.isfile(img_p):
                            with open(img_p, "rb") as f:
                                b64 = base64.b64encode(f.read()).decode("ascii")
                            start_mid = bridge.cdp_upload_image(b64, file_name=os.path.basename(img_p))

                    model_key = (
                        "veo_3_1_t2v_fast_portrait_ultra"
                        if "9:16" in aspect_ratio
                        else "veo_3_1_t2v_fast_ultra"
                    )
                    st, gen_mid, gen_pid = bridge.cdp_generate_video(
                        prompt=motion_p,
                        model_key=model_key,
                        ratio_key=aspect_ratio,
                        start_media_id=start_mid,
                        ref_media_ids=ref_media_ids if engine == "veo_ultra_consist" else None,
                        seed=303000 + idx,
                    )
                    if st == "OK" and gen_mid:
                        target_mid = gen_mid
                        if upscale_1080p:
                            st_up, up_mid, _ = bridge.cdp_upscale_video(
                                media_id=gen_mid,
                                ratio_key=aspect_ratio,
                                resolution_key="1080p",
                                model_key="veo_3_1_upsampler_1080p",
                                project_id=gen_pid,
                            )
                            if st_up == "OK" and up_mid:
                                target_mid = up_mid
                        dl_st, _ = bridge.cdp_poll_and_download_video(
                            media_id=target_mid,
                            save_path=save_mp4,
                            stop_event=lambda: JOB_MANAGER.is_cancelled(job_id),
                        )
                        if dl_st == "DONE" and os.path.isfile(save_mp4):
                            completed += 1
                            output_files.append(save_mp4)
                            JOB_MANAGER.update_job(
                                job_id,
                                completed_steps=completed,
                                add_output=save_mp4,
                                log_line=f"✅ Hoàn thành cảnh {idx}/{len(prompts)} -> {os.path.basename(save_mp4)}",
                            )
                            continue
                        else:
                            failed_scenes.append({"scene": idx, "error": f"Poll/Download: {dl_st}"})
                    else:
                        failed_scenes.append({"scene": idx, "error": gen_mid})
                elif engine == "muse_ai":
                    import muse_backend

                    profs = (
                        [p.name for p in muse_backend.PROFILE_ROOT.iterdir() if p.is_dir()]
                        if muse_backend.PROFILE_ROOT.is_dir()
                        else []
                    )
                    if not profs:
                        raise RuntimeError("Chưa có Profile đăng nhập Muse.ai trong thư mục muse_profiles/.")
                    # Gọi Muse backend nếu có profile
                    failed_scenes.append({"scene": idx, "error": "Cần mở phiên Muse.ai CDP"})
                else:
                    failed_scenes.append({"scene": idx, "error": f"Engine {engine} yêu cầu đăng nhập tài khoản trước."})
            except Exception as e:
                failed_scenes.append({"scene": idx, "error": str(e)})
                JOB_MANAGER.update_job(job_id, log_line=f"❌ Lỗi cảnh {idx}: {e}")

        final_status = "COMPLETED" if output_files else ("PARTIAL" if completed > 0 else "FAILED")
        JOB_MANAGER.update_job(
            job_id,
            status=final_status,
            progress=100,
            completed_steps=completed,
            log_line=f"🏁 Kết thúc: Thành công {completed}/{len(prompts)} cảnh.",
            result={
                "output_dir": out_dir,
                "video_files": output_files,
                "failed_scenes": failed_scenes,
            },
        )

    threading.Thread(target=_bg_worker, daemon=True).start()
    return {
        "status": "STARTED",
        "job_id": job_id,
        "engine": engine,
        "total_scenes": len(prompts),
        "output_dir": out_dir,
        "message": f"Đã đưa {len(prompts)} cảnh vào hàng đợi quay bất đồng bộ. Hãy gọi film_studio_job_status(job_id='{job_id}') để kiểm tra tiến độ.",
    }


def tool_film_studio_synthesize_voice(args: Dict[str, Any]) -> Dict[str, Any]:
    import openspeaker_tts
    import tool2
    import tool_vids_voice
    import vids_backend

    raw_texts = args.get("texts") or []
    if isinstance(raw_texts, str):
        raw_texts = [ln.strip() for ln in raw_texts.splitlines() if ln.strip()]
    texts = [str(t).strip() for t in raw_texts if str(t).strip()]
    if not texts:
        raise ValueError("Tham số 'texts' (danh sách câu thoại/thuyết minh) không được để trống.")

    engine = str(args.get("engine") or "edge_free").strip()
    voice_id = str(args.get("voice_id") or "edge_vi-VN-HoaiMyNeural").strip()
    speed = float(args.get("speed", 1.0) or 1.0)
    export_srt = bool(args.get("export_srt", True))
    merge_single = bool(args.get("merge_single_audio", False))
    out_dir = str(args.get("output_dir") or "").strip() or os.path.join(
        MCP_OUTPUT_ROOT, "voices", f"voice_{int(time.time())}"
    )
    os.makedirs(out_dir, exist_ok=True)

    audio_files: List[str] = []
    srt_entries: List[Tuple[float, float, str]] = []
    cur_time = 0.0

    vids_client = None
    if engine == "google_vids":
        accs = vids_backend.load_accounts(log=lambda _x: None)
        if accs:
            first_name = next(iter(accs.keys()))
            vids_client = vids_backend.VidsBackend(accs[first_name], name=first_name)

    hathanh_client = None
    if engine == "hathanh_api":
        cfg_ht = {}
        if os.path.isfile(openspeaker_tts.CONFIG_FILE):
            try:
                with open(openspeaker_tts.CONFIG_FILE, "r", encoding="utf-8") as f:
                    cfg_ht = json.load(f)
            except Exception:
                pass
        hathanh_client = openspeaker_tts.VoiceClient(cfg_ht)

    for idx, line_txt in enumerate(texts, start=1):
        clean_say = tool_vids_voice.clean_text(line_txt) or line_txt
        out_audio = os.path.join(out_dir, f"{idx:04d}.mp3")

        generated_ok = False
        if engine == "google_vids" and vids_client is not None:
            v_name = voice_id if voice_id in tool_vids_voice.VOICES else "Kore"
            st, url_or_err = vids_client.generate_voice(clean_say, voice=v_name)
            if st == "OK" and url_or_err:
                dl_ok, _ = vids_client.download(url_or_err, out_audio, min_size=512)
                generated_ok = bool(dl_ok and os.path.isfile(out_audio))

        if not generated_ok and hathanh_client is not None:
            try:
                hathanh_client.synth(clean_say, voice_id, out_audio, speed=speed)
                generated_ok = os.path.isfile(out_audio) and os.path.getsize(out_audio) > 256
            except Exception:
                generated_ok = False

        if not generated_ok:
            openspeaker_tts._synth_local_edge_tts(clean_say, voice_id, out_audio, speed=speed)

        dur = max(0.5, tool2.get_duration(out_audio))
        srt_entries.append((cur_time, cur_time + dur, openspeaker_tts.strip_voice_tags(clean_say)))
        cur_time += dur
        audio_files.append(out_audio)

    srt_path = ""
    if export_srt and srt_entries:
        srt_path = _write_srt_file(srt_entries, os.path.join(out_dir, "subtitles.srt"))

    merged_audio_path = ""
    if merge_single and len(audio_files) > 1:
        merged_audio_path = os.path.join(out_dir, "full_voiceover.mp3")
        concat_list = os.path.join(out_dir, "_concat_audio.txt")
        with open(concat_list, "w", encoding="utf-8") as f:
            for ap in audio_files:
                safe_ap = ap.replace("\\", "/").replace("'", "'\\''")
                f.write(f"file '{safe_ap}'\n")
        si, cflags = tool2._win_startup()
        subprocess.run(
            [tool2.FFMPEG_PATH, "-y", "-f", "concat", "-safe", "0", "-i", concat_list, "-c", "copy", merged_audio_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=si,
            creationflags=cflags,
        )
        try:
            os.remove(concat_list)
        except Exception:
            pass

    JOB_MANAGER.log_event(
        "film_studio_synthesize_voice",
        f"Đã tạo {len(audio_files)} file voice ({cur_time:.1f}s) bằng {voice_id}",
    )
    return {
        "status": "OK",
        "voice_id": voice_id,
        "output_dir": out_dir,
        "audio_files": audio_files,
        "merged_audio_path": merged_audio_path,
        "srt_subtitle_path": srt_path,
        "total_duration_seconds": round(cur_time, 2),
    }


def _resolve_media_inputs(inputs: List[str], valid_exts: Tuple[str, ...]) -> List[str]:
    import tool2

    resolved: List[str] = []
    for item in inputs or []:
        p = os.path.abspath(str(item).strip())
        if os.path.isdir(p):
            files = sorted(
                [os.path.join(p, f) for f in os.listdir(p) if f.lower().endswith(valid_exts)],
                key=tool2.natural_sort_key,
            )
            resolved.extend(files)
        elif os.path.isfile(p) and p.lower().endswith(valid_exts):
            resolved.append(p)
    return resolved


def tool_film_studio_post_production_merge(args: Dict[str, Any]) -> Dict[str, Any]:
    import tool2

    raw_visuals = args.get("visual_inputs") or []
    if isinstance(raw_visuals, str):
        raw_visuals = [raw_visuals]
    raw_audios = args.get("audio_inputs") or []
    if isinstance(raw_audios, str):
        raw_audios = [raw_audios]

    mode = str(args.get("mode") or "auto").strip().lower()
    sync_mode = str(args.get("sync_mode") or "speed").strip().lower()
    kb_effect = str(args.get("kenburns_effect") or "random").strip().lower()
    resolution = str(args.get("resolution") or "1080p").strip()
    aspect_ratio = str(args.get("aspect_ratio") or "16:9").strip()
    use_gpu = bool(args.get("use_gpu", True))

    vid_exts = (".mp4", ".mov", ".mkv", ".avi", ".webm")
    img_exts = (".jpg", ".jpeg", ".png", ".webp")
    aud_exts = (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac")

    video_files = _resolve_media_inputs(raw_visuals, vid_exts)
    image_files = _resolve_media_inputs(raw_visuals, img_exts)
    audio_files = _resolve_media_inputs(raw_audios, aud_exts)

    if mode == "auto":
        mode = "video_sync" if video_files else "image_kenburns"

    visual_files = video_files if mode == "video_sync" else image_files
    if not visual_files:
        raise ValueError(f"Không tìm thấy file hình ảnh/video hợp lệ trong visual_inputs: {raw_visuals}")

    movies_dir = os.path.join(MCP_OUTPUT_ROOT, "movies")
    os.makedirs(movies_dir, exist_ok=True)
    output_path = str(args.get("output_path") or "").strip()
    if not output_path:
        output_path = os.path.join(movies_dir, f"film_studio_final_{int(time.time())}.mp4")
    else:
        output_path = os.path.abspath(output_path)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

    out_w, out_h = tool2.get_resolution(resolution, aspect_ratio)
    out_size = f"{out_w}x{out_h}"
    fps = 30
    temp_dir = tempfile.mkdtemp(prefix="film_studio_mcp_merge_")
    rendered_segments: List[str] = []

    try:
        for idx, vis_path in enumerate(visual_files):
            aud_path = audio_files[idx] if idx < len(audio_files) else None
            seg_out = os.path.join(temp_dir, f"seg_{idx:04d}.mp4")
            dur_a = max(0.8, tool2.get_duration(aud_path)) if (aud_path and os.path.isfile(aud_path)) else 5.0

            if mode == "video_sync":
                dur_v = max(0.1, tool2.get_duration(vis_path))
                scale_pad = (
                    f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:force_divisible_by=2,"
                    f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2,setsar=1"
                )
                if sync_mode == "speed":
                    ratio = min(max(dur_v / max(dur_a, 0.1), 0.4), 2.5)
                    pts = 1.0 / max(ratio, 0.05)
                    vf = f"{scale_pad},setpts={pts:.4f}*PTS,fps={fps},trim=duration={dur_a:.3f},setpts=PTS-STARTPTS,format=yuv420p"
                elif sync_mode == "loop":
                    vf = f"{scale_pad},fps={fps},trim=duration={dur_a:.3f},setpts=PTS-STARTPTS,format=yuv420p"
                else:
                    if dur_v >= dur_a:
                        vf = f"{scale_pad},fps={fps},trim=duration={dur_a:.3f},setpts=PTS-STARTPTS,format=yuv420p"
                    else:
                        pad_t = dur_a - dur_v
                        vf = f"{scale_pad},fps={fps},tpad=stop_mode=clone:stop_duration={pad_t:.3f},setpts=PTS-STARTPTS,format=yuv420p"

                def _cmd_vid(use_gpu_local: bool, _vp=vis_path, _ap=aud_path, _vf=vf, _so=seg_out, _da=dur_a, _dv=dur_v):
                    cmd = [tool2.FFMPEG_PATH, "-y"]
                    if sync_mode == "loop" and _dv < _da:
                        cmd += ["-stream_loop", "-1"]
                    cmd += ["-i", _vp]
                    if _ap and os.path.isfile(_ap):
                        cmd += ["-i", _ap, "-vf", _vf, "-map", "0:v:0", "-map", "1:a:0"]
                    else:
                        cmd += [
                            "-f",
                            "lavfi",
                            "-i",
                            "anullsrc=channel_layout=stereo:sample_rate=44100",
                            "-vf",
                            _vf,
                            "-map",
                            "0:v:0",
                            "-map",
                            "1:a:0",
                        ]
                    v_enc = tool2.get_gpu_encoder_args("medium") if use_gpu_local else []
                    if not v_enc:
                        v_enc = ["-c:v", "libx264", "-preset", "fast", "-crf", "23"]
                    cmd += v_enc + ["-r", str(fps), "-c:a", "aac", "-b:a", "192k", "-t", f"{_da:.3f}", "-movflags", "+faststart", _so]
                    return cmd

                ok_seg = tool2._run_with_fallback(_cmd_vid, use_gpu, tag=f"MCP-VidSeg-{idx}")
            else:
                eff_filter = tool2.KenBurnsEffects.get_effect_by_name(
                    kb_effect, dur_a, fps=fps, intensity=1.25, size=out_size, seed=idx + 1
                )

                def _cmd_img(use_gpu_local: bool, _ip=vis_path, _ap=aud_path, _ef=eff_filter, _so=seg_out, _da=dur_a):
                    cmd = [tool2.FFMPEG_PATH, "-y", "-framerate", str(fps), "-loop", "1", "-i", _ip]
                    if _ap and os.path.isfile(_ap):
                        cmd += ["-i", _ap, "-vf", f"{_ef},format=yuv420p", "-map", "0:v:0", "-map", "1:a:0"]
                    else:
                        cmd += [
                            "-f",
                            "lavfi",
                            "-i",
                            "anullsrc=channel_layout=stereo:sample_rate=44100",
                            "-vf",
                            f"{_ef},format=yuv420p",
                            "-map",
                            "0:v:0",
                            "-map",
                            "1:a:0",
                        ]
                    v_enc = tool2.get_gpu_encoder_args("high") if use_gpu_local else []
                    if not v_enc:
                        v_enc = ["-c:v", "libx264", "-preset", "fast", "-crf", "23"]
                    cmd += v_enc + ["-c:a", "aac", "-b:a", "192k", "-t", f"{_da:.3f}", "-shortest", "-movflags", "+faststart", _so]
                    return cmd

                ok_seg = tool2._run_with_fallback(_cmd_img, use_gpu, tag=f"MCP-ImgSeg-{idx}")

            if ok_seg and os.path.isfile(seg_out):
                rendered_segments.append(seg_out)

        if not rendered_segments:
            raise RuntimeError("FFmpeg không render được phân đoạn nào.")

        concat_txt = os.path.join(temp_dir, "concat_list.txt")
        with open(concat_txt, "w", encoding="utf-8") as f:
            for seg_p in rendered_segments:
                safe_p = seg_p.replace("\\", "/").replace("'", "'\\''")
                f.write(f"file '{safe_p}'\n")

        si, cflags = tool2._win_startup()
        r_merge = subprocess.run(
            [tool2.FFMPEG_PATH, "-y", "-f", "concat", "-safe", "0", "-i", concat_txt, "-c", "copy", "-movflags", "+faststart", output_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="ignore",
            startupinfo=si,
            creationflags=cflags,
        )
        if r_merge.returncode != 0 or not os.path.isfile(output_path):
            raise RuntimeError(f"Lỗi ghép concat FFmpeg: {(r_merge.stderr or '')[-300:]}")
    finally:
        tool2._safe_rmtree(temp_dir)

    final_info = tool2.get_video_info(output_path)
    final_size_mb = round(os.path.getsize(output_path) / (1024 * 1024), 2)
    JOB_MANAGER.log_event(
        "film_studio_post_production_merge",
        f"Đã dựng xong phim MP4 ({final_info.get('duration', 0):.1f}s, {final_size_mb}MB) -> {output_path}",
    )
    return {
        "status": "OK",
        "output_video_path": output_path,
        "segments_merged": len(rendered_segments),
        "video_info": final_info,
        "file_size_mb": final_size_mb,
        "gpu_encoder_used": tool2.get_gpu_label() if use_gpu else "CPU (libx264)",
    }


def tool_film_studio_job_status(args: Dict[str, Any]) -> Dict[str, Any]:
    action = str(args.get("action") or "status").strip().lower()
    job_id = str(args.get("job_id") or "").strip()

    if action == "list" or not job_id:
        jobs = JOB_MANAGER.list_jobs(limit=15)
        return {
            "status": "OK",
            "total_jobs": len(jobs),
            "jobs": [
                {
                    "job_id": j["job_id"],
                    "job_type": j["job_type"],
                    "title": j["title"],
                    "status": j["status"],
                    "progress": j["progress"],
                    "completed_steps": f"{j.get('completed_steps', 0)}/{j.get('total_steps', 1)}",
                    "updated_at": j["updated_at"],
                    "outputs": j.get("outputs", []),
                }
                for j in jobs
            ],
        }

    if action == "cancel":
        ok = JOB_MANAGER.cancel_job(job_id)
        return {
            "status": "OK" if ok else "NOT_FOUND",
            "job_id": job_id,
            "message": f"Đã gửi yêu cầu dừng job {job_id}" if ok else f"Không tìm thấy job {job_id}",
        }

    job = JOB_MANAGER.get_job(job_id)
    if not job:
        return {"status": "NOT_FOUND", "job_id": job_id, "message": f"Không tìm thấy tiến trình có mã {job_id}."}
    return {"status": "OK", "job": job}


def tool_film_studio_auto_pipeline(args: Dict[str, Any]) -> Dict[str, Any]:
    idea = str(args.get("idea") or "").strip()
    if not idea:
        raise ValueError("Tham số 'idea' không được để trống.")

    num_scenes = max(1, min(20, int(args.get("num_scenes", 4))))
    style = str(args.get("style") or "3D Pixar / Disney").strip()
    narration_lines = [str(x).strip() for x in (args.get("narration_lines") or []) if str(x).strip()]
    voice_engine = str(args.get("voice_engine") or "edge_free").strip()
    voice_id = str(args.get("voice_id") or "edge_vi-VN-HoaiMyNeural").strip()
    visual_engine = str(args.get("visual_engine") or "kenburns_storyboard").strip()
    aspect_ratio = str(args.get("aspect_ratio") or "16:9").strip()
    resolution = str(args.get("resolution") or "1080p").strip()
    wait_for_completion = bool(args.get("wait_for_completion", True))

    project_slug = f"{int(time.time())}_{_safe_slug(idea, 20)}"
    proj_dir = os.path.join(MCP_OUTPUT_ROOT, "pipelines", project_slug)
    os.makedirs(proj_dir, exist_ok=True)

    job_id = JOB_MANAGER.create_job(
        job_type="auto_pipeline",
        title=f"Auto Pipeline ({num_scenes} cảnh): {idea[:55]}",
        total_steps=4,
        meta={"idea": idea, "project_dir": proj_dir, "visual_engine": visual_engine},
    )

    def _run_pipeline():
        try:
            # BƯỚC 1: Viết kịch bản & Prompt phân cảnh
            JOB_MANAGER.update_job(job_id, progress=10, log_line="📝 [Bước 1/4] Đang biên kịch & phân tách nhân vật...")
            sb_res = tool_film_studio_write_storyboard(
                {
                    "idea": idea,
                    "num_scenes": num_scenes,
                    "style": style,
                    "sanitize_google_policy": True,
                    "push_to_gui": True,
                }
            )

            # Tự sinh lời bình khớp từng cảnh nếu người dùng chưa truyền narration_lines
            if not narration_lines:
                auto_narrations = []
                for idx in range(1, num_scenes + 1):
                    if "vi-" in voice_id.lower() or voice_engine == "google_vids":
                        auto_narrations.append(f"Phân cảnh {idx}: {idea}.")
                    else:
                        auto_narrations.append(f"Scene {idx}: {idea}.")
                eff_narrations = auto_narrations
            else:
                eff_narrations = narration_lines[:num_scenes]
                while len(eff_narrations) < num_scenes:
                    eff_narrations.append(eff_narrations[-1])

            # BƯỚC 2: Tổng hợp giọng đọc & Phụ đề SRT
            JOB_MANAGER.update_job(
                job_id,
                progress=35,
                completed_steps=1,
                log_line=f"🔊 [Bước 2/4] Đang tổng hợp giọng đọc AI ({voice_id}) & phụ đề .SRT...",
            )
            voice_res = tool_film_studio_synthesize_voice(
                {
                    "texts": eff_narrations,
                    "engine": voice_engine,
                    "voice_id": voice_id,
                    "export_srt": True,
                    "merge_single_audio": True,
                    "output_dir": os.path.join(proj_dir, "voices"),
                }
            )

            # BƯỚC 3: Tạo Hình ảnh Phân cảnh Đồng nhất hoặc Video AI
            JOB_MANAGER.update_job(
                job_id,
                progress=60,
                completed_steps=2,
                log_line=f"🎨 [Bước 3/4] Đang khởi tạo hình ảnh/video phân cảnh ({visual_engine})...",
            )
            img_res = tool_film_studio_generate_character_images(
                {
                    "ref_lines": sb_res["ref_lines"],
                    "scene_lines": sb_res["image_keyframe_prompts"],
                    "style": style,
                    "aspect_ratio": aspect_ratio,
                    "output_dir": os.path.join(proj_dir, "images"),
                }
            )
            scene_img_paths = [item["image_path"] for item in img_res["scene_images"]]

            # BƯỚC 4: Dựng hậu kỳ FFmpeg GPU ghép Hình + Tiếng + Chuyển cảnh ra MP4 cuối cùng
            JOB_MANAGER.update_job(
                job_id,
                progress=85,
                completed_steps=3,
                log_line="🎞 [Bước 4/4] Đang dựng hậu kỳ FFmpeg (Ken Burns + Đồng bộ Audio)...",
            )
            final_mp4_path = os.path.join(proj_dir, f"final_movie_{project_slug}.mp4")
            merge_res = tool_film_studio_post_production_merge(
                {
                    "visual_inputs": scene_img_paths,
                    "audio_inputs": voice_res["audio_files"],
                    "output_path": final_mp4_path,
                    "mode": "image_kenburns",
                    "kenburns_effect": "random",
                    "resolution": resolution,
                    "aspect_ratio": aspect_ratio,
                    "use_gpu": True,
                }
            )

            full_result = {
                "project_dir": proj_dir,
                "final_video_path": merge_res["output_video_path"],
                "srt_subtitle_path": voice_res["srt_subtitle_path"],
                "storyboard_json": sb_res["saved_json_path"],
                "storyboard_xlsx": sb_res["saved_xlsx_path"],
                "scene_images": scene_img_paths,
                "audio_files": voice_res["audio_files"],
                "video_info": merge_res["video_info"],
                "file_size_mb": merge_res["file_size_mb"],
            }
            JOB_MANAGER.update_job(
                job_id,
                status="COMPLETED",
                progress=100,
                completed_steps=4,
                add_output=merge_res["output_video_path"],
                log_line=f"✅ Đã xuất xưởng bộ phim hoàn chỉnh: {merge_res['output_video_path']}",
                result=full_result,
            )
        except Exception as e:
            JOB_MANAGER.update_job(
                job_id,
                status="FAILED",
                log_line=f"❌ Pipeline thất bại: {e}",
                result={"error": str(e)},
            )

    if wait_for_completion:
        _run_pipeline()
        job_done = JOB_MANAGER.get_job(job_id) or {}
        return {
            "status": job_done.get("status", "COMPLETED"),
            "job_id": job_id,
            **job_done.get("result", {}),
        }
    else:
        threading.Thread(target=_run_pipeline, daemon=True).start()
        return {
            "status": "STARTED",
            "job_id": job_id,
            "project_dir": proj_dir,
            "message": f"Đã khởi chạy Đạo diễn Tự hành ngầm. Gọi film_studio_job_status(job_id='{job_id}') để lấy video khi hoàn tất.",
        }


def tool_film_studio_activate_license(args: Dict[str, Any]) -> Dict[str, Any]:
    import license_manager

    raw_key = str(args.get("license_key") or "").strip()
    sync_web = bool(args.get("sync_from_web", False))

    if raw_key:
        res = license_manager.activate_license(raw_key)
        JOB_MANAGER.log_event(
            "film_studio_activate_license",
            f"Kích hoạt Mã Máy {res.get('machine_id')}: {res.get('status')} ({res.get('plan_name')})",
        )
        return res

    if sync_web:
        res = license_manager.sync_license_from_web()
        JOB_MANAGER.log_event(
            "film_studio_activate_license",
            f"Đồng bộ Web cho Mã Máy {res.get('machine_id')}: {res.get('status')}",
        )
        return res

    status = license_manager.get_license_status()
    status["activation_portal"] = license_manager.WEB_ACTIVATION_PORTAL_URL
    status["instruction"] = (
        f"Mã Máy của thiết bị này là {status['machine_id']}. "
        f"Truy cập {license_manager.WEB_ACTIVATION_PORTAL_URL} để lấy Mã Kích Hoạt theo gói mua trên Web."
    )
    return status


TOOL_HANDLERS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    "film_studio_doctor": tool_film_studio_doctor,
    "film_studio_write_storyboard": tool_film_studio_write_storyboard,
    "film_studio_clone_video_prompts": tool_film_studio_clone_video_prompts,
    "film_studio_generate_character_images": tool_film_studio_generate_character_images,
    "film_studio_render_videos_async": tool_film_studio_render_videos_async,
    "film_studio_synthesize_voice": tool_film_studio_synthesize_voice,
    "film_studio_post_production_merge": tool_film_studio_post_production_merge,
    "film_studio_job_status": tool_film_studio_job_status,
    "film_studio_auto_pipeline": tool_film_studio_auto_pipeline,
    "film_studio_activate_license": tool_film_studio_activate_license,
}

_UNRESTRICTED_MCP_TOOLS = {
    "film_studio_doctor",
    "film_studio_job_status",
    "film_studio_activate_license",
}


def dispatch_mcp_tool_call(name: str, arguments: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Thực thi một MCP Tool theo tên và trả về cấu trúc chuẩn MCP CallToolResult."""
    fn = TOOL_HANDLERS.get(name)
    if not fn:
        return {
            "content": [{"type": "text", "text": json.dumps({"error": f"Không tồn tại MCP tool: {name}"}, ensure_ascii=False)}],
            "isError": True,
        }

    # Cổng kiểm tra Bản quyền theo Mã Máy (Hardware License Gate)
    if name not in _UNRESTRICTED_MCP_TOOLS:
        import license_manager
        lic = license_manager.get_license_status()
        if not lic.get("valid"):
            err_payload = {
                "status": "LICENSE_REQUIRED",
                "tool": name,
                "machine_id": lic.get("machine_id"),
                "license_status": lic.get("status"),
                "error": lic.get("error") or "Ứng dụng chưa được kích hoạt bản quyền hoặc gói đã hết hạn.",
                "activation_portal": license_manager.WEB_ACTIVATION_PORTAL_URL,
                "how_to_activate": (
                    f"1. Copy Mã Máy: {lic.get('machine_id')} | "
                    f"2. Mở Web {license_manager.WEB_ACTIVATION_PORTAL_URL} để lấy Mã Kích Hoạt theo gói mua | "
                    f"3. Nhập Mã Kích Hoạt trên ứng dụng Film Studio hoặc gọi tool film_studio_activate_license."
                ),
            }
            JOB_MANAGER.log_event(name, f"🔒 Chặn thực thi do chưa kích hoạt bản quyền (Mã Máy: {lic.get('machine_id')})")
            return {
                "content": [{"type": "text", "text": json.dumps(err_payload, ensure_ascii=False, indent=2)}],
                "isError": True,
            }

    try:
        res_data = fn(arguments or {})
        return {
            "content": [{"type": "text", "text": json.dumps(res_data, ensure_ascii=False, indent=2)}],
            "isError": False,
        }

    except Exception as e:
        tb = traceback.format_exc()
        JOB_MANAGER.log_event(name, f"❌ Lỗi thực thi tool: {e}")
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({"status": "ERROR", "tool": name, "error": str(e), "traceback": tb[-600:]}, ensure_ascii=False, indent=2),
                }
            ],
            "isError": True,
        }


# ═════════════════════════════════════════════════════════════════════════════
# 4. BỘ XỬ LÝ JSON-RPC 2.0 (DÙNG CHUNG CHO CẢ STDIO VÀ HTTP/SSE)
# ═════════════════════════════════════════════════════════════════════════════
def handle_jsonrpc_message(msg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Xử lý bản tin JSON-RPC 2.0 chuẩn Model Context Protocol."""
    if not isinstance(msg, dict):
        return None

    method = str(msg.get("method") or "")
    req_id = msg.get("id")
    params = msg.get("params") or {}

    # Notifications (không có id)
    if req_id is None:
        return None

    if method == "initialize":
        client_proto = str(params.get("protocolVersion") or MCP_PROTOCOL_VERSION)
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": client_proto,
                "capabilities": {
                    "tools": {"listChanged": False},
                    "resources": {"subscribe": False, "listChanged": False},
                    "prompts": {"listChanged": False},
                },
                "serverInfo": {
                    "name": MCP_SERVER_NAME,
                    "version": MCP_SERVER_VERSION,
                },
            },
        }

    if method == "ping":
        return {"jsonrpc": "2.0", "id": req_id, "result": {}}

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": MCP_TOOLS_SCHEMA},
        }

    if method == "tools/call":
        t_name = str(params.get("name") or "")
        t_args = params.get("arguments") or {}
        call_res = dispatch_mcp_tool_call(t_name, t_args)
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": call_res,
        }

    if method == "resources/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "resources": [
                    {
                        "uri": "filmstudio://status/doctor",
                        "name": "Trạng thái hệ thống Film Studio",
                        "mimeType": "application/json",
                        "description": "Thông tin tài khoản Google Ultra, Vids, Muse, API Key và GPU FFmpeg.",
                    },
                    {
                        "uri": "filmstudio://jobs/recent",
                        "name": "Danh sách tiến trình sản xuất Video gần đây",
                        "mimeType": "application/json",
                        "description": "Trạng thái và đường dẫn file MP4 của các job gần nhất.",
                    },
                ]
            },
        }

    if method == "resources/read":
        uri = str(params.get("uri") or "")
        if uri == "filmstudio://status/doctor":
            payload = tool_film_studio_doctor({"check_gpu": False})
        else:
            payload = tool_film_studio_job_status({"action": "list"})
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "contents": [
                    {
                        "uri": uri,
                        "mimeType": "application/json",
                        "text": json.dumps(payload, ensure_ascii=False, indent=2),
                    }
                ]
            },
        }

    if method == "prompts/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "prompts": [
                    {
                        "name": "produce_complete_video",
                        "description": "Mẫu câu lệnh giao việc cho AI tự động sản xuất 1 bộ phim hoàn chỉnh từ ý tưởng.",
                        "arguments": [
                            {"name": "topic", "description": "Chủ đề hoặc cốt truyện phim", "required": True},
                            {"name": "scenes", "description": "Số cảnh quay (mặc định 5)", "required": False},
                        ],
                    }
                ]
            },
        }

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


# ═════════════════════════════════════════════════════════════════════════════
# 5. MÁY CHỦ HTTP / SSE / STREAMABLE HTTP NỘI BỘ (CHẠY NGẦM TRONG FILM STUDIO)
# ═════════════════════════════════════════════════════════════════════════════
_SSE_CLIENTS: Dict[str, "queue.Queue[Optional[str]]"] = {}
_SSE_LOCK = threading.Lock()


class _MCPHTTPRequestHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: Any) -> None:
        return

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, Mcp-Session-Id")

    def _send_json(self, status: int, data: Any):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"

        if path in ("/", "/status", "/health"):
            self._send_json(
                200,
                {
                    "ok": True,
                    "server": MCP_SERVER_NAME,
                    "version": MCP_SERVER_VERSION,
                    "mcp_endpoint": f"http://127.0.0.1:{self.server.server_port}/mcp",
                    "sse_endpoint": f"http://127.0.0.1:{self.server.server_port}/sse",
                    "tools_count": len(MCP_TOOLS_SCHEMA),
                    "tools": [t["name"] for t in MCP_TOOLS_SCHEMA],
                },
            )
            return

        if path == "/api/tools":
            self._send_json(200, {"tools": MCP_TOOLS_SCHEMA})
            return

        if path == "/api/jobs":
            self._send_json(200, tool_film_studio_job_status({"action": "list"}))
            return

        if path == "/sse":
            session_id = uuid.uuid4().hex
            q: "queue.Queue[Optional[str]]" = queue.Queue()
            with _SSE_LOCK:
                _SSE_CLIENTS[session_id] = q

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self._send_cors_headers()
            self.end_headers()

            try:
                endpoint_ev = f"event: endpoint\ndata: /messages?session_id={session_id}\n\n"
                self.wfile.write(endpoint_ev.encode("utf-8"))
                self.wfile.flush()
                while True:
                    try:
                        msg_str = q.get(timeout=15.0)
                        if msg_str is None:
                            break
                        ev = f"event: message\ndata: {msg_str}\n\n"
                        self.wfile.write(ev.encode("utf-8"))
                        self.wfile.flush()
                    except queue.Empty:
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
            except Exception:
                pass
            finally:
                with _SSE_LOCK:
                    _SSE_CLIENTS.pop(session_id, None)
            return

        self._send_json(404, {"error": f"Unknown path: {path}"})

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        qs = urllib.parse.parse_qs(parsed.query)

        length = int(self.headers.get("Content-Length") or 0)
        raw_body = self.rfile.read(length).decode("utf-8", errors="replace") if length > 0 else "{}"
        try:
            payload = json.loads(raw_body)
        except Exception as e:
            self._send_json(400, {"error": f"Invalid JSON: {e}"})
            return

        # 1. Endpoint REST gọi nhanh cho n8n / Make / Webhook: POST /api/call {"name": "...", "arguments": {...}}
        if path == "/api/call":
            t_name = str(payload.get("name") or payload.get("tool") or "")
            t_args = payload.get("arguments") or payload.get("args") or {}
            res = dispatch_mcp_tool_call(t_name, t_args)
            self._send_json(200, res)
            return

        # 2. Endpoint Streamable HTTP MCP (/mcp) hoặc SSE message (/messages)
        if path in ("/mcp", "/messages", ""):
            if isinstance(payload, list):
                responses = [r for m in payload if (r := handle_jsonrpc_message(m)) is not None]
                resp_obj = responses
            else:
                resp_obj = handle_jsonrpc_message(payload)

            session_id = (qs.get("session_id") or [""])[0]
            if session_id:
                with _SSE_LOCK:
                    q = _SSE_CLIENTS.get(session_id)
                if q and resp_obj is not None:
                    q.put(json.dumps(resp_obj, ensure_ascii=False))
                self.send_response(202)
                self._send_cors_headers()
                self.send_header("Content-Length", "2")
                self.end_headers()
                self.wfile.write(b"OK")
                return

            if resp_obj is None:
                self.send_response(202)
                self._send_cors_headers()
                self.send_header("Content-Length", "0")
                self.end_headers()
                return

            self._send_json(200, resp_obj)
            return

        self._send_json(404, {"error": f"Unknown POST path: {path}"})


class BackgroundMCPServer:
    """Máy chủ HTTP/SSE chạy ngầm bên trong ứng dụng Desktop Film Studio."""

    def __init__(self, port: int = DEFAULT_MCP_HTTP_PORT, gui_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None):
        self.port = int(port)
        self.httpd: Optional[ThreadingHTTPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.running = False
        if gui_callback:
            JOB_MANAGER.gui_callback = gui_callback

    def start(self) -> Tuple[bool, str]:
        if self.running and self.httpd is not None:
            return True, f"http://127.0.0.1:{self.port}/mcp"

        for candidate_port in (self.port, self.port + 1, self.port + 2):
            try:
                srv = ThreadingHTTPServer(("127.0.0.1", candidate_port), _MCPHTTPRequestHandler)
                srv.daemon_threads = True
                self.port = candidate_port
                self.httpd = srv
                self.running = True
                self.thread = threading.Thread(target=srv.serve_forever, daemon=True)
                self.thread.start()
                JOB_MANAGER.log_event("mcp_http_server", f"🟢 Đã bật MCP Server tại http://127.0.0.1:{self.port}/mcp")
                return True, f"http://127.0.0.1:{self.port}/mcp"
            except OSError:
                continue
        return False, "Không thể mở cổng mạng cục bộ cho MCP Server."

    def stop(self):
        self.running = False
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None


_BG_SERVER_SINGLETON: Optional[BackgroundMCPServer] = None


def start_background_mcp_server(
    port: int = DEFAULT_MCP_HTTP_PORT,
    gui_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None,
) -> BackgroundMCPServer:
    global _BG_SERVER_SINGLETON
    if _BG_SERVER_SINGLETON is None:
        _BG_SERVER_SINGLETON = BackgroundMCPServer(port=port, gui_callback=gui_callback)
        _BG_SERVER_SINGLETON.start()
    elif gui_callback:
        JOB_MANAGER.gui_callback = gui_callback
    return _BG_SERVER_SINGLETON


# ═════════════════════════════════════════════════════════════════════════════
# 6. BỘ CÀI ĐẶT TỰ ĐỘNG 1-CLICK CHO KHÁCH HÀNG (CLAUDE DESKTOP / CURSOR / WINDSURF)
# ═════════════════════════════════════════════════════════════════════════════
def get_python_executable_for_mcp() -> str:
    """Tìm python.exe chuẩn để ghi vào file cấu hình MCP của khách hàng (không dùng pythonw.exe vì stdio cần stdout)."""
    exe = sys.executable or "python"
    if exe.lower().endswith("pythonw.exe"):
        cand = exe[:-11] + "python.exe"
        if os.path.isfile(cand):
            return cand
    return exe


def build_mcp_client_config_entry() -> Dict[str, Any]:
    """Tạo cấu trúc cấu hình chuẩn cho mục mcpServers."""
    py_exe = get_python_executable_for_mcp()
    script_path = os.path.abspath(__file__)
    return {
        "command": py_exe,
        "args": [script_path, "--stdio"],
        "env": {
            "PYTHONIOENCODING": "utf-8",
            "FILM_STUDIO_DIR": SRC_DIR,
        },
    }


def get_known_ai_client_targets() -> List[Dict[str, str]]:
    """Danh sách các phần mềm AI phổ biến hỗ trợ kết nối MCP tự động trên Windows."""
    appdata = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
    userprof = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    return [
        {
            "id": "claude_desktop",
            "name": "Claude Desktop (Anthropic)",
            "config_path": os.path.join(appdata, "Claude", "claude_desktop_config.json"),
        },
        {
            "id": "cursor",
            "name": "Cursor AI IDE",
            "config_path": os.path.join(userprof, ".cursor", "mcp.json"),
        },
        {
            "id": "windsurf",
            "name": "Windsurf IDE (Codeium)",
            "config_path": os.path.join(userprof, ".codeium", "windsurf", "mcp_config.json"),
        },
        {
            "id": "cline_vscode",
            "name": "Cline / Claude Dev (VS Code)",
            "config_path": os.path.join(
                appdata,
                "Code",
                "User",
                "globalStorage",
                "saoudrizwan.claude-dev",
                "settings",
                "cline_mcp_settings.json",
            ),
        },
    ]


def install_mcp_to_ai_clients(target_ids: Optional[List[str]] = None) -> Dict[str, Any]:
    """
    1-Click tự động gắn cấu hình MCP của Film Studio vào Claude Desktop, Cursor, Windsurf, Cline.
    Bảo toàn 100% các MCP server khác mà khách hàng đã cài trước đó.
    """
    entry = build_mcp_client_config_entry()
    targets = get_known_ai_client_targets()
    installed = []
    errors = []

    for t in targets:
        if target_ids and t["id"] not in target_ids:
            continue
        cfg_path = t["config_path"]
        try:
            os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
            existing_data: Dict[str, Any] = {}
            if os.path.isfile(cfg_path):
                try:
                    with open(cfg_path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    if isinstance(loaded, dict):
                        existing_data = loaded
                except Exception:
                    existing_data = {}

            mcp_servers = existing_data.get("mcpServers")
            if not isinstance(mcp_servers, dict):
                mcp_servers = {}
                existing_data["mcpServers"] = mcp_servers

            mcp_servers[MCP_SERVER_NAME] = entry
            with open(cfg_path, "w", encoding="utf-8") as f:
                json.dump(existing_data, f, ensure_ascii=False, indent=2)

            installed.append({"id": t["id"], "name": t["name"], "config_path": cfg_path})
        except Exception as e:
            errors.append({"id": t["id"], "name": t["name"], "error": str(e)})

    JOB_MANAGER.log_event(
        "install_mcp_1click",
        f"Đã cài đặt tự động MCP vào {len(installed)} ứng dụng AI ({', '.join(x['name'] for x in installed)})",
    )
    return {
        "ok": len(installed) > 0,
        "server_name": MCP_SERVER_NAME,
        "entry": entry,
        "installed_clients": installed,
        "errors": errors,
    }


# ═════════════════════════════════════════════════════════════════════════════
# 7. VÒNG LẶP STDIO TRANSPORT (KHI CHẠY QUA CLAUDE DESKTOP / CURSOR / ANTIGRAVITY)
# ═════════════════════════════════════════════════════════════════════════════
def run_stdio_server():
    """Chạy MCP Server ở chế độ chuẩn STDIO (Đọc từng dòng JSON-RPC từ stdin, ghi phản hồi ra stdout)."""
    # Khóa stdout nguyên bản cho giao thức JSON-RPC và chuyển mọi lệnh print() của các module con sang stderr
    real_stdout = sys.stdout
    sys.stdout = sys.stderr

    try:
        if hasattr(sys.stdin, "reconfigure"):
            sys.stdin.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(real_stdout, "reconfigure"):
            real_stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception as e:
            err_resp = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": f"Parse error: {e}"},
            }
            real_stdout.write(json.dumps(err_resp, ensure_ascii=False) + "\n")
            real_stdout.flush()
            continue

        if isinstance(msg, list):
            batch_resp = [r for item in msg if (r := handle_jsonrpc_message(item)) is not None]
            if batch_resp:
                real_stdout.write(json.dumps(batch_resp, ensure_ascii=False) + "\n")
                real_stdout.flush()
        else:
            resp = handle_jsonrpc_message(msg)
            if resp is not None:
                real_stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
                real_stdout.flush()


def main():
    parser = argparse.ArgumentParser(description="Film Studio MCP Server (STDIO & HTTP/SSE)")
    parser.add_argument("--stdio", action="store_true", help="Chạy ở chế độ STDIO JSON-RPC (mặc định cho Claude/Cursor).")
    parser.add_argument("--http", action="store_true", help="Chạy ở chế độ HTTP/SSE Server độc lập.")
    parser.add_argument("--port", type=int, default=DEFAULT_MCP_HTTP_PORT, help="Cổng HTTP/SSE (mặc định: 3100).")
    parser.add_argument("--install-1click", action="store_true", help="Tự động cài cấu hình MCP vào Claude Desktop, Cursor, Windsurf.")
    parser.add_argument("--self-test", action="store_true", help="Chạy kiểm thử tự động toàn bộ 9 MCP Tools.")
    args = parser.parse_args()

    if args.install_1click:
        res = install_mcp_to_ai_clients()
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return

    if args.self_test:
        print("=== BAT DAU KIEM THU FILM STUDIO MCP SERVER ===")
        import license_manager
        hwid = license_manager.get_machine_id()
        # Kích hoạt key hợp lệ cho máy hiện tại để test toàn bộ pipeline
        valid_key = license_manager.generate_license_key(
            machine_id=hwid,
            plan="ULTRA",
            expires_at_ts=int(time.time()) + 365 * 86400,
            email="tiende@forgezone.store",
        )
        act_res = license_manager.activate_license(valid_key, check_online=False)
        assert act_res["valid"] is True, f"License activation failed: {act_res}"
        print(f"[MCP-PASS] Hardware License Gate verified (HWID={hwid}, Plan={act_res['plan_name']}) OK")

        init_res = handle_jsonrpc_message(
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05"}}
        )
        assert init_res and init_res["result"]["serverInfo"]["name"] == MCP_SERVER_NAME
        list_res = handle_jsonrpc_message({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        tools = list_res["result"]["tools"]
        assert len(tools) >= 9, f"Expected >=9 MCP tools, got {len(tools)}"
        print(f"[MCP-PASS] JSON-RPC initialize & tools/list ({len(tools)} tools) OK")

        doc = tool_film_studio_doctor({"check_gpu": False})
        assert doc["status"] == "READY" and doc["license"]["valid"] is True
        print("[MCP-PASS] Tool 1: film_studio_doctor OK")


        pipe = tool_film_studio_auto_pipeline(
            {
                "idea": "Chú mèo máy thám hiểm thành phố pha lê phát sáng",
                "num_scenes": 2,
                "style": "3D Pixar / Disney",
                "visual_engine": "kenburns_storyboard",
                "wait_for_completion": True,
            }
        )
        assert pipe["status"] == "COMPLETED" and os.path.isfile(pipe["final_video_path"])
        print(f"[MCP-PASS] Tool 9: film_studio_auto_pipeline -> {pipe['final_video_path']} ({pipe['file_size_mb']} MB) OK")
        print("ALL_MCP_TOOLS_VERIFIED_OK")
        return

    if args.http:
        srv = start_background_mcp_server(port=args.port)
        print(f"[Film Studio MCP] HTTP/SSE Server đang chạy tại http://127.0.0.1:{srv.port}/mcp (Nhấn Ctrl+C để dừng)")
        try:
            while True:
                time.sleep(1.0)
        except KeyboardInterrupt:
            srv.stop()
        return

    # Mặc định chạy STDIO cho MCP Client
    run_stdio_server()


if __name__ == "__main__":
    main()
