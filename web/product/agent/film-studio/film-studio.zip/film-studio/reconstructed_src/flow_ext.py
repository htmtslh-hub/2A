"""
flow_ext.py — Điều khiển cửa sổ Flow (flow.google.com) qua extension + CaptchaServer (cổng 3000).

Dùng chung cho tool tạo video (tool5, tool7, tool4) và tool tạo ảnh (tool6).
Mỗi luồng = 1 cửa sổ Flow riêng (slot), lệnh gửi kèm tiền tố "@S<n>@" → extension chuyển đúng sang cửa sổ slot n.

Tool video dùng slot 11..19 (VIDEO_SLOT_BASE = 10) và tool đồng nhất dùng slot 21+ (INGREDIENT_SLOT_BASE = 20)
để chạy song song với tool ảnh (slot 1..9) mà không giành cửa sổ của nhau.
"""

import base64
import hashlib
import io
import json
import os
import queue
import re
import shutil
import tempfile
import threading
import time
import unicodedata
import requests
from PIL import Image

EXT_CAPTCHA_URL = "http://127.0.0.1:3000/captcha"
VIDEO_SLOT_BASE = 10
INGREDIENT_SLOT_BASE = 20
LAST_CREATED_SLOTS = []

_SLOT_ERR_WORDS = (
    "NO_SLOT",
    "SLOT_",
    "Không tìm thấy ô nhập",
    "Không bấm được nút Tạo",
    "Cài đặt video lỗi",
    "Không gõ được prompt",
    "không phản hồi",
    "đang tạo video khác",
    "Flow không trả lời",
)

ASSET_CACHE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flow_assets.json")
_asset_lock = threading.Lock()
_ui_upload_lock = threading.Lock()
_UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE)


def ext_call(action: str, slot: int = None, timeout: int = 30) -> str:
    """Gửi 1 lệnh tới extension qua CaptchaServer. slot → chỉ cửa sổ slot đó chạy."""
    act = f"@S{int(slot)}@{action}" if slot is not None else action
    r = requests.get(EXT_CAPTCHA_URL, params={"action": act}, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"Captcha server HTTP {r.status_code}: {r.text[:200]}")
    data = r.json()
    return str(data.get("captcha", ""))


def get_flow_project_id() -> str:
    """Lấy project id đang mở trên tab Flow chính (để mở các cửa sổ slot cùng project)."""
    try:
        js = "FLOWGEN|fake|__EVAL__||location.pathname.match(/project\\/([0-9a-f-]{8,})/i)?.[1] || ''"
        res = ext_call(js, timeout=8)
        if res.startswith("OK|"):
            val = json.loads(res[3:])
            return str(val or "").strip()
    except Exception:
        pass
    return ""


def wait_flow_slots_ready(slots, log=print, wait: int = 25) -> list:
    """Chờ các cửa sổ slot tải xong Flow (có ô prompt). Trả về danh sách slot sẵn sàng."""
    js = '({slot: sessionStorage.getItem("htSlot"), pm: !!document.querySelector(".ProseMirror")})'
    ready = set()
    t0 = time.time()
    while time.time() - t0 < wait and len(ready) < len(slots):
        for s in slots:
            if s in ready:
                continue
            try:
                res = ext_call(f"FLOWGEN|fake|__EVAL__||{js}", slot=s, timeout=4)
                if '"pm":true' in res:
                    ready.add(s)
            except Exception:
                pass
        if len(ready) < len(slots):
            time.sleep(1.0)
    return sorted(ready)


def ensure_flow_slots(n: int, project_id: str = "", log=print, wait: int = 25, base: int = 0, minimized: bool = True) -> list:
    """Tự mở (nếu thiếu) N cửa sổ Flow slot base+1..base+n. minimized=True → nằm luôn dưới taskbar
    (tạo video bấm bằng phím Enter qua CDP, không cần cửa sổ hiện). Trả về slot đã sẵn sàng."""
    global LAST_CREATED_SLOTS
    pid = project_id or get_flow_project_id()
    slots = [base + i + 1 for i in range(max(1, int(n)))]
    payload = json.dumps({"n": len(slots), "pid": pid, "base": base, "minimized": bool(minimized)})
    try:
        res = ext_call(f"FLOWGEN|fake|__SLOTS_ENSURE__|{payload}", timeout=15)
    except Exception as e:
        log(f"❌ Không mở được cửa sổ Flow (extension/cổng 3000): {e}")
        return []
    if not res.startswith("OK|"):
        log(f"❌ Mở cửa sổ Flow lỗi: {res}")
        return []
    try:
        info = json.loads(res[3:])
        created = [int(x.get("slot")) for x in info.get("created", []) if x.get("slot")]
        LAST_CREATED_SLOTS = created
        for x in info.get("created", []):
            if x.get("error"):
                log(f"⚠️ Slot {x.get('slot')}: {x.get('error')}")
        if created:
            log(f"🪟 Đã tự mở {len(created)} cửa sổ Flow mới (slot {created}), thu nhỏ sẵn dưới taskbar.")
    except Exception:
        pass
    log(f"⏳ Chờ {len(slots)} cửa sổ Flow tải xong...")
    return wait_flow_slots_ready(slots, log=log, wait=wait)


def reload_flow_slot(slot: int, log=print, wait: int = 20) -> bool:
    """F5 riêng 1 cửa sổ slot (lỗi / kẹt) rồi chờ nó sẵn sàng lại."""
    try:
        ext_call("FLOWGEN|fake|__RELOAD_PAGE__", slot=slot, timeout=10)
    except Exception:
        pass
    time.sleep(2.0)
    ready = wait_flow_slots_ready([slot], log=log, wait=wait)
    return slot in ready


class SlotPool:
    """Hàng cửa sổ rảnh: mỗi luồng mượn 1 cửa sổ, làm xong trả lại."""

    def __init__(self, slots):
        self._q = queue.Queue()
        for s in slots:
            self._q.put(s)

    def acquire(self, is_running=lambda: True):
        while is_running():
            try:
                return self._q.get(timeout=0.5)
            except queue.Empty:
                continue
        return None

    def release(self, slot):
        if slot is not None:
            self._q.put(slot)


def is_slot_error(err: str) -> bool:
    """Lỗi thuộc về cửa sổ (kẹt UI / bị đóng) → nên F5 / mở lại riêng cửa sổ đó."""
    s = str(err or "")
    return any(w in s for w in _SLOT_ERR_WORDS)


def flow_generate_video(
    slot: int,
    prompt: str,
    model: str = "Veo 3.1 - Lite",
    ratio: str = "16:9",
    duration: str = "8s",
    project_id: str = "",
    count: int = 1,
    status_cb=None,
    is_running=lambda: True,
    max_wait: int = 420,
    refs=None,
    voice: str = "",
):
    """Tạo 1 video trong cửa sổ slot. Trả (list[{mediaId,url}], None) hoặc (None, lỗi).
    refs  = tên các ảnh đã có trong project (bỏ đuôi) → gắn chip @ chế độ "Thành phần".
    voice = tên giọng (vd "achernar") → chip giọng nói (không chọn được thì bỏ qua)."""
    payload = {
        "projectId": project_id,
        "prompt": prompt,
        "model": model,
        "ratio": ratio,
        "duration": duration,
        "count": count,
        "refs": list(refs or []),
        "voice": voice or "",
    }
    try:
        res = ext_call("FLOWVID_START|" + json.dumps(payload, ensure_ascii=False), slot=slot, timeout=25)
    except Exception as e:
        return None, f"Không gọi được captcha server (cổng 3000): {e}"
    if res.startswith("ERR|"):
        return None, res[4:]

    t0 = time.time()
    last_stage = ""
    fails = 0
    while time.time() - t0 < max_wait:
        if not is_running():
            return None, "Đã dừng"
        time.sleep(2.5)
        try:
            res = ext_call("FLOWVID_POLL", slot=slot, timeout=15)
            fails = 0
        except Exception as e:
            fails += 1
            if fails >= 4:
                return None, f"Mất kết nối cửa sổ slot {slot}: {e}"
            continue
        if res.startswith("OK|PENDING"):
            parts = res.split("|")
            stage = parts[2] if len(parts) > 2 else ""
            if stage and stage != last_stage and status_cb:
                last_stage = stage
                status_cb(stage)
            continue
        if res.startswith("OK|IDLE"):
            return None, f"SLOT_{slot}: cửa sổ bị tải lại giữa chừng (mất trạng thái)"
        if res.startswith("ERR|"):
            return None, res[4:]
        if res.startswith("OK|"):
            try:
                items = json.loads(res[3:])
                valid = [x for x in (items or []) if x.get("url")]
                if valid:
                    return valid, None
                return None, "Không có link video"
            except Exception as e:
                return None, f"parse kết quả lỗi: {e}"
    return None, f"Quá thời gian chờ video ({max_wait}s)"


def download_file(url: str, save_path: str, min_size: int = 10000, tries: int = 3):
    """Tải file (link có chữ ký, không cần cookie). Ghi .part rồi đổi tên → không bao giờ để file dở."""
    last = ""
    part = save_path + ".part"
    os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
    for _ in range(max(1, tries)):
        try:
            r = requests.get(url, timeout=120)
            if r.status_code == 200 and len(r.content) >= min_size:
                with open(part, "wb") as f:
                    f.write(r.content)
                os.replace(part, save_path)
                return True, None
            last = f"HTTP {r.status_code}, {len(r.content)} bytes"
        except Exception as e:
            last = str(e)
        time.sleep(1.5)
    return False, last


def get_live_token():
    """Lấy token ya29 + email + project đang mở từ tab Flow (tài khoản đang đăng nhập trên trình duyệt)."""
    try:
        js = (
            "FLOWGEN|fake|__EVAL__||(async () => { "
            "let t = await requestCdp({ type: 'refreshToken' }); "
            "let pid = location.pathname.match(/project\\/([0-9a-f-]{8,})/i)?.[1] || ''; "
            "return { token: t?.token, email: t?.email, pid: pid }; })()"
        )
        res = ext_call(js, timeout=20)
        if res.startswith("OK|"):
            d = json.loads(res[3:]) or {}
            return d.get("token") or "", d.get("email") or "", d.get("pid") or ""
    except Exception:
        pass
    return "", "", ""


def _file_sha1(path: str) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def asset_name_for(path: str, uid: str = "") -> str:
    """Tên asset trên Flow: <uid chỉ gồm A-Z0-9_>_<6 ký tự hash file> (vd CHAR_01_a1b2c3)."""
    base = uid or os.path.splitext(os.path.basename(path))[0]
    base = unicodedata.normalize("NFKD", str(base)).encode("ascii", "ignore").decode("ascii")
    base = re.sub(r"[^A-Za-z0-9_]+", "_", base).strip("_") or "IMG"
    return f"{base}_{_file_sha1(path)[:6]}"


def _load_asset_cache() -> dict:
    try:
        if os.path.isfile(ASSET_CACHE_FILE):
            with open(ASSET_CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f) or {}
    except Exception:
        pass
    return {}


def _save_asset_cache(d: dict):
    try:
        with open(ASSET_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def forget_asset(project_id: str, name: str):
    """Chip không gắn được (ảnh bị xóa khỏi project…) → bỏ khỏi cache để lần sau upload lại."""
    with _asset_lock:
        d = _load_asset_cache()
        if d.pop(f"{project_id}|{name}", None) is not None:
            _save_asset_cache(d)


def upload_ref_image(path: str, file_name: str, project_id: str, token: str):
    """Upload 1 ảnh vào project Flow (giống nút Tải lên). Trả (mediaId, None) hoặc (None, lỗi)."""
    try:
        im = Image.open(path)
        if im.mode != "RGB":
            im = im.convert("RGB")
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=93)
        data = buf.getvalue()
    except Exception as e:
        return None, f"đọc ảnh lỗi: {e}"

    payload = {
        "clientContext": {"projectId": project_id, "tool": "PINHOLE"},
        "imageBytes": base64.b64encode(data).decode("ascii"),
        "isUserUploaded": True,
        "isHidden": False,
        "mimeType": "image/jpeg",
        "fileName": file_name,
    }
    headers = {
        "authorization": f"Bearer {token}",
        "content-type": "text/plain;charset=UTF-8",
        "origin": "https://labs.google",
        "referer": "https://labs.google/",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
    }
    try:
        r = requests.post(
            "https://aisandbox-pa.googleapis.com/v1/flow/uploadImage",
            data=json.dumps(payload),
            headers=headers,
            timeout=60,
        )
        if r.status_code != 200:
            return None, f"HTTP {r.status_code}: {r.text[:200]}"
        m = _UUID_RE.search(r.text)
        if m:
            return m.group(0), None
        return None, f"không thấy mediaId: {r.text[:200]}"
    except Exception as e:
        return None, str(e)


def _prepare_upload_file(path: str, upload_name: str) -> str:
    """Tên file khi upload = tên asset trên Flow (dùng để gắn chip @). Khác tên gốc → tạo bản sao tạm."""
    tmp_dir = os.path.join(tempfile.gettempdir(), "ht_flow_upload")
    os.makedirs(tmp_dir, exist_ok=True)
    if not upload_name.lower().endswith((".jpg", ".jpeg")):
        upload_name += ".jpg"
    dst = os.path.join(tmp_dir, upload_name)
    if path.lower().endswith((".jpg", ".jpeg")):
        shutil.copyfile(path, dst)
    else:
        im = Image.open(path)
        if im.mode != "RGB":
            im = im.convert("RGB")
        im.save(dst, format="JPEG", quality=93)
    return dst


def ensure_ref_assets(items, project_id: str, log=print, force: bool = False):
    """items = [(path, uid)]. Đảm bảo mọi ảnh đã nằm trong project Flow.
    Trả ({path: tên_asset}, số_ảnh_vừa_upload, [lỗi])."""
    out = {}
    errs = []
    uploaded = 0
    with _asset_lock:
        cache = _load_asset_cache()
    for path, uid in items:
        if not path or not os.path.isfile(path):
            continue
        name = asset_name_for(path, uid)
        key = f"{project_id}|{name}"
        if not force and key in cache:
            out[path] = name
            continue
        out[path] = name
    return out, uploaded, errs
