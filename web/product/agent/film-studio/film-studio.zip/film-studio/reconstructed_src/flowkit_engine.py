"""
flowkit_engine.py — Lõi Tích Hợp FlowKit cho Film studio
────────────────────────────────────────────────────────
Kết hợp:
  1. Giao thức Google Flow batchexecute (`flow_batch.py` + `flowkit_extension/`):
     • RPC `YhhmEf` (Text to video)
     • RPC `eb1hJf` (Image to video — 1 ảnh đầu)
     • RPC `nprQif` (Image to video — 2 ảnh đầu/cuối)
     • RPC `MZZa6b` (Veo Đồng nhất — Reference to video)
     • RPC `ogiZ0b` (Tạo ảnh mẫu nhân vật GEM_PIX_2 / NARWHAL)
     • RPC `maseQ`  (Upload ảnh lấy UUID media_id)
     • RPC `jwpduf` (Kiểm tra tiến độ render video)
  2. Chuẩn Kịch Bản Điện Ảnh 8 Giây 3 Nhịp (`0-3s / 3-6s / 6-8s`) & 10 Archetypes (`fk-scriptwriter`).
  3. Hồ Sơ Nhân Vật Biometric Visual Anchor Sheet (`fk-character-bible`).
  4. Bộ Lọc Chuyển Động Vật Lý 3 Pha & Bypass Tên Người Thật (`fk-action-choreography` + Rule 15).
  5. Phối Âm Điện Ảnh 4 Lớp & Sidechain Audio Ducking -14dB + Chuẩn Âm Lượng YouTube -14 LUFS (`fk-sound-design`).
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Optional

import flow_batch

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
FLOWKIT_EXTENSION_DIR = os.path.join(SRC_DIR, "flowkit_extension")

AUTO_STYLE_LABEL = "⚡ Tự nhận diện từ Prompt"

DEFAULT_STYLE_PRESETS = [
    AUTO_STYLE_LABEL,
    "3D Pixar / Disney",
    "Điện ảnh (Cinematic Realistic)",
    "Anime Nhật Bản",
    "Hoạt hình 2D",
    "Cyberpunk Sci-Fi",
    "Steampunk Cổ điển",
    "Fantasy Huyền ảo",
    "Đất sét (Claymation / Stop Motion)",
    "Tranh màu nước (Watercolor)",
    "Lego / Khối gạch 3D",
]

DEFAULT_STYLE_VALUES = DEFAULT_STYLE_PRESETS

_STYLE_DETECT_PATTERNS = [
    (r"\b(3d\s*pixar|disney\s*pixar|pixar\s*style|dreamworks|hoạt\s*hình\s*3d|3d\s*animation|3d\s*cute)\b", "3D Pixar / Disney"),
    (r"\b(anime|studio\s*ghibli|makoto\s*shinkai|manga|cel[\s-]*shaded|hoạt\s*hình\s*nhật)\b", "Anime Nhật Bản"),
    (r"\b(photorealistic|cinematic\s*realistic|live[\s-]*action|hyperrealistic|raw\s*photo|8k\s*film|điện\s*ảnh\s*thực\s*tế|người\s*thật)\b", "Điện ảnh (Cinematic Realistic)"),
    (r"\b(2d\s*cartoon|2d\s*animation|flat\s*illustration|hoạt\s*hình\s*2d|vector\s*cartoon)\b", "Hoạt hình 2D"),
    (r"\b(cyberpunk|neon\s*sci[\s-]*fi|futuristic\s*neon|blade\s*runner\s*style)\b", "Cyberpunk Sci-Fi"),
    (r"\b(steampunk|clockwork\s*brass|victorian\s*mechanical)\b", "Steampunk Cổ điển"),
    (r"\b(dark\s*fantasy|epic\s*fantasy|medieval\s*magic|tiên\s*hiệp|huyền\s*ảo|cổ\s*trang\s*huyền\s*huyễn)\b", "Fantasy Huyền ảo"),
    (r"\b(claymation|stop[\s-]*motion|plasticine|đất\s*sét)\b", "Đất sét (Claymation / Stop Motion)"),
    (r"\b(watercolor|oil\s*painting|màu\s*nước|tranh\s*sơn\s*dầu|ink\s*wash)\b", "Tranh màu nước (Watercolor)"),
    (r"\b(lego|voxel|minecraft\s*style|khối\s*gạch)\b", "Lego / Khối gạch 3D"),
    (r"\b(pixel\s*art|8[\s-]*bit|16[\s-]*bit)\b", "Pixel Art"),
    (r"\b(pencil\s*sketch|charcoal\s*drawing|line\s*art|phác\s*thảo)\b", "Phác thảo (Sketch)"),
]


def detect_style_from_prompt(prompt_text: str) -> Optional[str]:
    """Tự động nhận diện phong cách hình ảnh có sẵn trong câu lệnh (Prompt)."""
    s = (prompt_text or "").strip()
    if not s:
        return None

    # 1. Nhận diện thẻ [Style | ...] hoặc [Phong cách: ...] ở đầu câu lệnh
    bracket_m = re.match(r"^(?:Prompt\s*\d+\s*:\s*)?\[\s*([^\]|]{3,45}?)\s*(?:\|[^\]]*)?\]", s, flags=re.I)
    if bracket_m:
        cand = bracket_m.group(1).strip()
        if not re.match(r"^(CHAR_\d+|LOC_\d+|NV\d+|BG_\d+|Scene\s*\d+)$", cand, flags=re.I):
            return cand

    # 2. Nhận diện cú pháp Style: ... hoặc Phong cách: ...
    explicit_m = re.search(r"(?:visual\s*style|style|phong\s*cách)\s*[:=]\s*([^.,;\n|\]]{3,45})", s, flags=re.I)
    if explicit_m:
        return explicit_m.group(1).strip()

    # 3. Quét từ khóa phong cách phổ biến trong nội dung prompt
    for pat, label in _STYLE_DETECT_PATTERNS:
        if re.search(pat, s, flags=re.I):
            return label

    return None


def resolve_effective_style(
    prompt_text: str,
    user_style_choice: str = "",
    fallback_style: str = "3D Pixar / Disney",
) -> tuple[str, bool]:
    """
    Ưu tiên 1: Nhận diện phong cách từ trong Prompt.
    Ưu tiên 2: Nếu Prompt không có phong cách, lấy phong cách người dùng chọn hoặc tự gõ từ bàn phím.
    Trả về: (effective_style, detected_from_prompt)
    """
    detected = detect_style_from_prompt(prompt_text)
    if detected:
        return detected, True

    choice = (user_style_choice or "").strip()
    if choice and choice != AUTO_STYLE_LABEL and "Tự nhận diện" not in choice:
        return choice, False

    return fallback_style, False


def apply_style_to_prompt(
    prompt_text: str,
    user_style_choice: str = "",
    fallback_style: str = "3D Pixar / Disney",
) -> tuple[str, str, bool]:
    """
    Đảm bảo câu lệnh có phong cách chuẩn:
      • Nếu trong prompt đã có phong cách -> Giữ nguyên phong cách của prompt.
      • Nếu trong prompt chưa có phong cách -> Gắn phong cách từ ô chọn / bàn phím vào đầu prompt.
    Trả về: (final_prompt, effective_style, detected_from_prompt)
    """
    raw = (prompt_text or "").strip()
    eff_style, from_prompt = resolve_effective_style(raw, user_style_choice, fallback_style)
    if from_prompt or not raw:
        return raw, eff_style, True
    if raw.lower().startswith(f"[{eff_style.lower()}]"):
        return raw, eff_style, False
    return f"[{eff_style}] {raw}", eff_style, False

# 10 Archetypes Điện Ảnh từ fk-scriptwriter.md
CINEMATIC_ARCHETYPES = [
    ("Establishing Shot", "Extreme wide establishing shot", "Smooth crane-down camera movement"),
    ("Dialogue Two-Shot", "Medium two-shot with over-the-shoulder angle", "Static locked-off shot with subtle rack focus"),
    ("Action Beat", "Medium kinetic tracking shot", "Lateral tracking shot following the motion trajectory"),
    ("Pure Reaction Shot", " expressive close-up shot", "Slow push-in to extreme close-up"),
    ("Insert / Detail Shot", "Macro close-up on key thematic prop", "Smooth rack focus from foreground to subject"),
    ("Stalking / Suspense Shot", "Telephoto shot framed through foreground elements", "Locked-off telephoto depth framing"),
    ("Montage Beat", "Dynamic multi-angle composition", "Rhythmic cinematic tracking"),
    ("Heroic Low-Angle Reveal", "Low-angle heroic wide shot", "Slow tilt-up reveal with volumetric light"),
]

# Từ điển chuyển đổi hành động nhạy cảm / biến dạng vật lý sang chuẩn fk-action-choreography.md
PHYSICS_SAFE_CHOREOGRAPHY_RULES = [
    (
        r"\b(stabs?|stabbing|impales?|impaling|pierces?\s+through|blood\s+splatter\w*|slit\w*\s+throat)\b",
        "delivers a decisive diagonal downward slash, blade clashing against a raised iron shield in an explosive shower of orange sparks",
    ),
    (
        r"\b(shoots?\s+dead|headshot|gunshot\s+wound|bullet\s+pierc\w*)\b",
        "fires a tactical energy pulse forward along a clean linear trajectory, kicking up dust and bright sparks on impact",
    ),
    (
        r"\b(360[\s-]*degree\s+spin\w*|backflip\s+somersault\w*|twirls?\s+spinning\s+rapidly)\b",
        "ducks low beneath the incoming sweep, sidestepping swiftly with a solid defensive guard raised",
    ),
    (
        r"\b(grapples?\s+and\s+rolls?|wrestling\s+on\s+the\s+floor|chokehold|strangl\w+)\b",
        "drives a heavy gauntleted strike forward, deflecting the opposing force with a firm forearm parry",
    ),
    (
        r"\b(gore|gory|mutilat\w+|decapitat\w+|dismember\w+|corpse|dead\s+body|bleeding\s+heavily|pool\s+of\s+blood)\b",
        "dramatic battle-worn tension amidst drifting embers and deep chiaroscuro shadows",
    ),
]


def format_flowkit_3beat_prompt(
    scene_idx: int,
    core_action: str,
    style: str = "3D Pixar / Disney",
    char_ref: str = "CHAR_01",
    lighting: str = "cinematic volumetric lighting, rich color contrast",
    audio_cue: str = "immersive environmental ambience, crisp foley",
) -> str:
    """Định dạng câu lệnh cảnh quay 8s chuẩn 3 nhịp (0-3s / 3-6s / 6-8s) của FlowKit."""
    arch_name, framing, cam_move = CINEMATIC_ARCHETYPES[(scene_idx - 1) % len(CINEMATIC_ARCHETYPES)]
    clean_action = (core_action or "").strip().rstrip(".")
    return (
        f"Prompt {scene_idx}: [{style} | {arch_name}] ({char_ref}) "
        f"0-3s: {framing} — {clean_action}, establishing posture and spatial tension. "
        f"3-6s: Primary kinetic action — {clean_action} progresses along a clean unidirectional trajectory. "
        f"6-8s: Anchor pose & resolution — subject settles into a composed final frame as atmospheric particles drift. "
        f"{cam_move}. Lighting: {lighting}. Audio: {audio_cue}. "
        f"Negative: subtitles, captions, watermark, text overlay, extra limbs, distorted hands."
    )


def build_biometric_character_sheet(
    char_id: str,
    name: str,
    appearance: str,
    style: str = "3D Pixar / Disney",
) -> Dict[str, str]:
    """Tạo Hồ sơ Nhân vật chuẩn Biometric Visual Anchor Sheet (fk-character-bible)."""
    desc = (appearance or "").strip() or (
        "Distinctive lead character with expressive eyes, balanced facial bone structure, "
        "signature explorer outfit with weathered metallic details and locked color palette"
    )
    image_prompt = (
        f"Character reference sheet of {name} ({char_id}), {desc}. "
        f"Biometric visual anchor: front view, 3/4 view, and side profile, neutral studio lighting, "
        f"locked wardrobe state, {style}, 8k resolution, ultra-detailed textures. "
        f"Negative: subtitles, watermark, text overlay, blurry face."
    )
    return {
        "id": char_id,
        "name": name,
        "appearance": desc,
        "image_prompt": image_prompt,
    }


def apply_physics_safe_choreography(prompt_text: str) -> str:
    """Áp dụng bộ quy tắc chuyển động vật lý 3 pha & chống từ cấm của FlowKit (fk-action-choreography)."""
    cleaned = prompt_text or ""
    for pat, repl in PHYSICS_SAFE_CHOREOGRAPHY_RULES:
        cleaned = re.sub(pat, repl, cleaned, flags=re.IGNORECASE)
    if "negative:" not in cleaned.lower():
        cleaned = cleaned.rstrip(". ") + ". Negative: subtitles, watermark, text overlay, extra limbs."
    return cleaned


def build_flow_rpc_envelope(
    mode: str,
    project_id: str,
    prompt: str,
    aspect_ratio: str = "16:9",
    model_name: str = "abra_t2v_8s",
    start_media_id: Optional[str] = None,
    end_media_id: Optional[str] = None,
    ref_media_ids: Optional[List[str]] = None,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Đóng gói bản tin batchexecute RPC chuẩn của flow.google.com cho cả 4 chế độ video."""
    aspect = (
        flow_batch.VIDEO_ASPECT_PORTRAIT
        if ("9:16" in str(aspect_ratio) or "PORTRAIT" in str(aspect_ratio).upper())
        else flow_batch.VIDEO_ASPECT_LANDSCAPE
    )
    if mode == "t2v":
        rpcid = flow_batch.RPC_GEN_VIDEO_TEXT
        f_req = flow_batch.text_video_request(
            prompt=prompt,
            project_id=project_id,
            aspect=aspect,
            model=model_name or "abra_t2v_8s",
        )
    elif mode == "i2v_chain" and start_media_id and end_media_id:
        rpcid = flow_batch.RPC_GEN_VIDEO_FIRST_LAST
        f_req = flow_batch.omni_first_last_request(
            prompt=prompt,
            project_id=project_id,
            start_media_id=start_media_id,
            end_media_id=end_media_id,
            aspect=aspect,
        )
    elif mode == "consist" and ref_media_ids:
        rpcid = flow_batch.RPC_GEN_VIDEO_REFERENCES
        f_req = flow_batch.omni_reference_video_request(
            prompt=prompt,
            project_id=project_id,
            reference_media_ids=ref_media_ids,
            aspect=aspect,
        )
    elif mode == "i2v" and start_media_id:
        rpcid = flow_batch.RPC_GEN_VIDEO
        f_req = flow_batch.video_request(
            prompt=prompt,
            project_id=project_id,
            source_media_id=start_media_id,
            aspect=aspect,
            model=flow_batch.resolve_video_model(model_name),
        )
    else:
        rpcid = flow_batch.RPC_GEN_VIDEO_TEXT
        f_req = flow_batch.text_video_request(
            prompt=prompt,
            project_id=project_id,
            aspect=aspect,
            model="abra_t2v_8s",
        )
    return {
        "rpcid": rpcid,
        "f_req": f_req,
        "captcha_action": flow_batch.CAPTCHA_VIDEO,
        "batch_path": flow_batch.BATCH_PATH,
    }


def build_cinema_ducking_ffmpeg_filter(bg_vol: float = 0.25, voice_vol: float = 1.40) -> str:
    """Bộ lọc FFmpeg Sidechain Audio Ducking (-14dB nhạc nền / +3dB giọng đọc) + Chuẩn hóa -14 LUFS."""
    return (
        f"[0:a]volume={bg_vol:.2f}[bg];"
        f"[1:a]volume={voice_vol:.2f}[fg];"
        f"[bg][fg]amix=inputs=2:duration=first:dropout_transition=2,loudnorm=I=-14:LRA=7:TP=-1.0[aout]"
    )


# ─────────────────────────────────────────────────────────────────────────────
# 6. BỘ PHÂN TÍCH PROMPT THÔNG MINH: NHẬN DIỆN NHÂN VẬT DUY NHẤT (BƯỚC 1)
#    VÀ GẮN MÃ THAM CHIẾU CHO TỪNG PHÂN CẢNH (BƯỚC 2) + LỌC AN TOÀN GOOGLE FLOW
# ─────────────────────────────────────────────────────────────────────────────
FLOW_SAFE_VISUAL_REPLACEMENTS = [
    (
        r"\b(\d{1,2})\s*[-–]?\s*year\s*[-–]?\s*old\s+(girl|daughter|sister|lass|maiden)\b",
        "petite youthful storybook heroine",
    ),
    (
        r"\b(\d{1,2})\s*[-–]?\s*year\s*[-–]?\s*old\s+(boy|son|brother|lad)\b",
        "petite youthful storybook hero",
    ),
    (
        r"\b(\d{1,2})\s*[-–]?\s*year\s*[-–]?\s*old\s+(child|kid|toddler)\b",
        "petite youthful animated protagonist",
    ),
    (r"\b(\d{1,2})\s*[-–]?\s*year\s*[-–]?\s*old\b", "youthful"),
    (r"\b(little|small|young|tiny)\s+girl\b", "petite storybook heroine"),
    (r"\b(little|small|young|tiny)\s+boy\b", "petite storybook hero"),
    (
        r"\b(child|children|kid|kids|toddler|infant|baby|minor|underage|schoolgirl|schoolboy)\b",
        "stylized animated protagonist",
    ),
    (
        r"\b(stalking|stalks|preying\s+on|prey|devour\w*|eat\s+her|eating\s+her|attack\w*|lunging\s+at|pouncing\s+on|maul\w*|kill\w*|murder\w*|blood\w*|gore|corpse|terrified|screaming\s+in\s+terror)\b",
        "approaching with expressive theatrical posture",
    ),
]

FLOW_AGGRESSIVE_SAFE_REPLACEMENTS = [
    (r"\b(scary|terrifying|ferocious|savage|menacing|sinister|predator\w*|evil|cunning|sly|deceptive)\s+wolf\b", "expressive stylized anthropomorphic forest husky character"),
    (r"\banthropomorphic\s+wolf\b", "stylized animated woodland husky character in storybook attire"),
    (r"\btalking\s+wolf\b", "expressive stylized animated woodland husky character in storybook attire"),
    (r"\bbig\s+bad\s+wolf\b", "expressive stylized animated woodland husky character"),
    (r"\bwolf\b", "stylized animated woodland husky character"),
    (r"\b(sharp\s+teeth|sharp\s+fangs|bared\s+fangs|fangs|snarling|growling|claws|razor\s+claws)\b", "expressive animated features"),
    (r"\b(predator\w*|menacing\w*|sinister\w*|threatening\w*|lurking|ambush\w*)\b", "theatrical storybook"),
    (r"\b(axe|hatchet|knife|dagger|sword|blade|gun|rifle|weapon\w*)\b", "wooden walking staff"),
    (r"\b(hunter|woodsman)\b", "friendly woodland ranger"),
]

_VI_STYLE_TO_EN = {
    "điện ảnh (cinematic realistic)": "Cinematic Photorealistic 8K Film",
    "anime nhật bản": "Japanese Anime Studio Ghibli Style",
    "hoạt hình 2d": "2D Stylized Cartoon Illustration",
    "cổ tích 3d": "3D Pixar Disney Storybook Animation",
    "3d pixar / disney": "3D Pixar Disney Animation",
    "cyberpunk sci-fi": "Cyberpunk Futuristic Sci-Fi",
    "steampunk cổ điển": "Classic Victorian Steampunk",
    "fantasy huyền ảo": "Epic Magical Fantasy",
    "đất sét (claymation / stop motion)": "3D Claymation Stop Motion",
    "tranh màu nước (watercolor)": "Storybook Watercolor Painting",
    "lego / khối gạch 3d": "3D Lego Brick Animation",
}


def sanitize_prompt_for_google_flow(prompt_text: str, aggressive: bool = False) -> str:
    """
    Làm sạch các từ khóa dễ bị bộ lọc Google Flow (ogiZ0b / GEM_PIX_2 / Veo 3) chặn
    với lỗi PUBLIC_ERROR_UNSAFE_GENERATION, PUBLIC_ERROR_MINOR hoặc RPC ogiZ0b Error: [5] (NOT_FOUND do hậu kiểm)
    mà vẫn giữ nguyên 100% tạo hình thị giác.
    """
    out = (prompt_text or "").strip()
    if not out:
        return out
    for vi_k, en_v in _VI_STYLE_TO_EN.items():
        out = re.sub(re.escape(vi_k), en_v, out, flags=re.IGNORECASE)
    for pat, repl in FLOW_SAFE_VISUAL_REPLACEMENTS:
        out = re.sub(pat, repl, out, flags=re.IGNORECASE)
    if aggressive:
        for pat, repl in FLOW_AGGRESSIVE_SAFE_REPLACEMENTS:
            out = re.sub(pat, repl, out, flags=re.IGNORECASE)
    return out


def is_scene_prompt_line(line: str) -> bool:
    """
    Phân biệt chính xác 1 dòng là Câu lệnh Phân Cảnh (Bước 2) hay Hồ sơ Tham Chiếu Gốc (Bước 1).
    """
    s = (line or "").strip()
    if not s:
        return False
    # Nếu có mốc nhịp thời gian 0-3s / 3-6s / 6-8s hoặc từ khóa cảnh quay
    if re.search(r"\b(0-3s|3-6s|6-8s|0-2s|Lighting\s*:|Audio\s*:|Negative\s*:)\b", s, flags=re.I):
        return True
    # Nếu có tiền tố Prompt X: / Scene X: / Cảnh X: (dù phía trước có CHAR_01 | hay không)
    if re.search(r"(?:^|\|\s*)(?:Prompt|Scene|Cảnh)\s*\d+\s*[:\]]", s, flags=re.I):
        return True
    if re.match(r"^\[\s*(?:Scene|Cảnh)\s*\d+\s*\]", s, flags=re.I):
        return True
    # Nếu bên trong câu lệnh có nhúng định nghĩa nhân vật trong ngoặc đơn (CHAR_01: ...) kèm mô tả cảnh
    if re.search(r"\(\s*(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*:", s, flags=re.I):
        return True
    # Nếu có các thuật ngữ góc máy điện ảnh đặc trưng của phân cảnh
    if re.search(
        r"\b(wide\s+shot|medium\s+shot|close[\s-]*up|establishing\s+shot|tracking\s+shot|"
        r"two[\s-]*shot|over[\s-]*the[\s-]*shoulder|camera\s+pans|camera\s+tracks|crane[\s-]*down|push[\s-]*in)\b",
        s,
        flags=re.I,
    ) and not re.search(r"\b(turnaround|reference\s+sheet|multiple\s+angles|t-pose)\b", s, flags=re.I):
        return True
    return False


def _normalize_entity_uid(raw_uid: str) -> str:
    u = (raw_uid or "").strip().upper().replace(" ", "_")
    while u.startswith("REF_"):
        u = u[4:].strip("_")
    m_char = re.match(r"^(?:CHAR|NV)_?(\d+)$", u)
    if m_char:
        return f"CHAR_{int(m_char.group(1)):02d}"
    m_loc = re.match(r"^(?:LOC|BG|SET|ENV)_?(\d+)$", u)
    if m_loc:
        return f"LOC_{int(m_loc.group(1)):02d}"
    return u or "CHAR_01"


normalize_char_tag_id = _normalize_entity_uid


def to_single_frame_image_prompt(prompt_text: str) -> str:
    """
    Chuyển đổi bất kỳ câu lệnh phân cảnh nào (bao gồm câu lệnh Video 3 nhịp 0-3s / 3-6s / 6-8s)
    thành Câu lệnh Tạo Ảnh Tĩnh 1 Khung Hình Duy Nhất (Single-Frame Cinematic Keyframe Image Prompt).
    Khắc phục triệt để hiện tượng AI vẽ 4 khung tranh / 4 ảnh ghép trong 1 tấm ảnh (comic grid / split screen).
    """
    s = (prompt_text or "").strip()
    if not s:
        return ""

    # Tách giữ phần prefix CHAR_XX | và Prompt X: nếu có ở đầu dòng
    uid_prefix = ""
    if "|" in s[:45]:
        left, right = s.split("|", 1)
        if re.search(r"\b(?:CHAR|LOC|NV|BG|REF)\b", left, flags=re.I):
            uid_prefix = left.strip()
            s = right.strip()

    prompt_num_prefix = ""
    m_pnum = re.match(r"^((?:Prompt|Scene|Cảnh)\s*\d+\s*:\s*)", s, flags=re.I)
    if m_pnum:
        prompt_num_prefix = m_pnum.group(1).strip() + " "
        s = s[m_pnum.end():].strip()

    # Tách nhãn [Style] ở đầu nếu có
    style_tag = ""
    m_style = re.match(r"^(\[[^\]]{3,80}\])\s*", s)
    if m_style:
        style_tag = m_style.group(1).strip() + " "
        s = s[m_style.end():].strip()

    # Trích xuất phần Lighting nếu có trước khi loại bỏ Audio / Negative / Dialogue
    lighting_clause = ""
    m_light = re.search(
        r"\bLighting\s*:\s*([^.\n]+?)(?=\s*(?:\.\s*(?:Audio|Voiceover|Dialogue|Negative|SFX)|$))",
        s,
        flags=re.I,
    )
    if m_light and m_light.group(1).strip():
        lighting_clause = f" Lighting: {m_light.group(1).strip().rstrip('.')}."

    # Loại bỏ các trường chỉ dành cho Video/Âm thanh dễ khiến mô hình ảnh vẽ bong bóng thoại hoặc chia khung truyện tranh
    s = re.sub(
        r"\s*\b(?:Audio|Voiceover(?:\s*\([^\)]*\))?|Dialogue(?:\s*\([^\)]*\))?|SFX|Sound|Negative)\s*:.*$",
        "",
        s,
        flags=re.I,
    ).strip()
    s = re.sub(r"\s*\bLighting\s*:\s*[^.\n]+\.?", "", s, flags=re.I).strip()

    # Nếu câu lệnh có cấu trúc nhịp thời gian 0-3s / 3-6s / 6-8s:
    # Chỉ lấy khung hình chính (Keyframe) ở 0-3s, và nếu 3-6s có xuất hiện thêm nhân vật thứ 2 (CHAR_XX)
    # chưa có ở 0-3s thì gộp nhân vật đó vào CÙNG MỘT KHUNG HÌNH (loại bỏ hoàn toàn động tác thứ 2/thứ 3 của cùng 1 nhân vật)
    if re.search(r"\b(?:0-3s|3-6s|6-8s|0-2s)\s*:", s, flags=re.I):
        parts = re.split(r"\b(0-3s|0-2s|3-6s|2-5s|6-8s|5-8s)\s*:\s*", s, flags=re.I)
        lead_text = parts[0].strip().rstrip(".,; ")
        beats: Dict[str, str] = {}
        for i in range(1, len(parts) - 1, 2):
            b_key = parts[i].lower()
            b_val = parts[i + 1].strip().rstrip(".,; ")
            beats[b_key] = b_val

        beat1 = beats.get("0-3s") or beats.get("0-2s") or ""
        beat2 = beats.get("3-6s") or beats.get("2-5s") or ""

        # Kiểm tra xem beat2 có nhân vật CHAR_XX nào chưa được nhắc tới ở beat1 (0-3s) không
        chars_in_b1 = {
            _normalize_entity_uid(m.group(0))
            for m in re.finditer(r"\b(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\b", beat1, flags=re.I)
        }
        chars_in_b2 = {
            _normalize_entity_uid(m.group(0))
            for m in re.finditer(r"\b(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\b", beat2, flags=re.I)
        }
        new_chars_in_b2 = chars_in_b2 - chars_in_b1

        # Làm sạch các cụm chuyển cảnh máy quay trong beat1
        beat1_clean = re.sub(
            r"\b(?:camera\s+(?:pans|tracks|cuts|zooms|pushes|pulls)\s+(?:to|in|out|across|along)\s*)",
            "",
            beat1,
            flags=re.I,
        ).strip()

        if new_chars_in_b2 and beat2:
            beat2_clean = re.sub(
                r"^(?:camera\s+(?:pans|tracks|cuts|zooms|tilts|shifts)\s+(?:to|toward|across|on)\s+|meanwhile\s*,?\s*|then\s*,?\s*)",
                "",
                beat2,
                flags=re.I,
            ).strip()
            core_shot = f"{lead_text + ' ' if lead_text else ''}{beat1_clean}, while in the same unified camera frame {beat2_clean}."
        else:
            core_shot = f"{lead_text + ' ' if lead_text else ''}{beat1_clean}."
    else:
        # Loại bỏ các từ khóa chia khung hoặc cắt cảnh
        core_shot = re.sub(
            r"\b(?:camera\s+cuts\s+to|cut\s+to|split\s+screen|multiple\s+angles|four\s+panels|4\s+panels|comic\s+strip|storyboard\s+grid)\b",
            "",
            s,
            flags=re.I,
        ).strip()
        if not core_shot.endswith("."):
            core_shot += "."

    core_shot = re.sub(r"\s{2,}", " ", core_shot).strip()
    single_frame_lock = " Single unified full-frame composition (one continuous undivided camera shot only, seamless widescreen frame)."
    body = f"{style_tag}{core_shot}{lighting_clause}{single_frame_lock}".strip()
    if prompt_num_prefix:
        body = f"{prompt_num_prefix}{body}"
    if uid_prefix:
        body = f"{uid_prefix} | {body}"
    return body


def to_video_motion_prompt(prompt_text: str) -> str:
    """
    Chuyển câu lệnh từ tab Tạo Ảnh sang câu lệnh Chuyển Động Video 8s (loại bỏ các hậu tố khóa ảnh tĩnh
    như 'Single unified full-frame composition...' để mô hình Video Veo 3 / Muse diễn hoạt mượt mà).
    """
    s = (prompt_text or "").strip()
    if not s:
        return ""
    s = re.sub(
        r"\s*Single unified full-frame (?:cinematic still )?(?:composition|shot|image)\s*\([^\)]*\)\.?",
        "",
        s,
        flags=re.I,
    ).strip()
    return s


def _clean_entity_desc(raw_desc: str) -> str:
    d = (raw_desc or "").strip()
    # Bỏ tiền tố [Style ...] ở đầu nếu vô tình dính vào mô tả nhân vật
    d = re.sub(r"^\[\s*[^\]]{3,80}\]\s*", "", d).strip()
    # Bỏ tiền tố (CHAR_XX: ...) nếu bị bọc lặp
    m_inner = re.match(r"^\(\s*(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*:\s*([^\)]+)\)\s*$", d, flags=re.I)
    if m_inner:
        d = m_inner.group(1).strip()
    # Cắt bỏ phần 0-3s: ... nếu mô tả nhân vật bị dính cả câu lệnh cảnh quay phía sau
    d = re.split(r"\s*(?:\)\s*)?(?:0-3s\s*:|3-6s\s*:|Lighting\s*:|Audio\s*:|Negative\s*:)", d, maxsplit=1, flags=re.I)[0]
    d = d.strip(" ()|,-;.")
    return d


def _extract_free_text_characters(scene_lines: List[str]) -> Dict[str, str]:
    """
    Dự phòng thông minh khi kịch bản người dùng dán vào hoàn toàn không có mã CHAR_01 / CHAR_02:
    Tự động quét các cụm danh từ chỉ nhân vật lặp lại trong các câu lệnh để tạo CHAR_01, CHAR_02...
    """
    candidates: List[str] = []
    # Các mẫu cụm nhân vật tiếng Anh & tiếng Việt phổ biến trong prompt
    patterns = [
        r"\b((?:a|an|the)\s+(?:cute|young|little|petite|old|wise|giant|tall|brave|friendly|mystical|robotic|anthropomorphic|stylized)?\s*[a-zA-Z\-]+\s+(?:girl|boy|woman|man|heroine|hero|cat|dog|wolf|fox|rabbit|bear|robot|knight|warrior|wizard|princess|prince|grandmother|hunter|ranger|explorer|astronaut|fairy|dragon)(?:\s+(?:wearing|in|with)\s+[^.,;()\n]{5,65})?)",
        r"\b((?:chú|cô\s+bé|cậu\s+bé|ông\s+lão|bà\s+lão|chàng\s+trai|cô\s+gái|nhân\s+vật)\s+[^.,;()\n]{4,60})",
    ]
    seen_roots = set()
    for ln in scene_lines:
        for pat in patterns:
            for m in re.finditer(pat, ln, flags=re.I):
                phrase = m.group(1).strip()
                # Lấy từ khóa gốc (danh từ chính) để tránh trùng lặp cùng 1 nhân vật
                words = [w.lower() for w in re.findall(r"[a-zA-ZÀ-ỹ]+", phrase) if len(w) > 2]
                if not words:
                    continue
                noun_key = next(
                    (
                        w
                        for w in words
                        if w
                        in (
                            "girl",
                            "boy",
                            "woman",
                            "man",
                            "heroine",
                            "hero",
                            "cat",
                            "dog",
                            "wolf",
                            "fox",
                            "rabbit",
                            "bear",
                            "robot",
                            "knight",
                            "warrior",
                            "wizard",
                            "princess",
                            "prince",
                            "grandmother",
                            "hunter",
                            "ranger",
                            "explorer",
                            "astronaut",
                            "fairy",
                            "dragon",
                        )
                    ),
                    words[-1],
                )
                if noun_key not in seen_roots:
                    seen_roots.add(noun_key)
                    candidates.append(phrase)
                if len(candidates) >= 5:
                    break
    result: Dict[str, str] = {}
    for idx, cand in enumerate(candidates, start=1):
        result[f"CHAR_{idx:02d}"] = cand
    return result


def analyze_prompts_and_extract_entities(
    raw_lines_or_text: Any,
    character_bible_text: str = "",
    existing_ref_lines: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Đọc và phân tích toàn bộ kịch bản / danh sách câu lệnh (Prompts) trước khi tạo ảnh:
      1. Nhận diện chính xác có bao nhiêu Nhân vật (CHAR_01, CHAR_02, CHAR_03...) và Bối cảnh (LOC_01...)
         duy nhất xuất hiện trong toàn bộ các phân cảnh (khử trùng lặp 100%).
      2. Tách bạch rõ ràng:
         - `ref_lines`: Danh sách thực thể tham chiếu duy nhất cho Bước 1 (mỗi nhân vật chỉ tạo 1 ảnh Ref).
         - `scene_lines`: Danh sách câu lệnh phân cảnh cho Bước 2, mỗi cảnh được tự động gắn đúng mã
           nhân vật xuất hiện trong cảnh đó (ví dụ: `CHAR_01, CHAR_03 | Prompt 4: ...`).
    """
    if isinstance(raw_lines_or_text, str):
        raw_items = [ln.strip() for ln in raw_lines_or_text.splitlines() if ln.strip()]
    else:
        raw_items = [str(ln).strip() for ln in (raw_lines_or_text or []) if str(ln).strip()]

    # Nếu một dòng bị dính nhiều câu lệnh Prompt 1: ... Prompt 2: ... trên cùng 1 dòng thì tự tách rời
    input_lines: List[str] = []
    for item in raw_items:
        parts = re.split(
            r"(?<=\.)\s+(?=(?:\*\*)?(?:Prompt|Scene|Cảnh)\s*\d+\s*(?:\*\*)?\s*:)",
            item,
            flags=re.IGNORECASE,
        )
        for p in parts:
            ps = p.strip()
            if ps:
                input_lines.append(ps)

    unique_entities: Dict[str, str] = {}

    def _register_entity(raw_id: str, raw_desc: str):
        uid = _normalize_entity_uid(raw_id)
        cleaned = _clean_entity_desc(raw_desc)
        if not cleaned or len(cleaned) < 3:
            return
        old = unique_entities.get(uid, "")
        # Giữ bản mô tả chi tiết hơn nhưng không vượt quá 280 ký tự
        if not old or (len(cleaned) > len(old) and len(old) < 45):
            unique_entities[uid] = cleaned[:280]

    # 1. Trích xuất từ Hồ sơ nhân vật (Character Bible) nếu có
    if character_bible_text and character_bible_text.strip():
        blocks = re.split(
            r"(?=(?:-\s*|\*\*\s*)?(?:TÊN NHÂN VẬT|Character(?:\s*\d+)?)\s*(?:\*\*)?\s*:)",
            character_bible_text,
            flags=re.IGNORECASE,
        )
        idx_c = 1
        for blk in blocks:
            b = blk.strip()
            if not b or not re.search(r"(?:TÊN NHÂN VẬT|Character)", b, flags=re.I):
                continue
            code_m = re.search(r"(?:Mã nhận diện|ID|Code)\s*(?:\*\*)?\s*:\s*\**([A-Za-z0-9_]+)\**", b, flags=re.I)
            uid = _normalize_entity_uid(code_m.group(1) if code_m else f"CHAR_{idx_c:02d}")
            desc_parts = []
            for ln in b.splitlines()[1:]:
                cl = ln.strip().lstrip("+-*• ")
                if not cl or re.match(r"^(?:\*\*)?(?:Mã nhận diện|ID|Code)\s*(?:\*\*)?\s*:", cl, flags=re.I):
                    continue
                if cl.startswith("=") or "CÂU LỆNH TẠO ẢNH" in cl.upper():
                    break
                if re.match(r"^(?:-\s*|\*\*\s*)?(?:BỐI CẢNH|SETTING)", cl, flags=re.I):
                    break
                # Lấy phần tiếng Anh sau dấu ':' nếu có tiêu đề tiếng Việt
                if ":" in cl[:40]:
                    _, right_val = cl.split(":", 1)
                    if right_val.strip():
                        cl = right_val.strip()
                desc_parts.append(cl)
            if desc_parts:
                _register_entity(uid, ", ".join(desc_parts))
                idx_c += 1

        loc_m = re.search(
            r"(?:-\s*|\+\s*|\*\*\s*)?(?:BỐI CẢNH(?:\s*CHÍNH)?|SETTING)(?:\s*\([^\)]*\))?\s*(?:\*\*)?\s*:\s*([^\n\r]+)",
            character_bible_text,
            flags=re.IGNORECASE,
        )
        if loc_m and loc_m.group(1).strip():
            _register_entity("LOC_01", loc_m.group(1).strip())

    # 2. Phân loại từng dòng trong input_lines (và existing_ref_lines) thành Ref hay Scene
    pure_ref_lines: List[str] = []
    scenes_from_ref: List[str] = []
    scenes_from_input: List[str] = []

    for ln in existing_ref_lines or []:
        s = ln.strip()
        if not s:
            continue
        if is_scene_prompt_line(s):
            # Nếu dòng trong ô Ref thực chất là câu lệnh phân cảnh bị đẩy nhầm vào ô ①
            scenes_from_ref.append(s)
        else:
            pure_ref_lines.append(s)

    for ln in input_lines:
        s = ln.strip()
        if not s:
            continue
        if is_scene_prompt_line(s):
            scenes_from_input.append(s)
        elif re.match(r"^(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*[\|:]", s, flags=re.I):
            pure_ref_lines.append(s)
        else:
            scenes_from_input.append(s)

    # Giữ nguyên 100% số lượng và thứ tự các phân cảnh trong scenes_from_input!
    # Chỉ lấy từ scenes_from_ref nếu người dùng dán kịch bản vào ô ① mà ô ② đang trống
    raw_combined_scenes = scenes_from_input if scenes_from_input else scenes_from_ref

    scene_raw_lines: List[str] = []
    for sc in raw_combined_scenes:
        # Bỏ tiền tố CHAR_XX | ở đầu nếu có để lấy phần thân câu lệnh cảnh
        body = re.sub(
            r"^(?:(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)(?:\s*[,+&]\s*(?:CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+))*\s*\|\s*)+",
            "",
            sc,
            flags=re.I,
        ).strip()
        if body:
            scene_raw_lines.append(body)

    # 3. Đăng ký các dòng pure_ref_lines vào unique_entities
    for idx_r, rln in enumerate(pure_ref_lines, start=1):
        if "|" in rln[:35]:
            left, right = rln.split("|", 1)
            _register_entity(left, right)
        elif ":" in rln[:25]:
            left, right = rln.split(":", 1)
            _register_entity(left, right)
        else:
            _register_entity(f"CHAR_{idx_r:02d}", rln)

    # 4. Quét sâu bên trong toàn bộ các câu lệnh phân cảnh (scene_raw_lines)
    #    để tìm tất cả các định nghĩa (CHAR_01: ...), (CHAR_02: ...), (CHAR_03: ...), (LOC_01: ...)
    inline_paren_pat = re.compile(
        r"[\(\[]\s*(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*[:|\-–]\s*([^\)\]]{4,350})[\)\]]",
        flags=re.IGNORECASE,
    )
    inline_colon_pat = re.compile(
        r"\b(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*:\s*([^.()\n]{6,220}?)(?=\s+(?:0-3s:|3-6s:|Prompt\s*\d+|Scene\s*\d+|\(|\[|$))",
        flags=re.IGNORECASE,
    )

    for sc in scene_raw_lines:
        for m in inline_paren_pat.finditer(sc):
            _register_entity(m.group(1), m.group(2))
        for m in inline_colon_pat.finditer(sc):
            _register_entity(m.group(1), m.group(2))

    # 5. Nếu kịch bản tự do hoàn toàn chưa có thẻ CHAR_XX nào, tự động trích xuất nhân vật từ văn bản
    if not unique_entities and scene_raw_lines:
        inferred = _extract_free_text_characters(scene_raw_lines)
        for uid, desc in inferred.items():
            _register_entity(uid, desc)

    # Đảm bảo luôn có ít nhất CHAR_01 nếu vẫn trống
    if not unique_entities and scene_raw_lines:
        _register_entity("CHAR_01", "Main protagonist with consistent facial features and signature outfit")

    # 6. Sắp xếp danh sách thực thể tham chiếu: CHAR_01, CHAR_02... trước, LOC_01... sau
    def _sort_key(uid: str):
        is_loc = 1 if uid.startswith("LOC") else 0
        num_m = re.search(r"(\d+)", uid)
        return (is_loc, int(num_m.group(1)) if num_m else 99, uid)

    sorted_uids = sorted(unique_entities.keys(), key=_sort_key)
    ref_lines_out = [f"{uid} | {unique_entities[uid]}" for uid in sorted_uids]
    char_uids = [u for u in sorted_uids if u.startswith("CHAR")]
    loc_uids = [u for u in sorted_uids if u.startswith("LOC")]

    # 7. Gắn đúng mã nhân vật (CHAR_01, CHAR_02, CHAR_03...) cho từng phân cảnh ở Bước 2
    scene_lines_out: List[str] = []
    video_scene_lines_out: List[str] = []
    for idx_s, sc in enumerate(scene_raw_lines, start=1):
        # Tìm tất cả mã CHAR_XX / LOC_XX xuất hiện trực tiếp trong câu lệnh của cảnh này
        found_in_scene: List[str] = []
        for m in re.finditer(r"\b(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\b", sc, flags=re.I):
            norm_u = _normalize_entity_uid(m.group(1))
            if norm_u in unique_entities and norm_u not in found_in_scene:
                found_in_scene.append(norm_u)

        # Nếu cảnh không ghi trực tiếp mã CHAR_XX, đối chiếu từ khóa mô tả của từng nhân vật
        if not found_in_scene:
            sc_low = sc.lower()
            for u in char_uids:
                desc_words = [
                    w.lower()
                    for w in re.findall(r"[a-zA-Z]{4,}", unique_entities[u])
                    if w.lower() not in ("with", "wearing", "from", "that", "this", "have", "hair", "eyes", "style")
                ]
                if desc_words and any(w in sc_low for w in desc_words[:5]):
                    found_in_scene.append(u)

        if not found_in_scene and char_uids:
            found_in_scene.append(char_uids[0])

        # Đảm bảo câu lệnh cảnh có nhãn Prompt X: rõ ràng để không bao giờ bị nhầm với dòng Ref,
        # đồng thời rút gọn khối mô tả ngoại hình dài (CHAR_01: ...) đã tách lên Bước 1 thành (CHAR_01)
        # và tự động chuyển đổi sang chuẩn Single-Frame Keyframe cho Tạo Ảnh Đồng Nhất (giữ bản Video Motion riêng).
        clean_sc = re.sub(r"^(?:\*\*)?(?:Prompt|Scene|Cảnh)\s*\d+\s*(?:\*\*)?\s*:\s*", "", sc, flags=re.I).strip()
        clean_sc = inline_paren_pat.sub(lambda m: f"({_normalize_entity_uid(m.group(1))})", clean_sc).strip()
        prefix_uids = ", ".join(found_in_scene) if found_in_scene else "CHAR_01"
        img_keyframe_sc = to_single_frame_image_prompt(clean_sc)
        scene_lines_out.append(f"{prefix_uids} | Prompt {idx_s}: {img_keyframe_sc}")
        video_scene_lines_out.append(f"{prefix_uids} | Prompt {idx_s}: {clean_sc}")

    return {
        "unique_entities": [
            {
                "uid": u,
                "type": "LOC" if u.startswith("LOC") else "CHAR",
                "desc": unique_entities[u],
            }
            for u in sorted_uids
        ],
        "ref_lines": ref_lines_out,
        "scene_lines": scene_lines_out,
        "video_scene_lines": video_scene_lines_out,
        "num_chars": len(char_uids),
        "num_locs": len(loc_uids),
        "num_scenes": len(scene_lines_out),
    }

