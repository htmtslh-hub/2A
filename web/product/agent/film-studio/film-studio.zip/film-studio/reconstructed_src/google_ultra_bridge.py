"""
google_ultra_bridge.py — Cầu nối Tự động Đăng nhập Google Ultra + Thực thi RPC Flow (CDP + Port 3000)
────────────────────────────────────────────────────────────────────────────────────────────────────
Tương thích 100% với kiến trúc Google Flow mới (https://flow.google.com — boq_labs-ai-sandbox-frontend):
  1. Khởi chạy sẵn máy chủ nội bộ tại http://127.0.0.1:3000 (/captcha, /captcha/force-refresh,
     /captcha/open-project, /captcha/navigate, /status) — không bao giờ còn lỗi [WinError 10061].
  2. Tự động mở/kết nối Chrome Google Ultra (lưu phiên cố định tại google_ultra_profiles/ultra_account_1),
     tiêm hook WeakMap.prototype.set để lấy hàm gốc window.__realGrecaptchaExecute (vượt bẫy
     extension_hijack_detected của Google) và trích xuất tài khoản từ window.WIZ_global_data + RPC nzlxg.
  3. Thực thi trực tiếp các RPC batchexecute thế hệ mới của flow.google.com qua CDP:
     • nzlxg  : /VideoFxService.GetCredits (Lấy số dư Credits & gói Ultra/Pro)
     • maseQ  : /FlowService.UploadImage (Upload ảnh cho I2V / Đồng nhất nhân vật)
     • YhhmEf : /VideoFxService.BatchAsyncGenerateVideoText (Tạo video từ văn bản T2V)
     • eb1hJf : /VideoFxService.BatchAsyncGenerateVideoStartImage (Tạo video từ ảnh đầu I2V)
     • nprQif : /VideoFxService.BatchAsyncGenerateVideoStartAndEndImage (Tạo video từ ảnh đầu + cuối)
     • MZZa6b : /VideoFxService.BatchAsyncGenerateVideoReferenceImages (Tạo video đồng nhất R2V)
     • p0UkFb : /VideoFxService.BatchAsyncGenerateVideoUpsampleVideo (Upscale 1080p / 4K)
     • jwpduf : /VideoFxService.BatchCheckAsyncVideoGenerationStatus (Kiểm tra tiến trình render)
     • as29s  : /FlowService.GetMedia + Tải MP4 chất lượng gốc (=mm,22,15) qua phiên Cookie Chrome
"""

from __future__ import annotations

import json
import os
import random
import re
import socket
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import websocket  # websocket-client
except ImportError:
    websocket = None

try:
    from curl_cffi import requests as cffi_requests
except ImportError:
    cffi_requests = None

import requests


RECAPTCHA_SITE_KEY = "6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV"
LABS_FLOW_URL = "https://flow.google.com"
DEFAULT_PROJECT_ID = "2a17dbd7-150a-4587-a729-c14e7951f62e"
SESSION_COOKIE_NAME = "__Secure-next-auth.session-token"
VEO_ACC_FILES = (
    "veo_accounts.json",
    "tool4.json",
    "tool5.json",
    "tool6.json",
    "tool7.json",
    "accounts.json",
)

WEAKMAP_HOOK_JS = """
(() => {
    if (window.__ultraWeakMapHooked) return;
    window.__ultraWeakMapHooked = true;
    const origSet = WeakMap.prototype.set;
    WeakMap.prototype.set = function(k, v) {
        try {
            if (typeof v === 'function' && k && typeof k === 'object' &&
                typeof k.execute === 'function' && typeof k.ready === 'function') {
                window.__realGrecaptchaExecute = v;
            }
        } catch (e) {}
        return origSet.call(this, k, v);
    };
})();
"""


def find_browser_exe() -> str | None:
    """Tìm Google Chrome hoặc Microsoft Edge trên máy."""
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    ]
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None


def normalize_flow_model_key(model_key: str) -> str:
    """Chuẩn hóa model_key sang danh mục model đang bật trên flow.google.com."""
    mk = str(model_key or "").strip()
    if not mk:
        return "veo_3_1_t2v_fast_ultra"
    low_priority_map = {
        "veo_3_1_t2v_lite_low_priority": "veo_3_1_t2v_lite",
        "veo_3_1_i2v_lite_low_priority": "veo_3_1_i2v_lite",
        "veo_3_1_i2v_s_lite_low_priority": "veo_3_1_i2v_lite",
        "veo_3_1_i2v_s_lite_portrait_low_priority": "veo_3_1_i2v_lite",
        "veo_3_1_i2v_s_lite_fl_low_priority": "veo_3_1_interpolation_lite",
        "veo_3_1_i2v_s_lite_portrait_fl_low_priority": "veo_3_1_interpolation_lite",
        "veo_3_1_r2v_lite_low_priority": "veo_3_1_r2v_lite",
        "veo_3_1_r2v_high_landscape_ultra": "veo_3_1_r2v_fast_landscape_ultra",
        "veo_3_1_r2v_high_portrait_ultra": "veo_3_1_r2v_fast_portrait_ultra",
        "veo_3_1_r2v_high_landscape": "veo_3_1_r2v_fast_landscape",
        "veo_3_1_r2v_high_portrait": "veo_3_1_r2v_fast_portrait",
        "veo_3_1_interpolation_lite_low_priority": "veo_3_1_interpolation_lite",
        "veo_3_1_extension_lite_low_priority": "veo_3_1_extension_lite",
    }
    if mk in low_priority_map:
        return low_priority_map[mk]
    if mk.endswith("_low_priority"):
        return mk[: -len("_low_priority")]
    return mk


def ratio_to_flow_int(ratio_val) -> int:
    """Trong Protobuf của flow.google.com: 2 = Landscape (16:9), 1 = Portrait (9:16)."""
    s = str(ratio_val or "").upper()
    if "PORTRAIT" in s or "9:16" in s or s == "1":
        return 1
    return 2


class GoogleUltraBridge:
    """Quản lý trình duyệt Google Ultra (CDP) + Máy chủ Captcha Port 3000 + RPC batchexecute."""

    def __init__(self, app_dir: str, on_accounts_updated=None, on_status_changed=None):
        self.app_dir = os.path.abspath(app_dir)
        self.on_accounts_updated = on_accounts_updated
        self.on_status_changed = on_status_changed

        self.profiles_root = os.path.join(self.app_dir, "google_ultra_profiles")
        os.makedirs(self.profiles_root, exist_ok=True)

        self.cdp_ports: list[int] = [9222, 9223, 9224, 9225, 9226, 9227]
        self._lock = threading.Lock()
        self._cdp_call_lock = threading.RLock()
        self._hooked_tabs: set[str] = set()
        self._ws_pool: dict[str, object] = {}
        self._ws_send_locks: dict[str, threading.Lock] = {}
        self._ws_recv_locks: dict[str, threading.Lock] = {}
        self._ws_pending: dict[str, dict[int, dict]] = {}
        self._tab_semaphores: dict[str, threading.BoundedSemaphore] = {}
        self._rr_counter: int = 0
        self._msg_seq: int = 1000
        self.preferred_account_filter: str = "ALL"
        self.max_threads_per_account: int = 4

        self.connected_accounts: dict[str, dict] = {}
        self.fresh_headers: dict[str, str] = {}
        self.fresh_headers_ts: float = 0.0
        self.last_status_text: str = "Chưa mở trình duyệt Google Ultra"
        self.is_running: bool = True
        self._httpd: ThreadingHTTPServer | None = None

    # ─────────────────────────────────────────────────────────────────────────
    # 1. KHỞI ĐỘNG SERVER PORT 3000 & TỰ ĐỘNG KHÔI PHỤC PHIÊN GOOGLE ULTRA
    # ─────────────────────────────────────────────────────────────────────────
    def start(self):
        self._start_http_server_3000()
        t = threading.Thread(target=self._auto_sync_loop, daemon=True)
        t.start()

    def _is_port_in_use(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.4)
            return s.connect_ex(("127.0.0.1", port)) == 0

    def _start_http_server_3000(self):
        if self._is_port_in_use(3000):
            print("[ULTRA-BRIDGE] Port 3000 đã có tiến trình lắng nghe.", flush=True)
            return

        bridge = self

        class CaptchaHTTPHandler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass

            def _send_json(self, code: int, payload: dict):
                raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_OPTIONS(self):
                self.send_response(200)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "*")
                self.end_headers()

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                qs = urllib.parse.parse_qs(parsed.query)

                if parsed.path == "/captcha":
                    action = (qs.get("action") or ["VIDEO_GENERATION"])[0]
                    tok, err = bridge.solve_recaptcha(action=action, auto_open_browser=True)
                    if tok:
                        age_ms = int((time.time() - bridge.fresh_headers_ts) * 1000) if bridge.fresh_headers_ts else 0
                        self._send_json(
                            200,
                            {
                                "captcha": tok,
                                "headers": bridge.fresh_headers,
                                "headersAgeMs": age_ms,
                            },
                        )
                    else:
                        self._send_json(503, {"error": err or "Không lấy được reCAPTCHA từ Chrome Google Ultra"})
                    return

                if parsed.path == "/status":
                    self._send_json(
                        200,
                        {
                            "ok": True,
                            "status": bridge.last_status_text,
                            "connected_accounts": list(bridge.connected_accounts.values()),
                        },
                    )
                    return

                self._send_json(200, {"ok": True, "service": "GoogleUltraBridge-Port3000"})

            def do_POST(self):
                parsed = urllib.parse.urlparse(self.path)
                qs = urllib.parse.parse_qs(parsed.query)

                if parsed.path == "/captcha/force-refresh":
                    bridge.reload_labs_tabs()
                    self._send_json(200, {"ok": True, "action": "force-refresh"})
                    return

                if parsed.path == "/captcha/open-project":
                    pid = DEFAULT_PROJECT_ID
                    url = f"https://flow.google.com/project/{pid}"
                    bridge.navigate_labs_tabs(url)
                    self._send_json(200, {"url": url, "projectId": pid})
                    return

                if parsed.path == "/captcha/navigate":
                    url = (qs.get("url") or [LABS_FLOW_URL])[0]
                    bridge.navigate_labs_tabs(url)
                    self._send_json(200, {"url": url})
                    return

                if parsed.path == "/flowkit/rpc":
                    length = int(self.headers.get("Content-Length") or "0")
                    raw_body = self.rfile.read(length).decode("utf-8", errors="ignore") if length > 0 else "{}"
                    try:
                        req_data = json.loads(raw_body)
                        import flowkit_engine
                        env = flowkit_engine.build_flow_rpc_envelope(
                            mode=req_data.get("mode", "t2v"),
                            project_id=req_data.get("project_id") or DEFAULT_PROJECT_ID,
                            prompt=req_data.get("prompt", ""),
                            aspect_ratio=req_data.get("aspect_ratio", "16:9"),
                            model_name=req_data.get("model_name", "abra_t2v_8s"),
                            start_media_id=req_data.get("start_media_id"),
                            end_media_id=req_data.get("end_media_id"),
                            ref_media_ids=req_data.get("ref_media_ids"),
                        )
                        self._send_json(200, {"ok": True, "envelope": env})
                    except Exception as ex:
                        self._send_json(400, {"ok": False, "error": str(ex)})
                    return

                self._send_json(200, {"ok": True})

        try:
            self._httpd = ThreadingHTTPServer(("127.0.0.1", 3000), CaptchaHTTPHandler)
            th = threading.Thread(target=self._httpd.serve_forever, daemon=True)
            th.start()
            print("[ULTRA-BRIDGE] ✅ Đã khởi chạy Captcha & Account Server tại http://127.0.0.1:3000", flush=True)
        except Exception as e:
            print(f"[ULTRA-BRIDGE] ⚠️ Không thể bind port 3000: {e}", flush=True)

    # ─────────────────────────────────────────────────────────────────────────
    # 2. MỞ TRÌNH DUYỆT CHROME ĐỂ ĐĂNG NHẬP GOOGLE ULTRA (1-CLICK)
    # ─────────────────────────────────────────────────────────────────────────
    def _ensure_hook_extension_dir(self) -> str:
        ext_dir = os.path.join(self.profiles_root, "ultra_hook_ext")
        os.makedirs(ext_dir, exist_ok=True)
        manifest_path = os.path.join(ext_dir, "manifest.json")
        hook_path = os.path.join(ext_dir, "hook.js")
        manifest_data = {
            "manifest_version": 3,
            "name": "Google Ultra Flow Hook",
            "version": "1.0",
            "content_scripts": [
                {
                    "matches": ["https://flow.google.com/*", "https://labs.google/*"],
                    "js": ["hook.js"],
                    "run_at": "document_start",
                    "world": "MAIN",
                }
            ],
        }
        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                json.dump(manifest_data, f, indent=2)
            with open(hook_path, "w", encoding="utf-8") as f:
                f.write(WEAKMAP_HOOK_JS.strip() + "\n")
        except Exception:
            pass
        return ext_dir

    def open_google_ultra_browser(
        self,
        slot: int = 1,
        target_url: str = f"https://flow.google.com/project/{DEFAULT_PROJECT_ID}",
        minimized: bool = False,
    ) -> tuple[bool, str]:
        """Mở cửa sổ Chrome với profile cố định & cổng CDP để tự động bắt Tài khoản + Captcha."""
        slot = max(1, min(slot, len(self.cdp_ports)))
        port = self.cdp_ports[slot - 1]
        profile_dir = os.path.join(self.profiles_root, f"ultra_account_{slot}")
        os.makedirs(profile_dir, exist_ok=True)
        ext_dir = self._ensure_hook_extension_dir()

        tabs = self._get_cdp_tabs(port)
        if tabs is not None:
            labs_tab = self._find_labs_tab(tabs)
            if labs_tab:
                if not minimized:
                    self._cdp_send(labs_tab["webSocketDebuggerUrl"], "Page.bringToFront", {})
                self._ensure_tab_hooked(labs_tab)
                return True, f"Cửa sổ Google Ultra #{slot} đang chạy sẵn (Port {port})."
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/json/new?{target_url}", timeout=3)
                return True, f"Đã mở tab Flow mới trên cửa sổ Google Ultra #{slot}."
            except Exception:
                pass

        browser_exe = find_browser_exe()
        if not browser_exe:
            return False, "Không tìm thấy Google Chrome hoặc Microsoft Edge trên máy!"

        args = [
            browser_exe,
            f"--user-data-dir={profile_dir}",
            f"--remote-debugging-port={port}",
            "--remote-allow-origins=*",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-blink-features=AutomationControlled",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            f"--load-extension={ext_dir}",
        ]
        if minimized:
            args.append("--start-minimized")
        args.append(target_url)

        try:
            subprocess.Popen(args, close_fds=True)
            self._set_status(f"⏳ Đang kết nối Chrome Google Ultra #{slot}...")
            return True, f"Đã mở trình duyệt Google Ultra #{slot}."
        except Exception as e:
            return False, f"Lỗi mở trình duyệt: {e}"

    # ─────────────────────────────────────────────────────────────────────────
    # 3. GIAO TIẾP CDP (CHROME DEVTOOLS PROTOCOL) TRỰC TIẾP QUA WEBSOCKET
    # ─────────────────────────────────────────────────────────────────────────
    def _get_cdp_tabs(self, port: int) -> list[dict] | None:
        if not self._is_port_in_use(port):
            return None
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=1.5) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            if isinstance(data, list):
                return [
                    t
                    for t in data
                    if isinstance(t, dict) and t.get("type") == "page" and t.get("webSocketDebuggerUrl")
                ]
        except Exception:
            pass
        return None

    def _find_labs_tab(self, tabs: list[dict] | None) -> dict | None:
        if not tabs:
            return None
        for t in tabs:
            u = str(t.get("url") or "")
            if "flow.google.com" in u or "labs.google" in u:
                return t
        for t in tabs:
            u = str(t.get("url") or "")
            if "accounts.google.com" in u:
                return t
        return tabs[0] if tabs else None

    def _close_ws(self, ws_url: str):
        ws = self._ws_pool.pop(ws_url, None)
        if ws is not None:
            try:
                ws.close()
            except Exception:
                pass
        pend = self._ws_pending.get(ws_url)
        if pend:
            for item in list(pend.values()):
                try:
                    item["ev"].set()
                except Exception:
                    pass

    def _cdp_send(self, ws_url: str, method: str, params: dict = None, timeout: float = 15.0) -> dict | None:
        """Gửi lệnh CDP hỗ trợ Đa Luồng Đồng Thời (Multiplexed WebSocket theo msg_id).
        Cho phép 3-4 luồng gửi Runtime.evaluate (fetch batchexecute) song song trên cùng 1 tài khoản
        hoặc phân tải trên nhiều tài khoản mà không khóa cứng toàn cục.
        """
        if websocket is None or not ws_url:
            return None
        with self._lock:
            self._msg_seq = (self._msg_seq + 1) % 9000000 + 1000
            msg_id = self._msg_seq
            send_lock = self._ws_send_locks.setdefault(ws_url, threading.Lock())
            recv_lock = self._ws_recv_locks.setdefault(ws_url, threading.Lock())
            pending = self._ws_pending.setdefault(ws_url, {})
            slot = {"ev": threading.Event(), "res": None, "ok": False}
            pending[msg_id] = slot

        payload = json.dumps({"id": msg_id, "method": method, "params": params or {}})
        try:
            for attempt in range(2):
                try:
                    with send_lock:
                        ws = self._ws_pool.get(ws_url)
                        if ws is None or not getattr(ws, "connected", False):
                            ws = websocket.create_connection(ws_url, timeout=max(5.0, timeout), suppress_origin=True)
                            self._ws_pool[ws_url] = ws
                        ws.send(payload)

                    deadline = time.time() + timeout
                    while time.time() < deadline:
                        if slot["ev"].is_set():
                            return slot["res"]
                        if recv_lock.acquire(blocking=False):
                            try:
                                while not slot["ev"].is_set() and time.time() < deadline:
                                    ws_cur = self._ws_pool.get(ws_url)
                                    if ws_cur is None:
                                        break
                                    ws_cur.settimeout(min(0.6, max(0.15, deadline - time.time())))
                                    try:
                                        raw = ws_cur.recv()
                                    except websocket.WebSocketTimeoutException:
                                        continue
                                    if not raw:
                                        raise ConnectionError("Empty WebSocket frame")
                                    resp = json.loads(raw)
                                    rid = resp.get("id")
                                    if rid is not None and rid in pending:
                                        target_slot = pending[rid]
                                        target_slot["res"] = resp.get("result")
                                        target_slot["ok"] = True
                                        target_slot["ev"].set()
                            finally:
                                recv_lock.release()
                        else:
                            slot["ev"].wait(timeout=0.12)
                        if slot["ev"].is_set():
                            return slot["res"]
                    return None
                except Exception:
                    with send_lock:
                        self._close_ws(ws_url)
                    if attempt == 1:
                        return None
                    slot["ev"].clear()
            return None
        finally:
            pending.pop(msg_id, None)

    def _cdp_eval(self, ws_url: str, js_expr: str, await_promise: bool = True, timeout: float = 25.0):
        res = self._cdp_send(
            ws_url,
            "Runtime.evaluate",
            {
                "expression": js_expr,
                "awaitPromise": await_promise,
                "returnByValue": True,
            },
            timeout=timeout,
        )
        if not isinstance(res, dict):
            return None
        if "exceptionDetails" in res:
            return None
        val_obj = res.get("result") or {}
        return val_obj.get("value")

    def _ensure_tab_hooked(self, tab: dict) -> bool:
        """Đảm bảo tab flow.google.com đã được tiêm WeakMap hook để bắt __realGrecaptchaExecute."""
        ws_url = tab.get("webSocketDebuggerUrl") or ""
        tab_id = tab.get("id") or ws_url
        if not ws_url:
            return False

        with self._cdp_call_lock:
            if tab_id not in self._hooked_tabs:
                self._cdp_send(ws_url, "Page.enable", {}, timeout=3.0)
                self._cdp_send(ws_url, "Page.setBypassCSP", {"enabled": True}, timeout=3.0)
                self._cdp_send(
                    ws_url,
                    "Page.addScriptToEvaluateOnNewDocument",
                    {"source": WEAKMAP_HOOK_JS},
                    timeout=3.0,
                )
                self._hooked_tabs.add(tab_id)

            has_hook = self._cdp_eval(
                ws_url,
                "Boolean(typeof window.__realGrecaptchaExecute === 'function')",
                await_promise=False,
                timeout=3.0,
            )
            if not has_hook:
                url = str(tab.get("url") or "")
                if "flow.google.com" in url and "/about" not in url:
                    self._cdp_send(ws_url, "Page.enable", {}, timeout=3.0)
                    self._cdp_send(ws_url, "Page.setBypassCSP", {"enabled": True}, timeout=3.0)
                    self._cdp_send(
                        ws_url,
                        "Page.addScriptToEvaluateOnNewDocument",
                        {"source": WEAKMAP_HOOK_JS},
                        timeout=3.0,
                    )
                    self._cdp_send(ws_url, "Page.reload", {"ignoreCache": False}, timeout=4.0)
                    for _ in range(30):
                        time.sleep(0.25)
                        if self._cdp_eval(
                            ws_url,
                            "Boolean(typeof window.__realGrecaptchaExecute === 'function')",
                            await_promise=False,
                            timeout=2.0,
                        ):
                            return True
            return bool(has_hook)

    # ─────────────────────────────────────────────────────────────────────────
    # 4. TỰ ĐỘNG PHÁT HIỆN TÀI KHOẢN GOOGLE ULTRA TRÊN FLOW.GOOGLE.COM
    # ─────────────────────────────────────────────────────────────────────────
    def scan_and_sync_from_browsers(self) -> list[dict]:
        """Quét các cửa sổ Chrome Google Ultra và đồng bộ tài khoản + số dư Credits."""
        discovered = []
        any_browser_open = False
        logging_in_google = False

        for idx, port in enumerate(self.cdp_ports, start=1):
            tabs = self._get_cdp_tabs(port)
            if not tabs:
                continue
            any_browser_open = True
            tab = self._find_labs_tab(tabs)
            if not tab:
                continue
            url = str(tab.get("url") or "")
            ws_url = tab["webSocketDebuggerUrl"]

            if "accounts.google.com" in url:
                logging_in_google = True
                continue

            if "flow.google.com" not in url and "labs.google" not in url:
                continue

            self._ensure_tab_hooked(tab)

            js_inspect = r"""
            (async () => {
                try {
                    const wiz = window.WIZ_global_data || {};
                    const email = wiz.oPEP7c || '';
                    const at = wiz.SNlM0e || '';
                    const sid = wiz.FdrFJe || '';
                    const bl = wiz.cfb2h || '';
                    const siteKey = wiz.xZbWve || '6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV';
                    const path = location.pathname || '';
                    let projectId = '';
                    if (path.includes('/project/')) {
                        projectId = (path.split('/project/')[1] || '').split('/')[0].trim();
                    }
                    if (!email || !at) {
                        return { ok: false, reason: 'not_logged_in', url: location.href };
                    }
                    let credits = 'Ultra';
                    let tier = 'Ultra';
                    try {
                        const freq = JSON.stringify([[["nzlxg", "[]", null, "generic"]]]);
                        const body = new URLSearchParams({ "f.req": freq, "at": at }).toString();
                        const rpcUrl = `/_/AiSandboxAngularFrontend/data/batchexecute?rpcids=nzlxg&source-path=${encodeURIComponent(path)}&f.sid=${sid}&bl=${bl}&hl=vi&_reqid=${Math.floor(Math.random()*800000+100000)}&rt=c`;
                        const r = await fetch(rpcUrl, {
                            method: 'POST',
                            headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' },
                            body,
                            credentials: 'include'
                        });
                        const txt = await r.text();
                        for (const line of txt.split('\n')) {
                            if (line.includes('wrb.fr')) {
                                const arr = JSON.parse(line);
                                const inner = JSON.parse(arr[0][2]);
                                if (Array.isArray(inner) && typeof inner[0] === 'number') {
                                    credits = String(inner[0]);
                                    tier = (inner[1] === 2 || inner[2] === 3) ? 'Ultra' : 'Pro';
                                }
                                break;
                            }
                        }
                    } catch (e) {}
                    return {
                        ok: true,
                        email,
                        at,
                        sid,
                        bl,
                        siteKey,
                        projectId,
                        credits,
                        tier,
                        hasRecaptchaHook: typeof window.__realGrecaptchaExecute === 'function',
                        ua: navigator.userAgent || ''
                    };
                } catch (e) {
                    return { ok: false, err: String(e) };
                }
            })()
            """
            info = self._cdp_eval(ws_url, js_inspect, await_promise=True, timeout=10.0)
            if not isinstance(info, dict) or not info.get("ok"):
                continue

            email = str(info.get("email") or "").strip()
            if not email:
                continue

            project_id = str(info.get("projectId") or "").strip() or DEFAULT_PROJECT_ID
            credits = str(info.get("credits") or "Ultra")
            tier = str(info.get("tier") or "Ultra")
            token = f"cdp_flow::{port}::{email}"

            ua = str(info.get("ua") or "").strip()
            if ua:
                self.fresh_headers = {
                    "user-agent": ua,
                    "origin": "https://flow.google.com",
                    "referer": "https://flow.google.com/",
                }
                self.fresh_headers_ts = time.time()

            acc_entry = {
                "email": email,
                "token": token,
                "project_id": project_id,
                "credits": credits,
                "tier": tier,
                "slot": idx,
                "port": port,
                "ws_url": ws_url,
            }
            discovered.append(acc_entry)

        if discovered:
            changed = self._persist_discovered_accounts(discovered)
            summary = ", ".join(f"{a['email']} ({a['credits']} credits)" for a in discovered)
            self._set_status(f"🟢 Đã kết nối Google Ultra: {summary}")
            if changed and self.on_accounts_updated:
                try:
                    self.on_accounts_updated()
                except Exception:
                    pass
        elif logging_in_google:
            self._set_status("⏳ Đang chờ bạn hoàn tất đăng nhập Google trên cửa sổ Chrome...")
        elif any_browser_open:
            self._set_status("🟡 Cửa sổ Chrome đang mở — Hãy đăng nhập Google Ultra trên trang flow.google.com.")
        return discovered

    def _persist_discovered_accounts(self, discovered: list[dict]) -> bool:
        """Ghi đè/cập nhật tài khoản vừa bắt được từ trình duyệt vào tất cả các file JSON của tool."""
        with self._lock:
            existing = self._read_current_accounts()
            # Loại bỏ mọi token "captured_*" hoặc ya29 cũ đã hết hạn khi đã có phiên Google Ultra CDP
            filtered = []
            for a in existing:
                em = str(a.get("email") or "")
                tk = str(a.get("token") or "")
                if em.startswith("captured_") or tk.startswith("ya29."):
                    continue
                filtered.append(a)
            changed = len(filtered) != len(existing)
            existing = filtered

            for d in discovered:
                email = d["email"]
                tok = d["token"]
                pid = d.get("project_id") or DEFAULT_PROJECT_ID
                credits = d.get("credits") or "Ultra"
                self.connected_accounts[email] = d

                matched = None
                for a in existing:
                    if str(a.get("email") or "").lower() == email.lower() or a.get("token") == tok:
                        matched = a
                        break

                if matched is not None:
                    if (
                        matched.get("token") != tok
                        or matched.get("email") != email
                        or matched.get("project_id") != pid
                        or str(matched.get("credits")) != str(credits)
                    ):
                        matched["email"] = email
                        matched["token"] = tok
                        matched["project_id"] = pid
                        matched["credits"] = credits
                        changed = True
                else:
                    new_item = {
                        "email": email,
                        "token": tok,
                        "project_id": pid,
                        "credits": credits,
                    }
                    existing.insert(0, new_item)
                    changed = True

            if changed:
                payload = {"accounts": existing}
                for fname in VEO_ACC_FILES:
                    fpath = os.path.join(self.app_dir, fname)
                    try:
                        with open(fpath, "w", encoding="utf-8") as f:
                            json.dump(payload, f, indent=2, ensure_ascii=False)
                    except Exception:
                        pass
                print(
                    f"[ULTRA-BRIDGE] ✅ Đã đồng bộ {len(discovered)} tài khoản Google Ultra ({discovered[0]['email']} - {discovered[0]['credits']} credits)!",
                    flush=True,
                )
            return changed

    def _read_current_accounts(self) -> list[dict]:
        for fname in ("veo_accounts.json", "tool5.json", "accounts.json"):
            fpath = os.path.join(self.app_dir, fname)
            if os.path.isfile(fpath):
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    accs = data.get("accounts", []) if isinstance(data, dict) else []
                    if isinstance(accs, list):
                        return accs
                except Exception:
                    pass
        return []

    def _auto_sync_loop(self):
        # Tự động bật trình duyệt với profile đã lưu nếu chưa có cổng CDP nào mở
        prof1 = os.path.join(self.profiles_root, "ultra_account_1")
        if os.path.isdir(prof1) and not any(self._is_port_in_use(p) for p in self.cdp_ports):
            try:
                self.open_google_ultra_browser(slot=1, minimized=True)
                time.sleep(3.5)
            except Exception:
                pass

        while self.is_running:
            try:
                self.scan_and_sync_from_browsers()
            except Exception:
                pass
            time.sleep(3.5)

    def _set_status(self, text: str):
        if text != self.last_status_text:
            self.last_status_text = text
            if self.on_status_changed:
                try:
                    self.on_status_changed(text)
                except Exception:
                    pass

    # ─────────────────────────────────────────────────────────────────────────
    # 5. GIẢI RECAPTCHA ENTERPRISE & GỌI RPC BATCHEXECUTE QUA CDP
    # ─────────────────────────────────────────────────────────────────────────
    def _collect_all_ready_flow_tabs(self) -> list[dict]:
        """Thu thập danh sách toàn bộ tab flow.google.com đang mở trên các cổng CDP (đa tài khoản)."""
        ready_tabs = []
        for idx, port in enumerate(self.cdp_ports, start=1):
            tabs = self._get_cdp_tabs(port)
            if not tabs:
                continue
            for t in tabs:
                u = str(t.get("url") or "")
                if "flow.google.com" in u or "labs.google" in u:
                    t_copy = dict(t)
                    t_copy["_slot"] = idx
                    t_copy["_port"] = port
                    # Ghép thêm email/project_id nếu đã quét được
                    for acc in self.connected_accounts.values():
                        if acc.get("port") == port or acc.get("ws_url") == t.get("webSocketDebuggerUrl"):
                            t_copy["_email"] = acc.get("email", "")
                            t_copy["_project_id"] = acc.get("project_id", "")
                            break
                    ready_tabs.append(t_copy)
                    break
        return ready_tabs

    def get_account_choices_for_ui(self) -> list[str]:
        """Trả về danh sách chế độ chọn tài khoản cho ComboBox giao diện."""
        choices = ["⚡ Xoay vòng tất cả TK (Đa luồng)"]
        seen = set()
        for acc in self.connected_accounts.values():
            em = str(acc.get("email") or "").strip()
            slot = acc.get("slot") or 1
            if em and em not in seen:
                seen.add(em)
                choices.append(f"TK #{slot}: {em}")
        if len(choices) == 1:
            choices.append("TK #1 (Mặc định)")
        return choices

    def _ensure_ready_flow_tab(self, auto_open_browser: bool = True, preferred_account: str | None = None) -> dict | None:
        """Chọn tab Google Flow theo chế độ Xoay Vòng Đa Tài Khoản (Round-Robin) hoặc theo tài khoản chỉ định."""
        ready_tabs = self._collect_all_ready_flow_tabs()
        if not ready_tabs and auto_open_browser:
            self.open_google_ultra_browser(slot=1, minimized=True)
            deadline = time.time() + 20.0
            while time.time() < deadline:
                time.sleep(1.2)
                ready_tabs = self._collect_all_ready_flow_tabs()
                if ready_tabs:
                    break

        if not ready_tabs:
            return None

        pref = str(preferred_account or self.preferred_account_filter or "").strip()
        if pref and pref != "ALL" and "Xoay vòng" not in pref:
            for t in ready_tabs:
                em = str(t.get("_email") or "")
                slot_str = f"TK #{t.get('_slot')}"
                if (em and em.lower() in pref.lower()) or slot_str.lower() in pref.lower():
                    self._ensure_tab_hooked(t)
                    return t

        with self._lock:
            picked = ready_tabs[self._rr_counter % len(ready_tabs)]
            self._rr_counter += 1
        self._ensure_tab_hooked(picked)
        return picked

    def solve_recaptcha(self, action: str = "VIDEO_GENERATION", auto_open_browser: bool = True) -> tuple[str | None, str]:
        """Lấy reCAPTCHA Enterprise token thật qua window.__realGrecaptchaExecute (hỗ trợ đa luồng)."""
        tab = self._ensure_ready_flow_tab(auto_open_browser=auto_open_browser)
        if not tab:
            return (
                None,
                "Chưa mở hoặc chưa đăng nhập Google Ultra trên Chrome. Hãy bấm '🌐 ĐĂNG NHẬP ULTRA'!",
            )
        ws_url = tab["webSocketDebuggerUrl"]
        js_solve = f"""
        (async () => {{
            const siteKey = (window.WIZ_global_data && window.WIZ_global_data.xZbWve) || {json.dumps(RECAPTCHA_SITE_KEY)};
            const action = {json.dumps(action or "VIDEO_GENERATION")};
            for (let i = 0; i < 40; i++) {{
                if (typeof window.__realGrecaptchaExecute === 'function') break;
                await new Promise(r => setTimeout(r, 200));
            }}
            if (typeof window.__realGrecaptchaExecute === 'function') {{
                try {{
                    const tok = await window.__realGrecaptchaExecute(siteKey, {{ action }});
                    return {{ ok: true, token: tok || '' }};
                }} catch (e) {{
                    return {{ ok: false, error: String(e) }};
                }}
            }}
            if (window.grecaptcha && window.grecaptcha.enterprise && typeof window.grecaptcha.enterprise.execute === 'function') {{
                try {{
                    const tok = await window.grecaptcha.enterprise.execute(siteKey, {{ action }});
                    return {{ ok: true, token: tok || '' }};
                }} catch (e) {{
                    return {{ ok: false, error: String(e) }};
                }}
            }}
            return {{ ok: false, error: 'Chưa sẵn sàng hàm grecaptcha trên trang flow.google.com' }};
        }})()
        """
        res = self._cdp_eval(ws_url, js_solve, await_promise=True, timeout=25.0)
        if isinstance(res, dict) and res.get("ok") and res.get("token"):
            tok = str(res["token"])
            print(f"[ULTRA-BRIDGE] ✅ Đã giải Captcha ({action}) qua CDP — len={len(tok)}", flush=True)
            return tok, ""
        err = res.get("error") if isinstance(res, dict) else "Timeout khi giải reCAPTCHA"
        return None, str(err)

    def _call_batchexecute(
        self,
        rpcid: str,
        payload_obj,
        recaptcha_action: str | None = None,
        preferred_account: str | None = None,
    ) -> tuple[bool, any, str]:
        """Gọi RPC batchexecute trực tiếp từ bên trong tab flow.google.com (Hỗ trợ 3-4 luồng/tài khoản & Xoay vòng đa tài khoản)."""
        tab = self._ensure_ready_flow_tab(auto_open_browser=True, preferred_account=preferred_account)
        if not tab:
            return False, None, "Chưa mở trình duyệt Google Ultra. Hãy bấm '🌐 ĐĂNG NHẬP ULTRA'!"
        ws_url = tab["webSocketDebuggerUrl"]
        with self._lock:
            sem = self._tab_semaphores.setdefault(ws_url, threading.BoundedSemaphore(4))

        with sem:
            js_rpc = f"""
            (async () => {{
                for (let i = 0; i < 40; i++) {{
                    if (window.WIZ_global_data && window.WIZ_global_data.SNlM0e) break;
                    await new Promise(r => setTimeout(r, 200));
                }}
                const wiz = window.WIZ_global_data || {{}};
                const at = wiz.SNlM0e || '';
                const sid = wiz.FdrFJe || '';
                const bl = wiz.cfb2h || '';
                const siteKey = wiz.xZbWve || {json.dumps(RECAPTCHA_SITE_KEY)};
                if (!at) {{
                    return {{ ok: false, error: 'Tài khoản Google Ultra chưa đăng nhập trên flow.google.com!' }};
                }}

                let recaptchaToken = '';
                const action = {json.dumps(recaptcha_action)};
                if (action) {{
                    for (let i = 0; i < 40; i++) {{
                        if (typeof window.__realGrecaptchaExecute === 'function') break;
                        await new Promise(r => setTimeout(r, 200));
                    }}
                    if (typeof window.__realGrecaptchaExecute !== 'function') {{
                        return {{ ok: false, error: 'Đang nạp reCAPTCHA hook trên Chrome, vui lòng thử lại sau 2 giây.' }};
                    }}
                    recaptchaToken = await window.__realGrecaptchaExecute(siteKey, {{ action }});
                }}

                let payloadObj = {json.dumps(payload_obj)};
                const payloadStr = JSON.stringify(payloadObj).replace(/__RECAPTCHA_TOKEN__/g, recaptchaToken);
                const rpcid = {json.dumps(rpcid)};
                const freq = JSON.stringify([[[rpcid, payloadStr, null, "generic"]]]);
                const body = new URLSearchParams({{ "f.req": freq, "at": at }}).toString();
                const reqid = Math.floor(Math.random() * 800000 + 100000);
                const url = `/_/AiSandboxAngularFrontend/data/batchexecute?rpcids=${{rpcid}}&source-path=${{encodeURIComponent(location.pathname)}}&f.sid=${{sid}}&bl=${{bl}}&hl=vi&_reqid=${{reqid}}&rt=c`;
                const r = await fetch(url, {{
                    method: 'POST',
                    headers: {{ 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' }},
                    body,
                    credentials: 'include'
                }});
                const text = await r.text();
                return {{ ok: true, status: r.status, text }};
            }})()
            """
            res = self._cdp_eval(ws_url, js_rpc, await_promise=True, timeout=60.0)
            if not isinstance(res, dict) or not res.get("ok"):
                err = (res or {}).get("error") if isinstance(res, dict) else "Timeout khi gọi RPC batchexecute"
                return False, None, str(err)

            raw_text = str(res.get("text") or "")
            for line in raw_text.splitlines():
                if '"wrb.fr"' in line:
                    try:
                        arr = json.loads(line)
                        item = arr[0]
                        if item[2] is not None:
                            return True, json.loads(item[2]), ""
                        if len(item) > 5 and item[5] is not None:
                            err_raw = json.dumps(item[5], ensure_ascii=False)
                            hint = ""
                            if err_raw.startswith("[5"):
                                hint = " (NOT_FOUND: Bộ lọc hậu kiểm Google ẩn ảnh đầu ra hoặc Project ID cần làm mới)"
                            elif err_raw.startswith("[8"):
                                hint = " (RESOURCE_EXHAUSTED: Quá tải luồng tạm thời trên Google Flow)"
                            elif "UNSAFE" in err_raw.upper() or "MINOR" in err_raw.upper():
                                hint = " (SAFETY_FILTER: Vướng từ khóa nhạy cảm của Google)"
                            return False, None, f"RPC {rpcid} Error: {err_raw}{hint}"
                    except Exception as e:
                        return False, None, f"Lỗi giải mã RPC {rpcid}: {e}"
            return False, None, f"Phản hồi RPC {rpcid} không hợp lệ: {raw_text[:250]}"

    def _auto_create_flow_project(self, title: str = "Film Studio Project") -> str | None:
        """Tự động khởi tạo Project mới trên tài khoản Google Flow hiện tại qua RPC jHPbke."""
        try:
            import flow_batch

            inner_obj = ["projects/*", [None, [title]], [None, flow_batch.SURFACE_ID]]
            ok, data, _ = self._call_batchexecute(flow_batch.RPC_CREATE_PROJECT, inner_obj, recaptcha_action=None)
            if ok and isinstance(data, list) and data and isinstance(data[0], str):
                new_pid = str(data[0]).strip()
                if new_pid.startswith("projects/"):
                    new_pid = new_pid.split("/", 1)[1]
                if new_pid:
                    for acc in self.connected_accounts.values():
                        acc["project_id"] = new_pid
                    print(f"[ULTRA-BRIDGE] ✅ Đã tự động tạo Project ID mới trên Flow: {new_pid}", flush=True)
                    return new_pid
        except Exception as e:
            print(f"[ULTRA-BRIDGE] ⚠️ Không thể tự tạo Project mới qua jHPbke: {e}", flush=True)
        return None

    def _get_active_project_id(self, preferred_pid: str | None = None) -> str:
        for acc in self.connected_accounts.values():
            pid = str(acc.get("project_id") or "").strip()
            if pid and pid != DEFAULT_PROJECT_ID:
                return pid
        if preferred_pid and str(preferred_pid).strip() and str(preferred_pid).strip() != DEFAULT_PROJECT_ID:
            return str(preferred_pid).strip()
        created = self._auto_create_flow_project("Film Studio")
        if created:
            return created
        return DEFAULT_PROJECT_ID

    # ─────────────────────────────────────────────────────────────────────────
    # 6. CÁC HÀM NGHIỆP VỤ VIDEO FX (UPLOAD ẢNH, TẠO VIDEO, UPSCALE, POLL & TẢI MP4)
    # ─────────────────────────────────────────────────────────────────────────
    def cdp_upload_image(
        self,
        image_b64: str,
        mime_type: str = "image/jpeg",
        file_name: str = "image.jpg",
        project_id: str | None = None,
    ) -> str | None:
        """Upload ảnh qua RPC maseQ (/FlowService.UploadImage) và trả về mediaId."""
        pid = self._get_active_project_id(project_id)
        wf_id = str(uuid.uuid4())
        media_id = str(uuid.uuid4())
        client_ctx = [None, 22, None, None, None, pid, None, None, None, None, ["__RECAPTCHA_TOKEN__", 1]]
        h8a = [
            client_ctx,
            image_b64,
            mime_type,
            True,
            None,
            None,
            None,
            False,
            file_name,
            None,
            wf_id,
            media_id,
            None,
            [1],
        ]
        ok, data, err = self._call_batchexecute("maseQ", h8a, recaptcha_action="UPLOAD_IMAGE")
        if ok and isinstance(data, list) and len(data) > 0 and isinstance(data[0], list) and data[0]:
            uploaded_mid = str(data[0][0] or "").strip()
            if uploaded_mid:
                print(f"[ULTRA-BRIDGE] ✅ Upload ảnh thành công (maseQ) -> mediaId={uploaded_mid}", flush=True)
                return uploaded_mid
        print(f"[ULTRA-BRIDGE] ❌ Lỗi upload ảnh (maseQ): {err}", flush=True)
        return None

    def cdp_generate_image(
        self,
        prompt: str,
        model_key: str = "GEM_PIX_2",
        aspect_ratio: str = "16:9",
        seed: int | None = None,
        ref_media_ids: list[str] | None = None,
        project_id: str | None = None,
        save_path: str | None = None,
    ) -> tuple[bool, str, str]:
        """Tạo ảnh đồng nhất trực tiếp qua RPC ogiZ0b trên flow.google.com (Google Ultra CDP).
        Trả về: (ok, media_id, message_or_engine)
        """
        import flow_batch

        pid = self._get_active_project_id(project_id)
        ar_str = str(aspect_ratio or "")
        if "9:16" in ar_str:
            aspect = flow_batch.ASPECT_PORTRAIT
        elif "1:1" in ar_str:
            aspect = flow_batch.ASPECT_SQUARE
        elif "4:3" in ar_str:
            aspect = flow_batch.ASPECT_LANDSCAPE_4_3
        elif "3:4" in ar_str:
            aspect = flow_batch.ASPECT_PORTRAIT_4_3
        else:
            aspect = flow_batch.ASPECT_LANDSCAPE
        seed_val = int(seed) if seed is not None else random.randint(10000, 999999999)
        wire_model = (
            "NARWHAL"
            if "NARWHAL" in str(model_key).upper()
            else ("HARBOR_SEAL" if "HARBOR_SEAL" in str(model_key).upper() else "GEM_PIX_2")
        )
        clean_refs = [str(m).strip() for m in (ref_media_ids or []) if m and str(m).strip()]

        try:
            f_req_str = flow_batch.image_request(
                prompt=str(prompt or "").strip(),
                project_id=pid,
                count=1,
                aspect=aspect,
                seed=seed_val,
                model=wire_model,
                ref_media_ids=clean_refs or None,
            )
            inner_str = json.loads(f_req_str)[0][0][1].replace(
                flow_batch.CAPTCHA_SLOT, "__RECAPTCHA_TOKEN__"
            )
            inner_obj = json.loads(inner_str)
        except Exception as e:
            return False, "", f"Lỗi đóng gói ogiZ0b: {e}"

        ok, data, err = self._call_batchexecute("ogiZ0b", inner_obj, recaptcha_action="IMAGE_GENERATION")
        if not ok:
            print(f"[ULTRA-BRIDGE] ❌ ogiZ0b thất bại: {err}", flush=True)
            return False, "", err

        imgs = flow_batch.read_images(data)
        if imgs:
            gen_img = imgs[0]
            if save_path:
                if self._download_flow_image(gen_img.url, save_path):
                    return True, gen_img.media_id, f"Google Flow ({wire_model})"
                return False, gen_img.media_id, "Tải file ảnh từ flow-content.google thất bại"
            return True, gen_img.media_id, f"Google Flow ({wire_model})"

        fife_url = self._extract_fife_url_from_dz(data)
        if fife_url and save_path:
            if self._download_flow_image(fife_url, save_path):
                return True, str(uuid.uuid4()), f"Google Flow ({wire_model})"
        return False, "", "Không tìm thấy URL ảnh trong phản hồi ogiZ0b"

    def _download_flow_image(self, img_url: str, save_path: str) -> bool:
        """Tải ảnh trực tiếp từ https://flow-content.google/image/... hoặc FIFE URL."""
        try:
            headers = {
                "Referer": "https://flow.google.com/",
                "Origin": "https://flow.google.com",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            }
            r = requests.get(img_url, headers=headers, allow_redirects=True, timeout=60)
            if r.status_code == 200 and len(r.content) > 5_000:
                os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
                with open(save_path, "wb") as f:
                    f.write(r.content)
                print(
                    f"[ULTRA-BRIDGE] ✅ Đã tải ảnh Flow ({len(r.content):,} bytes) -> {save_path}",
                    flush=True,
                )
                return True
        except Exception as e:
            print(f"[ULTRA-BRIDGE] ❌ Lỗi tải ảnh Flow: {e}", flush=True)
        return False

    def cdp_generate_video(
        self,
        prompt: str,
        model_key: str,
        ratio_key: str,
        project_id: str | None = None,
        start_media_id: str | None = None,
        end_media_id: str | None = None,
        ref_media_ids: list[str] | None = None,
        seed: int | None = None,
    ) -> tuple[str, str, str]:
        """Tạo video qua RPC YhhmEf / eb1hJf / nprQif / MZZa6b trên flow.google.com (có tự động làm sạch từ nhạy cảm & thử lại)."""
        import flowkit_engine

        pid = self._get_active_project_id(project_id)
        norm_model = normalize_flow_model_key(model_key)
        aspect_int = ratio_to_flow_int(ratio_key)
        clean_refs = [str(m).strip() for m in (ref_media_ids or []) if m and str(m).strip()]

        def _build_and_call(prompt_str: str, cur_seed: int | None):
            media_seed = str(uuid.uuid4())
            workflow_seed = str(uuid.uuid4())
            batch_id = str(uuid.uuid4())
            seed_int = int(cur_seed) if cur_seed is not None else None

            h = [None, None, [[[str(prompt_str or "").strip()]]]]
            D = [None, None, None, seed_int, media_seed, workflow_seed]
            k = [None, 22, None, None, None, pid, None, None, None, None, ["__RECAPTCHA_TOKEN__", 1]]
            x = [batch_id, 1]

            eff_model = norm_model
            if start_media_id and end_media_id:
                rpc = "nprQif"
                E = [h, eff_model, aspect_int, None, [None, str(start_media_id)], [None, str(end_media_id)], D]
            elif start_media_id:
                rpc = "eb1hJf"
                E = [h, eff_model, aspect_int, None, [None, str(start_media_id)], D]
            elif clean_refs and not eff_model.startswith("abra_t2v_"):
                rpc = "MZZa6b"
                ref_list = [[None, mid] for mid in clean_refs]
                E = [h, ref_list, eff_model, aspect_int, None, D]
            else:
                rpc = "YhhmEf"
                r2v_to_t2v = {
                    "veo_3_1_r2v_lite": "veo_3_1_t2v_lite",
                    "veo_3_1_r2v_fast_landscape_ultra": "veo_3_1_t2v_fast_ultra",
                    "veo_3_1_r2v_fast_portrait_ultra": "veo_3_1_t2v_fast_portrait_ultra",
                    "veo_3_1_r2v_fast_landscape": "veo_3_1_t2v_fast",
                    "veo_3_1_r2v_fast_portrait": "veo_3_1_t2v_fast_portrait",
                }
                eff_model = r2v_to_t2v.get(eff_model, eff_model.replace("_r2v_", "_t2v_"))
                E = [h, eff_model, aspect_int, None, D]

            pl = [[E], k, x]
            ok_call, data_call, err_call = self._call_batchexecute(rpc, pl, recaptcha_action="VIDEO_GENERATION")
            return rpc, eff_model, ok_call, data_call, err_call

        safe_p = flowkit_engine.sanitize_prompt_for_google_flow(
            flowkit_engine.to_video_motion_prompt(prompt), aggressive=False
        )
        rpcid, used_model, ok, data, err = _build_and_call(safe_p, seed)
        if not ok:
            err_up = str(err or "").upper()
            if any(tok in err_up for tok in ("UNSAFE", "MINOR", "POLICY", "ERROR: [5", "ERROR: [8", "ERROR: [13", "ERROR: [3")):
                time.sleep(1.2)
                ultra_safe_p = flowkit_engine.sanitize_prompt_for_google_flow(
                    flowkit_engine.to_video_motion_prompt(prompt), aggressive=True
                )
                next_seed = (int(seed) + 77) if seed is not None else random.randint(10000, 999999)
                rpcid, used_model, ok, data, err = _build_and_call(ultra_safe_p, next_seed)

        if not ok:
            print(f"[ULTRA-BRIDGE] ❌ {rpcid} thất bại: {err}", flush=True)
            return "FAIL", err, ""

        try:
            # KS response: data[1] = remainingCredits, data[3] = list of dz media objects
            remaining = data[1] if len(data) > 1 and data[1] is not None else "?"
            media_list = data[3] if len(data) > 3 and isinstance(data[3], list) else []
            if media_list and isinstance(media_list[0], list):
                dz = media_list[0]
                gen_media_id = str(dz[0] or "")
                gen_pid = str(dz[1] or pid) if len(dz) > 1 else pid
                print(
                    f"[ULTRA-BRIDGE] ✅ {rpcid} OK | mediaId={gen_media_id} | model={used_model} | credits còn={remaining}",
                    flush=True,
                )
                return "OK", gen_media_id, gen_pid
        except Exception as e:
            return "FAIL", f"Lỗi đọc kết quả {rpcid}: {e}", ""

        return "FAIL", f"Phản hồi {rpcid} không chứa mediaId: {str(data)[:250]}", ""

    def cdp_upscale_video(
        self,
        media_id: str,
        ratio_key: str,
        resolution_key: str,
        model_key: str,
        project_id: str | None = None,
    ) -> tuple[str, str, str]:
        """Upscale video lên 1080p hoặc 4K qua RPC p0UkFb (/VideoFxService.BatchAsyncGenerateVideoUpsampleVideo)."""
        pid = self._get_active_project_id(project_id)
        mid_clean = str(media_id or "").strip()
        if not mid_clean:
            return "FAIL", "Thiếu mediaId để upscale", ""
        if mid_clean.endswith("_upsampled"):
            return "OK", mid_clean, pid

        aspect_int = ratio_to_flow_int(ratio_key)
        res_int = 3 if "4K" in str(resolution_key).upper() else 2

        media_seed = str(uuid.uuid4())
        workflow_seed = str(uuid.uuid4())
        batch_id = str(uuid.uuid4())
        seed_int = random.randint(10000, 999999)

        D = [None, None, None, seed_int, media_seed, workflow_seed]
        E = [None] * 32
        E[0] = [None, mid_clean]
        E[2] = aspect_int
        E[4] = D
        E[6] = res_int
        E[31] = str(model_key or "veo_3_1_upsampler_1080p")

        k = [None, 22, None, None, None, pid, None, None, None, None, ["__RECAPTCHA_TOKEN__", 1]]
        x = [batch_id, 1]
        payload = [[E], k, x]

        ok, data, err = self._call_batchexecute("p0UkFb", payload, recaptcha_action="VIDEO_GENERATION")
        if not ok:
            # Nếu video đã được gửi upscale trước đó, kiểm tra trực tiếp <media_id>_upsampled
            cand_mid = f"{mid_clean}_upsampled"
            ok_chk, data_chk, _ = self._call_batchexecute("jwpduf", [None, None, [[cand_mid]]], recaptcha_action=None)
            if ok_chk and isinstance(data_chk, list) and len(data_chk) > 2 and data_chk[2]:
                return "OK", cand_mid, pid
            return "FAIL", err, ""
        try:
            media_list = data[3] if len(data) > 3 and isinstance(data[3], list) else []
            if media_list and isinstance(media_list[0], list):
                dz = media_list[0]
                up_mid = str(dz[0] or f"{mid_clean}_upsampled")
                up_pid = str(dz[1] or pid) if len(dz) > 1 else pid
                print(
                    f"[ULTRA-BRIDGE] ✅ Đã kích hoạt Upscale {resolution_key} (p0UkFb) -> {up_mid}",
                    flush=True,
                )
                return "OK", up_mid, up_pid
        except Exception as e:
            return "FAIL", str(e), ""
        return "OK", f"{mid_clean}_upsampled", pid

    def cdp_poll_and_download_video(
        self,
        media_id: str,
        save_path: str,
        stop_event=None,
        progress_callback=None,
    ) -> tuple[str, str | None]:
        """Poll trạng thái video qua RPC jwpduf và tải MP4 qua as29s + phiên Cookie Chrome."""
        mid = str(media_id or "").strip()
        if not mid:
            return "FAILED: Thiếu mediaId", None

        delay = 5.0
        for attempt in range(75):
            if stop_event is not None and hasattr(stop_event, "is_set") and stop_event.is_set():
                return "STOPPED", None
            if callable(stop_event) and stop_event():
                return "STOPPED", None
            if progress_callback:
                try:
                    progress_callback(min(92, int(attempt * 2.5)))
                except Exception:
                    pass

            ok, data, err = self._call_batchexecute("jwpduf", [None, None, [[mid]]], recaptcha_action=None)
            if ok and isinstance(data, list) and len(data) > 2 and isinstance(data[2], list) and data[2]:
                dz = data[2][0]
                status_code = None
                err_detail = ""
                try:
                    mM = dz[5] if len(dz) > 5 and isinstance(dz[5], list) else []
                    EQ = mM[8] if len(mM) > 8 and isinstance(mM[8], list) else []
                    status_code = EQ[0] if len(EQ) > 0 else None
                    if len(EQ) > 1 and EQ[1]:
                        err_detail = json.dumps(EQ[1], ensure_ascii=False)
                except Exception:
                    pass

                if status_code == 3:
                    # Render thành công -> gọi as29s (/FlowService.GetMedia) để lấy URL FIFE và tải MP4
                    fife_url = self._extract_fife_url_from_dz(dz)
                    if not fife_url:
                        ok2, data2, _ = self._call_batchexecute("as29s", [mid, None, [1]], recaptcha_action=None)
                        if ok2 and isinstance(data2, list):
                            fife_url = self._extract_fife_url_from_dz(data2)

                    if fife_url:
                        dl_ok = self._download_fife_mp4(fife_url, save_path)
                        if dl_ok:
                            if progress_callback:
                                try:
                                    progress_callback(100)
                                except Exception:
                                    pass
                            return "DONE", mid
                    print(f"[ULTRA-BRIDGE] ⚠️ Status=3 nhưng chưa tải được MP4, thử lại...", flush=True)

                elif status_code in (4, 5, 7):
                    reason = f"FAILED (code={status_code}) {err_detail}".strip()
                    print(f"[ULTRA-BRIDGE] ❌ Video generation failed: {reason}", flush=True)
                    return reason[:140], None

            time.sleep(delay)
            delay = min(delay + 2.0, 15.0)

        return "TIMEOUT", None

    def _extract_fife_url_from_dz(self, obj) -> str | None:
        """Tìm URL https://lh3.googleusercontent.com/asb/... trong cấu trúc dz."""
        raw = json.dumps(obj)
        m = re.search(r"https://lh3\.googleusercontent\.com/asb/[A-Za-z0-9_\-]+", raw)
        if m:
            return m.group(0)
        m2 = re.search(r"https://[^\s\"'\\]+googleusercontent\.com[^\s\"'\\]+", raw)
        if m2:
            return m2.group(0)
        return None

    def _download_fife_mp4(self, fife_url: str, save_path: str) -> bool:
        """Tải MP4 từ FIFE URL với tham số =mm,22,15 và toàn bộ Cookie của Chrome CDP."""
        tab = self._ensure_ready_flow_tab(auto_open_browser=False)
        if not tab or cffi_requests is None:
            return False

        ws_url = tab["webSocketDebuggerUrl"]
        cookies_res = self._cdp_send(ws_url, "Storage.getCookies", {}, timeout=6.0)
        cookies_list = (cookies_res or {}).get("cookies") or []

        sess = cffi_requests.Session(impersonate="chrome124")
        for c in cookies_list:
            if isinstance(c, dict) and c.get("name") and c.get("value") is not None:
                sess.cookies.set(
                    str(c["name"]),
                    str(c["value"]),
                    domain=str(c.get("domain") or ""),
                    path=str(c.get("path") or "/"),
                )

        base_url = fife_url.split("=")[0]
        video_url = base_url + "=mm,15,37,22"
        try:
            r = sess.get(video_url, allow_redirects=True, timeout=120)
            ct = str(r.headers.get("content-type") or "").lower()
            if r.status_code == 200 and len(r.content) > 50_000 and ("video" in ct or r.content[4:8] == b"ftyp"):
                os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
                part_path = save_path + ".part"
                with open(part_path, "wb") as f:
                    f.write(r.content)
                os.replace(part_path, save_path)
                print(
                    f"[ULTRA-BRIDGE] ✅ Đã tải MP4 ({len(r.content):,} bytes) -> {save_path}",
                    flush=True,
                )
                return True
            print(
                f"[ULTRA-BRIDGE] ⚠️ Tải MP4 thất bại: HTTP {r.status_code}, ct={ct}, len={len(r.content)}",
                flush=True,
            )
        except Exception as e:
            print(f"[ULTRA-BRIDGE] ❌ Lỗi tải MP4: {e}", flush=True)
        return False

    def reload_labs_tabs(self):
        for port in self.cdp_ports:
            tabs = self._get_cdp_tabs(port)
            if not tabs:
                continue
            for t in tabs:
                u = str(t.get("url") or "")
                if "flow.google.com" in u or "labs.google" in u:
                    ws_url = t["webSocketDebuggerUrl"]
                    self._cdp_eval(
                        ws_url,
                        "try { localStorage.removeItem('_grecaptcha'); } catch(e){}",
                        await_promise=False,
                        timeout=2.0,
                    )
                    self._cdp_send(ws_url, "Page.reload", {"ignoreCache": False}, timeout=4.0)

    def navigate_labs_tabs(self, url: str):
        for port in self.cdp_ports:
            tabs = self._get_cdp_tabs(port)
            if not tabs:
                continue
            for t in tabs:
                u = str(t.get("url") or "")
                if "flow.google.com" in u or "labs.google" in u:
                    ws_url = t["webSocketDebuggerUrl"]
                    self._cdp_send(ws_url, "Page.navigate", {"url": url}, timeout=4.0)
                    return


_GLOBAL_BRIDGE: GoogleUltraBridge | None = None


def init_global_bridge(app_dir: str, on_accounts_updated=None, on_status_changed=None) -> GoogleUltraBridge:
    global _GLOBAL_BRIDGE
    if _GLOBAL_BRIDGE is None:
        _GLOBAL_BRIDGE = GoogleUltraBridge(
            app_dir=app_dir,
            on_accounts_updated=on_accounts_updated,
            on_status_changed=on_status_changed,
        )
        _GLOBAL_BRIDGE.start()
    else:
        if on_accounts_updated:
            _GLOBAL_BRIDGE.on_accounts_updated = on_accounts_updated
        if on_status_changed:
            _GLOBAL_BRIDGE.on_status_changed = on_status_changed
    return _GLOBAL_BRIDGE


def get_global_bridge() -> GoogleUltraBridge | None:
    return _GLOBAL_BRIDGE
