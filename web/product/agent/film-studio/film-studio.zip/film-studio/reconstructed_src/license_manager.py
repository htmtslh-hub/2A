# -*- coding: utf-8 -*-
"""
FILM STUDIO PRO — HARDWARE MACHINE ID & SUBSCRIPTION LICENSE MANAGER
====================================================================
Quản lý bản quyền theo Mã Máy (Hardware ID / HWID) và thời hạn gói mua trên Web (https://forgezone.store).
- Tạo Mã Máy độc nhất cho từng thiết bị (CPU + Disk Serial + Windows MachineGuid): FS-XXXX-XXXX-XXXX-XXXX
- Xác thực chữ ký mật mã HMAC-SHA256 chống giả mạo (Offline + Online Sync với Web).
- Kiểm tra chính xác thời hạn gói mua trên Web (Premium 1 Tháng / Ultra 1 Năm / Ultra Lifetime Vĩnh Viễn).
- Chống chỉnh lùi đồng hồ hệ thống (Anti-Clock-Rollback) và tự động khóa khi hết hạn hoặc thu hồi.
"""

from __future__ import annotations

import base64
import ctypes
import datetime
import hashlib
import hmac
import json
import os
import platform
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from typing import Any, Dict, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LICENSE_FILE = os.path.join(BASE_DIR, "license_state.json")

# Website chính thức để khách hàng lấy mã kích hoạt và kiểm tra thời hạn gói
DEFAULT_WEB_BASE_URL = os.environ.get("FORGEZONE_WEB_URL", "https://forgezone.store").rstrip("/")
WEB_ACTIVATION_PORTAL_URL = f"{DEFAULT_WEB_BASE_URL}/kich-hoat"

# Khóa ký HMAC-SHA256 đồng bộ 1:1 giữa Desktop (license_manager.py) và Web (src/lib/license-key.ts)
_MASTER_SEED = os.environ.get(
    "FORGEZONE_LICENSE_SECRET",
    "FZ_FILM_STUDIO_2026_HWID_MASTER_SIGNING_KEY_9F8E7D6C5B4A39281706"
)

LIFETIME_TIMESTAMP = 4102444800  # 2099-12-31 00:00:00 UTC

PLAN_LABELS: Dict[str, str] = {
    "PRO": "Premium (Gói 1 Tháng)",
    "PREMIUM": "Premium (Gói 1 Tháng)",
    "ULTRA": "Ultra (Gói 1 Năm)",
    "BUNDLE": "Ultra Lifetime (Vĩnh Viễn)",
    "LIFETIME": "Ultra Lifetime (Vĩnh Viễn)",
    "TRIAL": "Gói Dùng Thử",
    "CUSTOM": "Gói Theo Thời Hạn Web",
}

_CACHED_MACHINE_ID: Optional[str] = None


def _get_signing_key() -> bytes:
    """Trả về khóa nhị phân 32-byte chuẩn từ chuỗi khóa chủ."""
    return hashlib.sha256(f"FORGEZONE_HWID_V1::{_MASTER_SEED}".encode("utf-8")).digest()


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(text: str) -> bytes:
    pad = (4 - (len(text) % 4)) % 4
    return base64.urlsafe_b64decode(text + ("=" * pad))


def _read_windows_machine_guid() -> str:
    if sys.platform != "win32":
        return ""
    try:
        import winreg
        access = winreg.KEY_READ
        if hasattr(winreg, "KEY_WOW64_64KEY"):
            access |= winreg.KEY_WOW64_64KEY
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            access,
        ) as key:
            val, _ = winreg.QueryValueEx(key, "MachineGuid")
            return str(val or "").strip()
    except Exception:
        return ""


def _read_windows_volume_serial() -> str:
    if sys.platform != "win32":
        return ""
    try:
        vol_name_buf = ctypes.create_unicode_buffer(261)
        fs_name_buf = ctypes.create_unicode_buffer(261)
        serial_num = ctypes.c_ulong(0)
        max_comp_len = ctypes.c_ulong(0)
        fs_flags = ctypes.c_ulong(0)
        sys_drive = os.environ.get("SystemDrive", "C:") + "\\"
        res = ctypes.windll.kernel32.GetVolumeInformationW(
            ctypes.c_wchar_p(sys_drive),
            vol_name_buf,
            ctypes.sizeof(vol_name_buf),
            ctypes.byref(serial_num),
            ctypes.byref(max_comp_len),
            ctypes.byref(fs_flags),
            fs_name_buf,
            ctypes.sizeof(fs_name_buf),
        )
        if res:
            return f"{serial_num.value:08X}"
    except Exception:
        pass
    return ""


def get_machine_id() -> str:
    """
    Sinh Mã Máy (Hardware ID / HWID) cố định và duy nhất cho từng máy tính.
    Định dạng: FS-XXXX-XXXX-XXXX-XXXX (16 ký tự Hex viết hoa).
    """
    global _CACHED_MACHINE_ID
    if _CACHED_MACHINE_ID:
        return _CACHED_MACHINE_ID

    parts = [
        _read_windows_machine_guid(),
        _read_windows_volume_serial(),
        platform.node(),
        platform.machine(),
        platform.processor(),
    ]
    raw_fingerprint = "|".join(p.strip().upper() for p in parts if p and p.strip())
    if not raw_fingerprint:
        raw_fingerprint = "FALLBACK_MACHINE_FINGERPRINT_FILM_STUDIO"

    digest = hashlib.sha256(f"FILM_STUDIO_HWID_V1::{raw_fingerprint}".encode("utf-8")).hexdigest().upper()
    h16 = digest[:16]
    _CACHED_MACHINE_ID = f"FS-{h16[0:4]}-{h16[4:8]}-{h16[8:12]}-{h16[12:16]}"
    return _CACHED_MACHINE_ID


def normalize_machine_id(raw_id: str) -> str:
    """
    Chuẩn hóa Mã Máy người dùng nhập vào về dạng chuẩn FS-XXXX-XXXX-XXXX-XXXX.
    Trả về chuỗi rỗng nếu không đúng định dạng 16 ký tự Hex.
    """
    if not raw_id:
        return ""
    cleaned = re.sub(r"[^A-Fa-f0-9]", "", raw_id.strip().upper())
    # Nếu bắt đầu bằng FS (F5? Không, F và S: S không phải hex, nên chỉ còn F ở đầu nếu gõ FS-...)
    # Tốt hơn là bỏ tiền tố FS- hoặc FS trước khi lọc hex:
    s = raw_id.strip().upper()
    if s.startswith("FS-"):
        s = s[3:]
    elif s.startswith("FS"):
        s = s[2:]
    hex_only = re.sub(r"[^0-9A-F]", "", s)
    if len(hex_only) != 16:
        return ""
    return f"FS-{hex_only[0:4]}-{hex_only[4:8]}-{hex_only[8:12]}-{hex_only[12:16]}"


def generate_license_key(
    machine_id: str,
    plan: str = "PRO",
    expires_at_ts: int = 0,
    email: str = "",
    license_id: str = "",
    issued_at_ts: int = 0,
) -> str:
    """
    Tạo Mã Kích Hoạt (FZKEY-...) gắn chặt với Mã Máy (machine_id) và thời hạn gói mua (expires_at_ts).
    Hàm này tương thích 100% với hàm tạo key trên Web (src/lib/license-key.ts).
    """
    norm_hwid = normalize_machine_id(machine_id)
    if not norm_hwid:
        raise ValueError(f"Mã máy không hợp lệ: {machine_id!r} (Cần dạng FS-XXXX-XXXX-XXXX-XXXX)")

    now_ts = int(issued_at_ts or time.time())
    plan_code = (plan or "PRO").strip().upper()
    if plan_code in ("BUNDLE", "LIFETIME") and not expires_at_ts:
        exp_ts = LIFETIME_TIMESTAMP
    elif not expires_at_ts:
        # Mặc định PRO = 30 ngày, ULTRA = 365 ngày
        days = 365 if plan_code == "ULTRA" else 30
        exp_ts = now_ts + (days * 86400)
    else:
        exp_ts = int(expires_at_ts)

    if not license_id:
        short_hash = hashlib.sha256(f"{norm_hwid}:{plan_code}:{now_ts}".encode("utf-8")).hexdigest()[:8].upper()
        license_id = f"LIC-{short_hash}"

    payload = {
        "app": "film-studio",
        "e": (email or "customer@forgezone.store").strip().lower(),
        "h": norm_hwid,
        "i": now_ts,
        "id": license_id,
        "p": plan_code,
        "v": 1,
        "x": exp_ts,
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    b64_payload = _b64url_encode(payload_bytes)
    sig_bytes = hmac.new(_get_signing_key(), b64_payload.encode("ascii"), hashlib.sha256).digest()[:16]
    b64_sig = _b64url_encode(sig_bytes)
    return f"FZKEY-{b64_payload}.{b64_sig}"


def format_expiry_vn(exp_ts: int, plan_code: str = "") -> str:
    if plan_code in ("BUNDLE", "LIFETIME") or exp_ts >= 4000000000:
        return "Vĩnh viễn (Trọn đời)"
    dt = datetime.datetime.fromtimestamp(exp_ts)
    return dt.strftime("%d/%m/%Y %H:%M")


def compute_remaining_text(exp_ts: int, plan_code: str = "", now_ts: Optional[int] = None) -> str:
    if plan_code in ("BUNDLE", "LIFETIME") or exp_ts >= 4000000000:
        return "Trọn đời (Không giới hạn)"
    now_val = int(now_ts if now_ts is not None else time.time())
    diff = exp_ts - now_val
    if diff <= 0:
        return "Đã hết hạn"
    days = diff // 86400
    hours = (diff % 86400) // 3600
    mins = (diff % 3600) // 60
    if days > 0:
        return f"Còn {days} ngày {hours} giờ"
    if hours > 0:
        return f"Còn {hours} giờ {mins} phút"
    return f"Còn {max(1, mins)} phút"


def _load_saved_state() -> Dict[str, Any]:
    if not os.path.exists(LICENSE_FILE):
        return {}
    try:
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_state(state: Dict[str, Any]) -> None:
    try:
        with open(LICENSE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def verify_license_key(
    license_key: str,
    expected_machine_id: Optional[str] = None,
    check_online: bool = False,
) -> Dict[str, Any]:
    """
    Kiểm tra tính hợp lệ của Mã Kích Hoạt (FZKEY-...):
    1. Kiểm tra cấu trúc và chữ ký HMAC-SHA256.
    2. Đối chiếu Mã Máy trong key với Mã Máy thực tế của thiết bị.
    3. Kiểm tra thời hạn gói mua (exp) và chống chỉnh lùi giờ hệ thống.
    4. (Tùy chọn) Kiểm tra trực tuyến với https://forgezone.store/api/license/verify.
    """
    local_hwid = normalize_machine_id(expected_machine_id) if expected_machine_id else get_machine_id()
    raw_key = (license_key or "").strip()

    base_result: Dict[str, Any] = {
        "valid": False,
        "status": "UNACTIVATED",
        "machine_id": local_hwid,
        "license_key": raw_key,
        "plan": "",
        "plan_name": "Chưa kích hoạt",
        "email": "",
        "license_id": "",
        "issued_at": 0,
        "expires_at": 0,
        "expires_at_str": "—",
        "remaining_text": "Chưa kích hoạt",
        "is_lifetime": False,
        "error": "",
    }

    if not raw_key:
        base_result["error"] = "Chưa nhập Mã Kích Hoạt (License Key)."
        return base_result

    if not raw_key.startswith("FZKEY-") or "." not in raw_key:
        base_result["status"] = "INVALID_FORMAT"
        base_result["error"] = "Định dạng Mã Kích Hoạt không hợp lệ (Cần bắt đầu bằng FZKEY-...)."
        return base_result

    body = raw_key[6:]
    parts = body.split(".", 1)
    if len(parts) != 2:
        base_result["status"] = "INVALID_FORMAT"
        base_result["error"] = "Cấu trúc Mã Kích Hoạt bị thiếu chữ ký bảo mật."
        return base_result

    b64_payload, b64_sig = parts[0].strip(), parts[1].strip()
    try:
        expected_sig_bytes = hmac.new(
            _get_signing_key(), b64_payload.encode("ascii"), hashlib.sha256
        ).digest()[:16]
        expected_b64_sig = _b64url_encode(expected_sig_bytes)
    except Exception:
        base_result["status"] = "INVALID_SIGNATURE"
        base_result["error"] = "Không thể xác thực chữ ký Mã Kích Hoạt."
        return base_result

    if not hmac.compare_digest(b64_sig, expected_b64_sig):
        base_result["status"] = "INVALID_SIGNATURE"
        base_result["error"] = "Mã Kích Hoạt không hợp lệ hoặc đã bị can thiệp sửa đổi!"
        return base_result

    try:
        payload_raw = _b64url_decode(b64_payload).decode("utf-8")
        payload = json.loads(payload_raw)
    except Exception:
        base_result["status"] = "CORRUPTED_PAYLOAD"
        base_result["error"] = "Dữ liệu bên trong Mã Kích Hoạt bị hỏng."
        return base_result

    key_hwid = normalize_machine_id(str(payload.get("h", "")))
    if not key_hwid or key_hwid != local_hwid:
        base_result["status"] = "MACHINE_MISMATCH"
        base_result["error"] = (
            f"Mã Kích Hoạt này được cấp cho Mã Máy khác ({key_hwid or 'N/A'}), "
            f"không khớp với Mã Máy hiện tại của bạn ({local_hwid})!"
        )
        return base_result

    plan_code = str(payload.get("p", "PRO")).upper()
    exp_ts = int(payload.get("x", 0))
    iat_ts = int(payload.get("i", 0))
    email = str(payload.get("e", ""))
    lic_id = str(payload.get("id", ""))
    is_lifetime = plan_code in ("BUNDLE", "LIFETIME") or exp_ts >= 4000000000

    now_ts = int(time.time())
    saved = _load_saved_state()
    last_seen_ts = int(saved.get("last_seen_ts", 0))

    # Chống chỉnh lùi đồng hồ máy tính (cho phép sai số tối đa 10 phút)
    if last_seen_ts > 0 and now_ts + 600 < last_seen_ts:
        base_result["status"] = "CLOCK_TAMPERED"
        base_result["error"] = (
            "Phát hiện đồng hồ hệ thống bị chỉnh lùi! Vui lòng đồng bộ lại ngày giờ chuẩn của Windows."
        )
        return base_result

    effective_now = max(now_ts, last_seen_ts)

    base_result.update(
        {
            "plan": plan_code,
            "plan_name": PLAN_LABELS.get(plan_code, f"Gói {plan_code}"),
            "email": email,
            "license_id": lic_id,
            "issued_at": iat_ts,
            "expires_at": exp_ts,
            "expires_at_str": format_expiry_vn(exp_ts, plan_code),
            "remaining_text": compute_remaining_text(exp_ts, plan_code, effective_now),
            "is_lifetime": is_lifetime,
        }
    )

    if not is_lifetime and effective_now >= exp_ts:
        base_result["status"] = "EXPIRED"
        base_result["error"] = (
            f"Gói bản quyền ({base_result['plan_name']}) đã hết hạn vào lúc {base_result['expires_at_str']}. "
            f"Vui lòng gia hạn trên {DEFAULT_WEB_BASE_URL} và lấy Mã Kích Hoạt mới!"
        )
        return base_result

    # Kiểm tra trực tuyến với Web Server nếu có yêu cầu
    if check_online:
        online_info = _check_online_status(raw_key, local_hwid)
        if online_info.get("revoked"):
            base_result["status"] = "REVOKED"
            base_result["error"] = online_info.get(
                "reason",
                "Mã Kích Hoạt đã bị thu hồi hoặc đơn hàng đã hoàn tiền trên hệ thống Web.",
            )
            return base_result

    base_result["valid"] = True
    base_result["status"] = "ACTIVE"
    base_result["error"] = ""
    return base_result


def _check_online_status(license_key: str, machine_id: str) -> Dict[str, Any]:
    """Gọi API /api/license/verify trên Web để kiểm tra thu hồi hoặc cập nhật thời gian thực."""
    url = f"{DEFAULT_WEB_BASE_URL}/api/license/verify"
    req_body = json.dumps(
        {
            "action": "verify",
            "licenseKey": license_key,
            "machineId": machine_id,
            "app": "film-studio",
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=req_body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "FilmStudioPro-LicenseClient/2.5",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            data = json.loads(raw)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {"online_checked": False}


def activate_license(license_key: str, check_online: bool = True) -> Dict[str, Any]:
    """
    Kích hoạt bản quyền bằng Mã Kích Hoạt (FZKEY-...) và lưu trạng thái xuống đĩa.
    """
    res = verify_license_key(license_key, check_online=check_online)
    if res.get("valid"):
        now_ts = int(time.time())
        saved = _load_saved_state()
        last_seen = max(now_ts, int(saved.get("last_seen_ts", 0)))
        _save_state(
            {
                "license_key": license_key.strip(),
                "machine_id": res["machine_id"],
                "plan": res["plan"],
                "plan_name": res["plan_name"],
                "email": res["email"],
                "license_id": res["license_id"],
                "issued_at": res["issued_at"],
                "expires_at": res["expires_at"],
                "activated_at": now_ts,
                "last_seen_ts": last_seen,
            }
        )
    return res


def sync_license_from_web(web_base_url: Optional[str] = None) -> Dict[str, Any]:
    """
    Tự động hỏi Server Web (https://forgezone.store/api/license/verify) xem Mã Máy hiện tại
    đã được khách hàng đăng ký/lấy key trên Web chưa; nếu có thì tự tải về và kích hoạt ngay!
    """
    base_url = (web_base_url or DEFAULT_WEB_BASE_URL).rstrip("/")
    local_hwid = get_machine_id()
    url = f"{base_url}/api/license/verify"
    req_body = json.dumps(
        {
            "action": "fetch_by_machine",
            "machineId": local_hwid,
            "app": "film-studio",
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=req_body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "FilmStudioPro-LicenseClient/2.5",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
            if isinstance(data, dict) and data.get("licenseKey"):
                return activate_license(str(data["licenseKey"]), check_online=False)
            return {
                "valid": False,
                "status": "NOT_FOUND_ON_WEB",
                "machine_id": local_hwid,
                "error": data.get(
                    "error",
                    f"Chưa tìm thấy Mã Kích Hoạt cho Mã Máy {local_hwid} trên Web. "
                    f"Vui lòng đăng nhập {base_url}/kich-hoat và nhập Mã Máy để tạo key!",
                ),
            }
    except urllib.error.HTTPError as he:
        try:
            err_body = json.loads(he.read().decode("utf-8", errors="replace"))
            msg = err_body.get("error") or f"HTTP {he.code}"
        except Exception:
            msg = f"HTTP {he.code}"
        return {
            "valid": False,
            "status": "WEB_ERROR",
            "machine_id": local_hwid,
            "error": msg,
        }
    except Exception as e:
        return {
            "valid": False,
            "status": "OFFLINE",
            "machine_id": local_hwid,
            "error": f"Không thể kết nối tới máy chủ {base_url} ({e}). Vui lòng dán trực tiếp Mã Kích Hoạt FZKEY-...",
        }


def get_license_status(check_online: bool = False) -> Dict[str, Any]:
    """
    Kiểm tra trạng thái bản quyền hiện tại của máy.
    Luôn xác thực lại chữ ký mật mã, Mã Máy phần cứng và thời gian hết hạn thực tế.
    """
    saved = _load_saved_state()
    saved_key = str(saved.get("license_key", "")).strip()
    if not saved_key:
        return {
            "valid": False,
            "status": "UNACTIVATED",
            "machine_id": get_machine_id(),
            "license_key": "",
            "plan": "",
            "plan_name": "Chưa kích hoạt",
            "email": "",
            "license_id": "",
            "issued_at": 0,
            "expires_at": 0,
            "expires_at_str": "—",
            "remaining_text": "Chưa kích hoạt",
            "is_lifetime": False,
            "error": "Ứng dụng chưa được kích hoạt bản quyền cho Mã Máy này.",
        }

    res = verify_license_key(saved_key, check_online=check_online)
    if res.get("valid"):
        now_ts = int(time.time())
        if now_ts > int(saved.get("last_seen_ts", 0)):
            saved["last_seen_ts"] = now_ts
            _save_state(saved)
    return res


def deactivate_local_license() -> Dict[str, Any]:
    """Xóa Mã Kích Hoạt đang lưu trên máy hiện tại."""
    try:
        if os.path.exists(LICENSE_FILE):
            os.remove(LICENSE_FILE)
    except Exception:
        pass
    return get_license_status(check_online=False)


if __name__ == "__main__":
    # Self-test nhanh qua CLI
    hwid = get_machine_id()
    print(f"[HWID] Mã Máy hiện tại: {hwid}")
    sample_key = generate_license_key(
        machine_id=hwid,
        plan="ULTRA",
        expires_at_ts=int(time.time()) + 30 * 86400,
        email="tiende@forgezone.store",
    )
    print(f"[KEY] Mã Kích Hoạt mẫu (30 ngày): {sample_key}")
    check = verify_license_key(sample_key)
    assert check["valid"] is True, f"Verify failed: {check}"
    print(f"[VERIFY] Hợp lệ: {check['plan_name']} | Hạn: {check['expires_at_str']} ({check['remaining_text']})")
