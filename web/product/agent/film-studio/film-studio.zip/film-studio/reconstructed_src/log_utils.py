"""
log_utils.py v2 — Throttled logger + Status updater + UI Bridge dùng chung.

★ 100% BACKWARD COMPATIBLE với v1 — chỉ cần thay file, không đổi code cũ.
★ THÊM primitives mới để giải quyết tận gốc vấn đề UI đơ:

    - ThrottledTextLogger       (v1, giữ nguyên) — batch log vào textbox
    - ThrottledStatusUpdater    (v1, giữ nguyên) — coalesce per-row status
    - WidgetCoalescer           (MỚI) — coalesce bất kỳ widget.configure() nào
    - schedule_ui(fn)           (MỚI) — gộp nhiều after(0) thành 1 tick
    - BoundedThreadPool         (MỚI) — giới hạn số thread đồng thời
    - UIBridge                  (MỚI) — gắn tất cả vào 1 app instance
"""

import threading
from collections import deque, OrderedDict
from concurrent.futures import ThreadPoolExecutor


class ThrottledTextLogger:
    """
    Logger gom batch cho Tk Text / CTkTextbox widget.
    """

    def __init__(self, widget, tk_master=None, flush_ms=120, max_lines=1500, buffer_cap=5000):
        self.widget = widget
        self.tk_master = tk_master or widget
        self.flush_ms = flush_ms
        self.max_lines = max_lines
        self.buffer_cap = buffer_cap
        self._buf = deque()
        self._lock = threading.Lock()
        self._scheduled = False
        self._closed = False

    def log(self, msg: str):
        if self._closed:
            return
        line = str(msg)
        if not line.endswith("\n"):
            line += "\n"
        with self._lock:
            if len(self._buf) >= self.buffer_cap:
                self._buf.popleft()
            self._buf.append(line)
            if not self._scheduled:
                self._scheduled = True
                try:
                    self.tk_master.after(self.flush_ms, self._flush)
                except Exception:
                    self._scheduled = False

    def _flush(self):
        with self._lock:
            if not self._buf or self._closed:
                self._scheduled = False
                return
            batch = "".join(self._buf)
            self._buf.clear()
            self._scheduled = False

        try:
            self.widget.configure(state="normal")
            self.widget.insert("end", batch)
            try:
                end_idx = self.widget.index("end-1c")
                total_lines = int(str(end_idx).split(".")[0])
                if total_lines > self.max_lines:
                    trim_to = total_lines - self.max_lines
                    self.widget.delete("1.0", f"{trim_to}.0")
            except Exception:
                pass
            self.widget.see("end")
            self.widget.configure(state="disabled")
        except Exception:
            pass

    def close(self):
        self._closed = True
        with self._lock:
            self._buf.clear()


def attach_logger(owner, widget, tk_master=None, flush_ms=120, max_lines=1500):
    """Gắn throttled logger vào owner. Sau khi gọi, owner.log(msg) là thread-safe batched."""
    logger = ThrottledTextLogger(
        widget=widget,
        tk_master=tk_master or owner,
        flush_ms=flush_ms,
        max_lines=max_lines,
    )
    owner._logger = logger

    def _log(msg):
        logger.log(msg)

    owner.log = _log
    owner._log_ui = _log
    return logger


class ThrottledStatusUpdater:
    """Coalesce cập nhật trạng thái theo key (row_id) trên UI thread."""

    def __init__(self, tk_master, apply_func, key_func=None, flush_ms=120):
        self.tk_master = tk_master
        self.apply_func = apply_func
        self.key_func = key_func or (lambda item: item[0] if isinstance(item, tuple) else id(item))
        self.flush_ms = flush_ms
        self._pending = OrderedDict()
        self._lock = threading.Lock()
        self._scheduled = False
        self._closed = False

    def update(self, *payload):
        if self._closed:
            return
        item = payload[0] if len(payload) == 1 else payload
        key = self.key_func(item)
        with self._lock:
            self._pending[key] = payload
            if not self._scheduled:
                self._scheduled = True
                try:
                    self.tk_master.after(self.flush_ms, self._flush)
                except Exception:
                    self._scheduled = False

    def _flush(self):
        with self._lock:
            if not self._pending or self._closed:
                self._scheduled = False
                return
            items = list(self._pending.values())
            self._pending.clear()
            self._scheduled = False

        for payload in items:
            try:
                self.apply_func(*payload)
            except Exception:
                pass

    def flush_now(self):
        self._flush()

    def close(self):
        self._closed = True
        with self._lock:
            self._pending.clear()


def attach_status_updater(owner, apply_func, key_func=None, tk_master=None, flush_ms=120):
    updater = ThrottledStatusUpdater(
        tk_master=tk_master or owner,
        apply_func=apply_func,
        key_func=key_func,
        flush_ms=flush_ms,
    )
    owner._status_updater = updater
    return updater


class WidgetCoalescer:
    """
    Gộp nhiều `widget.configure(**kwargs)` thành 1 flush / ~100ms.
    Key = id(widget). Mỗi widget chỉ giữ state CUỐI CÙNG.
    """

    def __init__(self, tk_master, flush_ms=100):
        self.tk_master = tk_master
        self.flush_ms = flush_ms
        self._pending_widgets = OrderedDict()
        self._pending_calls = []
        self._lock = threading.Lock()
        self._scheduled = False
        self._closed = False

    def set(self, widget, **kwargs):
        """Coalesced widget.configure(**kwargs). Thread-safe."""
        if self._closed or widget is None:
            return
        wid = id(widget)
        with self._lock:
            if wid in self._pending_widgets:
                _, prev_kw = self._pending_widgets[wid]
                prev_kw.update(kwargs)
            else:
                self._pending_widgets[wid] = (widget, dict(kwargs))
            self._schedule_locked()

    def call(self, fn):
        """One-shot callable chạy trên UI thread, gộp vào batch tiếp theo."""
        if self._closed or fn is None:
            return
        with self._lock:
            self._pending_calls.append(fn)
            self._schedule_locked()

    def _schedule_locked(self):
        if not self._scheduled and not self._closed:
            self._scheduled = True
            try:
                self.tk_master.after(self.flush_ms, self._flush)
            except Exception:
                self._scheduled = False

    def _flush(self):
        with self._lock:
            widgets = list(self._pending_widgets.values())
            calls = list(self._pending_calls)
            self._pending_widgets.clear()
            self._pending_calls.clear()
            self._scheduled = False

        for w, kw in widgets:
            try:
                w.configure(**kw)
            except Exception:
                pass
        for fn in calls:
            try:
                fn()
            except Exception:
                pass

    def flush_now(self):
        self._flush()

    def close(self):
        self._closed = True
        with self._lock:
            self._pending_widgets.clear()
            self._pending_calls.clear()


class BoundedThreadPool:
    """
    Wrapper thin quanh ThreadPoolExecutor — giới hạn concurrency.
    """

    def __init__(self, max_workers=8, thread_name_prefix="tool-worker"):
        self._pool = ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix=thread_name_prefix,
        )

    def submit(self, fn, *args, **kwargs):
        return self._pool.submit(fn, *args, **kwargs)

    def shutdown(self, wait=False, cancel_futures=True):
        try:
            self._pool.shutdown(wait=wait, cancel_futures=cancel_futures)
        except TypeError:
            self._pool.shutdown(wait=wait)


class UIBridge:
    """
    Hub duy nhất cho mọi UI update từ background thread.
    """

    def __init__(self, tk_master, flush_ms=100):
        self.tk_master = tk_master
        self._coal = WidgetCoalescer(tk_master, flush_ms=flush_ms)
        self._logger = None
        self._status_updater = None
        self._pool = None

    def attach_logger(self, widget, flush_ms=120, max_lines=1500):
        self._logger = attach_logger(
            self.tk_master, widget, tk_master=self.tk_master, flush_ms=flush_ms, max_lines=max_lines
        )
        return self._logger

    def log(self, msg: str):
        if self._logger:
            self._logger.log(msg)

    def widget_set(self, widget, **kwargs):
        """Drop-in thay cho: self.after(0, lambda: widget.configure(**kwargs))"""
        self._coal.set(widget, **kwargs)

    def run_in_ui(self, fn):
        """Drop-in thay cho: self.after(0, fn) — gộp vào batch coalescer."""
        self._coal.call(fn)

    def attach_status_updater(self, apply_func, key_func=None, flush_ms=120):
        self._status_updater = attach_status_updater(
            self.tk_master, apply_func, key_func=key_func, tk_master=self.tk_master, flush_ms=flush_ms
        )
        return self._status_updater

    def status_update(self, *payload):
        if self._status_updater:
            self._status_updater.update(*payload)

    def attach_pool(self, max_workers=8, thread_name_prefix="ui-worker"):
        self._pool = BoundedThreadPool(max_workers=max_workers, thread_name_prefix=thread_name_prefix)
        return self._pool

    def submit(self, fn, *args, **kwargs):
        if self._pool is None:
            self.attach_pool()
        return self._pool.submit(fn, *args, **kwargs)

    def flush_now(self):
        self._coal.flush_now()
        if self._status_updater:
            self._status_updater.flush_now()

    def close(self):
        self._coal.close()
        if self._logger:
            self._logger.close()
        if self._status_updater:
            self._status_updater.close()
        if self._pool:
            self._pool.shutdown(wait=False)


def attach_ui_bridge(owner, log_widget=None, flush_ms=100, max_workers=8):
    """
    Gắn UIBridge vào owner trong 1 dòng.
        self.ui = attach_ui_bridge(self, self.log_box)
    """
    bridge = UIBridge(owner, flush_ms=flush_ms)
    if log_widget is not None:
        bridge.attach_logger(log_widget)
    bridge.attach_pool(max_workers=max_workers)
    owner.ui = bridge
    return bridge
