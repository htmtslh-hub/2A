"""
multi_llm_bridge.py — Trung tâm API Đa Hãng (Multi-Provider LLM & Multimodal Gateway) cho Film studio
─────────────────────────────────────────────────────────────────────────────────────────────────────
Hỗ trợ 8 hệ sinh thái AI lớn + tự động xoay vòng Key (Key Rotation) & chuyển mạch dự phòng (Failover):
  1. Google Gemini   (gemini-2.5-flash, gemini-2.5-pro, gemini-2.0-flash)
  2. OpenAI          (gpt-4o, gpt-4o-mini, gpt-4.1, o3-mini)
  3. Anthropic       (claude-sonnet-4-20250514, claude-3-7-sonnet-latest, claude-3-5-sonnet-latest, claude-3-5-haiku-latest)
  4. DeepSeek        (deepseek-chat [V3], deepseek-reasoner [R1])
  5. Groq            (llama-3.3-70b-versatile, meta-llama/llama-4-scout-17b-16e-instruct, qwen-qwq-32b)
  6. xAI (Grok)      (grok-3-beta, grok-2-vision-1212, grok-2-latest)
  7. OpenRouter      (google/gemini-2.5-flash, anthropic/claude-3.7-sonnet, deepseek/deepseek-chat-v3-0324:free, openai/gpt-4o-mini)
  8. Custom / 9Router(OpenAI-Compatible endpoint bất kỳ: 9Router, Ollama, vLLM, LM Studio, OneAPI...)
"""

from __future__ import annotations

import base64
import io
import json
import os
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import requests

try:
    from PIL import Image
except Exception:
    Image = None

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SRC_DIR, "ai_providers.json")
GEMINI_TXT_FILE = os.path.join(SRC_DIR, "gemini.txt")

PROVIDERS_META: Dict[str, Dict[str, Any]] = {
    "gemini": {
        "name": "✨ Google Gemini",
        "short": "Gemini",
        "base_url": "https://generativelanguage.googleapis.com/v1beta",
        "models": [
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.0-flash",
            "gemini-1.5-flash",
        ],
        "default_model": "gemini-2.5-flash",
        "key_hint": "AIzaSy... (Mỗi dòng 1 Gemini API Key — lấy tại aistudio.google.com)",
        "supports_vision": True,
    },
    "openai": {
        "name": "🟢 OpenAI (ChatGPT)",
        "short": "OpenAI",
        "base_url": "https://api.openai.com/v1",
        "models": [
            "gpt-4o-mini",
            "gpt-4o",
            "gpt-4.1",
            "gpt-4.1-mini",
            "o3-mini",
        ],
        "default_model": "gpt-4o-mini",
        "key_hint": "sk-proj-... (Mỗi dòng 1 OpenAI API Key — lấy tại platform.openai.com)",
        "supports_vision": True,
    },
    "anthropic": {
        "name": "🟠 Anthropic (Claude)",
        "short": "Anthropic",
        "base_url": "https://api.anthropic.com/v1",
        "models": [
            "claude-3-7-sonnet-latest",
            "claude-sonnet-4-20250514",
            "claude-3-5-sonnet-latest",
            "claude-3-5-haiku-latest",
        ],
        "default_model": "claude-3-7-sonnet-latest",
        "key_hint": "sk-ant-api03-... (Mỗi dòng 1 Claude API Key — lấy tại console.anthropic.com)",
        "supports_vision": True,
    },
    "deepseek": {
        "name": "🐋 DeepSeek (V3 / R1)",
        "short": "DeepSeek",
        "base_url": "https://api.deepseek.com/v1",
        "models": [
            "deepseek-chat",
            "deepseek-reasoner",
        ],
        "default_model": "deepseek-chat",
        "key_hint": "sk-... (Mỗi dòng 1 DeepSeek API Key — lấy tại platform.deepseek.com)",
        "supports_vision": False,
    },
    "groq": {
        "name": "⚡ Groq (Llama / Qwen)",
        "short": "Groq",
        "base_url": "https://api.groq.com/openai/v1",
        "models": [
            "llama-3.3-70b-versatile",
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "qwen-qwq-32b",
            "llama-3.1-8b-instant",
        ],
        "default_model": "llama-3.3-70b-versatile",
        "key_hint": "gsk_... (Mỗi dòng 1 Groq API Key — lấy tại console.groq.com)",
        "supports_vision": True,
    },
    "xai": {
        "name": "✖️ xAI (Grok)",
        "short": "xAI Grok",
        "base_url": "https://api.x.ai/v1",
        "models": [
            "grok-3-beta",
            "grok-3-mini-beta",
            "grok-2-vision-1212",
            "grok-2-latest",
        ],
        "default_model": "grok-3-beta",
        "key_hint": "xai-... (Mỗi dòng 1 xAI API Key — lấy tại console.x.ai)",
        "supports_vision": True,
    },
    "openrouter": {
        "name": "🌐 OpenRouter (Đa Model)",
        "short": "OpenRouter",
        "base_url": "https://openrouter.ai/api/v1",
        "models": [
            "google/gemini-2.5-flash",
            "anthropic/claude-3.7-sonnet",
            "openai/gpt-4o-mini",
            "deepseek/deepseek-chat-v3-0324:free",
            "meta-llama/llama-3.3-70b-instruct:free",
        ],
        "default_model": "google/gemini-2.5-flash",
        "key_hint": "sk-or-v1-... (Mỗi dòng 1 OpenRouter Key — lấy tại openrouter.ai)",
        "supports_vision": True,
    },
    "custom": {
        "name": "🔧 Custom / 9Router / Local",
        "short": "Custom",
        "base_url": "http://127.0.0.1:20128/v1",
        "models": [
            "ag/gemini-3.8-flash-high",
            "ag/gemini-2.5-pro",
            "ag/claude-3-7-sonnet",
            "gpt-4o-mini",
        ],
        "default_model": "ag/gemini-3.8-flash-high",
        "key_hint": "Nhập API Key cho Endpoint tương thích OpenAI (hoặc để trống nếu chạy Local/Ollama)",
        "supports_vision": True,
    },
}

_LOCK = threading.Lock()
_KEY_INDICES: Dict[str, int] = {k: 0 for k in PROVIDERS_META}


def load_config() -> Dict[str, Any]:
    """Đọc cấu hình đa hãng từ ai_providers.json và tự đồng bộ với gemini.txt."""
    cfg: Dict[str, Any] = {
        "active_provider": "auto",  # 'auto' hoặc mã hãng ('gemini', 'openai', 'anthropic', 'deepseek'...)
        "providers": {},
    }
    for pid, meta in PROVIDERS_META.items():
        cfg["providers"][pid] = {
            "keys": [],
            "model": meta["default_model"],
            "base_url": meta["base_url"],
        }

    if os.path.isfile(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                if saved.get("active_provider"):
                    cfg["active_provider"] = saved["active_provider"]
                saved_provs = saved.get("providers") or {}
                for pid in PROVIDERS_META:
                    if pid in saved_provs and isinstance(saved_provs[pid], dict):
                        p_in = saved_provs[pid]
                        keys = [str(k).strip() for k in (p_in.get("keys") or []) if str(k).strip()]
                        cfg["providers"][pid]["keys"] = keys
                        if p_in.get("model"):
                            cfg["providers"][pid]["model"] = str(p_in["model"]).strip()
                        if p_in.get("base_url"):
                            cfg["providers"][pid]["base_url"] = str(p_in["base_url"]).strip()
        except Exception:
            pass

    # Đồng bộ 2 chiều với gemini.txt để tương thích ngược
    if os.path.isfile(GEMINI_TXT_FILE):
        try:
            with open(GEMINI_TXT_FILE, "r", encoding="utf-8", errors="ignore") as f:
                gem_keys = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]
            for gk in gem_keys:
                detected = detect_provider_from_key(gk)
                target_pid = detected or "gemini"
                if gk not in cfg["providers"][target_pid]["keys"]:
                    cfg["providers"][target_pid]["keys"].append(gk)
        except Exception:
            pass

    return cfg


def save_config(cfg: Dict[str, Any]) -> None:
    """Lưu cấu hình đa hãng vào ai_providers.json và đồng bộ key Gemini ra gemini.txt."""
    with _LOCK:
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

        gem_keys = (cfg.get("providers", {}).get("gemini", {}) or {}).get("keys") or []
        try:
            with open(GEMINI_TXT_FILE, "w", encoding="utf-8") as f:
                f.write("\n".join(gem_keys) + ("\n" if gem_keys else ""))
        except Exception:
            pass


def detect_provider_from_key(api_key: str) -> Optional[str]:
    """Tự động nhận diện hãng AI dựa trên tiền tố API key."""
    k = (api_key or "").strip()
    if not k:
        return None
    if k.startswith("AIza"):
        return "gemini"
    if k.startswith("sk-ant-"):
        return "anthropic"
    if k.startswith("gsk_"):
        return "groq"
    if k.startswith("sk-or-"):
        return "openrouter"
    if k.startswith("xai-"):
        return "xai"
    return None


def get_summary_badge() -> str:
    """Trả về nhãn tóm tắt số hãng / số key đã cài đặt để hiển thị trên nút Sidebar."""
    cfg = load_config()
    active = cfg.get("active_provider", "auto")
    provs = cfg.get("providers", {})
    total_keys = sum(len(v.get("keys") or []) for v in provs.values())
    active_provs = [PROVIDERS_META[p]["short"] for p, v in provs.items() if v.get("keys") and p in PROVIDERS_META]

    if total_keys == 0:
        return "🤖 API Đa Hãng (0)"
    if active != "auto" and active in PROVIDERS_META:
        k_cnt = len((provs.get(active) or {}).get("keys") or [])
        return f"🤖 API: {PROVIDERS_META[active]['short']} ({k_cnt or total_keys})"
    if len(active_provs) == 1:
        return f"🤖 API: {active_provs[0]} ({total_keys})"
    return f"🤖 API Đa Hãng ({total_keys} key)"


def get_ordered_candidate_providers(preferred_provider: Optional[str] = None, require_vision: bool = False) -> List[Tuple[str, Dict[str, Any]]]:
    """Lấy danh sách các hãng có API key theo thứ tự ưu tiên."""
    cfg = load_config()
    provs = cfg.get("providers", {})
    active = preferred_provider or cfg.get("active_provider", "auto")

    order: List[str] = []
    if active and active != "auto" and active in PROVIDERS_META:
        order.append(active)
    for pid in ("gemini", "openai", "anthropic", "deepseek", "groq", "xai", "openrouter", "custom"):
        if pid not in order:
            order.append(pid)

    result: List[Tuple[str, Dict[str, Any]]] = []
    for pid in order:
        p_cfg = provs.get(pid) or {}
        keys = p_cfg.get("keys") or []
        if not keys and pid != "custom":
            continue
        if pid == "custom" and not keys and active != "custom":
            continue
        if require_vision and not PROVIDERS_META[pid].get("supports_vision", False):
            continue
        result.append((pid, p_cfg))
    return result


# ─────────────────────────────────────────────────────────────────────────────
# HÀM GỌI TRỰC TIẾP TỪNG HÃNG (GEMINI / OPENAI-COMPATIBLE / ANTHROPIC)
# ─────────────────────────────────────────────────────────────────────────────
def _call_gemini(
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    images_b64: Optional[List[str]] = None,
    temperature: float = 0.6,
    timeout: int = 90,
) -> str:
    clean_model = (model or "gemini-2.5-flash").replace("models/", "").strip()
    candidates = [clean_model]
    for fallback_m in ("gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"):
        if fallback_m not in candidates:
            candidates.append(fallback_m)

    parts: List[Dict[str, Any]] = []
    if system_prompt:
        parts.append({"text": f"{system_prompt.strip()}\n\n{prompt.strip()}"})
    else:
        parts.append({"text": prompt.strip()})

    for b64 in images_b64 or []:
        parts.append({"inline_data": {"mime_type": "image/jpeg", "data": b64}})

    last_err = None
    for m in candidates:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={api_key}"
        payload = {
            "contents": [{"parts": parts}],
            "generationConfig": {"temperature": temperature},
        }
        try:
            r = requests.post(url, json=payload, timeout=timeout)
            if r.status_code == 200:
                data = r.json()
                cands = data.get("candidates") or []
                if cands:
                    r_parts = (cands[0].get("content") or {}).get("parts") or []
                    txt = "".join(p.get("text", "") for p in r_parts).strip()
                    if txt:
                        return txt
            last_err = RuntimeError(f"Gemini HTTP {r.status_code}: {r.text[:220]}")
            if r.status_code in (401, 403, 429):
                break
        except Exception as e:
            last_err = e
    raise last_err or RuntimeError("Không gọi được Google Gemini API.")


def _call_anthropic(
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    images_b64: Optional[List[str]] = None,
    temperature: float = 0.6,
    timeout: int = 90,
) -> str:
    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        " content-type": "application/json",
        "Content-Type": "application/json",
    }
    content_blocks: List[Dict[str, Any]] = []
    for b64 in images_b64 or []:
        content_blocks.append(
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": b64,
                },
            }
        )
    content_blocks.append({"type": "text", "text": prompt.strip()})

    payload: Dict[str, Any] = {
        "model": model or "claude-3-7-sonnet-latest",
        "max_tokens": 4096,
        "temperature": temperature,
        "messages": [{"role": "user", "content": content_blocks}],
    }
    if system_prompt:
        payload["system"] = system_prompt.strip()

    r = requests.post(url, headers=headers, json=payload, timeout=timeout)
    if r.status_code == 200:
        data = r.json()
        blocks = data.get("content") or []
        txt = "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()
        if txt:
            return txt
    raise RuntimeError(f"Anthropic HTTP {r.status_code}: {r.text[:240]}")


def _call_openai_compatible(
    base_url: str,
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    images_b64: Optional[List[str]] = None,
    temperature: float = 0.6,
    timeout: int = 90,
) -> str:
    url = f"{base_url.rstrip('/')}/chat/completions"
    headers: Dict[str, str] = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    if "openrouter.ai" in base_url:
        headers["HTTP-Referer"] = "https://filmstudio.ai"
        headers["X-Title"] = "Film studio"

    messages: List[Dict[str, Any]] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt.strip()})

    if images_b64:
        user_content: List[Dict[str, Any]] = [{"type": "text", "text": prompt.strip()}]
        for b64 in images_b64:
            user_content.append(
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{b64}"},
                }
            )
        messages.append({"role": "user", "content": user_content})
    else:
        messages.append({"role": "user", "content": prompt.strip()})

    payload: Dict[str, Any] = {
        "model": model,
        "messages": messages,
    }
    # o1 / o3-mini / deepseek-reasoner không nhận temperature tùy chỉnh ở một số endpoint
    if not any(x in (model or "").lower() for x in ("o1", "o3", "reasoner")):
        payload["temperature"] = temperature

    r = requests.post(url, headers=headers, json=payload, timeout=timeout)
    if r.status_code == 200:
        data = r.json()
        choices = data.get("choices") or []
        if choices:
            msg = choices[0].get("message") or {}
            txt = (msg.get("content") or "").strip()
            if txt:
                return txt
    raise RuntimeError(f"HTTP {r.status_code}: {r.text[:240]}")


def call_single_provider(
    pid: str,
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    images_b64: Optional[List[str]] = None,
    base_url: str = "",
    temperature: float = 0.6,
    timeout: int = 90,
) -> str:
    """Gọi 1 hãng cụ thể với key và model chỉ định."""
    meta = PROVIDERS_META.get(pid, PROVIDERS_META["openai"])
    eff_model = (model or meta["default_model"]).strip()
    eff_base = (base_url or meta["base_url"]).strip()

    if pid == "gemini":
        return _call_gemini(api_key, eff_model, prompt, system_prompt, images_b64, temperature, timeout)
    elif pid == "anthropic":
        return _call_anthropic(api_key, eff_model, prompt, system_prompt, images_b64, temperature, timeout)
    else:
        return _call_openai_compatible(eff_base, api_key, eff_model, prompt, system_prompt, images_b64, temperature, timeout)


def generate_text(
    prompt: str,
    system_prompt: str = "",
    preferred_provider: Optional[str] = None,
    temperature: float = 0.6,
    timeout: int = 90,
) -> Tuple[bool, str, str]:
    """
    Sinh văn bản qua hệ thống API Đa Hãng (tự động xoay vòng key và chuyển mạch dự phòng).
    Trả về: (ok, response_text, provider_label_or_error)
    """
    candidates = get_ordered_candidate_providers(preferred_provider=preferred_provider, require_vision=False)
    if not candidates:
        return False, "", "Chưa cấu hình API Key nào trong mục Cài đặt API."

    last_err = ""
    for pid, p_cfg in candidates:
        keys = p_cfg.get("keys") or ([""] if pid == "custom" else [])
        model = p_cfg.get("model") or PROVIDERS_META[pid]["default_model"]
        base_url = p_cfg.get("base_url") or PROVIDERS_META[pid]["base_url"]
        short_name = PROVIDERS_META[pid]["short"]

        for _ in range(max(1, len(keys))):
            idx = _KEY_INDICES.get(pid, 0) % len(keys)
            key = keys[idx]
            try:
                txt = call_single_provider(
                    pid=pid,
                    api_key=key,
                    model=model,
                    prompt=prompt,
                    system_prompt=system_prompt,
                    images_b64=None,
                    base_url=base_url,
                    temperature=temperature,
                    timeout=timeout,
                )
                if txt and txt.strip():
                    return True, txt.strip(), f"{short_name} ({model})"
            except Exception as e:
                last_err = f"[{short_name}] {e}"
                _KEY_INDICES[pid] = idx + 1
                time.sleep(0.2)

    return False, "", last_err or "Tất cả API Key đều lỗi hoặc hết hạn mức."


def generate_multimodal(
    content_list: list,
    preferred_provider: Optional[str] = None,
    temperature: float = 0.4,
    timeout: int = 90,
) -> Tuple[bool, str, str]:
    """
    Phân tích đa phương thức (Văn bản + Khung hình ảnh PIL) qua các hãng hỗ trợ Vision
    (Gemini, OpenAI, Anthropic, Groq Llama-4, xAI Grok, OpenRouter).
    """
    text_parts: List[str] = []
    images_b64: List[str] = []

    for item in content_list:
        if isinstance(item, str):
            text_parts.append(item)
        elif Image is not None and isinstance(item, Image.Image):
            buf = io.BytesIO()
            item.convert("RGB").save(buf, format="JPEG", quality=82)
            images_b64.append(base64.b64encode(buf.getvalue()).decode("ascii"))

    prompt = "\n\n".join(text_parts).strip()
    candidates = get_ordered_candidate_providers(preferred_provider=preferred_provider, require_vision=bool(images_b64))
    if not candidates and images_b64:
        # Nếu hãng đang chọn (vd DeepSeek) không nhận ảnh trực tiếp, thử gọi text-only hoặc hãng khác
        candidates = get_ordered_candidate_providers(preferred_provider=preferred_provider, require_vision=False)
        images_b64 = []

    if not candidates:
        return False, "", "Chưa cấu hình API Key nào."

    last_err = ""
    for pid, p_cfg in candidates:
        keys = p_cfg.get("keys") or ([""] if pid == "custom" else [])
        model = p_cfg.get("model") or PROVIDERS_META[pid]["default_model"]
        base_url = p_cfg.get("base_url") or PROVIDERS_META[pid]["base_url"]
        short_name = PROVIDERS_META[pid]["short"]

        for _ in range(max(1, len(keys))):
            idx = _KEY_INDICES.get(pid, 0) % len(keys)
            key = keys[idx]
            try:
                txt = call_single_provider(
                    pid=pid,
                    api_key=key,
                    model=model,
                    prompt=prompt,
                    system_prompt="",
                    images_b64=images_b64 if PROVIDERS_META[pid].get("supports_vision") else None,
                    base_url=base_url,
                    temperature=temperature,
                    timeout=timeout,
                )
                if txt and txt.strip():
                    return True, txt.strip(), f"{short_name} ({model})"
            except Exception as e:
                last_err = f"[{short_name}] {e}"
                _KEY_INDICES[pid] = idx + 1
                time.sleep(0.2)

    return False, "", last_err or "Lỗi gọi API đa phương thức."
