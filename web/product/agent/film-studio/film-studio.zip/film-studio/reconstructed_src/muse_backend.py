"""
muse_backend.py — Tạo video bằng Muse (muse.ai) qua Chrome/Edge + CDP.

Port từ bản `c.py` của tool Muse sang dạng ĐỒNG BỘ (threading) để dùng chung
trực tiếp trong Film Studio.

Cách chạy của Muse:
  1. Mở Chrome/Edge với một thư mục profile riêng + --remote-debugging-port.
  2. Mở tab https://muse.ai/thread/new, tiêm engine/page_helper.js vào trang.
     Helper tạo ra window.__qt với các hàm: state() / send() / result() /
     rawOpen() / rawSlice() / rawClose() / resetChat().
  3. send(message, attachments) → đẩy prompt + ảnh (base64) vào React Chat
     Controller của Muse, trả về sessionId.
  4. result(sessionId) → poll tới khi có media.
  5. rawOpen/rawSlice/rawClose → tải file về theo từng khúc 2MB.

Đăng nhập Muse là đăng nhập THEO PROFILE CHROME (không phải token). Mỗi thư
mục con trong `muse_profiles/` là một tài khoản đã đăng nhập sẵn.
"""

from __future__ import annotations

import asyncio
import base64
import datetime
import json
import mimetypes
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from contextlib import contextmanager
from pathlib import Path

try:
    import websockets.asyncio.client as ws_client
except Exception:
    ws_client = None

BASE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
HELPER_FILE = BASE_DIR / "engine" / "page_helper.js"
MUSE_URL = "https://muse.ai/thread/new"
REFUSAL_FILE = "muse_tu_choi.txt"
SLICE = 2 * 1024 * 1024

RATIO_VI = {
    "9:16": "9:16 dọc",
    "16:9": "16:9 ngang",
    "1:1": "1:1 vuông",
    "4:3": "4:3 ngang",
    "3:4": "3:4 dọc",
}
RATIOS = list(RATIO_VI.keys())

_REFUSAL_RE = re.compile(
    r"(không thể tạo|không được phép|vi phạm|chính sách|policy|cannot generate|can't generate|unable to generate|i cannot|i can't|sorry, i)",
    re.IGNORECASE,
)


def _profile_root() -> Path:
    """Thư mục chứa các profile Chrome đã đăng nhập Muse.

    Mặc định là `muse_profiles/` cạnh file này. Muốn NHIỀU TOOL dùng CHUNG một
    lần đăng nhập thì đặt biến môi trường MUSE_PROFILE_ROOT, hoặc tạo file
    `muse_profiles.txt` cạnh file này và ghi đường dẫn thư mục dùng chung vào.
    """
    env = os.environ.get("MUSE_PROFILE_ROOT", "").strip()
    if env:
        return Path(env)
    cfg = BASE_DIR / "muse_profiles.txt"
    if cfg.is_file():
        try:
            for line in cfg.read_text(encoding="utf-8").splitlines():
                t = line.strip()
                if t and not t.startswith("#"):
                    return Path(t)
        except Exception:
            pass
    return BASE_DIR / "muse_profiles"


PROFILE_ROOT = _profile_root()


class MuseError(Exception):
    """Muse báo lỗi hoặc không trả về kết quả."""


class MuseStopped(MuseError):
    """Người dùng bấm Dừng."""


class MuseRefused(MuseError):
    """Muse trả lời bằng CHỮ và không dựng video."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class CDPError(MuseError):
    """Lỗi giao thức Chrome DevTools."""


def looks_like_refusal(text: str) -> bool:
    if not text:
        return False
    return bool(_REFUSAL_RE.search(text)) or len(text.strip()) > 25


def ghi_tu_choi(out_dir: str | Path, so_dong: int, prompt: str, loi_muse: str) -> Path:
    """Ghi lại prompt bị Muse từ chối + nguyên văn lời từ chối vào `<thư mục video>/muse_tu_choi.txt`."""
    out_p = Path(out_dir)
    out_p.mkdir(parents=True, exist_ok=True)
    path = out_p / REFUSAL_FILE
    now_str = datetime.datetime.now().strftime("%d/%m %H:%M:%S")
    khoi = (
        f"────────────────────────────────────────────────────────────────────────\n"
        f"[{now_str}]  DÒNG #{so_dong:03d}\n\n"
        f"PROMPT ĐÃ GỬI:\n{prompt}\n\n"
        f"MUSE TRẢ LỜI:\n{loi_muse}\n\n"
    )
    with open(path, "a", encoding="utf-8") as f:
        f.write(khoi)
    return path


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def list_targets(port: int) -> list[dict]:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=3) as r:
        return json.load(r)


def find_browser() -> str:
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p
    for name in ("chrome", "msedge"):
        found = shutil.which(name)
        if found:
            return found
    raise MuseError("Không tìm thấy Google Chrome hoặc Microsoft Edge")


def kill_profile_browsers(profile: Path):
    """Tắt mọi Chrome/Edge còn sót đang giữ thư mục profile này."""
    try:
        folder = str(profile.resolve()).replace("'", "''")
        script = (
            "Get-CimInstance Win32_Process -Filter \"name='chrome.exe' or name='msedge.exe'\" | "
            f"Where-Object {{ $_.CommandLine -like '*{folder}*' }} | "
            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True,
            timeout=15,
            creationflags=0x08000000,
        )
    except Exception:
        pass


class CDPSession:
    def __init__(self, ws_url: str):
        self.ws_url = ws_url
        self.ws = None
        self.next_id = 0
        self.pending: dict[int, asyncio.Future] = {}
        self.reader: asyncio.Task | None = None

    def alive(self) -> bool:
        if self.ws is None:
            return False
        closed = getattr(self.ws, "closed", None)
        if closed is not None:
            return not closed
        state = getattr(self.ws, "state", None)
        return state is not None and getattr(state, "name", "") == "OPEN"

    async def connect(self):
        if ws_client is None:
            raise MuseError("Thiếu thư viện websockets")
        self.ws = await ws_client.connect(
            self.ws_url,
            max_size=64 * 1024 * 1024,
            ping_interval=20,
            ping_timeout=60,
        )
        self.reader = asyncio.create_task(self._read())

    async def _read(self):
        try:
            async for raw in self.ws:
                msg = json.loads(raw)
                msg_id = msg.get("id")
                if msg_id is not None:
                    fut = self.pending.pop(msg_id, None)
                    if fut and not fut.done():
                        if "error" in msg:
                            fut.set_exception(CDPError(msg["error"].get("message", "CDP error")))
                        else:
                            fut.set_result(msg.get("result", {}))
        except Exception:
            pass
        finally:
            for fut in self.pending.values():
                if not fut.done():
                    fut.set_exception(CDPError("Mất kết nối với Chrome"))
            self.pending.clear()

    async def send(self, method: str, params: dict | None = None, timeout: float = 30.0) -> dict:
        if not self.alive():
            raise CDPError("Chưa kết nối Chrome")
        loop = asyncio.get_running_loop()
        self.next_id += 1
        req_id = self.next_id
        fut = loop.create_future()
        self.pending[req_id] = fut
        await self.ws.send(json.dumps({"id": req_id, "method": method, "params": params or {}}))
        return await asyncio.wait_for(fut, timeout=timeout)

    async def evaluate(self, expression: str, timeout: float = 30.0):
        res = await self.send(
            "Runtime.evaluate",
            {"expression": expression, "awaitPromise": True, "returnByValue": True},
            timeout=timeout,
        )
        if "exceptionDetails" in res:
            details = res["exceptionDetails"]
            exc = details.get("exception", {})
            raise CDPError(exc.get("description") or details.get("text") or "JS error")
        return res.get("result", {}).get("value")

    async def close(self):
        if self.reader:
            self.reader.cancel()
        if self.ws:
            try:
                await self.ws.close()
            except Exception:
                pass


class Chrome:
    def __init__(self, visible: bool = False, profile: Path | None = None, port: int | None = None):
        self.visible = visible
        self.port = port or free_port()
        self.profile = profile or (PROFILE_ROOT / "acc_01")
        self.process: subprocess.Popen | None = None
        self.session: CDPSession | None = None
        self.launched = False
        self._launch_log = None
        self._parent_chrome: Chrome | None = None
        self.target_id: str | None = None

    @staticmethod
    def _port_is_free(port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind(("127.0.0.1", port))
                return True
            except OSError:
                return False

    def _running_port(self) -> int:
        port_file = self.profile / "DevToolsActivePort"
        if not port_file.is_file():
            return 0
        try:
            lines = port_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            port = int(lines[0].strip())
            list_targets(port)
            return port
        except (OSError, ValueError, IndexError):
            return 0

    async def _attach_existing(self) -> bool:
        port = self._running_port()
        if not port:
            return False
        self.port = port
        targets = list_targets(port)
        pages = [t for t in targets if t.get("type") == "page"]
        page = next((t for t in pages if "muse.ai" in t.get("url", "")), pages[0] if pages else None)
        if not page:
            return False
        self.target_id = page.get("id")
        self.session = CDPSession(page["webSocketDebuggerUrl"])
        await self.session.connect()
        await self.set_visible(self.visible)
        return True

    async def _launch(self, browser: str, log_path: Path) -> list[dict]:
        if not self._port_is_free(self.port):
            self.port = free_port()
        for lock_name in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
            lock_file = self.profile / lock_name
            if lock_file.exists():
                try:
                    lock_file.unlink()
                except OSError:
                    pass
        position = "80,40" if self.visible else "-3000,-3000"
        args = [
            browser,
            f"--user-data-dir={self.profile.resolve()}",
            f"--remote-debugging-port={self.port}",
            "--remote-debugging-address=127.0.0.1",
            "--no-first-run",
            "--no-default-browser-check",
            "--remote-allow-origins=*",
            "--disable-default-apps",
            "--disable-features=Translate,MediaRouter",
            "--disable-backgrounding-occluded-windows",
            f"--window-position={position}",
            "--window-size=1280,860",
            MUSE_URL,
        ]
        self._launch_log = open(log_path, "ab")
        self.process = subprocess.Popen(
            args,
            stdout=self._launch_log,
            stderr=subprocess.STDOUT,
            creationflags=0x08000000 if not self.visible else 0,
        )
        self.launched = True
        gave_up_at = time.time() + 20.0
        while time.time() < gave_up_at:
            if self.process.poll() is not None:
                break
            try:
                targets = list_targets(self.port)
                if targets:
                    return targets
            except Exception:
                pass
            await asyncio.sleep(0.35)
        raise MuseError("Chrome đã thoát sớm hoặc không phản hồi CDP")

    async def start(self):
        self.profile.mkdir(parents=True, exist_ok=True)
        if await self._attach_existing():
            return
        browser = find_browser()
        log_path = self.profile / "cdp-launch.log"
        last_error = ""
        for attempt in range(1, 3):
            try:
                if attempt > 1:
                    kill_profile_browsers(self.profile)
                targets = await self._launch(browser, log_path)
                pages = [t for t in targets if t.get("type") == "page"]
                if not pages:
                    req = urllib.request.Request(f"http://127.0.0.1:{self.port}/json/new?about:blank", method="PUT")
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        page = json.load(resp)
                else:
                    page = next((t for t in pages if "muse.ai" in t.get("url", "")), pages[0])
                self.target_id = page.get("id")
                self.session = CDPSession(page["webSocketDebuggerUrl"])
                await self.session.connect()
                await self.set_visible(self.visible)
                return
            except Exception as exc:
                last_error = str(exc)
                await self._drop_process()
        raise MuseError(
            f"Chrome không mở được cho profile '{self.profile.name}'. "
            f"Thường là do một cửa sổ Chrome khác đang dùng profile này — hãy đóng rồi thử lại. Chi tiết: {last_error}"
        )

    async def _drop_process(self):
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass
            self.process = None
        if self._launch_log:
            try:
                self._launch_log.close()
            except Exception:
                pass
            self._launch_log = None

    async def attach_target(self, target: dict):
        self.target_id = target.get("id")
        self.session = CDPSession(target["webSocketDebuggerUrl"])
        await self.session.connect()

    async def new_tab(self, url: str = MUSE_URL) -> Chrome:
        encoded = urllib.parse.quote(url, safe=":/?&=#")
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}/json/new?{encoded}", method="PUT")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                target = json.load(resp)
        except Exception as exc:
            raise MuseError(f"Chrome của profile '{self.profile.name}' không còn nhận lệnh mở tab ({exc})")
        child = Chrome(visible=self.visible, profile=self.profile, port=self.port)
        child._parent_chrome = self
        await child.attach_target(target)
        return child

    async def set_visible(self, visible: bool):
        self.visible = visible
        if not self.session or not self.session.alive():
            return
        try:
            info = await self.session.send("Browser.getWindowForTarget", {}, timeout=5)
            window_id = info.get("windowId")
            if window_id:
                bounds = {"left": 80, "top": 40, "windowState": "normal"} if visible else {"left": -3000, "top": -3000, "windowState": "normal"}
                await self.session.send("Browser.setWindowBounds", {"windowId": window_id, "bounds": bounds}, timeout=5)
            if visible:
                await self.session.send("Page.bringToFront", {}, timeout=5)
        except Exception:
            pass

    async def close(self, terminate_browser: bool = True):
        if self.session:
            await self.session.close()
            self.session = None
        if self._parent_chrome is not None and self.target_id:
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{self.port}/json/close/{self.target_id}", timeout=3)
            except Exception:
                pass
            return
        if terminate_browser:
            await self._drop_process()


def _read_helper() -> str:
    if not HELPER_FILE.is_file():
        raise MuseError(f"Thiếu file helper: {HELPER_FILE}")
    txt = HELPER_FILE.read_text(encoding="utf-8")
    return txt.replace("Object[_0x4b4d5a(0xfe)](_0x530b20)", "Object[_0x4b4d5a(0xfe)](_0x530b20||{})")


class Muse:
    def __init__(self, visible: bool = False, profile: Path | None = None, port: int | None = None):
        self.chrome = Chrome(visible=visible, profile=profile, port=port)
        self.helper = _read_helper()

    @classmethod
    async def from_chrome(cls, chrome: Chrome) -> Muse:
        m = cls(visible=chrome.visible, profile=chrome.profile, port=chrome.port)
        m.chrome = chrome
        await m._initialize_page()
        return m

    async def open(self):
        await self.chrome.start()
        await self._initialize_page()

    async def _initialize_page(self):
        await self.chrome.session.send("Page.enable")
        current = str(await self.js("location.href") or "")
        if "muse.ai" not in current:
            await self.chrome.session.send("Page.navigate", {"url": MUSE_URL})
            await asyncio.sleep(2.5)
        for _ in range(20):
            await self.js(self.helper, timeout=15)
            ready = await self.js("typeof window.__qt !== 'undefined' && typeof window.__qt.state === 'function'")
            if ready:
                return
            await asyncio.sleep(0.5)
        raise MuseError("Không nạp được helper Muse vào tab trình duyệt")

    async def js(self, expression: str, timeout: float = 30.0):
        if not self.chrome.session:
            raise MuseError("Chưa mở Muse")
        return await self.chrome.session.evaluate(expression, timeout=timeout)

    async def ensure_helper(self):
        ok = await self.js("typeof window.__qt !== 'undefined' && typeof window.__qt.state === 'function'")
        if not ok:
            await self.js(self.helper, timeout=15)

    async def state(self) -> dict:
        await self.ensure_helper()
        return await self.js("window.__qt.state()", timeout=15) or {}

    async def wait_ready(self, timeout: float = 45.0, should_stop=None) -> dict:
        started = time.time()
        while time.time() - started < timeout:
            if should_stop and should_stop():
                raise MuseStopped("Người dùng bấm Dừng.")
            st = await self.state()
            if st.get("connected") and st.get("hasChat"):
                return st
            await asyncio.sleep(1.0)
        raise MuseError("Muse chưa sẵn sàng hoặc chưa đăng nhập (mở Quản lý tài khoản → Đăng nhập lại profile)")

    async def submit(
        self,
        prompt: str,
        ratio: str = "16:9",
        reference_paths: list[Path] | None = None,
        kind: str = "video",
        duration: str = "8s",
    ) -> str:
        await self.ensure_helper()
        what = "video" if kind == "video" else "ảnh"
        r_vi = RATIO_VI.get(ratio, ratio)
        dur_num = str(duration).rstrip("s").strip()
        order = f"Tạo {what} khung hình {r_vi}"
        if kind == "video" and dur_num:
            order += f", dài {dur_num} giây"
        message = f"{order}.\n{prompt}\n\nHãy tạo luôn {what} theo prompt này, đừng hỏi gì thêm."

        attachments = []
        for ref_p in reference_paths or []:
            p = Path(ref_p)
            if not p.is_file():
                raise MuseError(f"Không đọc được đầy đủ ảnh tham chiếu trước khi gửi Muse: {p}")
            mime = mimetypes.guess_type(str(p))[0] or "image/jpeg"
            b64 = base64.b64encode(p.read_bytes()).decode("ascii")
            attachments.append(
                {
                    "type": "image",
                    "filename": p.name,
                    "mimeType": mime,
                    "dataBase64": b64,
                }
            )
        expr = f"window.__qt.send({json.dumps(message, ensure_ascii=False)}, {json.dumps(attachments, ensure_ascii=False)})"
        res = await self.js(expr, timeout=120) or {}
        sid = res.get("sessionId") or res.get("id")
        if not sid and not res.get("ok", True):
            raise MuseError(f"Muse không nhận yêu cầu: {res}")
        return str(sid or "")

    async def reset_chat(self):
        await self.ensure_helper()
        return await self.js("window.__qt.resetChat()", timeout=30)

    async def poll(self, session_id: str) -> dict:
        await self.ensure_helper()
        return await self.js(f"window.__qt.result({json.dumps(session_id)})", timeout=30) or {}

    async def download(self, item: dict, progress=None) -> bytes:
        await self.ensure_helper()
        url = item.get("url") or item.get("path")
        if not url:
            raise MuseError(f"Kết quả không có URL: {item}")
        raw = await self.js(f"window.__qt.rawOpen({json.dumps(url)})", timeout=180)
        if not raw or "id" not in raw:
            raise MuseError(f"Không mở được file: {url}")
        handle = raw["id"]
        size = int(raw.get("size") or 0)
        data = bytearray()
        try:
            offset = 0
            while offset < size:
                take = min(SLICE, size - offset)
                chunk_b64 = await self.js(f"window.__qt.rawSlice({handle}, {offset}, {take})", timeout=60)
                chunk = base64.b64decode(chunk_b64)
                data.extend(chunk)
                offset += len(chunk)
                if progress and size > 0:
                    progress(int(offset * 100 / size))
        finally:
            try:
                await self.js(f"window.__qt.rawClose({handle})", timeout=20)
            except Exception:
                pass
        return bytes(data)


class _BackgroundLoop:
    _lock = threading.Lock()
    _instance: _BackgroundLoop | None = None

    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, daemon=True, name="muse-loop")
        self.thread.start()

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    @classmethod
    def get(cls) -> _BackgroundLoop:
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def call(self, coro, timeout: float | None = None):
        fut = asyncio.run_coroutine_threadsafe(coro, self.loop)
        return fut.result(timeout=timeout)


def run_async(coro, timeout: float | None = None):
    return _BackgroundLoop.get().call(coro, timeout=timeout)


def _ensure_root() -> Path:
    global PROFILE_ROOT
    try:
        PROFILE_ROOT.mkdir(parents=True, exist_ok=True)
        return PROFILE_ROOT
    except OSError:
        PROFILE_ROOT = BASE_DIR / "muse_profiles"
        PROFILE_ROOT.mkdir(parents=True, exist_ok=True)
        return PROFILE_ROOT


def discover_profiles() -> list[Path]:
    root = _ensure_root()
    return sorted([p for p in root.iterdir() if p.is_dir()], key=lambda p: p.name.lower())


def ensure_profiles() -> list[Path]:
    profiles = discover_profiles()
    if not profiles:
        default = _ensure_root() / "acc_01"
        default.mkdir(parents=True, exist_ok=True)
        return [default]
    return profiles


def new_profile_path() -> Path:
    root = _ensure_root()
    idx = 1
    while True:
        p = root / f"acc_{idx:02d}"
        if not p.exists():
            p.mkdir(parents=True, exist_ok=True)
            return p
        idx += 1


_login_windows: dict[str, Chrome] = {}


def open_login_window(profile: Path, log=print):
    key = str(profile.resolve())
    old = _login_windows.pop(key, None)
    if old:
        try:
            run_async(old.close(terminate_browser=True), timeout=10)
        except Exception:
            pass

    async def task():
        chrome = Chrome(visible=True, profile=profile)
        await chrome.start()
        return chrome

    try:
        chrome = run_async(task(), timeout=40)
        _login_windows[key] = chrome
        log(f"🌐 Đã mở Chrome cho profile '{profile.name}' — đăng nhập Muse rồi đóng cửa sổ.")
    except Exception as exc:
        log(f"❌ Không mở được Chrome cho profile {profile.name}: {exc}")


def close_login_window(profile: Path):
    key = str(profile.resolve())
    chrome = _login_windows.pop(key, None)
    if chrome:
        try:
            run_async(chrome.close(terminate_browser=True), timeout=10)
        except Exception:
            pass


def check_profile_state(profile: Path, timeout: float = 25.0) -> dict:
    async def task():
        client = Muse(visible=False, profile=profile)
        try:
            await client.open()
            return await client.state()
        finally:
            if str(profile.resolve()) not in _login_windows:
                await client.chrome.close(terminate_browser=True)

    try:
        return run_async(task(), timeout=timeout)
    except Exception as exc:
        return {"connected": False, "hasChat": False, "error": str(exc)}


def _pick_video(media: list[dict]) -> dict | None:
    for item in media or []:
        url = str(item.get("url") or item.get("path") or "").lower()
        if item.get("kind") == "video" or url.endswith((".mp4", ".webm", ".mov")):
            return item
    return media[0] if media else None


class MuseWorker:
    def __init__(self, client: Muse, label: str, profile: Path, pool: MusePool | None = None):
        self.client = client
        self.label = label
        self.profile = profile
        self.pool = pool
        self.lock = threading.Lock()

    def wait_ready(self, timeout: float = 45.0, stop_event: threading.Event | None = None):
        should_stop = (lambda: stop_event.is_set()) if stop_event else None
        return run_async(self.client.wait_ready(timeout=timeout, should_stop=should_stop), timeout=timeout + 5)

    def new_chat(self, log=print):
        try:
            run_async(self.client.reset_chat(), timeout=30)
        except Exception as exc:
            log(f"⚠️ Không mở được chat mới ({exc}) → dựng lại tab Muse…")
            self.revive()

    def revive(self):
        if self.pool:
            self.pool.revive(self)

    def close(self):
        try:
            run_async(self.client.chrome.close(terminate_browser=False), timeout=10)
        except Exception:
            pass

    def generate_video(
        self,
        prompt: str,
        ratio: str,
        image_paths: list[Path],
        out_path: Path,
        status=None,
        stop_event: threading.Event | None = None,
        timeout: float = 480.0,
        duration: str = "8s",
    ) -> Path:
        say = status or (lambda _t: None)

        def stopped() -> bool:
            return bool(stop_event and stop_event.is_set())

        self.wait_ready(timeout=45.0, stop_event=stop_event)
        session_id = run_async(
            self.client.submit(prompt, ratio=ratio, reference_paths=image_paths, kind="video", duration=duration),
            timeout=130,
        )
        started = time.time()
        while time.time() - started < timeout:
            if stopped():
                raise MuseStopped("Người dùng bấm Dừng.")
            res = run_async(self.client.poll(session_id), timeout=35)
            media = res.get("media") or []
            if media:
                picked = _pick_video(media)
                if picked:
                    say("⬇ Đang tải video về…")
                    data = run_async(
                        self.client.download(picked, progress=lambda pct: say(f"⬇ Tải video {pct}%")),
                        timeout=300,
                    )
                    if not data or len(data) < 3500:
                        raise MuseError("Muse trả về file rỗng")
                    out_path.parent.mkdir(parents=True, exist_ok=True)
                    out_path.write_bytes(data)
                    return out_path
            texts = res.get("texts") or []
            if texts:
                reply = "\n".join(texts).strip()
                if looks_like_refusal(reply):
                    raise MuseRefused(reply)
            elapsed = int(time.time() - started)
            say(f"⏳ Muse đang tạo… {elapsed}s")
            time.sleep(3.0)
        raise MuseError(f"Quá thời gian chờ Muse ({int(timeout)}s)")


class MusePool:
    def __init__(
        self,
        threads: int = 1,
        visible: bool = False,
        log=print,
        profiles: list[Path] | None = None,
        stop_event: threading.Event | None = None,
        max_workers: int | None = None,
    ):
        self.threads = max(1, int(threads))
        self.visible = visible
        self.log = log
        self.profiles = profiles
        self.stop_event = stop_event
        self.max_workers = max_workers
        self.workers: list[MuseWorker] = []
        self._masters: dict[str, Chrome] = {}
        self._free: list[MuseWorker] = []
        self._cond = threading.Condition()
        self._rebuild_lock = threading.Lock()

    def _should_stop(self) -> bool:
        return bool(self.stop_event and self.stop_event.is_set())

    def _check_stop(self):
        if self._should_stop():
            raise MuseStopped("Người dùng bấm Dừng.")

    async def _open_master(self, profile: Path) -> Muse:
        client = Muse(visible=self.visible, profile=profile)
        await client.open()
        await client.wait_ready(timeout=45.0, should_stop=self._should_stop)
        return client

    async def _open_tab(self, master: Chrome) -> Muse:
        tab_chrome = await master.new_tab(MUSE_URL)
        client = await Muse.from_chrome(tab_chrome)
        await client.wait_ready(timeout=45.0, should_stop=self._should_stop)
        return client

    def open(self):
        profiles = self.profiles or ensure_profiles()
        if not profiles:
            raise MuseError("Chưa có profile Muse nào — bấm 'Quản lý tài khoản' để thêm")
        cap = self.max_workers or (len(profiles) * self.threads)
        for profile in profiles:
            if len(self.workers) >= cap:
                break
            self._check_stop()
            self.log(f"🌐 Đang mở Muse ({profile.name})…")
            try:
                first_client = run_async(self._open_master(profile), timeout=90)
                self._masters[str(profile.resolve())] = first_client.chrome
                w0 = MuseWorker(first_client, f"{profile.name}#1", profile, pool=self)
                self.workers.append(w0)
                self._free.append(w0)
                for idx in range(2, self.threads + 1):
                    if len(self.workers) >= cap:
                        break
                    self._check_stop()
                    self.log(f"🗂 Mở thêm tab Muse ({profile.name}#{idx})…")
                    tab_client = run_async(self._open_tab(first_client.chrome), timeout=60)
                    w = MuseWorker(tab_client, f"{profile.name}#{idx}", profile, pool=self)
                    self.workers.append(w)
                    self._free.append(w)
            except MuseStopped:
                raise
            except Exception as exc:
                self.log(f"⚠️ Tài khoản '{profile.name}': {exc}")
        if not self.workers:
            raise MuseError("Không tạo được worker Muse nào")
        self.log(f"✅ Muse sẵn sàng: {len(self.workers)} tab / {len(self._masters)} tài khoản")

    def revive(self, worker: MuseWorker):
        with self._rebuild_lock:
            try:
                master = self._masters.get(str(worker.profile.resolve()))
                if master:
                    worker.client = run_async(self._open_tab(master), timeout=60)
                    return
            except Exception as exc:
                self.log(f"⚠️ Tab [{worker.label}] không mở lại được ({exc}); dựng lại Chrome của tài khoản {worker.profile.name}…")
            self._rebuild_profile(worker.profile)

    def _rebuild_profile(self, profile: Path):
        key = str(profile.resolve())
        old_master = self._masters.pop(key, None)
        if old_master:
            try:
                run_async(old_master.close(terminate_browser=True), timeout=10)
            except Exception:
                pass
        kill_profile_browsers(profile)
        victims = [w for w in self.workers if str(w.profile.resolve()) == key]
        if not victims:
            return
        first_client = run_async(self._open_master(profile), timeout=90)
        self._masters[key] = first_client.chrome
        victims[0].client = first_client
        for w in victims[1:]:
            w.client = run_async(self._open_tab(first_client.chrome), timeout=60)
        self.log(f"♻️ Đã dựng lại {len(victims)} tab cho tài khoản {profile.name}")

    @contextmanager
    def acquire(self, stop_event: threading.Event | None = None):
        worker = None
        with self._cond:
            while not self._free:
                if (stop_event and stop_event.is_set()) or self._should_stop():
                    raise MuseStopped("Người dùng bấm Dừng.")
                self._cond.wait(timeout=0.5)
            worker = self._free.pop(0)
        try:
            yield worker
        finally:
            if worker is not None:
                with self._cond:
                    self._free.append(worker)
                    self._cond.notify()

    def close(self):
        for master in list(self._masters.values()):
            try:
                run_async(master.close(terminate_browser=True), timeout=10)
            except Exception:
                pass
        self._masters.clear()
        self.workers.clear()
        self._free.clear()
