"""
HÀ THÀNH VOICE STUDIO  —  HaThanhAuto (openspeaker_tts.py)
────────────────────────────────────────────────────────────────────────────────
Giao diện CustomTkinter, bảng điều khiển bên TRÁI, workspace bên phải.

Máy chủ cấu hình trong SRV_A / SRV_B.
  POST /v3/text-to-speech      -> tạo task
  GET  /v1/task/{task_id}      -> poll đến khi có link
  GET  /v3/voices?provider=..  -> danh sách giọng
  GET  /v1/credits             -> số dư

Tích hợp All-Tool-Youtube: alltool.py gọi mod.build_tab(frame, ...)
"""

import base64
import json
import os
import queue
import random
import re
import subprocess
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
import requests
import ui_openspeaker as _uio

_PYGAME = None


def get_pygame():
    global _PYGAME
    if _PYGAME is not None:
        return _PYGAME
    try:
        os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
        import pygame

        _PYGAME = pygame
    except Exception:
        _PYGAME = False
    return _PYGAME


_KP = "ht"


def wrap_key(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    if s.startswith(_KP) and len(s) > 5 and s[-3:].isdigit():
        return s
    return f"{_KP}{s}{random.randint(0, 999):03d}"


def unwrap_key(wrapped: str) -> str:
    s = (wrapped or "").strip()
    if s.startswith(_KP) and len(s) > 5 and s[-3:].isdigit():
        return s[len(_KP) : -3]
    return s


def _app_dir() -> str:
    """Thư mục chứa tool. Nuitka đặt __compiled__, PyInstaller đặt sys.frozen."""
    if getattr(sys, "frozen", False) or "__compiled__" in globals():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _data_dir() -> str:
    """Chỗ ghi được. Cạnh tool là chính; nằm trong Program Files thì lùi về AppData."""
    d = _app_dir()
    probe = os.path.join(d, ".ghi_thu")
    try:
        with open(probe, "w", encoding="utf-8") as f:
            f.write("x")
        os.remove(probe)
        return d
    except Exception:
        fallback = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "HaThanhVoice")
        os.makedirs(fallback, exist_ok=True)
        return fallback


DATA_DIR = _data_dir()


def _dpath(filename: str) -> str:
    """Đã có file ở thư mục hiện hành thì dùng tiếp, chưa có thì đặt cạnh tool."""
    if os.path.exists(filename):
        return os.path.abspath(filename)
    return os.path.join(DATA_DIR, filename)


CONFIG_FILE = _dpath("hathanh_voice.json")
KEY_FILE = _dpath("hathanh_key.txt")
VOICE_CACHE = _dpath("hathanh_voices.json")
TAGS_FILE = _dpath("voice_tags.json")
DEFAULT_OUTPUT = os.path.join(DATA_DIR, "HaThanh_Voice_Output")

SRV_A = "aHR0cHM6Ly9hcGkuYWkzMy5wcm8="
SRV_B = "aHR0cHM6Ly9hcGkub3BlbnNwZWFrZXIuYWk="
API_BASE = base64.b64decode(SRV_A).decode("utf-8")
API_BASE_ALT = base64.b64decode(SRV_B).decode("utf-8")
WEB_ORIGIN = "https://ai33.pro"

EP_TTS = "/v3/text-to-speech"
EP_TASK = "/v1/task/{task_id}"
EP_VOICES = "/v3/voices"
EP_DIALOGUE = "/v3/text-to-speech/dialogue"
EP_DICT = "/v3/dictionaries"
EP_DICT_PREVIEW = "/v3/dictionaries/preview"
EP_VOICE_CLONE = "/v3/text-to-speech/voice-clone"
EP_CREDITS = "/v1/credits"
EP_HEALTH = "/v1/health-check"

PROVIDERS = ["edge", "elevenlabs", "minimax", "vbee", "fishaudio", "kokoro", "kikivoice", "clone"]
ALL_SRC = "(tất cả nguồn)"
TAG_CAPABLE = {"elevenlabs", "clone"}
TAG_RE = re.compile(r"\[[a-zA-Z][a-zA-Z0-9 _-]{1,24}\]")
CACHE_DAYS = 7

DEFAULT_TAGS = {
    "Tốc độ": [
        ("Rất chậm", "[very slow]"),
        ("Chậm", "[slow]"),
        ("Bình thường", "[normal]"),
        ("Nhanh", "[fast]"),
        ("Rất nhanh", "[very fast]"),
    ],
    "Ngắt nghỉ": [
        ("Nghỉ ngắn", "[short pause]"),
        ("Nghỉ", "[pause]"),
        ("Nghỉ dài", "[long pause]"),
        ("Ngắt câu", "[break]"),
        ("Hít thở", "[breath]"),
    ],
    "Hiệu ứng": [
        ("Cười", "[laughs]"),
        ("Cười khẽ", "[chuckles]"),
        ("Thở dài", "[sighs]"),
        ("Thì thầm", "[whispers]"),
        ("Hét", "[shouts]"),
        ("Khóc", "[crying]"),
        ("Hắng giọng", "[clears throat]"),
        ("Ngáp", "[yawns]"),
        ("Nghẹn ngào", "[sobbing]"),
    ],
    "Cảm xúc": [
        ("Trìu mến", "[affection]"),
        ("Thích thú", "[amusement]"),
        ("Giận dữ", "[anger]"),
        ("Kinh ngạc", "[awe]"),
        ("Bối rối", "[confusion]"),
        ("Vui sướng", "[joy]"),
        ("Buồn", "[sadness]"),
        ("Ngạc nhiên", "[surprise]"),
        ("Lo lắng", "[nervous]"),
    ],
}

LANG_CODES = {
    "Tự nhận (auto)": "auto",
    "Việt": "vi",
    "Anh": "en",
    "Nhật": "ja",
    "Hàn": "ko",
    "Trung": "zh",
    "Thái": "th",
    "Pháp": "fr",
    "Đức": "de",
    "Tây Ban Nha": "es",
    "Indonesia": "id",
}

MIN_CHUNK = 1600
MAX_CHUNK = 2000

KEYS_TASK_ID = ("task_id", "taskId", "id", "request_id", "requestId", "uuid")
KEYS_AUDIO = (
    "audio_url",
    "audioUrl",
    "audio_link",
    "audioLink",
    "url",
    "link",
    "output_url",
    "outputUrl",
    "file_url",
    "fileUrl",
    "result_url",
    "download_url",
)
KEYS_STATUS = ("status", "state", "task_status", "taskStatus")
KEYS_CREDIT = (
    "credits",
    "credit",
    "balance",
    "premium_credits",
    "premiumCredits",
    "remaining",
    "available",
    "amount",
    "total",
)
KEYS_VOICE_ID = ("voice_id", "voiceId", "id", "code", "voice_code", "value", "slug")
KEYS_VOICE_NAME = ("name", "display_name", "displayName", "title", "label", "voice_name")
DONE_WORDS = ("success", "succeed", "succeeded", "done", "completed", "complete", "finished", "ok")
FAIL_WORDS = ("fail", "failed", "failure", "error", "cancel", "canceled", "cancelled", "rejected")
AUDIO_EXT = (".mp3", ".wav", ".m4a", ".ogg", ".aac", ".flac", ".opus")
NOT_AUDIO_EXT = (".srt", ".vtt", ".json", ".txt", ".xml", ".zip")
PREVIEW_KEYS = (
    "preview_url",
    "previewUrl",
    "preview",
    "sample_url",
    "sampleUrl",
    "sample",
    "demo_url",
    "demo",
    "audio_url",
    "audio",
)

SPLIT_NAMES = {
    "none": "không chia",
    "comma": "theo dấu phẩy",
    "punct": "theo dấu câu",
    "lines": "theo dòng",
    "manual": "sửa tay",
    "auto": "tự động",
}


def normalize_voice_id(voice_id: str, provider: str = "") -> str:
    v = (voice_id or "").strip().replace(":", "_")
    p = (provider or "").strip().lower()
    if not v:
        return ""
    if p and p != ALL_SRC and not v.lower().startswith(f"{p}_"):
        return f"{p}_{v}"
    return v


def voice_provider(voice_id: str, fallback: str = "edge") -> str:
    v = (voice_id or "").strip().lower()
    for p in PROVIDERS:
        if v.startswith(f"{p}_") or v.startswith(f"{p}:"):
            return p
    return fallback


def strip_voice_tags(text: str) -> str:
    s = TAG_RE.sub("", text or "")
    return re.sub(r"\s{2,}", " ", s).strip()


def cache_read() -> dict:
    if os.path.exists(VOICE_CACHE):
        try:
            with open(VOICE_CACHE, "r", encoding="utf-8") as f:
                return json.load(f) or {}
        except Exception:
            pass
    return {}


def cache_write(provider: str, items: list):
    db = cache_read()
    db[provider] = {"ts": time.time(), "items": items}
    try:
        with open(VOICE_CACHE, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False)
    except Exception:
        pass


def load_tags() -> dict:
    if os.path.exists(TAGS_FILE):
        try:
            with open(TAGS_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                return raw
        except Exception:
            pass
    try:
        with open(TAGS_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_TAGS, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return dict(DEFAULT_TAGS)


def walk(obj):
    stack = [obj]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            yield cur
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)


def find_by_keys(obj, keys, pred=None):
    want = {k.lower() for k in keys}
    for d in walk(obj):
        for k, v in d.items():
            if str(k).lower() in want and isinstance(v, (str, int, float)):
                if pred is None or pred(v):
                    return v
    return None


def find_audio_url(obj, exclude_subtitles: bool = True):
    def _ok(val):
        if not isinstance(val, str) or not val.startswith("http"):
            return False
        base = val.split("?", 1)[0].lower()
        if exclude_subtitles and base.endswith(NOT_AUDIO_EXT):
            return False
        return base.endswith(AUDIO_EXT) or any(w in base for w in ("audio", "storage", "cdn"))

    return find_by_keys(obj, KEYS_AUDIO, _ok)


def find_status(obj) -> str:
    v = find_by_keys(obj, KEYS_STATUS)
    return str(v or "").strip().lower()


def find_number(obj, keys):
    v = find_by_keys(obj, keys)
    if v is None:
        return None
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None


def find_list_of_dicts(obj) -> list:
    best = []
    stack = [obj]
    while stack:
        cur = stack.pop()
        if isinstance(cur, list):
            dicts = [x for x in cur if isinstance(x, dict)]
            if len(dicts) > len(best):
                best = dicts
            stack.extend(cur)
        elif isinstance(cur, dict):
            stack.extend(cur.values())
    return best


def find_voice_list(obj) -> list:
    """Lấy mảng GIỌNG, không lấy nhầm mảng con như verified_languages."""
    id_keys = {k.lower() for k in KEYS_VOICE_ID}
    name_keys = {k.lower() for k in KEYS_VOICE_NAME}
    best = []
    best_score = -1
    stack = [obj]
    while stack:
        cur = stack.pop()
        if isinstance(cur, list):
            dicts = [x for x in cur if isinstance(x, dict)]
            if dicts:
                has_id = sum(1 for d in dicts if any(k.lower() in id_keys for k in d))
                has_nm = sum(1 for d in dicts if any(k.lower() in name_keys for k in d))
                score = has_id * 10 + has_nm * 5 + len(dicts)
                if has_id > 0 and score > best_score:
                    best_score = score
                    best = dicts
            stack.extend(cur)
        elif isinstance(cur, dict):
            stack.extend(cur.values())
    return best


def find_preview(item: dict) -> str:
    """Link nghe thử sẵn có của giọng (không tốn credit)."""
    v = find_by_keys(item, PREVIEW_KEYS, lambda u: isinstance(u, str) and u.startswith("http"))
    return str(v or "")


def looks_like_id(s) -> bool:
    t = str(s or "").strip()
    return 4 <= len(t) <= 120 and " " not in t


def looks_like_voice_code(s: str) -> bool:
    """Phân biệt MÃ giọng với TÊN giọng."""
    t = (s or "").strip()
    if not looks_like_id(t) or len(t) < 6:
        return False
    low = t.lower()
    if any(low.startswith(f"{p}_") or low.startswith(f"{p}:") for p in PROVIDERS):
        return True
    if "_" in t or "-" in t or any(ch.isdigit() for ch in t):
        return True
    return len(t) >= 18


class Pacer:
    """Giữ khoảng cách tối thiểu giữa MỌI request của mọi luồng."""

    def __init__(self, gap: float = 0.6, gap_max: float = 6.0):
        self.gap = float(gap)
        self.gap_min = float(gap)
        self.gap_max = float(gap_max)
        self.busy = 0
        self.total = 0
        self._lock = threading.Lock()
        self._last = 0.0

    def wait(self, extra: float = 0.0):
        with self._lock:
            now = time.time()
            delay = max(0.0, (self._last + self.gap + extra) - now)
            self._last = max(now, self._last + self.gap + extra)
        if delay > 0:
            time.sleep(delay + random.uniform(0.02, 0.12))

    def on_busy(self):
        with self._lock:
            self.busy += 1
            self.total += 1
            self.gap = min(self.gap_max, self.gap * 1.35 + 0.2)

    def on_ok(self):
        with self._lock:
            self.total += 1
            self.gap = max(self.gap_min, self.gap * 0.92)


BUILTIN_EDGE_VOICES = [
    {"voice_id": "edge_vi-VN-HoaiMyNeural", "name": "🇻🇳 Hoài My (Nữ - Miền Nam Tự Nhiên)", "_provider": "edge"},
    {"voice_id": "edge_vi-VN-NamMinhNeural", "name": "🇻🇳 Nam Minh (Nam - Trầm Ấm Chuẩn)", "_provider": "edge"},
    {"voice_id": "edge_en-US-AriaNeural", "name": "🇺🇸 Aria (Nữ - Thuyết Minh Truyền Cảm)", "_provider": "edge"},
    {"voice_id": "edge_en-US-ChristopherNeural", "name": "🇺🇸 Christopher (Nam - Điện Ảnh Sâu Lắng)", "_provider": "edge"},
    {"voice_id": "edge_en-US-GuyNeural", "name": "🇺🇸 Guy (Nam - Kể Chuyện Tự Nhiên)", "_provider": "edge"},
    {"voice_id": "edge_en-US-JennyNeural", "name": "🇺🇸 Jenny (Nữ - Trẻ Trung Rõ Nét)", "_provider": "edge"},
    {"voice_id": "edge_en-GB-SoniaNeural", "name": "🇬🇧 Sonia (Nữ - Anh Quốc Sang Trọng)", "_provider": "edge"},
    {"voice_id": "edge_en-GB-RyanNeural", "name": "🇬🇧 Ryan (Nam - Anh Quốc Lịch Lãm)", "_provider": "edge"},
    {"voice_id": "edge_ja-JP-NanamiNeural", "name": "🇯🇵 Nanami (Nữ - Anime Nhật Bản)", "_provider": "edge"},
    {"voice_id": "edge_ko-KR-SunHiNeural", "name": "🇰🇷 SunHi (Nữ - Hàn Quốc Tự Nhiên)", "_provider": "edge"},
    {"voice_id": "edge_zh-CN-XiaoxiaoNeural", "name": "🇨🇳 Xiaoxiao (Nữ - Trung Quốc Truyền Cảm)", "_provider": "edge"},
    {"voice_id": "edge_fr-FR-DeniseNeural", "name": "🇫🇷 Denise (Nữ - Pháp Thanh Lịch)", "_provider": "edge"},
]


def _synth_local_edge_tts(text: str, voice_id: str, out_path: str, speed: float = 1.0) -> str:
    """Tổng hợp giọng nói miễn phí trực tiếp trên máy (Edge-TTS -> Google TTS Multi-chunk -> Windows SAPI)."""
    import urllib.parse

    raw_v = (voice_id or "vi-VN-HoaiMyNeural").strip()
    for p in PROVIDERS:
        if raw_v.lower().startswith(f"{p}_") or raw_v.lower().startswith(f"{p}:"):
            raw_v = raw_v.split("_", 1)[-1].split(":", 1)[-1]
            break
    if "Neural" not in raw_v:
        raw_v = "vi-VN-HoaiMyNeural"

    pct = int(round((float(speed or 1.0) - 1.0) * 100))
    rate_str = f"{pct:+d}%"
    clean_txt = strip_voice_tags(text) or "Xin chào."
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)

    # Tầng 1: Thử Edge-TTS WebSocket
    try:
        import asyncio
        import edge_tts

        async def _run():
            comm = edge_tts.Communicate(clean_txt, raw_v, rate=rate_str)
            await comm.save(out_path)

        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(_run())
        finally:
            loop.close()
        if os.path.exists(out_path) and os.path.getsize(out_path) >= 256:
            return out_path
    except Exception:
        pass

    # Tầng 2: Google Cloud/Translate TTS Stream (Hỗ trợ đầy đủ Tiếng Việt, Anh, Nhật, Hàn, Trung, Pháp...)
    try:
        tl = "vi"
        m_lang = re.match(r"^([a-z]{2})-[A-Z]{2}", raw_v)
        if m_lang:
            tl = m_lang.group(1).lower()
            if tl == "zh":
                tl = "zh-CN"

        words = clean_txt.split()
        chunks = []
        cur = ""
        for w in words:
            if len(cur) + len(w) + 1 <= 175:
                cur = f"{cur} {w}".strip()
            else:
                if cur:
                    chunks.append(cur)
                cur = w[:175]
        if cur:
            chunks.append(cur)

        mp3_bytes = bytearray()
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        for ch in chunks or ["Xin chào"]:
            q_enc = urllib.parse.quote(ch)
            g_url = f"https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl={tl}&q={q_enc}"
            r = requests.get(g_url, headers=headers, timeout=15)
            if r.status_code == 200 and len(r.content) > 128:
                mp3_bytes.extend(r.content)
        if len(mp3_bytes) >= 256:
            with open(out_path, "wb") as f:
                f.write(mp3_bytes)
            return out_path
    except Exception:
        pass

    raise RuntimeError("Không tạo được file âm thanh miễn phí. Vui lòng kiểm tra kết nối mạng hoặc nhập API Key.")


class VoiceClient:
    """Client giao tiếp với máy chủ HaThanh TTS / OpenSpeaker v3 (Tích hợp sẵn Edge-TTS miễn phí)."""

    REJECT_TTL = 7 * 86400
    CHARS_PER_SEC = 28.0
    POLL_GROW = 1.25
    POLL_CAP = 8.0

    def __init__(self, cfg: dict, logger=None, dump: bool = False):
        self.cfg = cfg or {}
        self.log = logger or (lambda _m: None)
        self._dump = bool(dump)
        raw_k = unwrap_key(self.cfg.get("api_key", ""))
        self._local_edge_only = not bool(raw_k)
        self._key = raw_k or "free_edge_local"
        self._auth = "xi"
        self._shape = self.cfg.setdefault("schema_cache", {})
        self.s = requests.Session()
        self.s.headers.update(
            {
                "xi-api-key": self._key,
                "accept": "application/json, text/plain, */*",
                "accept-language": "vi,en-US;q=0.9,en;q=0.8",
                "origin": WEB_ORIGIN,
                "referer": f"{WEB_ORIGIN}/",
                "user-agent": "HaThanhAuto-VoiceStudio/1.0",
            }
        )
        self._hlock = threading.Lock()
        self._voice_fix = {}
        self._vlock = threading.Lock()
        self.pacer = Pacer(float(self.cfg.get("min_gap", 0.6)))
        self.ppacer = Pacer(float(self.cfg.get("poll_gap", 1.0)), gap_max=8.0)
        self._busy_wait = 0.0
        self._notready = 0
        self.base = (self.cfg.get("api_base") or API_BASE).rstrip("/")
        self._base_switched = False

    def _switch_auth(self):
        with self._hlock:
            if self._auth == "xi":
                self.s.headers.pop("xi-api-key", None)
                self.s.headers["authorization"] = f"Bearer {self._key}"
                self._auth = "bearer"
                self.log("↻ Đổi sang header Authorization: Bearer")

    def _dump_raw(self, tag: str, data):
        if not self._dump:
            return
        try:
            fn = os.path.join(DATA_DIR, f"_dump_{tag}_{int(time.time())}.json")
            with open(fn, "w", encoding="utf-8") as f:
                if isinstance(data, (dict, list)):
                    json.dump(data, f, ensure_ascii=False, indent=2)
                else:
                    f.write(str(data))
        except Exception:
            pass

    def _req(self, method: str, ep: str, timeout: int = 30, pace: bool = True, poll: bool = False, **kw):
        p = self.ppacer if poll else self.pacer
        tries = max(2, int(self.cfg.get("retry", 3)))
        last = None
        for attempt in range(1, tries + 1):
            if pace:
                p.wait()
            url = f"{self.base}{ep}"
            try:
                r = self.s.request(method, url, timeout=timeout, **kw)
                if r.status_code == 401 and self._auth == "xi":
                    self._switch_auth()
                    continue
                if r.status_code == 401:
                    raise RuntimeError("API key sai hoặc hết hạn (401)")
                if r.status_code == 422:
                    raise RuntimeError(f"Tham số không hợp lệ (422): {r.text[:240]}")
                if r.status_code in (429, 502, 503, 504):
                    p.on_busy()
                    wait_s = min(15.0, 2.0 * attempt)
                    time.sleep(wait_s)
                    continue
                if r.status_code >= 400:
                    raise RuntimeError(f"HTTP {r.status_code}: {r.text[:240]}")
                p.on_ok()
                return r
            except requests.RequestException as e:
                last = e
                if not self._base_switched and API_BASE_ALT and self.base != API_BASE_ALT:
                    self.base = API_BASE_ALT.rstrip("/")
                    self._base_switched = True
                    self.log("↻ Chuyển sang máy chủ dự phòng")
                    continue
                time.sleep(1.5 * attempt)
        raise RuntimeError(f"Gọi API thất bại: {last}")

    def _json(self, method: str, ep: str, **kw):
        r = self._req(method, ep, **kw)
        data = r.json()
        self._dump_raw(ep.strip("/").replace("/", "_"), data)
        return data

    def health(self) -> dict:
        if self._local_edge_only:
            return {"status": "ok", "mode": "local_edge"}
        try:
            return self._json("GET", EP_HEALTH, timeout=15, pace=False)
        except Exception:
            return {}

    def credits(self):
        if self._local_edge_only:
            return 999999.0
        data = self._json("GET", EP_CREDITS, timeout=20, pace=True)
        return find_number(data, KEYS_CREDIT)

    def _voice_page(self, provider: str, page: int = 1, size: int = 100, extra: dict = None):
        params = {"page": page, "page_size": size}
        if provider and provider != ALL_SRC:
            params["provider"] = provider
        if extra:
            params.update(extra)
        return self._json("GET", EP_VOICES, params=params, timeout=30, pace=True)

    def voices(self, provider: str = "edge", size: int = 100, max_pages: int = 40, progress=None, extra: dict = None) -> list:
        """Tải danh sách giọng (Hỗ trợ kho giọng Edge-TTS miễn phí tích hợp sẵn khi chưa nhập API Key)."""
        if self._local_edge_only:
            return [dict(x) for x in BUILTIN_EDGE_VOICES]
        try:
            first = self._voice_page(provider, 1, size, extra)
            items = list(find_voice_list(first))
            total = find_number(
                first,
                ("total", "total_count", "totalCount", "count", "total_items", "totalItems", "records"),
            )
            if not total or total <= len(items) or len(items) == 0:
                return items or ([dict(x) for x in BUILTIN_EDGE_VOICES] if provider in ("edge", ALL_SRC, "") else [])
            pages = min(max_pages, int((total + size - 1) // size))
            if pages <= 1:
                return items

            def grab(pg):
                return find_voice_list(self._voice_page(provider, pg, size, extra))

            with ThreadPoolExecutor(max_workers=6) as ex:
                futs = [ex.submit(grab, pg) for pg in range(2, pages + 1)]
                for idx, fut in enumerate(futs, start=2):
                    try:
                        items.extend(fut.result())
                        if progress:
                            progress(idx, pages)
                    except Exception:
                        pass
            return items
        except Exception:
            if provider in ("edge", ALL_SRC, ""):
                return [dict(x) for x in BUILTIN_EDGE_VOICES]
            raise

    def _send_tts(self, fields: dict, mode: str = "form"):
        """mode='json' theo tài liệu, mode='form' giống hệt trang web (multipart)."""
        if mode == "form":
            files = {
                k: (None, "true" if v is True else ("false" if v is False else str(v)))
                for k, v in fields.items()
                if v is not None
            }
            return self._json("POST", EP_TTS, files=files, timeout=45)
        return self._json(
            "POST",
            EP_TTS,
            json=fields,
            headers={"content-type": "application/json"},
            timeout=45,
        )

    def create_task(self, text: str, voice_id: str, speed: float = 1.0, extras: dict = None):
        """POST /v3/text-to-speech. Mã giọng luôn dạng <kho>_<id>."""
        fields = {
            "text": text,
            "voice_id": voice_id,
            "speed": int(speed) if float(speed).is_integer() else float(speed),
        }
        if extras:
            fields.update(extras)
        mode = self._shape.get("tts_mode", "form")
        data = self._send_tts(fields, mode=mode)
        direct = find_audio_url(data)
        tid = find_by_keys(data, KEYS_TASK_ID, looks_like_id)
        if not tid and not direct:
            raise RuntimeError(f"Không đọc được task_id: {data}")
        return str(tid or ""), direct

    def _first_delay(self, nchars: int, base_gap: float) -> float:
        est = max(1.0, float(nchars or 0) / self.CHARS_PER_SEC)
        return max(base_gap, min(12.0, est * 0.65))

    def wait_task(self, task_id: str, stop_event=None, want_srt: bool = False, nchars: int = 0) -> tuple:
        timeout_s = float(self.cfg.get("poll_timeout", 240))
        step = float(self.cfg.get("poll_interval", 2.0))
        t0 = time.time()
        time.sleep(self._first_delay(nchars, step))

        while time.time() - t0 < timeout_s:
            if stop_event and stop_event.is_set():
                raise RuntimeError("Đã dừng")
            ep = EP_TASK.format(task_id=task_id)
            data = self._json("GET", ep, timeout=25, pace=True, poll=True)
            st = find_status(data)
            if any(w in st for w in FAIL_WORDS):
                msg = find_by_keys(data, ("message", "error", "error_message", "detail")) or st
                raise RuntimeError(f"Task lỗi: {msg}")
            url = find_audio_url(data)
            if url or any(w in st for w in DONE_WORDS):
                if not url:
                    raise RuntimeError("Task xong nhưng không đọc được link.")
                srt_url = find_by_keys(
                    data,
                    KEYS_AUDIO + ("srt_url", "subtitle_url", "transcript_url"),
                    lambda v: isinstance(v, str) and v.startswith("http") and v.split("?", 1)[0].lower().endswith((".srt", ".vtt")),
                )
                return url, srt_url
            time.sleep(step)
            step = min(self.POLL_CAP, step * self.POLL_GROW)
        raise RuntimeError(f"Chờ quá {int(timeout_s)}s chưa xong")

    def download(self, url: str, out_path: str):
        part = out_path + ".part"
        with self.s.get(url, stream=True, timeout=90) as r:
            r.raise_for_status()
            with open(part, "wb") as f:
                for chunk in r.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
        if os.path.getsize(part) < 256:
            raise RuntimeError(f"File tải về hỏng ({os.path.getsize(part)} bytes)")
        os.replace(part, out_path)

    def synth(
        self,
        text: str,
        voice_id: str,
        out_path: str,
        speed: float = 1.0,
        stop_event=None,
        extras: dict = None,
    ):
        is_edge = (voice_id or "").lower().startswith("edge") or "neural" in (voice_id or "").lower()
        if self._local_edge_only or is_edge:
            if self._local_edge_only:
                _synth_local_edge_tts(text, voice_id, out_path, speed=speed)
                return out_path, None
            try:
                tid, direct = self.create_task(text, voice_id, speed=speed, extras=extras)
                srt_url = None
                if direct:
                    url = direct
                else:
                    url, srt_url = self.wait_task(
                        tid,
                        stop_event=stop_event,
                        want_srt=bool((extras or {}).get("with_transcript")),
                        nchars=len(text or ""),
                    )
                self.download(url, out_path)
                srt_path = None
                if srt_url:
                    try:
                        srt_path = os.path.splitext(out_path)[0] + ".srt"
                        self.download(srt_url, srt_path)
                    except Exception:
                        srt_path = None
                return out_path, srt_path
            except Exception:
                _synth_local_edge_tts(text, voice_id, out_path, speed=speed)
                return out_path, None

        tid, direct = self.create_task(text, voice_id, speed=speed, extras=extras)
        srt_url = None
        if direct:
            url = direct
        else:
            url, srt_url = self.wait_task(
                tid,
                stop_event=stop_event,
                want_srt=bool((extras or {}).get("with_transcript")),
                nchars=len(text or ""),
            )
        self.download(url, out_path)
        srt_path = None
        if srt_url:
            try:
                srt_path = os.path.splitext(out_path)[0] + ".srt"
                self.download(srt_url, srt_path)
            except Exception:
                srt_path = None
        return out_path, srt_path

    def create_dialogue(self, lines: list, gap: float = 0.4, speed: float = 1.0, extras: dict = None) -> tuple:
        """lines: [(nhãn 'A'..'Z', voice_id, text)] -> task_id hoặc link trực tiếp."""
        payload = {
            "dialogue": [{"speaker": spk, "voice_id": vid, "text": txt} for spk, vid, txt in lines],
            "gap_seconds": round(float(gap), 2),
            "speed": float(speed),
        }
        if extras:
            payload.update(extras)
        data = self._json("POST", EP_DIALOGUE, json=payload, timeout=45)
        direct = find_audio_url(data)
        tid = find_by_keys(data, KEYS_TASK_ID, looks_like_id)
        if not tid and not direct:
            raise RuntimeError(f"Không đọc được task_id của hội thoại: {data}")
        return str(tid or ""), direct

    def dictionaries(self) -> list:
        data = self._json("GET", EP_DICT, timeout=25)
        return find_list_of_dicts(data)

    @staticmethod
    def _rule_forms(rules: list) -> list:
        """rules: [(tìm, thay, nguyên_từ, phân_biệt_hoa_thường)] -> đúng schema v3."""
        return [
            {
                "from": src,
                "to": dst,
                "matchType": "word" if whole else "contains",
                "caseSensitive": bool(case),
            }
            for src, dst, whole, case in rules
        ]

    def create_dictionary(self, name: str, rules: list) -> str:
        body = {"name": name, "rules": self._rule_forms(rules)}
        data = self._json("POST", EP_DICT, json=body, timeout=30)
        did = find_by_keys(data, ("dictionary_id", "id", "uuid", "pronunciation_dictionary_id"))
        return str(did or "")

    def preview_dictionary(self, text: str, rules: list = None, dict_id: str = None) -> str:
        """POST /v3/dictionaries/preview { text, rules } -> { input, output }."""
        body = {"text": text}
        if rules:
            body["rules"] = self._rule_forms(rules)
        if dict_id:
            body["dictionary_id"] = dict_id
        data = self._json("POST", EP_DICT_PREVIEW, json=body, timeout=25)
        out = find_by_keys(data, ("output", "result", "preview", "text"))
        return str(out or json.dumps(data, ensure_ascii=False))

    def delete_voice(self, voice_id: str) -> tuple:
        """Xoá một giọng nhân bản."""
        raw_id = (voice_id or "").strip()
        if raw_id.lower().startswith("clone_"):
            raw_id = raw_id.split("_", 1)[1]
        r = self._req("DELETE", f"{EP_VOICE_CLONE}/{raw_id}", timeout=25)
        return r.status_code < 300, r.text

    def clone_voice(self, audio_path: str, name: str, denoise: bool = False) -> dict:
        """POST /v3/text-to-speech/voice-clone."""
        if not name.strip():
            raise ValueError("Chưa đặt tên giọng.")
        with open(audio_path, "rb") as f:
            blob = f.read()
        files = {
            "voice_name": (None, name.strip()),
            "audio_file": (os.path.basename(audio_path), blob, "audio/mpeg"),
        }
        return self._json("POST", EP_VOICE_CLONE, files=files, timeout=90)


def split_by_punct(text: str, max_chunk: int = MAX_CHUNK) -> list:
    sents = re.split(r"(?<=[\.\!\?\…:;])\s+", (text or "").strip())
    out = []
    cur = ""
    for s in sents:
        s = s.strip()
        if not s:
            continue
        if len(cur) + len(s) + 1 <= max_chunk:
            cur = f"{cur} {s}".strip() if cur else s
        else:
            if cur:
                out.append(cur)
            cur = s
    if cur:
        out.append(cur)
    return out


def split_by_lines(text: str, max_chunk: int = MAX_CHUNK) -> list:
    return [ln.strip() for ln in (text or "").splitlines() if ln.strip()]


def load_sid_map(out_dir: str) -> dict:
    """Đọc srt_timing.json do tt.py ghi cạnh audio: tts_index -> scene_id."""
    p = os.path.join(out_dir or "", "srt_timing.json")
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return {int(k): int(v) for k, v in data.items() if str(k).isdigit()}
        except Exception:
            pass
    return {}


def parse_srt_text(raw: str) -> list:
    blocks = re.split(r"\n\s*\n", (raw or "").strip())
    out = []
    for b in blocks:
        lines = [ln.strip() for ln in b.splitlines() if ln.strip()]
        text_lines = [ln for ln in lines if not ln.isdigit() and "-->" not in ln]
        if text_lines:
            out.append(" ".join(text_lines))
    return out


def ffmpeg_available() -> bool:
    try:
        r = subprocess.run(["ffmpeg", "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return r.returncode == 0
    except Exception:
        return False


def concat_audio(files: list, out_path: str) -> bool:
    if not files:
        return False
    lst = out_path + ".list.txt"
    try:
        with open(lst, "w", encoding="utf-8") as f:
            for p in files:
                safe = p.replace("'", "'\\''")
                f.write(f"file '{safe}'\n")
        r = subprocess.run(
            ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", out_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return r.returncode == 0
    finally:
        try:
            os.remove(lst)
        except Exception:
            pass


def audio_dur(path: str) -> float:
    try:
        r = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                path,
            ],
            capture_output=True,
            text=True,
        )
        return float((r.stdout or "").strip())
    except Exception:
        return 3.0


def _srt_ts(sec: float) -> str:
    ms = max(0, int(round(sec * 1000)))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def build_merged_srt(pairs: list) -> str:
    t = 0.0
    blocks = []
    for idx, (txt, fp) in enumerate(pairs, start=1):
        d = max(0.5, audio_dur(fp)) if fp and os.path.exists(fp) else 3.0
        blocks.append(f"{idx}\n{_srt_ts(t)} --> {_srt_ts(t + d)}\n{txt}\n")
        t += d
    return "\n".join(blocks)


def build_per_clip_srt(pairs: list) -> str:
    blocks = []
    for idx, (txt, fp) in enumerate(pairs, start=1):
        d = max(0.5, audio_dur(fp)) if fp and os.path.exists(fp) else 3.0
        blocks.append(f"### {os.path.basename(fp or f'{idx}.mp3')}\n1\n{_srt_ts(0)} --> {_srt_ts(d)}\n{txt}\n")
    return "\n".join(blocks)


class HaThanhVoiceApp(ctk.CTkFrame):
    """Ứng dụng Hà Thành Voice Studio."""

    def __init__(self, master=None):
        super().__init__(master, fg_color="transparent")
        self.cfg = self._load_config()
        self.q = queue.Queue()
        self.stop_event = threading.Event()
        self.running = False
        self.processed_chunks = []
        self.split_mode = "auto"
        self.results = []
        self.file_checkboxes = []
        self.failed_jobs = []
        self._jobs = []
        self.voice_map = {}
        self.voice_rows = []
        self._voice_ids = {}
        self.voice_raw = []
        self._esc_bind = None
        self._preview_id = None
        self._picker_prev_btn = None
        self.dict_map = {"— Không dùng —": ""}
        self.tags = load_tags()
        self._tag_combos = []
        self.out_dir = self.cfg.get("out_dir") or DEFAULT_OUTPUT
        os.makedirs(self.out_dir, exist_ok=True)
        self.save_location = self.out_dir
        self.playing = False

        self._build_ui()
        self._cfg_sig = ""
        self._load_cached_voices()
        self.after(200, self._poll_queue)
        self.after(8000, self._autosave)

    def _load_config(self) -> dict:
        d = {
            "api_key": "",
            "provider": "edge",
            "voice_id": "",
            "voice_label": "",
            "speed": "1.0",
            "threads": "2",
            "poll_interval": 2.0,
            "poll_timeout": 240,
            "retry": 3,
            "min_gap": 0.6,
            "resume": True,
            "dump": False,
            "transcript": True,
            "strip_tags": True,
            "context_chaining": False,
            "out_lang": "Tự nhận (auto)",
            "similarity": "0.85",
            "filters": {},
            "dict_label": "— Không dùng —",
            "quality_tier": "high",
            "api_base": API_BASE,
            "schema_cache": {},
        }
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                if isinstance(saved, dict):
                    d.update(saved)
            except Exception:
                pass
        if not d.get("api_key") and os.path.exists(KEY_FILE):
            try:
                with open(KEY_FILE, "r", encoding="utf-8") as f:
                    d["api_key"] = f.read().strip()
            except Exception:
                pass
        return d

    def _collect(self) -> dict:
        try:
            self.cfg["api_key"] = self.ent_key.get().strip()
            self.cfg["provider"] = self.cb_prov.get().strip()
            self.cfg["voice_label"] = self.cb_voice.get().strip()
            self.cfg["voice_id"] = self.resolve_voice()
            self.cfg["speed"] = self.ent_speed.get().strip() or "1.0"
            self.cfg["threads"] = self.ent_threads.get().strip() or "2"
            self.cfg["resume"] = bool(self.sw_resume.get())
            self.cfg["dump"] = bool(self.sw_dump.get())
            self.cfg["transcript"] = bool(self.sw_transcript.get())
            self.cfg["strip_tags"] = bool(self.sw_striptag.get())
            self.cfg["context_chaining"] = bool(self.sw_chain.get())
            self.cfg["out_lang"] = self.cb_lang_out.get().strip()
            self.cfg["similarity"] = self.ent_sim.get().strip() or "0.85"
            self.cfg["quality_tier"] = "cheap" if "Giá" in self.cb_quality.get() else "high"
            self.cfg["dict_label"] = self.cb_dict.get().strip()
            self.cfg["out_dir"] = self.save_location
        except Exception:
            pass
        return self.cfg

    def save_config_now(self):
        """Lưu tay + nói rõ đã lưu gì, vào đâu."""
        self.save_config(quiet=False)
        self.status("💾 Đã lưu cấu hình")
        self.log(f"💾 Đã lưu → {CONFIG_FILE}")

    def _autosave(self):
        if not self.winfo_exists():
            return
        try:
            sig = json.dumps(self._collect(), ensure_ascii=False, sort_keys=True, default=str)
            if sig != self._cfg_sig:
                self.save_config(quiet=True)
                self._cfg_sig = sig
        except Exception:
            pass
        self.after(8000, self._autosave)

    def save_config(self, quiet: bool = False):
        self._collect()
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
        except Exception as e:
            if not quiet:
                messagebox.showerror("Không lưu được", f"Không tạo được file:\n{CONFIG_FILE}\n\n{e}")

    def save_key(self):
        k = self.ent_key.get().strip()
        self.cfg["api_key"] = k
        try:
            with open(KEY_FILE, "w", encoding="utf-8") as f:
                f.write(k)
            self.save_config(quiet=True)
            self.log("💾 Đã lưu API key.")
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    def _build_ui(self):
        _uio.setup_ui(self)

    def _build_left(self):
        _uio.build_left(self)

    def _build_right(self):
        _uio.build_right(self)

    def _build_tag_bar(self, parent, row: int, target):
        _uio.build_tag_bar(self, parent, row, target)

    def insert_tag(self, choice: str, target_box=None):
        box = target_box or self.textbox
        m = TAG_RE.search(choice or "")
        if not m:
            return
        tag = m.group(0)
        box.insert("insert", f"{tag} ")
        box.focus_set()
        self._update_char()
        self.log(f"🏷 Chèn thẻ {tag}")

    def edit_tags(self):
        load_tags()
        try:
            os.startfile(TAGS_FILE)
        except Exception:
            messagebox.showinfo("Sửa thẻ", f"Mở file này để thêm bớt thẻ:\n{TAGS_FILE}")

    def _build_tab_dialogue(self, tab, *a):
        _uio.build_tab_dialogue(self, tab)

    def scan_speakers(self) -> list:
        raw = self.dlg_box.get("1.0", "end-1c")
        labs = sorted({m.group(1) for m in re.finditer(r"^\s*([A-Z])\s*>", raw, flags=re.M)})
        for w in self.dlg_voices_frame.winfo_children():
            w.destroy()
        self.dlg_speaker_combos.clear()
        vals = list(self.voice_map.keys()) or [self.cb_voice.get()]
        for spk in labs:
            r = ctk.CTkFrame(self.dlg_voices_frame, fg_color="transparent")
            r.pack(fill="x", pady=2)
            ctk.CTkLabel(r, text=f"{spk}>", width=36).pack(side="left")
            cb = _uio.combo(r, vals)
            cb.set(vals[0] if vals else "")
            cb.pack(side="left", fill="x", expand=True, padx=4)
            self.dlg_speaker_combos[spk] = cb
        self.log(f"🎭 Tìm thấy {len(labs)} nhân vật: {', '.join(labs)}")
        return labs

    def import_dialogue_txt(self):
        p = filedialog.askopenfilename(filetypes=[("Text", "*.txt"), ("Tất cả", "*.*")])
        if p:
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                self.dlg_box.delete("1.0", "end")
                self.dlg_box.insert("1.0", f.read())
            self.scan_speakers()

    def start_dialogue(self):
        raw = self.dlg_box.get("1.0", "end-1c")
        lines = []
        for ln in raw.splitlines():
            m = re.match(r"^\s*([A-Z])\s*>\s*(.+)$", ln)
            if m:
                spk, txt = m.group(1), m.group(2).strip()
                cb = self.dlg_speaker_combos.get(spk)
                vid = self.voice_map.get(cb.get(), cb.get()) if cb else self.resolve_voice()
                lines.append((spk, vid, txt))
        if not lines:
            messagebox.showwarning("Chưa có thoại", "Viết thoại theo dạng A> nội dung.")
            return
        gap = float(self.ent_gap.get().strip() or 0.4)
        cfg = self._snap()
        threading.Thread(target=self._dialogue_worker, args=(lines, gap, cfg), daemon=True).start()

    def _dialogue_worker(self, lines: list, gap: float, cfg: dict):
        try:
            api = self.client(cfg)
            tid, direct = api.create_dialogue(lines, gap=gap, speed=float(cfg.get("speed", 1.0)))
            out_path = os.path.join(self.save_location, f"dialogue_{datetime.now().strftime('%H%M%S')}.mp3")
            url = direct or api.wait_task(tid)[0]
            api.download(url, out_path)
            self.q.put(("file", out_path))
            self.q.put(("log", f"✅ {os.path.basename(out_path)}"))
        except Exception as e:
            self.q.put(("log", f"❌ Hội thoại lỗi: {e}"))

    def _build_tab_dict(self, tab, *a):
        _uio.build_tab_dict(self, tab)

    def _parse_rules(self) -> list:
        whole = bool(self.sw_whole.get())
        case = bool(self.sw_case.get())
        rules = []
        for ln in self.dict_box.get("1.0", "end-1c").splitlines():
            if "=" in ln:
                a, b = ln.split("=", 1)
                if a.strip() and b.strip():
                    rules.append((a.strip(), b.strip(), whole, case))
        return rules

    def load_dicts(self):
        cfg = self._snap()

        def job():
            try:
                items = self.client(cfg).dictionaries()
                self.q.put(("dicts", items))
            except Exception as e:
                self.q.put(("log", f"❌ Tải từ điển lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def apply_dicts(self, items: list):
        self.dict_map = {"— Không dùng —": ""}
        for d in items or []:
            did = str(d.get("id") or d.get("dictionary_id") or "")
            nm = str(d.get("name") or d.get("title") or did)
            if did:
                self.dict_map[f"{nm} · {did[:8]}"] = did
        self.cb_dict.configure(values=list(self.dict_map.keys()))

    def create_dict(self):
        name = self.ent_dictname.get().strip()
        rules = self._parse_rules()
        if not name or not rules:
            messagebox.showwarning("Thiếu thông tin", "Đặt tên và nhập ít nhất 1 luật.")
            return
        cfg = self._snap()

        def job():
            try:
                did = self.client(cfg).create_dictionary(name, rules)
                self.q.put(("log", f"✅ Đã tạo từ điển '{name}' ({len(rules)} luật) · id={did}"))
            except Exception as e:
                self.q.put(("log", f"❌ Tạo từ điển lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def preview_dict(self):
        rules = self._parse_rules()
        sample = self.textbox.get("1.0", "end-1c").strip()[:500] or "HaThanhAuto xin chào AI"
        cfg = self._snap()

        def job():
            try:
                out = self.client(cfg).preview_dictionary(sample, rules=rules)
                self.q.put(("dictprev", out))
            except Exception as e:
                self.q.put(("log", f"❌ Xem thử lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def _build_tab_clone(self, tab, *a):
        _uio.build_tab_clone(self, tab)

    def pick_clone_file(self):
        p = filedialog.askopenfilename(
            filetypes=[("Âm thanh", "*.mp3 *.wav *.m4a *.aac *.ogg *.webm *.flac *.opus"), ("Tất cả", "*.*")]
        )
        if p:
            self.clone_file = p
            mb = os.path.getsize(p) / (1024 * 1024)
            self.lbl_clonefile.configure(text=f"{os.path.basename(p)} · {mb:.1f} MB")

    def _after_clone(self, voice_id: str, name: str, sample_url: str, raw: dict):
        full_id = normalize_voice_id(voice_id, "clone")
        label = f"{name} · Nhân bản · {full_id}"
        self.voice_map[label] = full_id
        self.set_voice(label, full_id)
        self.log(f"✅ Clone xong: {label}")

    def list_clones(self):
        cfg = self._snap()

        def job():
            try:
                items = self.client(cfg).voices("clone", max_pages=5)
                self.q.put(("clonelist", items))
            except Exception as e:
                self.q.put(("log", f"❌ Không lấy được danh sách clone: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def apply_clone_list(self, rows: list):
        self.clone_rows = list(rows or [])
        self.clone_list.delete(0, "end")
        for r in self.clone_rows:
            vid = str(find_by_keys(r, KEYS_VOICE_ID) or "")
            nm = str(find_by_keys(r, KEYS_VOICE_NAME) or "(không tên)")
            self.clone_list.insert("end", f" {nm:<30} {vid}")

    def _picked_clones(self) -> list:
        sel = self.clone_list.curselection()
        return [self.clone_rows[i] for i in sel if i < len(self.clone_rows)]

    def use_selected_clone(self):
        picked = self._picked_clones()
        if not picked:
            return
        r = picked[0]
        vid = normalize_voice_id(str(find_by_keys(r, KEYS_VOICE_ID) or ""), "clone")
        nm = str(find_by_keys(r, KEYS_VOICE_NAME) or vid)
        label = f"{nm} · Nhân bản · {vid}"
        self.voice_map[label] = vid
        self.set_voice(label, vid)

    def delete_clones(self):
        picked = self._picked_clones()
        if not picked:
            return
        cfg = self._snap()

        def job():
            api = self.client(cfg)
            ids = []
            for r in picked:
                vid = str(find_by_keys(r, KEYS_VOICE_ID) or "")
                if vid:
                    api.delete_voice(vid)
                    ids.append(vid)
            self.q.put(("dropvoices", ids))

        threading.Thread(target=job, daemon=True).start()

    def _drop_voices(self, ids: list):
        self.list_clones()

    def start_clone(self):
        if not self.clone_file:
            messagebox.showwarning("Chưa chọn file", "Chọn file mẫu trước.")
            return
        name = self.ent_clonename.get().strip()
        if not name:
            messagebox.showwarning("Thiếu tên", "Đặt tên cho giọng clone.")
            return
        denoise = bool(self.sw_denoise.get())
        cfg = self._snap()

        def job():
            try:
                raw = self.client(cfg).clone_voice(self.clone_file, name, denoise=denoise)
                vid = str(find_by_keys(raw, KEYS_VOICE_ID) or "")
                prev = find_preview(raw)
                self.q.put(("clone_ok", (vid, name, prev, raw)))
            except Exception as e:
                self.q.put(("log", f"❌ Clone lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def _extras(self, snap: dict = None) -> dict:
        s = snap or self._collect()
        ex = {}
        if s.get("transcript"):
            ex["with_transcript"] = True
        if s.get("context_chaining"):
            ex["context_chaining"] = True
        lang = LANG_CODES.get(s.get("out_lang", ""), "auto")
        if lang and lang != "auto":
            ex["language"] = lang
        try:
            ex["similarity"] = float(s.get("similarity", 0.85))
        except Exception:
            pass
        return ex

    def status(self, msg: str):
        self.q.put(("status", msg))

    def log(self, msg: str):
        self.q.put(("log", msg))

    def _log_now(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.console.insert("end", f"[{ts}] {msg}\n")
        self.console.see("end")

    def clear_log(self):
        self.console.delete("1.0", "end")

    def _update_char(self):
        try:
            n = len(self.textbox.get("1.0", "end-1c"))
            self.lbl_char.configure(text=f"{n:,} ký tự")
        except Exception:
            pass

    def toggle_key(self):
        cur = self.ent_key.cget("show")
        self.ent_key.configure(show="" if cur == "•" else "•")

    def _set_srt_preview(self, text: str):
        self.srt_box.delete("1.0", "end")
        self.srt_box.insert("1.0", text or "")

    def client(self, snap: dict = None) -> VoiceClient:
        """Dựng client từ bản cfg đã chụp."""
        s = snap or self.cfg
        return VoiceClient(s, logger=self.log, dump=bool(s.get("dump")))

    def _snap(self) -> dict:
        """Chụp cfg từ widget — gọi ở LUỒNG CHÍNH trước khi mở luồng nền."""
        return dict(self._collect())

    def check_key(self):
        cfg = self._snap()

        def job():
            try:
                api = self.client(cfg)
                cr = api.credits()
                if cr is not None:
                    self.q.put(("credit", f"💳 Số dư: {cr:,.0f} credit"))
                    self.q.put(("log", f"✅ Key hợp lệ · {cr:,.0f} credit"))
            except Exception as e:
                self.q.put(("log", f"⚠ Kiểm tra key lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def _load_cached_voices(self):
        """Nạp từ bộ nhớ đệm lúc mở tool (hoặc nạp sẵn danh sách giọng Edge-TTS miễn phí)."""
        db = cache_read()
        prov = self.cb_prov.get().strip() or "edge"
        items = []
        if prov == ALL_SRC:
            for pv, rec in db.items():
                for it in (rec or {}).get("items") or []:
                    it["_provider"] = pv
                    items.append(it)
        elif prov in db:
            items = list((db.get(prov) or {}).get("items") or [])
            for it in items:
                it["_provider"] = prov
        if not items:
            items = [dict(x) for x in BUILTIN_EDGE_VOICES]
        if items:
            self.apply_voices(items, prov)

    def load_voices(self, search_term: str = "", force: bool = True, id_mode: bool = False):
        prov = self.cb_prov.get().strip() or "edge"
        cfg = self._snap()

        def job():
            try:
                api = self.client(cfg)
                provs = PROVIDERS if prov == ALL_SRC else [prov]
                found = []
                for pv in provs:
                    extra = {"search": search_term} if search_term else None
                    arr = api.voices(pv, extra=extra)
                    for it in arr:
                        it["_provider"] = pv
                    if not search_term and arr:
                        cache_write(pv, arr)
                    found.extend(arr)
                self.q.put(("voices", (found, prov)))
            except Exception as e:
                self.q.put(("log", f"❌ Tải giọng lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def search_voices(self):
        term = self.ent_search.get().strip()
        if looks_like_voice_code(term):
            pv = voice_provider(term, self.cb_prov.get().strip())
            full = normalize_voice_id(term, pv)
            self.set_voice(full, full)
            return
        self.load_voices(search_term=term, force=True)

    def apply_voices(self, items: list, provider: str):
        self.voice_raw = list(items or [])
        self.voice_rows = []
        self.voice_map.clear()
        for it in self.voice_raw:
            pv = it.get("_provider") or provider
            raw_id = str(find_by_keys(it, KEYS_VOICE_ID) or "")
            if not raw_id:
                continue
            full_id = normalize_voice_id(raw_id, pv)
            nm = str(find_by_keys(it, KEYS_VOICE_NAME) or raw_id)
            label = f"{nm} · {pv} · {full_id}"
            self.voice_map[label] = full_id
            self.voice_rows.append(
                {
                    "label": label,
                    "id": full_id,
                    "name": nm,
                    "provider": pv,
                    "preview": find_preview(it),
                    "raw": it,
                }
            )
        self.filter_voices()

    @staticmethod
    def _clean_str(val: str) -> str:
        return re.sub(r"\s*\(\d+\)\s*$", "", (val or "").strip())

    def _clean_sel(self, cb) -> str:
        return self._clean_str(cb.get())

    def _filter_combos(self) -> dict:
        return {
            "lang": self.cb_lang,
            "tone": self.cb_tone,
            "age": self.cb_age,
            "cat": self.cb_cat,
            "sex": self.cb_sex,
            "src": self.cb_src,
            "tag": self.cb_tag,
        }

    def _restore_filters(self):
        pass

    def _filtered_rows(self) -> list:
        q = self.ent_search.get().strip().lower()
        out = []
        for r in self.voice_rows:
            if q and q not in r["label"].lower() and q not in r["id"].lower():
                continue
            out.append(r)
        return out

    def filter_voices(self):
        rows = self._filtered_rows()
        labels = [r["label"] for r in rows[:150]] or ["—"]
        self.cb_voice.configure(values=labels)
        if labels and labels[0] != "—":
            self.cb_voice.set(labels[0])

    def _preview_busy(self) -> bool:
        pg = get_pygame()
        try:
            return bool(pg and pg.mixer.get_init() and pg.mixer.music.get_busy())
        except Exception:
            return False

    def stop_preview(self):
        pg = get_pygame()
        try:
            if pg and pg.mixer.get_init():
                pg.mixer.music.stop()
                pg.mixer.music.unload()
        except Exception:
            pass
        self._preview_id = None
        self._set_preview_btn(False)

    def _set_preview_btn(self, active: bool):
        try:
            self.btn_prev.configure(text="⏹ Dừng" if active else "▶ Nghe thử")
        except Exception:
            pass

    def _watch_preview(self):
        if self._preview_busy():
            self.after(250, self._watch_preview)
        else:
            self._set_preview_btn(False)

    def preview_voice(self, row: dict = None):
        """Phát thử giọng bằng link mẫu sẵn có hoặc tổng hợp nhanh mẫu 2s bằng Edge-TTS miễn phí."""
        if self._preview_busy():
            self.stop_preview()
            return
        if row is None:
            cur = self.cb_voice.get()
            row = next((r for r in self.voice_rows if r["label"] == cur), None)
        vid = (row or {}).get("id") or self.resolve_voice()
        prev_url = (row or {}).get("preview")

        def job():
            try:
                tmp = os.path.join(tempfile.gettempdir(), f"preview_{int(time.time())}.mp3")
                if prev_url:
                    r = requests.get(prev_url, timeout=20)
                    with open(tmp, "wb") as f:
                        f.write(r.content)
                else:
                    sample_txt = (
                        "Xin chào, đây là giọng đọc thử nghiệm từ phòng thu AI."
                        if "vi-vn" in vid.lower()
                        else "Hello, welcome to CineFlow AI Voice Studio."
                    )
                    _synth_local_edge_tts(sample_txt, vid, tmp, speed=1.0)
                pg = get_pygame()
                if pg:
                    if not pg.mixer.get_init():
                        pg.mixer.init()
                    pg.mixer.music.load(tmp)
                    pg.mixer.music.play()
                    self.q.put(("previewing", (row or {}).get("label", vid)))
                else:
                    os.startfile(tmp)
                    self.q.put(("log", f"🔊 Đang mở file nghe thử: {os.path.basename(tmp)}"))
            except Exception as e:
                self.q.put(("log", f"❌ Nghe thử lỗi: {e}"))

        threading.Thread(target=job, daemon=True).start()

    def open_voice_picker(self):
        """Bảng chọn giọng phủ ngay trong tool."""
        if not self.voice_rows:
            messagebox.showinfo("Chưa có giọng", "Bấm 'Tải danh sách giọng' trước đã.")
            return
        H = {}
        ov, lbl_cnt, ent, lst = _uio.build_picker(self, H)
        shown = list(self.voice_rows)

        def fill(_e=None):
            q = ent.get().strip().lower()
            shown.clear()
            lst.delete(0, "end")
            for r in self.voice_rows:
                if not q or q in r["label"].lower():
                    shown.append(r)
                    lst.insert("end", f" {r['label']}")
            lbl_cnt.configure(text=f"{len(shown)} giọng")

        def choose(_e=None):
            sel = lst.curselection()
            if sel and sel[0] < len(shown):
                r = shown[sel[0]]
                self.set_voice(r["label"], r["id"])
                ov.destroy()

        def play_sel():
            sel = lst.curselection()
            if sel and sel[0] < len(shown):
                self.preview_voice(shown[sel[0]])

        H["close"] = ov.destroy
        H["choose"] = choose
        H["play"] = play_sel
        H["search"] = lambda: (ov.destroy(), self.search_voices())
        ent.bind("<KeyRelease>", fill)
        lst.bind("<Double-Button-1>", choose)
        fill()

    def set_voice(self, label: str, voice_id: str = None):
        """Đặt giọng VÀ ghi nhớ."""
        vid = voice_id or self.voice_map.get(label, label)
        self.cb_voice.set(label)
        self.cfg["voice_label"] = label
        self.cfg["voice_id"] = vid
        self.save_config(quiet=True)

    def _on_pick_voice(self, choice: str = None):
        ch = choice or self.cb_voice.get()
        self.set_voice(ch, self.voice_map.get(ch, ch))

    def resolve_voice(self) -> str:
        cur = self.cb_voice.get().strip()
        if cur in self.voice_map:
            return self.voice_map[cur]
        if " · " in cur:
            return cur.rsplit(" · ", 1)[-1].strip()
        return normalize_voice_id(cur, self.cb_prov.get().strip())

    def import_txt(self):
        p = filedialog.askopenfilename(filetypes=[("Text", "*.txt"), ("Tất cả", "*.*")])
        if p:
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                self.textbox.delete("1.0", "end")
                self.textbox.insert("1.0", f.read())
            self._update_char()

    def _display_chunks(self, chunks: list, switch_tab: bool = True):
        self.processed_chunks = list(chunks)
        self.chunks_box.delete("1.0", "end")
        for i, c in enumerate(self.processed_chunks, start=1):
            self.chunks_box.insert("end", f"--- ĐOẠN {i} ({len(c)} ký tự) ---\n{c}\n\n")
        self._update_split_hint()
        if switch_tab:
            self.tabview.set("Đoạn chia")

    def set_split_mode(self, mode: str, chunks: list):
        self.split_mode = mode
        self._display_chunks(chunks)

    def _update_split_hint(self):
        nm = SPLIT_NAMES.get(self.split_mode, self.split_mode)
        self.lbl_split.configure(text=f"{nm} · {len(self.processed_chunks)} file")

    def _chunks_for_run(self, raw_text: str) -> list:
        if self.split_mode == "manual" and self.processed_chunks:
            return list(self.processed_chunks)
        if self.split_mode == "none":
            return [raw_text.strip()] if raw_text.strip() else []
        if self.split_mode == "comma":
            return [p.strip() for p in re.split(r"[,\uFF0C]+", raw_text) if p.strip()]
        if self.split_mode == "lines":
            return split_by_lines(raw_text)
        return split_by_punct(raw_text)

    def apply_chunk_edits(self):
        raw = self.chunks_box.get("1.0", "end-1c")
        parts = [p.strip() for p in re.split(r"---\s*ĐOẠN\s*\d+[^\n]*---", raw) if p.strip()]
        self.set_split_mode("manual", parts)

    def srt_to_text(self):
        lines = parse_srt_text(self.srt_box.get("1.0", "end-1c"))
        if lines:
            self.textbox.delete("1.0", "end")
            self.textbox.insert("1.0", "\n".join(lines))
            self.set_split_mode("lines", lines)
            self.tabview.set("Văn bản")

    def do_split_punct(self):
        raw = self.textbox.get("1.0", "end-1c").strip()
        if raw:
            self.set_split_mode("punct", split_by_punct(raw))

    def do_split_lines(self):
        raw = self.textbox.get("1.0", "end-1c").strip()
        if raw:
            self.set_split_mode("lines", split_by_lines(raw))

    def do_no_split(self):
        raw = self.textbox.get("1.0", "end-1c").strip()
        if raw:
            self.set_split_mode("none", [raw])

    def do_split_comma(self):
        raw = self.textbox.get("1.0", "end-1c").strip()
        if raw:
            self.set_split_mode("comma", [p.strip() for p in re.split(r"[,\uFF0C]+", raw) if p.strip()])

    def import_srt(self):
        p = filedialog.askopenfilename(filetypes=[("Phụ đề SRT", "*.srt"), ("Tất cả", "*.*")])
        if p:
            with open(p, "r", encoding="utf-8-sig", errors="replace") as f:
                raw = f.read()
            self._set_srt_preview(raw)
            lines = parse_srt_text(raw)
            if lines:
                self.textbox.delete("1.0", "end")
                self.textbox.insert("1.0", "\n".join(lines))
                self.set_split_mode("lines", lines)

    def save_srt(self, mode: str = "merged"):
        if not self.results:
            messagebox.showinfo("Chưa có", "Tạo voice trước đã!")
            return
        content = build_merged_srt(self.results) if mode == "merged" else build_per_clip_srt(self.results)
        p = filedialog.asksaveasfilename(defaultextension=".srt", filetypes=[("SRT", "*.srt"), ("Text", "*.txt")])
        if p:
            with open(p, "w", encoding="utf-8-sig") as f:
                f.write(content)
            self.log(f"💾 Đã lưu {p}")

    def copy_srt(self):
        txt = self.srt_box.get("1.0", "end-1c").strip()
        if txt:
            self.clipboard_clear()
            self.clipboard_append(txt)
            self.log("📋 Đã copy SRT.")

    def add_file(self, path: str):
        cb = ctk.CTkCheckBox(self.file_list, text=os.path.basename(path))
        cb.pack(anchor="w", padx=4, pady=2)
        cb.select()
        self.file_checkboxes.append((cb, path))

    def select_all(self):
        for cb, _ in self.file_checkboxes:
            cb.select()

    def deselect_all(self):
        for cb, _ in self.file_checkboxes:
            cb.deselect()

    def _selected_files(self) -> list:
        return [p for cb, p in self.file_checkboxes if cb.get() and os.path.exists(p)]

    def delete_selected(self):
        sel = self._selected_files()
        for p in sel:
            try:
                os.remove(p)
            except Exception:
                pass
        kept = []
        for cb, p in self.file_checkboxes:
            if p in sel:
                cb.destroy()
            else:
                kept.append((cb, p))
        self.file_checkboxes = kept

    def merge_selected(self):
        sel = self._selected_files()
        if len(sel) < 2:
            messagebox.showinfo("Cần 2 file", "Chọn ít nhất 2 file để nối.")
            return
        out = os.path.join(self.save_location, f"merged_{datetime.now().strftime('%H%M%S')}.mp3")
        if concat_audio(sel, out):
            self.add_file(out)
            self.log(f"✅ Đã nối: {os.path.basename(out)}")

    def playback(self):
        sel = self._selected_files()
        if not sel:
            return
        pg = get_pygame()
        if not pg:
            return
        if self.playing:
            pg.mixer.music.stop()
            self.playing = False
            self.btn_play.configure(text="▶ Nghe")
            return
        if not pg.mixer.get_init():
            pg.mixer.init()
        pg.mixer.music.load(sel[0])
        pg.mixer.music.play()
        self.playing = True
        self.btn_play.configure(text="⏹ Ngừng")

    def choose_save(self):
        d = filedialog.askdirectory(initialdir=self.save_location)
        if d:
            self.save_location = d
            self.lbl_path.configure(text=d)
            self.save_config(quiet=True)

    def open_folder(self):
        if os.path.exists(self.save_location):
            try:
                os.startfile(self.save_location)
            except Exception:
                pass

    def reset_app(self):
        self.textbox.delete("1.0", "end")
        self.chunks_box.delete("1.0", "end")
        self._set_srt_preview("")
        for cb, _ in self.file_checkboxes:
            cb.destroy()
        self.file_checkboxes.clear()
        self.results.clear()
        self.processed_chunks.clear()
        self.progress.set(0)
        self._update_char()

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ văn bản, đoạn chia, SRT và danh sách file audio từ phiên trước."""
        if self.running:
            messagebox.showwarning("Đang chạy", "Vui lòng dừng tiến trình trước khi làm sạch!")
            return
        if ask_confirm:
            ok = messagebox.askyesno(
                "Làm sạch phiên trước",
                "Bạn có muốn xoá toàn bộ văn bản, kịch bản hội thoại, phụ đề SRT và dọn danh sách file audio từ lần dùng trước không?",
            )
            if not ok:
                return
        if delete_files:
            for _, p in list(self.file_checkboxes):
                if p and os.path.isfile(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass
        self.reset_app()
        if hasattr(self, "dlg_box"):
            try:
                self.dlg_box.delete("1.0", "end")
            except Exception:
                pass
        self.failed_jobs.clear()
        self.log("🧹 Đã làm sạch văn bản, đoạn chia, SRT và danh sách file từ phiên trước.")

    def start_generation(self, merge_after: bool = False, jobs: list = None):
        if self.running:
            return
        raw = self.textbox.get("1.0", "end-1c").strip()
        if jobs is None:
            chunks = self._chunks_for_run(raw)
            if not chunks:
                messagebox.showwarning("Chưa có text", "Nhập nội dung ở tab Văn bản.")
                return
            jobs = list(enumerate(chunks, start=1))

        cfg = self._snap()
        vid = cfg.get("voice_id")
        if not vid:
            messagebox.showwarning("Thiếu giọng", "Chọn giọng, hoặc gõ thẳng voice_id.")
            return

        self.running = True
        self.stop_event.clear()
        self.btn_gen.configure(state="disabled")
        self.btn_genmerge.configure(state="disabled")
        self.btn_stop.configure(state="normal")

        threading.Thread(
            target=self._worker,
            args=(jobs, vid, float(cfg.get("speed", 1.0)), int(cfg.get("threads", 2)), merge_after, cfg),
            daemon=True,
        ).start()

    def retry_failed(self):
        if not self.failed_jobs:
            messagebox.showinfo("Không có đoạn lỗi", "Lần chạy gần nhất không sót đoạn nào.")
            return
        self.start_generation(False, jobs=list(self.failed_jobs))

    def stop_generation(self):
        self.stop_event.set()
        self.status("⏹ Đang dừng…")

    def _worker(self, jobs: list, voice_id: str, speed: float, threads: int, merge_after: bool, cfg: dict):
        try:
            api = self.client(cfg)
            sid_map = load_sid_map(self.save_location)
            pv = voice_provider(voice_id, cfg.get("provider", "edge"))
            do_strip = bool(cfg.get("strip_tags")) and pv not in TAG_CAPABLE
            extras = self._extras(cfg)
            done_map = {}
            fails = []

            def one(job):
                idx, txt = job
                if self.stop_event.is_set():
                    return
                send_txt = strip_voice_tags(txt) if do_strip else txt
                sid = sid_map.get(idx)
                fn = f"{sid:04d}.mp3" if sid is not None else f"voice_{idx:04d}.mp3"
                out_p = os.path.join(self.save_location, fn)
                if cfg.get("resume") and os.path.exists(out_p) and os.path.getsize(out_p) > 256:
                    done_map[idx] = (txt, out_p)
                    self.q.put(("file", out_p))
                    return
                try:
                    fp, _ = api.synth(
                        send_txt,
                        voice_id,
                        out_p,
                        speed=speed,
                        stop_event=self.stop_event,
                        extras=extras,
                    )
                    done_map[idx] = (txt, fp)
                    self.q.put(("file", fp))
                except Exception as e:
                    fails.append(job)
                    self.q.put(("log", f"❌ Đoạn {idx}: {e}"))

            with ThreadPoolExecutor(max_workers=max(1, threads)) as ex:
                list(ex.map(one, jobs))

            self.failed_jobs = fails
            self.results = [done_map[i] for i in sorted(done_map)]
            if self.results:
                self.q.put(("srt", build_merged_srt(self.results)))
            if merge_after and len(self.results) > 1 and ffmpeg_available():
                full_p = os.path.join(self.save_location, f"full_{datetime.now().strftime('%H%M%S')}.mp3")
                if concat_audio([p for _, p in self.results], full_p):
                    self.q.put(("file", full_p))

            cb_done = getattr(self.master, "_os_on_done", None) or getattr(self, "_os_on_done", None)
            if callable(cb_done):
                try:
                    cb_done([p for _, p in self.results])
                except Exception:
                    pass
        finally:
            self.q.put(("done", None))

    def _poll_queue(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "log":
                    self._log_now(str(val))
                elif kind == "status":
                    self.lbl_status.configure(text=str(val))
                elif kind == "file":
                    self.add_file(val)
                elif kind == "credit":
                    self.lbl_credit.configure(text=str(val))
                elif kind == "voices":
                    items, pv = val
                    self.apply_voices(items, pv)
                elif kind == "dicts":
                    self.apply_dicts(val)
                elif kind == "dictprev":
                    self.dict_preview.configure(state="normal")
                    self.dict_preview.delete("1.0", "end")
                    self.dict_preview.insert("1.0", str(val))
                    self.dict_preview.configure(state="disabled")
                elif kind == "clonelist":
                    self.apply_clone_list(val)
                elif kind == "clone_ok":
                    self._after_clone(*val)
                elif kind == "dropvoices":
                    self._drop_voices(val)
                elif kind == "previewing":
                    self._set_preview_btn(True)
                    self._watch_preview()
                elif kind == "srt":
                    self._set_srt_preview(str(val))
                elif kind == "done":
                    self.running = False
                    self.btn_gen.configure(state="normal")
                    self.btn_genmerge.configure(state="normal")
                    self.btn_stop.configure(state="disabled")
                    self.lbl_status.configure(text="✅ Hoàn tất.")
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(150, self._poll_queue)

    def _on_close(self):
        self.stop_generation()
        self.save_config(quiet=True)

    # ── Pipeline hooks cho tt.py ──
    def _os_set_output(self, path: str):
        if path:
            os.makedirs(path, exist_ok=True)
            self.save_location = path
            self.lbl_path.configure(text=path)

    def _os_set_text(self, lines):
        txt = "\n".join(lines) if isinstance(lines, (list, tuple)) else str(lines or "")
        self.textbox.delete("1.0", "end")
        self.textbox.insert("1.0", txt)
        self.do_split_lines()
        self._update_char()

    def _os_start(self, merge: bool = False):
        self.start_generation(merge_after=merge)

    def stop(self):
        self.stop_generation()

    def _os_get_settings(self) -> dict:
        return dict(self._collect())

    def _os_set_settings(self, d: dict):
        if not isinstance(d, dict):
            return
        self.cfg.update(d)
        if d.get("voice_id"):
            self.set_voice(d.get("voice_label") or d["voice_id"], d["voice_id"])


VoiceApp = HaThanhVoiceApp


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    app = HaThanhVoiceApp(master=parent)
    app.pack(fill="both", expand=True)
    return app
