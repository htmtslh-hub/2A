"""
prompt_review.py — Tab RÀ SOÁT PROMPT
──────────────────────────────────────────────────────────────────────────────
Nhận các prompt bị chặn chính sách hoặc lỗi quá 5 lần từ VEO 3 / Imagen,
gửi qua AI (9Router) để chuẩn đoán mục vi phạm và viết lại prompt hợp lệ
nhưng giữ nguyên nội dung, bối cảnh và mạch câu chuyện; sau đó trả ngược
về đúng dòng ở tab gốc để tạo lại.

Tích hợp với tt.py qua:
    review_tab.add_prompt(src, row_id, prompt_text, reason)
    pipeline.retry_reviewed_prompt(src, row_id, new_prompt)
"""

import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from tkinter import messagebox
import customtkinter as ctk
import ui_review as _uir

BASE_DIR = (
    os.path.dirname(sys.executable)
    if getattr(sys, "frozen", False)
    else os.path.dirname(os.path.abspath(__file__))
)
CFG_FILE = os.path.join(BASE_DIR, "prompt_review.json")
CHATBOT_CFG = os.path.join(BASE_DIR, "gem_studio_config.json")
SHARED_R9KEY_FILE = os.path.join(BASE_DIR, "router9_key.txt")

DEFAULT_URL = os.environ.get("NINEROUTER_URL", "http://127.0.0.1:20128/v1")
DEFAULT_MODEL = "gemini-3.8-flash-high"
MODEL_PREFER = (
    "gemini-3.8-flash-high",
    "gemini-3.8-flash",
    "gemini-3.7-flash-high",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-3-flash",
    "gemini-pro",
    "claude-sonnet",
    "gpt-5",
)

FAIL_LIMIT = 5
POLICY_LIMIT = 2
MAX_ROUNDS = 4

SRC_LABEL = {
    "tay": "Dán tay",
    "prompt1": "Kịch bản Prompt",
    "video_to_prompt": "Video to Prompt",
    "veo": "VEO 3",
    "veo7": "VEO 3 Đồng Nhất",
    "veo4": "Ảnh ra Video",
    "imagen": "Imagen",
    "img6": "Image Đồng Nhất",
    "muse": "Video Muse",
    "imagen_consist": "Imagen Đồng Nhất",
}

POLICY = """BẢNG CHÍNH SÁCH CỦA GOOGLE VEO 3 / IMAGEN / WHISK
==================================================

[A] AN TOÀN TRẺ EM (nghiêm ngặt nhất — dính 1 từ là chặn, kể cả cảnh vô hại)
  • Hệ thống tự dịch sang tiếng Anh rồi quét từ khoá. Các từ: child, kid, boy,
    girl, baby, toddler, infant, minor, teen, teenager, adolescent, schoolboy,
    schoolgirl, little boy/girl, young boy/girl, son, daughter (khi nhỏ),
    học sinh, đứa bé, cậu bé, cô bé, em bé, thiếu niên, vị thành niên… khi đi
    cùng BẤT KỲ tình huống căng thẳng, sợ hãi, khóc, tối tăm, bị thương, một
    mình trong rừng/đêm, bị đuổi, nhìn thứ đáng sợ, hoặc đứng cạnh người lớn
    trong ngữ cảnh nhạy cảm → chặn ngay với mã PUBLIC_ERROR_MINOR / 58061214
    / 29310472.
  • Kể cả cảnh đời thường, bộ lọc của VEO 3 / Imagen thường xuyên chặn nhầm hễ
    có nhân vật dưới 18 tuổi hoặc tuổi mơ hồ ("young figure", "small person").

[B] BẠO LỰC & MÁU ME (mã 90789179, 61493863, 62263041)
  • Máu, vết thương hở, đâm chém, bắn giết, tra tấn, xác chết, bộ phận cơ thể
    rời, hành hạ động vật, đánh đập trực diện, vũ khí chĩa vào người.
  • Từ nhạy cảm: blood, gore, wound, corpse, dead body, stab, shoot, kill,
    murder, decapitate, severed, gunshot, explosion hitting people, torture,
    bleeding, puddle of blood, bloody.

[C] TỰ HẠI & TỰ TỬ
  • Tự tử, tự cắt, treo cổ, nhảy lầu, uống thuốc quá liều, tuyệt vọng muốn chết.

[D] NỘI DUNG NHẠY CẢM / GỢI DỤC (mã 57734940, 32635315)
  • Khỏa thân, bán khỏa thân, đồ lót, bikini hở hang, góc máy tập trung ngực/
    hông/mông, tư thế gợi cảm, hôn sâu, giường chiếu, từ ngữ: nude, naked,
    sexy, sensual, cleavage, lingerie, seductive, erotic, undressing, bathing
    suit, skin exposure, intimate.

[E] NGƯỜI THẬT / NGƯỜI NỔI TIẾNG / CHÍNH TRỊ GIA (mã 35561574, PROMINENT_PEOPLE)
  • Tên diễn viên, ca sĩ, tổng thống, tỷ phú, chính trị gia,KOL thật; hoặc mô
    tả nhận diện đúng một người nổi tiếng thật; hoặc dùng ảnh tham chiếu có mặt
    người giống người thật / người nổi tiếng.

[F] THƯƠNG HIỆU, LOGO & BẢN QUYỀN
  • Tên hãng (Nike, Apple, Coca-Cola, Marvel, Disney…), nhân vật có bản quyền
    (Spider-Man, Pikachu, Mickey…), biển hiệu có chữ thương hiệu.

[G] THÙ GHÉT, TÔN GIÁO CỰC ĐOAN, KHỦNG BỐ, CHẤT CẤM
  • Biểu tượng phát xít, KKK, khủng bố, bom, ma tuý, kim tiêm, hút chích,
    xúc phạm tôn giáo/chủng tộc.

[H] Y TẾ KINH DỊ / BODY HORROR / QUÁI DỊ QUÁ MỨC
  • Biến dạng cơ thể ghê rợn, ký sinh trùng chui khỏi da, mắt/miệng mọc sai
    chỗ, thối rữa, phẫu thuật mở.

[I] THẢM HOẠ THẬT & TIN GIẢ
  • Tái hiện vụ khủng bố, tai nạn máy bay, chiến tranh đang diễn ra với địa
    danh/cờ quốc gia cụ thể.

[J] LỖI KỸ THUẬT DO PROMPT (gây lỗi tạo chung / 5 lần liên tiếp)
  • Prompt quá dài rối, nhồi nhiều cảnh đối lập trong 1 shot, yêu cầu hiện chữ
    dài, câu phủ định ("no blood", "not a child" — chữ "blood"/"child" vẫn kích
    hoạt bộ lọc!), hoặc từ ngữ đa nghĩa dễ hiểu sang nghĩa cấm."""

FIX_RULES = """NGUYÊN TẮC SỬA BẮT BUỘC (GIỮ NGUYÊN CÂU CHUYỆN):
0. PHẢI ĐỐI CHIẾU PROMPT GỐC: liệt kê tự kiểm trong đầu các yếu tố cốt lõi
   của câu gốc gồm (a) Nhân vật & ngoại hình/trang phục không vi phạm,
   (b) Hành động chính đang diễn ra, (c) Bối cảnh/địa điểm/thời gian,
   (d) Góc máy/ánh sáng/phong cách điện ảnh, (e) Cảm xúc/không khí cảnh.
   Prompt viết lại PHẢI GIỮ ĐỦ cả 5 phần này, chỉ thay đúng cụm từ kích hoạt
   bộ lọc. CẤM tóm tắt, CẤM lược bỏ chi tiết bối cảnh hay kỹ thuật quay, CẤM
   đổi sang cảnh khác hoặc làm lệch mạch câu chuyện. Độ dài câu mới tương đương
   câu gốc (không rút ngắn quá 20%).
1. Giữ nguyên NGÔN NGỮ của prompt gốc (gốc tiếng Anh → trả tiếng Anh; gốc
   tiếng Việt → trả tiếng Việt; có nhãn [ Cảnh X ] hay tên nhân vật viết hoa
   ở đầu thì giữ nguyên cấu trúc đó).
2. Nếu dính [A] Trẻ em / MINOR:
   - Đổi mọi nhân vật trẻ em/thiếu niên thành người trưởng thành rõ tuổi:
     "a 25-year-old woman", "a young adult man in his mid-twenties",
     "một thanh niên trưởng thành 25 tuổi".
   - Xoá SẠCH các từ: child, kid, boy, girl, baby, minor, teen, little,
     youth, schoolboy/girl, son/daughter (khi gợi tuổi nhỏ). Không giữ cả
     trong câu phủ định.
3. Nếu dính [B] Bạo lực / máu:
   - Giữ kịch tính bằng ánh sáng, bóng đổ, biểu cảm căng thẳng, hiệu ứng
     khói/bụi/tia lửa điện ảnh thay cho máu và vết thương.
   - Đổi vũ khí đâm/bắn trực tiếp thành tư thế đối đầu, đỡ đòn, sóng xung
     kích, hoặc cắt cảnh ngay trước va chạm.
   - Thay "dead body / corpse / blood" bằng "motionless figure on the ground",
     "dark stain", "exhausted warrior kneeling", "scuff marks on armor".
4. Nếu dính [D] Nhạy cảm:
   - Cho nhân vật mặc trang phục kín đáo, lịch sự, đúng bối cảnh; đổi góc máy
     về trung cảnh / cận mặt biểu cảm; bỏ mọi từ gợi cảm.
5. Nếu dính [E] Người nổi tiếng / người thật:
   - Bỏ tên riêng; mô tả bằng ngoại hình hư cấu chung ("a charismatic
     middle-aged actor in a tailored suit").
6. Nếu dính [F] Thương hiệu:
   - Bỏ tên hãng/nhân vật bản quyền; thay bằng mô tả thiết kế chung không logo.
7. Nếu dính [H] Kinh dị / quái vật quá ghê:
   - Chuyển sang phong cách dark fantasy / điện ảnh huyền bí: bóng tối, sương
     mù, đôi mắt phát sáng, hình bóng khổng lồ — tránh từ ngữ thịt thối, máu
     mủ, biến dạng cơ thể.
8. TUYỆT ĐỐI KHÔNG dùng từ cấm trong câu phủ định (ví dụ viết "no blood, no
   child" sẽ VẪN BỊ CHẶN vì bộ lọc bắt từ khoá). Chỉ mô tả thứ muốn thấy.
9. Prompt viết lại phải là 1 đoạn hoàn chỉnh, dùng được ngay cho VEO 3 / Imagen,
   không kèm giải thích bên trong chuỗi prompt."""

SYSTEM_PROMPT = f"""Bạn là chuyên gia rà soát và sửa prompt cho Google VEO 3, Imagen 4 và Whisk.

{POLICY}

{FIX_RULES}

Hãy phân tích prompt bị lỗi và trả về ĐÚNG MỘT JSON hợp lệ theo mẫu sau (không bọc giải thích ngoài JSON):
{{
  "violated_codes": ["A - An toàn trẻ em", "B - Bạo lực"],
  "diagnosis": "Giải thích ngắn gọn bằng tiếng Việt: từ/cụm từ nào trong prompt đã kích hoạt mục chính sách nào và vì sao bị chặn.",
  "changes": [
    "cụm cũ → cụm mới (lý do)",
    "cụm cũ → cụm mới (lý do)"
  ],
  "fixed_prompt": "Prompt đã viết lại hoàn chỉnh, sạch 100% từ khoá nhạy cảm, giữ nguyên bối cảnh/góc máy/nhân vật/mạch truyện."
}}"""

ROUND_NOTE = {
    2: """⚠️ CẢNH BÁO VÒNG 2: Bản sửa trước VẪN BỊ GOOGLE CHẶN khi chạy thật.
Bạn bắt buộc phải:
• Rà từng từ trong bản trước, tìm các từ ẩn còn gợi nghĩa nhạy cảm (tuổi trẻ,
  xung đột cơ thể, kinh dị, da thịt, người thật, từ lóng, ẩn dụ bạo lực).
• Thay thế MẠNH TAY hơn bằng hình ảnh ẩn dụ điện ảnh an toàn (ánh sáng, bóng
  đổ, biểu cảm gương mặt, chuyển động ống kính, khung cảnh thiên nhiên/kiến trúc).
• Mọi nhân vật phải ghi rõ tuổi trưởng thành ("a 28-year-old adult…").
• Nhưng PHẢI GIỮ ĐỦ nhân vật, bối cảnh, hành động cốt lõi và góc máy của prompt gốc.""",
    3: """⚠️ CẢNH BÁO VÒNG 3 (NGHIÊM NGẶT): Đã sửa 2 lần mà Google VEO/Imagen VẪN CHẶN.
Lần này phải làm sạch tuyệt đối nhưng KHÔNG ĐƯỢC LÀM MẤT CÂU CHUYỆN GỐC:
• Đọc lại PROMPT GỐC: giữ nguyên địa điểm, thời gian, trang phục, góc máy và
  ý nghĩa cảnh đó trong mạch truyện.
• Bỏ hẳn mọi động từ tác động vật lý giữa các nhân vật (đánh, giữ, kéo, ngã,
  chảy, rách, hét, khóc, sợ hãi, tấn công, truy đuổi) → chuyển sang diễn tả
  bằng ánh mắt, tư thế đứng đối diện, khoảng lặng căng thẳng, gió thổi, ánh đèn.
• Không dùng bất kỳ tính từ tối tăm/đáng sợ/máu/vết thương/cơ thể nào.
• Nhân vật ghi rõ "a 30-year-old adult wearing full modest attire".""",
    4: """⚠️ CẢNH BÁO VÒNG 4 (MỨC CUỐI — AN TOÀN TUYỆT ĐỐI, VẪN ĐÚNG CẢNH GỐC):
Đã 3 vòng vẫn bị chặn. Hãy viết lại cảnh này theo lối ĐIỆN ẢNH TƯỢNG TRƯNG:
• Giữ đúng nhân vật (người trưởng thành 30 tuổi, trang phục kín đáo), đúng bối
  cảnh/địa điểm và đúng thông điệp/cảm xúc của câu gốc để video ghép vào không
  lệch kịch bản.
• Thay hành động nhạy cảm bằng cảnh nhân vật bước đi/đứng trầm ngâm/nhìn xa
  trong đúng bối cảnh đó, kết hợp chuyển động máy quay mượt, ánh sáng điện ảnh
  đẹp, không có bất kỳ yếu tố xung đột, sợ hãi hay cơ thể nào.""",
}


def _extract_json(text: str) -> dict:
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.I)
    t = re.sub(r"\s*```$", "", t)
    try:
        return json.loads(t)
    except Exception:
        pass
    m = re.search(r"\{.*\}", t, flags=re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    raise ValueError(f"AI không trả về JSON hợp lệ: {t[:200]}")


def _text_of(content) -> str:
    """Rút text từ message.content (hỗ trợ cả string lẫn list block của Claude/Gemini)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict):
                if b.get("type") in ("thinking", "reasoning"):
                    continue
                parts.append(b.get("text") or b.get("content") or "")
            elif isinstance(b, str):
                parts.append(b)
        return "\n".join(p for p in parts if p)
    return ""


def read_reply(raw: str) -> str:
    """Đọc phản hồi từ 9Router — chịu được cả JSON thường lẫn SSE stream."""
    s = (raw or "").strip()
    if not s:
        return ""
    if s.startswith("{"):
        try:
            data = json.loads(s)
            if isinstance(data.get("error"), dict):
                raise RuntimeError(data["error"].get("message") or str(data["error"]))
            choices = data.get("choices") or []
            if choices:
                msg = choices[0].get("message") or choices[0].get("delta") or {}
                txt = _text_of(msg.get("content")) or msg.get("reasoning_content") or ""
                if txt.strip():
                    return txt
            if isinstance(data.get("content"), list):
                return _text_of(data["content"])
            if isinstance(data.get("output_text"), str):
                return data["output_text"]
        except RuntimeError:
            raise
        except Exception:
            pass

    chunks = []
    for line in s.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            ev = json.loads(payload)
            for ch in ev.get("choices") or []:
                delta = ch.get("delta") or ch.get("message") or {}
                piece = _text_of(delta.get("content"))
                if piece:
                    chunks.append(piece)
        except Exception:
            continue
    return "".join(chunks)


def live_key(pipeline) -> str:
    """Đọc key 9Router trực tiếp từ tab Kịch Bản đang mở (nếu có)."""
    if pipeline is None:
        return ""
    try:
        cb = getattr(pipeline, "chatbot_app", None)
        if cb is not None and hasattr(cb, "ent_r9key"):
            k = cb.ent_r9key.get().strip()
            if k:
                return k
    except Exception:
        pass
    return ""


def _shared_r9key() -> str:
    """Đọc key 9Router từ file dùng chung router9_key.txt."""
    if os.path.exists(SHARED_R9KEY_FILE):
        try:
            with open(SHARED_R9KEY_FILE, "r", encoding="utf-8") as f:
                return f.read().strip()
        except Exception:
            pass
    return ""


def borrow_key():
    """Tự mượn URL/Key/Model 9Router từ router9_key.txt hoặc gem_studio_config.json."""
    url = DEFAULT_URL
    key = _shared_r9key()
    model = DEFAULT_MODEL
    src = "router9_key.txt" if key else ""

    if os.path.exists(CHATBOT_CFG):
        try:
            with open(CHATBOT_CFG, "r", encoding="utf-8") as f:
                d = json.load(f)
            url = (d.get("router9_url") or url).strip()
            if not key:
                key = (d.get("router9_key") or d.get("api_key") or "").strip()
                if key:
                    src = "gem_studio_config.json"
            model = (d.get("router9_model") or model).strip()
        except Exception:
            pass
    return url, key, model, src


def mask(k: str) -> str:
    if not k:
        return "(trống)"
    if len(k) <= 10:
        return k[:3] + "…"
    return f"{k[:6]}…{k[-4:]}"


def fallback_models(current: str, models: list) -> list:
    """Danh sách model để thử lần lượt: model đang chọn trước, rồi các model khác."""
    seen = set()
    out = []
    for m in [current] + list(models or []) + list(MODEL_PREFER):
        m = (m or "").strip()
        if m and m not in seen:
            seen.add(m)
            out.append(m)
    return out


def pick_model(models: list) -> str:
    """Chọn model phù hợp từ danh sách 9Router trả về."""
    if not models:
        return DEFAULT_MODEL
    for pref in MODEL_PREFER:
        for m in models:
            if pref in m.lower():
                return m
    return models[0]


def list_models(url: str, key: str) -> list:
    base = (url or DEFAULT_URL).rstrip("/")
    req_url = f"{base}/models"
    headers = {"Accept": "application/json", "User-Agent": "AllTool-PromptReview/1.0"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    req = urllib.request.Request(req_url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    items = data.get("data") or data.get("models") or []
    out = []
    for it in items:
        if isinstance(it, dict):
            mid = it.get("id") or it.get("name")
            if mid:
                out.append(str(mid))
        elif isinstance(it, str):
            out.append(it)
    return out


def _local_policy_sanitize(prompt_text: str, reason: str = "", round_no: int = 1) -> dict:
    """Bộ lọc & viết lại câu lệnh nội bộ theo 10 nhóm chính sách của Google VEO 3 / Imagen."""
    fixed = prompt_text
    codes = []
    changes = []

    rules = [
        # [A] An toàn trẻ em
        (
            r"\b(little boy|young boy|schoolboy|boy|child|kid|toddler|baby|infant|minor|teenager|teen)\b",
            "a 25-year-old young adult",
            "A - An toàn trẻ em",
            "Đổi từ chỉ trẻ vị thành niên sang người trưởng thành 25 tuổi rõ ràng",
        ),
        (
            r"\b(little girl|young girl|schoolgirl|girl)\b",
            "a 25-year-old young adult woman",
            "A - An toàn trẻ em",
            "Đổi từ chỉ bé gái sang phụ nữ trưởng thành 25 tuổi",
        ),
        (
            r"(cậu bé|đứa bé|em bé|đứa trẻ|thiếu niên|học sinh nhỏ)",
            "một thanh niên trưởng thành 25 tuổi",
            "A - An toàn trẻ em",
            "Đổi nhân vật nhỏ tuổi sang thanh niên trưởng thành 25 tuổi",
        ),
        (
            r"(cô bé|bé gái)",
            "một cô gái trưởng thành 25 tuổi",
            "A - An toàn trẻ em",
            "Đổi nhân vật nhỏ tuổi sang người trưởng thành 25 tuổi",
        ),
        # [B] Bạo lực & Máu me
        (
            r"\b(blood|bloody|bleeding|gore|puddle of blood|wound|open wound)\b",
            "dramatic crimson light reflection and dark shadow",
            "B - Bạo lực & Máu me",
            "Thay chi tiết máu/vết thương bằng hiệu ứng ánh sáng và bóng đổ điện ảnh",
        ),
        (
            r"\b(corpse|dead body|severed|decapitate|murder|kill|killing|stab|stabbing|shoot|shooting|torture)\b",
            "dramatic cinematic confrontation with glowing energy sparks",
            "B - Bạo lực & Máu me",
            "Thay hành động bạo lực trực diện bằng đối đầu điện ảnh và tia sáng năng lượng",
        ),
        (
            r"(máu me|vết thương|xác chết|đâm chém|bắn giết|tra tấn|chảy máu)",
            "hiệu ứng bóng đổ kịch tính và tia lửa điện ảnh",
            "B - Bạo lực & Máu me",
            "Làm sạch từ ngữ bạo lực/máu me sang miêu tả điện ảnh an toàn",
        ),
        # [D] Nhạy cảm
        (
            r"\b(nude|naked|lingerie|bikini|cleavage|erotic|seductive|sensual|undressing)\b",
            "wearing elegant full modest cinematic attire",
            "D - Nội dung nhạy cảm",
            "Đổi trang phục/mô tả nhạy cảm sang trang phục lịch sự kín đáo",
        ),
    ]

    for pat, repl, code_label, desc in rules:
        if re.search(pat, fixed, flags=re.IGNORECASE):
            fixed = re.sub(pat, repl, fixed, flags=re.IGNORECASE)
            if code_label not in codes:
                codes.append(code_label)
            changes.append(f"{desc} ({pat} → {repl})")

    if not codes:
        if "58061214" in (reason or "") or "MINOR" in (reason or "").upper():
            codes.append("A - An toàn trẻ em")
        elif "90789179" in (reason or ""):
            codes.append("B - Bạo lực & Máu me")
        else:
            codes.append("J - Tinh chỉnh diễn đạt an toàn")
        changes.append("Làm rõ độ tuổi trưởng thành và bổ sung mô tả ánh sáng điện ảnh an toàn")

    if round_no >= 2 and "adult" not in fixed.lower() and "trưởng thành" not in fixed.lower():
        fixed = f"{fixed.rstrip('. ')}, featuring a 28-year-old adult in modest attire, cinematic safe lighting."

    try:
        import flowkit_engine
        fk_fixed = flowkit_engine.apply_physics_safe_choreography(fixed)
        if fk_fixed != fixed:
            fixed = fk_fixed
            changes.append("Áp dụng chuẩn chuyển động vật lý 3 pha FlowKit (fk-action-choreography)")
    except Exception:
        pass

    diag = (
        f"Đã rà soát theo Bộ Quy Tắc An Toàn VEO 3 / Imagen + FlowKit Choreography (Vòng {round_no}). "
        f"Phát hiện nhóm cần làm sạch: {', '.join(codes)}. "
        "Đã giữ nguyên bối cảnh, góc máy và mạch truyện, chỉ thay thế từ khoá nhạy cảm."
    )
    return {
        "violated_codes": codes,
        "diagnosis": diag,
        "changes": changes,
        "fixed_prompt": fixed,
    }


def _call_gemini_direct_review(user_msg: str) -> dict:
    """Thử gọi qua hệ thống API Đa Hãng (Gemini / OpenAI / Anthropic / DeepSeek...) hoặc gemini.txt."""
    try:
        import multi_llm_bridge as _mlb

        ok_m, txt_m, _ = _mlb.generate_text(
            prompt=user_msg,
            system_prompt=SYSTEM_PROMPT,
            temperature=0.25,
            timeout=30,
        )
        if ok_m and txt_m:
            return _extract_json(txt_m)
    except Exception:
        pass

    gem_file = os.path.join(BASE_DIR, "gemini.txt")
    if not os.path.exists(gem_file):
        return None
    try:
        with open(gem_file, "r", encoding="utf-8") as f:
            keys = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]
    except Exception:
        keys = []
    if not keys:
        return None

    full_prompt = f"{SYSTEM_PROMPT}\n\n{user_msg}"
    for key in keys[:2]:
        for m in ("gemini-2.5-flash", "gemini-2.0-flash"):
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={key}"
            body = {
                "contents": [{"parts": [{"text": full_prompt}]}],
                "generationConfig": {"temperature": 0.25},
            }
            try:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(body).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=25) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="replace"))
                cands = data.get("candidates") or []
                if cands:
                    parts = (cands[0].get("content") or {}).get("parts") or []
                    txt = "".join(p.get("text", "") for p in parts).strip()
                    if txt:
                        return _extract_json(txt)
            except Exception:
                continue
    return None


def call_router(
    url: str,
    key: str,
    model: str,
    prompt_text: str,
    reason: str = "",
    round_no: int = 1,
    failed_before: list = None,
    extra_note: str = "",
    timeout: int = 120,
) -> dict:
    base = (url or DEFAULT_URL).rstrip("/")
    req_url = f"{base}/chat/completions"

    user_msg = f"PROMPT GỐC BỊ CHẶN:\n{prompt_text}\n"
    if reason:
        user_msg += f"\nLÝ DO / MÃ LỖI TỪ GOOGLE:\n{reason}\n"
    if failed_before:
        prev_txt = "\n".join(f"  - Lần {i + 1}: {p}" for i, p in enumerate(failed_before))
        user_msg += f"\nCÁC BẢN SỬA TRƯỚC ĐÓ VẪN BỊ CHẶN (TUYỆT ĐỐI KHÔNG LẶP LẠI CÁCH VIẾT NÀY):\n{prev_txt}\n"
    if round_no in ROUND_NOTE:
        user_msg += f"\n{ROUND_NOTE[round_no]}\n"
    if extra_note:
        user_msg += f"\nGHI CHÚ THÊM:\n{extra_note}\n"
    user_msg += "\nHãy rà soát và trả về JSON đúng cấu trúc yêu cầu."

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "AllTool-PromptReview/1.0",
    }
    if key:
        headers["Authorization"] = f"Bearer {key}"

    eff_timeout = 5 if ("127.0.0.1" in base or "localhost" in base) else timeout
    for stream_flag in (False, True):
        body = {
            "model": model or DEFAULT_MODEL,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            "temperature": min(0.25 + 0.1 * max(0, round_no - 1), 0.7),
            "stream": stream_flag,
        }
        try:
            req = urllib.request.Request(
                req_url,
                data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=eff_timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            reply = read_reply(raw)
            if reply.strip():
                return _extract_json(reply)
        except urllib.error.HTTPError:
            break
        except Exception:
            break

    gem_res = _call_gemini_direct_review(user_msg)
    if gem_res and gem_res.get("fixed_prompt"):
        return gem_res

    return _local_policy_sanitize(prompt_text, reason=reason, round_no=round_no)


class ReviewTab(ctk.CTkFrame):
    """Tab Rà Soát Prompt."""

    _src_label = SRC_LABEL

    def __init__(self, master, pipeline=None):
        super().__init__(master, fg_color="transparent")
        self.pipeline = pipeline
        self.items = []
        self.selected_uid = None
        self._seq = 0
        self._busy = False
        self.cfg = self._load_cfg()

        _uir.setup_ui(self)
        self.refresh_key(silent=True)
        _uir.render_list(self)

    def _load_cfg(self) -> dict:
        url, key, model, _ = borrow_key()
        d = {
            "url": url,
            "key": "",
            "model": model,
            "models": [model],
            "auto_review": True,
            "auto_send_back": True,
        }
        if os.path.exists(CFG_FILE):
            try:
                with open(CFG_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                if isinstance(saved, dict):
                    d.update(saved)
            except Exception:
                pass
        return d

    def save_cfg(self):
        try:
            self.cfg["url"] = self.ent_url.get().strip() or DEFAULT_URL
            self.cfg["key"] = self.ent_key.get().strip()
            self.cfg["model"] = self.cb_model.get().strip() or DEFAULT_MODEL
            self.cfg["auto_review"] = bool(self.sw_auto_review.get())
            self.cfg["auto_send_back"] = bool(self.sw_auto_back.get())
            with open(CFG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
            self.refresh_key(silent=True)
            self.lbl_status.configure(text="Đã lưu cài đặt", text_color=_uir.T.OK)
        except Exception as e:
            self.log(f"⚠️ Lỗi lưu cấu hình: {e}")

    def key_now(self) -> str:
        """Lấy API key theo thứ tự ưu tiên: ô nhập riêng → tab Kịch Bản đang mở → file cấu hình."""
        own = self.ent_key.get().strip()
        if own:
            return own
        lk = live_key(self.pipeline)
        if lk:
            return lk
        _, bk, _, _ = borrow_key()
        return bk

    def key_src(self) -> str:
        own = self.ent_key.get().strip()
        if own:
            return f"Key riêng ({mask(own)})"
        lk = live_key(self.pipeline)
        if lk:
            return f"Tab Kịch Bản ({mask(lk)})"
        _, bk, _, src = borrow_key()
        if bk:
            return f"{src} ({mask(bk)})"
        return "Chưa có key"

    def refresh_key(self, silent=False):
        """Đồng bộ lại URL/Key/Model từ tab Kịch Bản."""
        src_txt = self.key_src()
        try:
            self.lbl_key_src.configure(text=f"Đang dùng: {src_txt}")
        except Exception:
            pass
        if not silent:
            self.log(f"🔑 Nguồn key: {src_txt}")

    def log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}\n"

        def _append():
            try:
                self.txt_log.configure(state="normal")
                self.txt_log.insert("end", line)
                self.txt_log.see("end")
                self.txt_log.configure(state="disabled")
            except Exception:
                pass

        try:
            self.after(0, _append)
        except Exception:
            pass

    def add_prompt(self, src: str, row_id, prompt_text: str, reason: str = "") -> bool:
        """Nhận prompt lỗi từ tab khác. Trả về True nếu nhận và sẽ rà soát, False nếu đã hết vòng."""
        text = (prompt_text or "").strip()
        if not text:
            return False

        existing = None
        if src != "tay" and row_id is not None:
            for it in self.items:
                if it["src"] == src and it["row_id"] == row_id:
                    existing = it
                    break

        if existing is not None:
            if existing.get("round", 1) >= MAX_ROUNDS:
                self.log(
                    f"⛔ [{SRC_LABEL.get(src, src)} #{row_id + 1}] Đã qua {MAX_ROUNDS} vòng rà soát mà vẫn lỗi — dừng tự động để tránh lặp vô tận."
                )
                return False
            existing.setdefault("history", []).append(existing.get("fixed") or existing.get("orig"))
            existing["round"] = existing.get("round", 1) + 1
            existing["reason"] = reason or existing.get("reason", "")
            existing["status"] = "cho"
            self.selected_uid = existing["uid"]
            self.log(
                f"📥 Nhận lại [{SRC_LABEL.get(src, src)} #{row_id + 1}] (vòng {existing['round']}/{MAX_ROUNDS}) — Lý do: {reason[:90]}"
            )
            _uir.render_list(self)
            if self.sw_auto_review.get():
                self._start([existing])
            return True

        self._seq += 1
        uid = f"rv_{self._seq}_{int(time.time() * 1000) % 100000}"
        item = {
            "uid": uid,
            "src": src or "tay",
            "row_id": row_id,
            "orig": text,
            "reason": reason or "",
            "status": "cho",
            "codes": [],
            "diagnosis": "",
            "changes": [],
            "fixed": "",
            "round": 1,
            "history": [],
        }
        self.items.append(item)
        self.selected_uid = uid
        rid_str = f" #{row_id + 1}" if row_id is not None else ""
        self.log(f"📥 Nhận prompt từ [{SRC_LABEL.get(src, src)}{rid_str}] — {text[:70]}…")
        _uir.render_list(self)

        if self.sw_auto_review.get():
            self._start([item])
        return True

    def add_manual(self, raw_text: str, reason: str = ""):
        lines = [ln.strip() for ln in (raw_text or "").splitlines() if ln.strip()]
        added = []
        for ln in lines:
            self._seq += 1
            uid = f"rv_{self._seq}_{int(time.time() * 1000) % 100000}"
            it = {
                "uid": uid,
                "src": "tay",
                "row_id": None,
                "orig": ln,
                "reason": reason or "Rà soát chủ động",
                "status": "cho",
                "codes": [],
                "diagnosis": "",
                "changes": [],
                "fixed": "",
                "round": 1,
                "history": [],
            }
            self.items.append(it)
            added.append(it)
        if added:
            self.selected_uid = added[0]["uid"]
            _uir.render_list(self)
            self._start(added)

    def _start(self, targets: list):
        if not targets:
            return
        if self._busy:
            self.log("⏳ Đang rà soát mục khác — các mục mới sẽ tự chạy nối tiếp ngay khi xong.")
            return
        snap = self._snapshot_cfg()
        self._busy = True
        threading.Thread(target=self._work_many, args=(targets, snap), daemon=True).start()

    def retry_stuck(self) -> int:
        """Quét các mục đang kẹt ('cho' hoặc 'loi') và kích hoạt chạy lại. Trả về số mục được đẩy."""
        stuck = [it for it in self.items if it.get("status") in ("cho", "loi")]
        if stuck and not self._busy:
            self._start(stuck)
        return len(stuck)

    def _drain_pending(self):
        """Nếu trong lúc bận có mục mới được thêm (status='cho'), chạy tiếp luôn."""
        pending = [it for it in self.items if it.get("status") == "cho"]
        if pending and not self._busy:
            self._start(pending)

    def review_selected(self):
        cur = self._current()
        if not cur:
            messagebox.showinfo("Chưa chọn", "Chọn 1 prompt trong danh sách trước.")
            return
        cur["status"] = "cho"
        self._start([cur])

    def review_all(self):
        targets = [it for it in self.items if it.get("status") in ("cho", "loi", "xong")]
        if not targets:
            return
        for it in targets:
            it["status"] = "cho"
        self._start(targets)

    def _snapshot_cfg(self) -> dict:
        """Đọc cấu hình trên main thread trước khi vào worker thread."""
        return {
            "url": self.ent_url.get().strip() or DEFAULT_URL,
            "key": self.key_now(),
            "model": self.cb_model.get().strip() or DEFAULT_MODEL,
            "models": list(self.cfg.get("models") or []),
            "auto_back": bool(self.sw_auto_back.get()),
        }

    def _work_many(self, targets: list, snap: dict):
        try:
            for it in targets:
                self._work_one(it, snap)
        finally:
            self._busy = False
            self.after(0, lambda: _uir.render_list(self))
            self.after(200, self._drain_pending)

    def _work_one(self, it: dict, snap: dict):
        it["status"] = "dang"
        self.after(0, lambda: _uir.render_list(self))

        candidates = fallback_models(snap["model"], snap["models"])
        res = None
        last_err = None

        for m in candidates:
            try:
                self.log(f"🤖 Đang rà soát bằng model {m} (vòng {it.get('round', 1)})…")
                res = call_router(
                    url=snap["url"],
                    key=snap["key"],
                    model=m,
                    prompt_text=it["orig"],
                    reason=it.get("reason", ""),
                    round_no=it.get("round", 1),
                    failed_before=it.get("history") or [],
                )
                if res and res.get("fixed_prompt"):
                    break
            except Exception as e:
                last_err = e
                self.log(f"⚠️ Model {m} lỗi: {e}")

        if not res or not res.get("fixed_prompt"):
            it["status"] = "loi"
            it["diagnosis"] = f"Rà soát thất bại: {last_err}"
            self.log(f"❌ Không rà soát được: {last_err}")
            return

        it["codes"] = list(res.get("violated_codes") or [])
        it["diagnosis"] = str(res.get("diagnosis") or "")
        it["changes"] = list(res.get("changes") or [])
        it["fixed"] = str(res.get("fixed_prompt") or "").strip()
        it["status"] = "xong"
        self.log(f"✅ Đã sửa xong [{SRC_LABEL.get(it['src'], it['src'])}] → {it['fixed'][:80]}…")

        if snap.get("auto_back") and it["src"] != "tay" and it.get("row_id") is not None:
            self.after(0, lambda item=it: self.send_back(item))

    def send_back(self, it: dict = None):
        item = it or self._current()
        if not item:
            return
        new_p = item.get("fixed", "").strip()
        if item is self._current():
            try:
                edited = self.txt_fixed.get("1.0", "end").strip()
                if edited:
                    new_p = edited
                    item["fixed"] = edited
            except Exception:
                pass
        if not new_p:
            messagebox.showwarning("Trống", "Chưa có prompt đã sửa để trả về.")
            return
        if item["src"] == "tay" or item.get("row_id") is None:
            return

        if self.pipeline and hasattr(self.pipeline, "retry_reviewed_prompt"):
            try:
                ok = self.pipeline.retry_reviewed_prompt(item["src"], item["row_id"], new_p)
                if ok:
                    item["status"] = "daguilai"
                    self.log(
                        f"📤 Đã trả prompt về [{SRC_LABEL.get(item['src'], item['src'])} #{item['row_id'] + 1}] và kích hoạt tạo lại."
                    )
                    _uir.render_list(self)
                else:
                    self.log("⚠️ Tab gốc không nhận được prompt trả về.")
            except Exception as e:
                self.log(f"❌ Lỗi trả prompt về tab gốc: {e}")

    def send_back_all(self):
        count = 0
        for it in list(self.items):
            if it.get("status") == "xong" and it["src"] != "tay" and it.get("row_id") is not None:
                self.send_back(it)
                count += 1
        self.lbl_status.configure(text=f"Đã trả {count} mục về tab tạo", text_color=_uir.T.OK)

    def _current(self):
        for it in self.items:
            if it["uid"] == self.selected_uid:
                return it
        return self.items[0] if self.items else None

    def select(self, uid: str):
        self.selected_uid = uid
        _uir.render_list(self)

    def clear_done(self):
        self.items = [it for it in self.items if it.get("status") != "daguilai"]
        if self.selected_uid and not any(it["uid"] == self.selected_uid for it in self.items):
            self.selected_uid = self.items[0]["uid"] if self.items else None
        _uir.render_list(self)

    def clear_all(self):
        self.items.clear()
        self.selected_uid = None
        _uir.render_list(self)

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ danh sách câu lệnh chờ rà soát / đã sửa."""
        if ask_confirm:
            if not messagebox.askyesno("Làm sạch Chuẩn hóa prompt", "Bạn muốn xoá toàn bộ danh sách câu lệnh trong tab Chuẩn hóa prompt không?"):
                return
        self.clear_all()
        for box_attr in ("txt_orig", "txt_diag", "txt_fixed"):
            bx = getattr(self, box_attr, None)
            if bx is not None:
                try:
                    bx.configure(state="normal")
                    bx.delete("1.0", "end")
                except Exception:
                    pass
        self.log("🧹 Đã làm sạch toàn bộ danh sách câu lệnh cũ.")

    def _render(self):
        _uir.render_list(self)

    def load_models(self):
        url = self.ent_url.get().strip() or DEFAULT_URL
        key = self.key_now()

        def _bg():
            try:
                ms = list_models(url, key)
                if not ms:
                    raise RuntimeError("Danh sách rỗng")
                chosen = pick_model(ms)
                self.cfg["models"] = ms

                def _apply():
                    self.cb_model.configure(values=ms)
                    self.cb_model.set(chosen)
                    self.save_cfg()
                    self.log(f"📋 Đã nạp {len(ms)} model từ 9Router (chọn: {chosen})")

                self.after(0, _apply)
            except Exception as e:
                self.log(f"⚠️ Không tải được danh sách model: {e}")

        threading.Thread(target=_bg, daemon=True).start()


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Điểm vào chuẩn cho AllToolYoutube."""
    pipeline = kwargs.get("pipeline")
    tab = ReviewTab(parent, pipeline=pipeline)
    tab.pack(fill="both", expand=True)
    return tab
