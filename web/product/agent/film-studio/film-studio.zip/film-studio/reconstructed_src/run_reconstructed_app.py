"""
run_reconstructed_app.py — Trình khởi chạy AllToolYoutube (Bản Phục Dựng Mã Nguồn Phần 3 -> 10)
───────────────────────────────────────────────────────────────────────────────────────────────
Nạp trực tiếp 16 module Python sạch đã phục dựng từ AllToolYoutube.exe:
  • Phần 3: KỊCH BẢN PROMPT VEO3   (veo3_prompt_tool2.py)
  • Phần 4: VEO 3 TEXT TO VIDEO    (tool5.py + ui_tool5.py)
  • Phần 5: VEO 3 ĐỒNG NHẤT        (tool7.py + ui_tool7.py)
  • Phần 6: ẢNH RA VIDEO (I2V)     (tool4.py + ui_tool4.py)
  • Phần 7: RÀ SOÁT PROMPT         (prompt_review.py + ui_review.py)
  • Phần 8: TẠO VIDEO (SYNC + FX)  (tool2.py + ui_tool2.py)
  • Phần 9: VOICE HATHANH          (openspeaker_tts.py + ui_openspeaker.py)
  • Phần 10: VIDEO TO PROMPT       (videopromt.py)
"""

import json
import os
import shutil
import sys
import traceback
import uuid
from tkinter import filedialog, messagebox

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

# Bảo vệ stdout/stderr UTF-8 cho cả python.exe (cp1252) và pythonw.exe (None)
if sys.stdout is None:
    sys.stdout = open(os.path.join(SRC_DIR, "app_runtime.log"), "a", encoding="utf-8", buffering=1)
elif hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr is None:
    sys.stderr = sys.stdout
elif hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import tkinter as tk
import customtkinter as ctk

# Bổ sung thư mục gốc F:\HaThanhStudio\AllTool vào PATH để dùng chung ffmpeg.exe nếu có
ORIG_APP_DIR = r"F:\HaThanhStudio\AllTool"
if os.path.isdir(ORIG_APP_DIR):
    os.environ["PATH"] = ORIG_APP_DIR + os.pathsep + os.environ.get("PATH", "")

from ui import T, F, set_density_early, card, row, lbl, btn, btn_primary, sbtn, dialog, account_row, opt, entry, TabStrip
from google_ultra_bridge import init_global_bridge, get_global_bridge

import veo3_prompt_tool2
import tool5
import tool6_image_consist
import tool7
import tool_muse_charvideo
import tool4
import prompt_review
import tool2
import openspeaker_tts
import tool_vids_voice
import videopromt


TABS_SPEC = [
    ("📝 Prompt", "veo3_prompt", veo3_prompt_tool2),
    ("🔍 Video to prompt", "video_to_prompt", videopromt),
    ("✨ Chuẩn hóa prompt", "prompt_review", prompt_review),
    ("🎬 Text to video", "veo3_t2v", tool5),
    ("🎨 Image đồng nhất", "image_consist", tool6_image_consist),
    ("🎭 Video đồng nhất", "veo3_consist", tool7),
    ("🎞 Video Muse", "muse_video", tool_muse_charvideo),
    ("📷 Image to video", "veo3_i2v", tool4),
    ("🔊 Voice", "voice_hathanh", openspeaker_tts),
    ("🎙 Voice Gemini 2", "vids_voice", tool_vids_voice),
    ("🎞 Hậu kỳ", "video_merge", tool2),
]

WORKFLOW_GROUPS = [
    (
        "BƯỚC 1 · PROMPT & KỊCH BẢN",
        [
            ("veo3_prompt", "📝 Prompt", "Từ ý tưởng tạo kịch bản & cảnh quay"),
            ("video_to_prompt", "🔍 Video to prompt", "Bóc tách prompt từ video mẫu"),
            ("prompt_review", "✨ Chuẩn hóa prompt", "Làm sạch từ nhạy cảm bị Google chặn"),
        ],
    ),
    (
        "BƯỚC 2 · TẠO ẢNH & VIDEO AI",
        [
            ("veo3_t2v", "🎬 Text to video", "Quay hàng loạt cảnh phim từ prompt"),
            ("image_consist", "🎨 Image đồng nhất", "Tạo ảnh đồng nhất qua từng phân cảnh"),
            ("veo3_consist", "🎭 Video đồng nhất", "Đồng nhất mặt nhân vật & giọng nói"),
            ("muse_video", "🎞 Video Muse", "Đồng nhất nhân vật qua Muse.ai"),
            ("veo3_i2v", "📷 Image to video", "Chuyển động từ 1 hoặc 2 ảnh đầu-cuối"),
        ],
    ),
    (
        "BƯỚC 3 · VOICE & HẬU KỲ",
        [
            ("voice_hathanh", "🔊 Voice", "Đọc lời thoại đa giọng & xuất phụ đề SRT"),
            ("vids_voice", "🎙 Voice Gemini 2", "23 giọng Google Vids + thẻ cảm xúc"),
            ("video_merge", "🎞 Hậu kỳ", "Ghép giọng đọc khớp video + 58 chuyển cảnh"),
        ],
    ),
]

TAB_GUIDE_META = {
    "veo3_prompt": {
        "stage": "BƯỚC 1/3 · SOẠN PROMPT",
        "title": "📝 Prompt — Tạo Kịch Bản & Câu Lệnh Cảnh Quay",
        "steps": "① Nhập ý tưởng (hoặc bấm '💡 Nạp mẫu thử')  ➔  ② Bấm '✨ Viết Kịch Bản'  ➔  ③ Bấm '📤 Đẩy sang Image/Video đồng nhất'",
        "next_key": "image_consist",
        "next_label": "Sang Image đồng nhất ➔",
    },
    "video_to_prompt": {
        "stage": "BƯỚC 1/3 · TÁCH PROMPT",
        "title": "🔍 Video to prompt — Tách Kịch Bản Từ Video Có Sẵn",
        "steps": "① Chọn file video mẫu (.mp4)  ➔  ② Bấm '🔍 Bắt Đầu Tách Kịch Bản'  ➔  ③ Bấm '📤 Đẩy sang Text to video'",
        "next_key": "veo3_t2v",
        "next_label": "Sang Text to video ➔",
    },
    "prompt_review": {
        "stage": "BƯỚC 1/3 · CHUẨN HÓA AN TOÀN",
        "title": "✨ Chuẩn hóa prompt — Làm Sạch Câu Lệnh Bị Chặn",
        "steps": "① Tự động nhận prompt bị chặn (hoặc bấm '+ Dán thêm')  ➔  ② AI lọc sạch từ cấm  ➔  ③ Tự trả về tab tạo video",
        "next_key": "veo3_t2v",
        "next_label": "Sang Text to video ➔",
    },
    "veo3_t2v": {
        "stage": "BƯỚC 2/3 · TEXT TO VIDEO",
        "title": "🎬 Text to video — Quay Video Hàng Loạt Từ Văn Bản",
        "steps": "① Dán prompt (mỗi dòng 1 cảnh)  ➔  ② Bấm '🎬 Bắt Đầu Quay Video'  ➔  ③ Bấm '🔗 Nối thành phim dài'",
        "next_key": "voice_hathanh",
        "next_label": "Sang Voice ➔",
    },
    "image_consist": {
        "stage": "BƯỚC 2/3 · IMAGE ĐỒNG NHẤT",
        "title": "🎨 Image đồng nhất — Tạo Ảnh Nhân Vật & Bối Cảnh Đồng Nhất Qua Từng Phân Cảnh",
        "steps": "① Nhập hồ sơ/ảnh mẫu ở tab '👤 Ảnh Mẫu'  ➔  ② Nạp câu lệnh phân cảnh  ➔  ③ Bấm '🎨 Tạo Ảnh Đồng Nhất' rồi đẩy sang Video Muse / Image to video",
        "next_key": "muse_video",
        "next_label": "Sang Video Muse ➔",
    },
    "veo3_consist": {
        "stage": "BƯỚC 2/3 · VIDEO ĐỒNG NHẤT",
        "title": "🎭 Video đồng nhất — Giữ Nguyên Khuôn Mặt Nhân Vật & Giọng Nói",
        "steps": "① Nạp ảnh mẫu vào tab '👤 Ảnh Mẫu'  ➔  ② Viết 'MÃ_ẢNH | câu lệnh'  ➔  ③ Bấm 'Tạo video'",
        "next_key": "voice_hathanh",
        "next_label": "Sang Voice ➔",
    },
    "muse_video": {
        "stage": "BƯỚC 2/3 · VIDEO MUSE",
        "title": "🎞 Video Muse — Quay Video Nhân Vật Đồng Nhất Bằng Muse.ai",
        "steps": "① Chọn thư mục ảnh nhân vật (hoặc nhận từ Image đồng nhất)  ➔  ② Viết 'CHAR_01 | câu lệnh'  ➔  ③ Bấm 'Tạo video'",
        "next_key": "vids_voice",
        "next_label": "Sang Voice Gemini 2 ➔",
    },
    "veo3_i2v": {
        "stage": "BƯỚC 2/3 · IMAGE TO VIDEO",
        "title": "📷 Image to video — Biến Ảnh Tĩnh Thành Video Chuyển Động",
        "steps": "① Chọn ảnh bắt đầu (hoặc nhận từ tab Image đồng nhất)  ➔  ② Nhập mô tả  ➔  ③ Bấm 'Tạo video'",
        "next_key": "video_merge",
        "next_label": "Sang Hậu kỳ ➔",
    },
    "voice_hathanh": {
        "stage": "BƯỚC 3/3 · PHÒNG THU VOICE",
        "title": "🔊 Voice — Giọng Đọc AI Đa Ngôn Ngữ & Xuất Phụ Đề SRT",
        "steps": "① Chọn giọng đọc (Sẵn 12 giọng Edge-TTS miễn phí)  ➔  ② Nhập kịch bản lời thoại  ➔  ③ Bấm '🔊 Đọc thành tiếng'",
        "next_key": "video_merge",
        "next_label": "Sang Hậu kỳ ➔",
    },
    "vids_voice": {
        "stage": "BƯỚC 3/3 · VOICE GEMINI 2",
        "title": "🎙 Voice Gemini 2 — 23 Giọng Đọc Google Vids + Tự Gắn Thẻ Cảm Xúc",
        "steps": "① Bấm 'Quản lý cookie' nạp cookie Google Vids  ➔  ② Chọn giọng đọc + dán kịch bản (.txt / .srt)  ➔  ③ Bấm 'TẠO VOICE'",
        "next_key": "video_merge",
        "next_label": "Sang Hậu kỳ ➔",
    },
    "video_merge": {
        "stage": "BƯỚC 3/3 · HẬU KỲ VIDEO",
        "title": "🎞 Hậu kỳ — Đồng Bộ Giọng Đọc, Lồng Nhạc & 58 Chuyển Cảnh",
        "steps": "① Chọn thư mục Audio & thư mục Video/Ảnh  ➔  ② Chọn kiểu đồng bộ & chuyển cảnh  ➔  ③ Bấm '🎞 Bắt Đầu Dựng'",
        "next_key": "veo3_prompt",
        "next_label": "↺ Về Prompt",
    },
}


class ReconstructedAllToolApp(ctk.CTk):
    """Cửa sổ chính Film studio (Tích hợp FlowKit & 8 chức năng làm phim AI toàn diện)."""

    VEO_ACC_FILES = ("veo_accounts.json", "tool4.json", "tool5.json", "tool6.json", "tool7.json", "accounts.json")

    def __init__(self):
        set_density_early()
        ctk.set_appearance_mode("dark")
        super().__init__()
        F.init()

        self.title("Film studio")
        self.geometry("1480x900")
        self.minsize(1200, 740)
        self.configure(fg_color=T.BG)

        self._tab_frames = {}
        self._tab_btns = {}
        self._tab_sub_lbls = {}
        self._tab_instances = {}
        self._current_key = None
        self._shared_acc_list_frame = None
        self._lbl_ultra_status = None
        self._user_closing = False

        self._sync_initial_configs_from_orig()
        self.ultra_bridge = init_global_bridge(
            SRC_DIR,
            on_accounts_updated=lambda: self.after(0, self._on_bridge_accounts_updated),
            on_status_changed=lambda st: self.after(0, lambda s=st: self._on_bridge_status_changed(s)),
        )
        try:
            import film_studio_mcp_server as _mcp_srv

            self.mcp_server = _mcp_srv.start_background_mcp_server(
                port=3100,
                gui_callback=lambda ev, data: self.after(0, lambda e=ev, d=data: self._on_mcp_gui_event(e, d)),
            )
        except Exception as e:
            print(f"[MCP-WARN] Không thể khởi chạy MCP Server ngầm: {e}", flush=True)
            self.mcp_server = None

        self._build_shell()
        self.select_tab("veo3_prompt")
        self._refresh_license_badge()
        self.after(200, self._bring_to_front)
        if "--self-test" not in sys.argv:
            self.after(450, self._check_license_on_startup)


    def report_callback_exception(self, exc, val, tb):
        """Chặn mọi ngoại lệ callback Tkinter làm sập mainloop, chỉ ghi log an toàn."""
        try:
            err_txt = "".join(traceback.format_exception(exc, val, tb))
            print(f"[TK-CALLBACK-WARN]\n{err_txt}", flush=True)
        except Exception:
            pass

    def _on_bridge_accounts_updated(self):
        """Callback tự động khi GoogleUltraBridge bắt được Token + Session từ Chrome."""
        self._refresh_header_acc_badge()
        self._render_shared_acc_list()
        for key in ("veo3_t2v", "image_consist", "veo3_consist", "veo3_i2v"):
            inst = self._tab_instances.get(key)
            if inst is not None:
                try:
                    if hasattr(inst, "_update_acc_count_label"):
                        inst._update_acc_count_label()
                    if hasattr(inst, "_render_account_list"):
                        inst._render_account_list()
                except Exception:
                    pass

    def _on_bridge_status_changed(self, status_text: str):
        if self._lbl_ultra_status is not None and self._lbl_ultra_status.winfo_exists():
            col = T.OK if "🟢" in status_text else ("#fbbf24" if "⏳" in status_text or "🟡" in status_text else T.MUTED)
            self._lbl_ultra_status.configure(text=status_text, text_color=col)
        if hasattr(self, "btn_ultra_login"):
            if "🟢" in status_text:
                accs = list(self.ultra_bridge.connected_accounts.keys())
                short_mail = accs[0].split("@")[0] if accs else "Đã kết nối"
                self.btn_ultra_login.configure(
                    text=f"🟢 Google Ultra: {short_mail}",
                    fg_color="#10b981",
                    hover_color="#34d399",
                    text_color="#051b11",
                )
            else:
                self.btn_ultra_login.configure(
                    text="🌐 Đăng Nhập Google Ultra",
                    fg_color="#1f6feb",
                    hover_color="#388bfd",
                    text_color="#ffffff",
                )

    def _QuickLoginUltra(self, slot: int = 1):
        ok, msg = self.ultra_bridge.open_google_ultra_browser(slot=slot)
        if not ok:
            messagebox.showerror("Lỗi mở trình duyệt", msg, parent=self)

    def _sync_initial_configs_from_orig(self):
        """Tự động đồng bộ file tài khoản & API key sẵn có từ F:\\HaThanhStudio\\AllTool nếu bản phục dựng chưa có."""
        if not os.path.isdir(ORIG_APP_DIR):
            return
        for fname in (*self.VEO_ACC_FILES, "gemini.txt", "router9_key.txt"):
            src = os.path.join(ORIG_APP_DIR, fname)
            dst = os.path.join(SRC_DIR, fname)
            if os.path.isfile(src) and not os.path.isfile(dst):
                try:
                    shutil.copy2(src, dst)
                except Exception:
                    pass
        accs = self._load_all_known_veo_accounts(include_orig=True)
        if accs:
            self._write_shared_veo_accounts(accs, notify_tabs=False)

    def _bring_to_front(self):
        try:
            self.deiconify()
            self.state("normal")
            self.lift()
            self.attributes("-topmost", True)
            self.update_idletasks()
            import ctypes
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id()) or self.winfo_id()
            ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            ctypes.windll.user32.SetForegroundWindow(hwnd)
            self.after(800, lambda: self.attributes("-topmost", False))
            self.focus_force()
            print(f"[XÁC MINH GUI] Window HWND={hwnd} Title='{self.title()}' is visible and active!", flush=True)
        except Exception as e:
            print(f"[GUI WARN] _bring_to_front: {e}", flush=True)

    def _build_shell(self):
        """Bố cục Studio 2 Cột Trực Quan Dành Cho Người Mới:
        - Cột Trái (Sidebar 250px): Quy trình 3 Bước rõ ràng + Trung tâm Tài khoản & API.
        - Cột Phải (Workspace): Thanh Hướng Dẫn Nhanh 3 Bước ở trên + Không gian làm việc rộng rãi ở dưới.
        """
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=0, minsize=252)
        self.grid_columnconfigure(1, weight=1)

        # ═══════════════════════════════════════════════════════════════════
        # 1. CỘT TRÁI: THANH ĐIỀU HƯỚNG THEO QUY TRÌNH 3 BƯỚC
        # ═══════════════════════════════════════════════════════════════════
        sidebar = ctk.CTkFrame(
            self,
            fg_color=T.SIDEBAR,
            corner_radius=0,
            width=252,
            border_width=1,
            border_color=T.DIVIDER,
        )
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)
        sidebar.grid_rowconfigure(1, weight=1)
        sidebar.grid_columnconfigure(0, weight=1)

        # Logo & Tên ứng dụng
        brand_box = ctk.CTkFrame(sidebar, fg_color="#0b1117", corner_radius=0)
        brand_box.grid(row=0, column=0, sticky="ew")
        ctk.CTkLabel(
            brand_box,
            text="🎬 FILM STUDIO",
            font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"),
            text_color=T.ACCENT,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(12, 1))
        ctk.CTkLabel(
            brand_box,
            text="Xưởng Làm Phim AI · FlowKit Engine",
            font=F.tiny,
            text_color=T.MUTED,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(0, 10))

        # Danh sách 8 chức năng chia theo 3 bước quy trình
        nav_scroll = ctk.CTkScrollableFrame(
            sidebar,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_fg_color=T.SIDEBAR,
            scrollbar_button_color="#263445",
            scrollbar_button_hover_color=T.ACCENT,
        )
        nav_scroll.grid(row=1, column=0, sticky="nsew", padx=6, pady=4)
        nav_scroll.grid_columnconfigure(0, weight=1)

        for grp_title, items in WORKFLOW_GROUPS:
            grp_lbl = ctk.CTkLabel(
                nav_scroll,
                text=grp_title,
                font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
                text_color="#38bdf8",
                anchor="w",
            )
            grp_lbl.pack(fill="x", padx=8, pady=(10, 3))

            for key, title_txt, desc_txt in items:
                item_card = ctk.CTkFrame(
                    nav_scroll,
                    fg_color="transparent",
                    corner_radius=8,
                )
                item_card.pack(fill="x", padx=2, pady=2)

                b = ctk.CTkButton(
                    item_card,
                    text=title_txt,
                    height=36,
                    anchor="w",
                    corner_radius=8,
                    fg_color="transparent",
                    hover_color=T.TAB_HOVER,
                    text_color=T.TEXT_DIM,
                    font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
                    command=lambda k=key: self.select_tab(k),
                )
                b.pack(fill="x")
                self._tab_btns[key] = b

        # Hộp điều khiển Tài khoản & Kết nối nhanh ở đáy Sidebar
        acc_dock = ctk.CTkFrame(
            sidebar,
            fg_color="#0c1218",
            corner_radius=10,
            border_width=1,
            border_color=T.BORDER,
        )
        acc_dock.grid(row=2, column=0, sticky="ew", padx=8, pady=(4, 10))
        acc_dock.grid_columnconfigure((0, 1), weight=1)

        ctk.CTkLabel(
            acc_dock,
            text="⚡ KẾT NỐI TÀI KHOẢN & KHO LƯU TRỮ",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=T.MUTED,
            anchor="w",
        ).grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(8, 4))

        self.btn_ultra_login = ctk.CTkButton(
            acc_dock,
            text="🌐 Đăng Nhập Google Ultra",
            height=32,
            corner_radius=7,
            fg_color="#1f6feb",
            hover_color="#388bfd",
            text_color="#ffffff",
            font=F.h,
            command=lambda: self._QuickLoginUltra(slot=1),
        )
        self.btn_ultra_login.grid(row=1, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 5))

        self.btn_veo_acc = ctk.CTkButton(
            acc_dock,
            text="🔑 Tài Khoản VEO (0)",
            height=30,
            corner_radius=7,
            fg_color=T.ACCENT,
            hover_color=T.ACCENT_HOVER,
            text_color="#05131d",
            font=F.h,
            command=self.open_shared_veo_accounts,
        )
        self.btn_veo_acc.grid(row=2, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 5))

        self.btn_gemini_api = ctk.CTkButton(
            acc_dock,
            text="Nhập API",
            height=28,
            corner_radius=7,
            fg_color=T.INPUT,
            hover_color=T.TAB_HOVER,
            border_color=T.BORDER,
            border_width=1,
            text_color=T.TEXT_STRONG,
            font=F.label,
            command=self.open_gemini_api_dialog,
        )
        self.btn_gemini_api.grid(row=3, column=0, sticky="ew", padx=(8, 3), pady=(0, 5))

        self.btn_open_videos = ctk.CTkButton(
            acc_dock,
            text="📂 Mở Kho Video",
            height=28,
            corner_radius=7,
            fg_color=T.INPUT,
            hover_color=T.TAB_HOVER,
            border_color=T.BORDER,
            border_width=1,
            text_color=T.TEXT_STRONG,
            font=F.label,
            command=self._open_default_video_folder,
        )
        self.btn_open_videos.grid(row=3, column=1, sticky="ew", padx=(3, 8), pady=(0, 5))

        mcp_port = getattr(getattr(self, "mcp_server", None), "port", 3100)
        self.btn_mcp_center = ctk.CTkButton(
            acc_dock,
            text=f"🔌 Kết Nối AI (MCP · :{mcp_port})",
            height=30,
            corner_radius=7,
            fg_color="#0f293a",
            hover_color="#163b52",
            border_color="#38bdf8",
            border_width=1,
            text_color="#7ce8ff",
            font=F.h,
            command=self.open_mcp_control_center_dialog,
        )
        self.btn_mcp_center.grid(row=4, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 5))

        self.btn_license_key = ctk.CTkButton(
            acc_dock,
            text="🔑 Bản Quyền: Đang kiểm tra...",
            height=30,
            corner_radius=7,
            fg_color="#1f2412",
            hover_color="#2e361b",
            border_color="#facc15",
            border_width=1,
            text_color="#fde047",
            font=F.h,
            command=self.open_license_activation_dialog,
        )
        self.btn_license_key.grid(row=5, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 8))

        self._refresh_header_acc_badge()


        # ═══════════════════════════════════════════════════════════════════
        # 2. CỘT PHẢI: THANH HƯỚNG DẪN CHO NGƯỜI MỚI + WORKSPACE CHÍNH
        # ═══════════════════════════════════════════════════════════════════
        right_pane = ctk.CTkFrame(self, fg_color=T.BG, corner_radius=0)
        right_pane.grid(row=0, column=1, sticky="nsew")
        right_pane.grid_rowconfigure(1, weight=1)
        right_pane.grid_columnconfigure(0, weight=1)

        # Thanh Hướng Dẫn Trực Quan (Guide Banner)
        self.guide_banner = ctk.CTkFrame(
            right_pane,
            fg_color="#131c26",
            corner_radius=10,
            border_width=1,
            border_color="#233549",
        )
        self.guide_banner.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 2))
        self.guide_banner.grid_columnconfigure(1, weight=1)

        self.lbl_guide_stage = ctk.CTkLabel(
            self.guide_banner,
            text="BƯỚC 1/3",
            fg_color="#00b4d8",
            text_color="#04121c",
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            padx=10,
            pady=4,
        )
        self.lbl_guide_stage.grid(row=0, column=0, rowspan=2, padx=(12, 10), pady=10, sticky="w")

        self.lbl_guide_title = ctk.CTkLabel(
            self.guide_banner,
            text="📝 Biên Kịch & Tạo Câu Lệnh Cảnh Quay",
            text_color="#f8fbff",
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            anchor="w",
        )
        self.lbl_guide_title.grid(row=0, column=1, sticky="ew", pady=(8, 0))

        self.lbl_guide_steps = ctk.CTkLabel(
            self.guide_banner,
            text="Hướng dẫn nhanh...",
            text_color="#7ce8ff",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            anchor="w",
        )
        self.lbl_guide_steps.grid(row=1, column=1, sticky="ew", pady=(0, 8))

        self._next_step_target = "veo3_t2v"
        self.btn_clear_tab = ctk.CTkButton(
            self.guide_banner,
            text="🧹 Làm sạch tab này",
            height=32,
            width=142,
            corner_radius=8,
            fg_color="#2a1b24",
            hover_color="#3f2433",
            border_width=1,
            border_color="#f43f5e",
            text_color="#fda4af",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=lambda: self.clear_current_tab_session(ask_confirm=True),
        )
        self.btn_clear_tab.grid(row=0, column=2, rowspan=2, padx=(6, 4), pady=10, sticky="e")

        self.btn_clear_all = ctk.CTkButton(
            self.guide_banner,
            text="🧹 Làm sạch toàn bộ",
            height=32,
            width=146,
            corner_radius=8,
            fg_color="#311b1b",
            hover_color="#4c2323",
            border_width=1,
            border_color="#ef4444",
            text_color="#fca5a5",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=lambda: self.clear_all_tabs_session(ask_confirm=True),
        )
        self.btn_clear_all.grid(row=0, column=3, rowspan=2, padx=(0, 6), pady=10, sticky="e")

        self.auto_shutdown_var = tk.BooleanVar(value=False)
        self.chk_auto_shutdown = ctk.CTkCheckBox(
            self.guide_banner,
            text="🔌 Tự tắt máy khi xong",
            variable=self.auto_shutdown_var,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color="#fde047",
            fg_color="#dc2626",
            hover_color="#b91c1c",
            checkbox_width=18,
            checkbox_height=18,
        )
        self.chk_auto_shutdown.grid(row=0, column=5, rowspan=2, padx=(0, 12), pady=10, sticky="e")

        self.btn_next_step = ctk.CTkButton(
            self.guide_banner,
            text="Sang Bước 2: Quay Video ➔",
            height=32,
            width=190,
            corner_radius=8,
            fg_color="#1c2b3b",
            hover_color="#293f56",
            border_width=1,
            border_color="#38bdf8",
            text_color="#7ce8ff",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            command=lambda: self.select_tab(self._next_step_target),
        )
        self.btn_next_step.grid(row=0, column=4, rowspan=2, padx=(0, 12), pady=10, sticky="e")

        # Vùng chứa các Tab
        self.body = ctk.CTkFrame(right_pane, fg_color=T.BG, corner_radius=0)
        self.body.grid(row=1, column=0, sticky="nsew")
        self.body.grid_rowconfigure(0, weight=1)
        self.body.grid_columnconfigure(0, weight=1)

    def _open_default_video_folder(self):
        out_dir = os.path.join(SRC_DIR, "Video_Result")
        os.makedirs(out_dir, exist_ok=True)
        try:
            os.startfile(out_dir)
        except Exception:
            pass

    # ═══════════════════════════════════════════════════════════════════════
    # QUẢN LÝ TÀI KHOẢN VEO / IMAGEN DÙNG CHUNG (Đồng bộ tool4/5/6/7)
    # ═══════════════════════════════════════════════════════════════════════
    def _normalize_acc_item(self, raw: dict) -> dict | None:
        if not isinstance(raw, dict):
            return None
        tok = str(raw.get("token") or "").strip()
        email = str(raw.get("email") or "").strip()
        if not tok:
            return None
        # Bỏ qua các token captured_* hoặc ya29.* cũ đã bị Google vô hiệu hóa từ 21/10/2026
        if email.startswith("captured_") or tok.startswith("ya29."):
            return None
        pid = str(raw.get("project_id") or "").strip() or str(uuid.uuid4())
        item = {
            "email": email,
            "token": tok,
            "project_id": pid,
            "credits": raw.get("credits", "Ultra"),
        }
        sess = str(raw.get("labs_session") or "").strip()
        if sess:
            item["labs_session"] = sess
        return item

    def _load_all_known_veo_accounts(self, include_orig: bool = False) -> list[dict]:
        dirs = [SRC_DIR]
        if include_orig and os.path.isdir(ORIG_APP_DIR) and ORIG_APP_DIR not in dirs:
            dirs.append(ORIG_APP_DIR)
        merged = []
        seen_tokens = set()
        for d in dirs:
            for fname in self.VEO_ACC_FILES:
                fpath = os.path.join(d, fname)
                if not os.path.isfile(fpath):
                    continue
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    raw_list = data.get("accounts", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
                    for a in raw_list:
                        norm = self._normalize_acc_item(a)
                        if norm and norm["token"] not in seen_tokens:
                            seen_tokens.add(norm["token"])
                            merged.append(norm)
                except Exception:
                    pass
        return merged

    def _write_shared_veo_accounts(self, accounts: list[dict], notify_tabs: bool = True):
        payload = {"accounts": accounts}
        for fname in self.VEO_ACC_FILES:
            fpath = os.path.join(SRC_DIR, fname)
            try:
                with open(fpath, "w", encoding="utf-8") as f:
                    json.dump(payload, f, indent=2, ensure_ascii=False)
            except Exception:
                pass
        self._refresh_header_acc_badge(len(accounts))
        if notify_tabs:
            for key in ("veo3_t2v", "veo3_consist", "veo3_i2v"):
                inst = self._tab_instances.get(key)
                if inst is not None:
                    try:
                        if hasattr(inst, "_update_acc_count_label"):
                            inst._update_acc_count_label()
                        if hasattr(inst, "_render_account_list"):
                            inst._render_account_list()
                    except Exception:
                        pass

    def _refresh_header_acc_badge(self, count: int | None = None):
        if not hasattr(self, "btn_veo_acc"):
            return
        if count is None:
            count = len(self._load_all_known_veo_accounts(include_orig=False))
        self.btn_veo_acc.configure(text=f"🔑 TÀI KHOẢN VEO ({count})")

    def _delete_account(self, idx: int):
        """Hàm callback khi bấm nút Xóa ✕ trên dòng account_row của bảng dùng chung."""
        accs = self._load_all_known_veo_accounts(include_orig=False)
        if 0 <= idx < len(accs):
            accs.pop(idx)
            self._write_shared_veo_accounts(accs, notify_tabs=True)
            self._render_shared_acc_list()

    def _render_shared_acc_list(self):
        target = self._shared_acc_list_frame
        if target is None or not target.winfo_exists():
            return
        for w in target.winfo_children():
            w.destroy()
        accs = self._load_all_known_veo_accounts(include_orig=False)
        if not accs:
            lbl(
                target,
                "Chưa có tài khoản nào — bấm “➕ Thêm tài khoản mới” hoặc “📂 Chọn file JSON”.",
                T.MUTED,
                F.ui,
            ).pack(pady=28)
            return
        for i, acc in enumerate(accs):
            account_row(self, target, i, acc)

    def open_shared_veo_accounts(self):
        """Hộp thoại Quản lý Tài khoản VEO / Imagen dùng chung cho toàn bộ các tab VEO."""
        win = dialog(self, "Quản lý Tài khoản Google Ultra / VEO 3 — Tự động 1-Click", 720, 650, grab=False)

        head = row(win)
        head.pack(fill="x", padx=18, pady=(14, 2))
        lbl(head, "QUẢN LÝ TÀI KHOẢN GOOGLE ULTRA & VEO 3", T.TEXT_STRONG, F.title).pack(side="left")

        # ── KHỐI 1: ĐĂNG NHẬP GOOGLE ULTRA TỰ ĐỘNG 1-CLICK (KHUYÊN DÙNG) ──
        ultra_card = card(win, fg_color="#182030", corner_radius=T.RADIUS)
        ultra_card.pack(fill="x", padx=18, pady=(6, 10))

        lbl(
            ultra_card,
            "⚡ CÁCH DỄ NHẤT: CHỈ CẦN ĐĂNG NHẬP TÀI KHOẢN GOOGLE ULTRA (TỰ ĐỘNG 100%)",
            "#58a6ff",
            F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 2))

        lbl(
            ultra_card,
            "Bấm nút bên dưới để mở Chrome → Đăng nhập Gmail Google Ultra của anh trên trang labs.google.\n"
            "Tool sẽ TỰ ĐỘNG lấy Token (ya29), Cookie Session, Project ID và TỰ ĐỘNG giải Captcha ngầm!",
            T.TEXT_DIM,
            F.label,
            anchor="w",
            justify="left",
        ).pack(fill="x", padx=14, pady=(0, 8))

        u_btns = row(ultra_card)
        u_btns.pack(fill="x", padx=14, pady=(0, 8))

        ctk.CTkButton(
            u_btns,
            text="🌐 Mở Chrome Google Ultra #1",
            height=34,
            width=215,
            corner_radius=T.RADIUS,
            fg_color="#1f7a4c",
            hover_color="#25915a",
            text_color="#ffffff",
            font=F.h,
            command=lambda: self._QuickLoginUltra(slot=1),
        ).pack(side="left", padx=(0, 5))

        btn(u_btns, "➕ TK Ultra #2", lambda: self._QuickLoginUltra(slot=2), width=102).pack(
            side="left", padx=(0, 5)
        )
        btn(u_btns, "➕ TK Ultra #3", lambda: self._QuickLoginUltra(slot=3), width=102).pack(
            side="left", padx=(0, 5)
        )
        btn(u_btns, "➕ TK Ultra #4", lambda: self._QuickLoginUltra(slot=4), width=102).pack(
            side="left", padx=(0, 5)
        )
        btn(
            u_btns,
            "🔄 Quét ngay",
            lambda: self.ultra_bridge.scan_and_sync_from_browsers(),
            width=98,
        ).pack(side="left")

        st_txt = self.ultra_bridge.last_status_text
        st_col = T.OK if "🟢" in st_txt else ("#e0a458" if "⏳" in st_txt or "🟡" in st_txt else T.MUTED)
        self._lbl_ultra_status = lbl(ultra_card, st_txt, st_col, F.ui_sb, anchor="w")
        self._lbl_ultra_status.pack(fill="x", padx=14, pady=(0, 10))

        # ── KHỐI 2: DANH SÁCH TÀI KHOẢN ĐÃ ĐỒNG BỘ & NHẬP THỦ CÔNG ──
        top_btns = row(win)
        top_btns.pack(fill="x", padx=18, pady=(0, 6))
        btn(top_btns, "➕ Dán JSON / Token thủ công", lambda: self._open_add_shared_account(win), width=190).pack(
            side="left", padx=(0, 6)
        )
        btn(top_btns, "📂 Nhập từ file JSON", lambda: self._import_veo_json_file(win), width=150).pack(
            side="left", padx=(0, 6)
        )
        btn(top_btns, "🔄 Đọc lại từ tool", lambda: self._reload_from_orig_dir(win), width=140).pack(
            side="left", padx=(0, 6)
        )

        box = card(win)
        box.pack(fill="both", expand=True, padx=18, pady=4)
        list_frame = ctk.CTkScrollableFrame(
            box,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_fg_color=T.CARD,
            scrollbar_button_color="#3a3d4d",
            scrollbar_button_hover_color=T.ACCENT,
        )
        list_frame.pack(fill="both", expand=True, padx=8, pady=8)
        self._shared_acc_list_frame = list_frame
        self._render_shared_acc_list()

        footer = row(win)
        footer.pack(fill="x", padx=18, pady=12)
        btn_primary(
            footer,
            "💾 Lưu & đồng bộ",
            lambda: (
                self._write_shared_veo_accounts(self._load_all_known_veo_accounts(include_orig=False), notify_tabs=True),
                messagebox.showinfo("Đã đồng bộ", "Đã lưu & đồng bộ tài khoản cho toàn bộ các tool VEO!", parent=win),
            ),
            width=145,
        ).pack(side="right", padx=(6, 0))
        sbtn(footer, "Đóng", win.destroy, width=96).pack(side="right")

    def _parse_accounts_input(self, raw_text: str) -> list[dict]:
        text = (raw_text or "").strip()
        if not text:
            return []
        parsed_items = []
        # Thử parse JSON trước
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                if isinstance(data.get("accounts"), list):
                    parsed_items = data["accounts"]
                elif data.get("token"):
                    parsed_items = [data]
            elif isinstance(data, list):
                parsed_items = data
        except Exception:
            # Cho phép dán trực tiếp mỗi dòng 1 token ya29...
            for line in text.splitlines():
                s = line.strip().strip(",").strip('"').strip("'")
                if s and (s.startswith("ya29.") or len(s) > 25):
                    parsed_items.append({"token": s, "project_id": str(uuid.uuid4())})
        valid = []
        for a in parsed_items:
            norm = self._normalize_acc_item(a)
            if norm:
                valid.append(norm)
        return valid

    def _merge_and_save_accounts(self, new_valid: list[dict], parent_win=None) -> tuple[int, int, int]:
        existing = self._load_all_known_veo_accounts(include_orig=False)
        by_token = {a["token"]: i for i, a in enumerate(existing)}
        added = 0
        updated = 0
        for v in new_valid:
            tok = v["token"]
            if tok in by_token:
                idx = by_token[tok]
                # Cập nhật thêm project_id / labs_session nếu có
                existing[idx].update({k: val for k, val in v.items() if val})
                updated += 1
            else:
                by_token[tok] = len(existing)
                existing.append(v)
                added += 1
        self._write_shared_veo_accounts(existing, notify_tabs=True)
        self._render_shared_acc_list()
        return added, updated, len(existing)

    def _open_add_shared_account(self, parent_win=None):
        dlg = dialog(parent_win or self, "Thêm tài khoản VEO / Imagen", 620, 520, grab=True)
        lbl(
            dlg,
            "Dán JSON (1 hoặc nhiều tài khoản) HOẶC dán trực tiếp mỗi dòng 1 token ya29...",
            T.TEXT_STRONG,
            F.ui_sb,
        ).pack(anchor="w", padx=20, pady=(16, 6))

        txt = ctk.CTkTextbox(
            dlg,
            height=210,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER,
            border_width=1,
            text_color=T.TEXT,
            font=F.mono_sm,
        )
        txt.pack(fill="both", expand=True, padx=20, pady=4)
        txt.focus()

        hint = card(dlg)
        hint.pack(padx=20, pady=8, fill="x")
        ctk.CTkLabel(
            hint,
            justify="left",
            text_color=T.MUTED,
            font=F.mono_sm,
            text=(
                '{\n'
                '  "accounts": [\n'
                '    {\n'
                '      "token": "ya29.a0...",\n'
                '      "project_id": "uuid... (bỏ trống sẽ tự sinh UUID)",\n'
                '      "labs_session": "... (cookie __Secure-next-auth.session-token)"\n'
                '    }\n'
                '  ]\n'
                '}'
            ),
        ).pack(padx=12, pady=8, anchor="w")

        def on_save():
            valid = self._parse_accounts_input(txt.get("1.0", "end"))
            if not valid:
                messagebox.showerror(
                    "Không hợp lệ",
                    "Không tìm thấy tài khoản hợp lệ! Hãy dán JSON có 'accounts' hoặc dòng token 'ya29...'.",
                    parent=dlg,
                )
                return
            added, updated, total = self._merge_and_save_accounts(valid, parent_win=dlg)
            dlg.destroy()
            messagebox.showinfo(
                "Thành công",
                f"Đã thêm {added} tài khoản mới (cập nhật {updated})!\nTổng cộng: {total} tài khoản đang hoạt động.",
                parent=parent_win or self,
            )

        bf = row(dlg)
        bf.pack(fill="x", padx=20, pady=12)
        btn(bf, "📂 Chọn file JSON...", lambda: self._import_veo_json_file(dlg, into_textbox=txt), width=140).pack(
            side="left"
        )
        btn_primary(bf, "💾 Lưu & Đồng bộ", on_save, width=140).pack(side="right")
        sbtn(bf, "Huỷ", dlg.destroy, width=86).pack(side="right", padx=(0, 6))

    def _import_veo_json_file(self, parent_win=None, into_textbox=None):
        fpath = filedialog.askopenfilename(
            parent=parent_win or self,
            title="Chọn file JSON chứa tài khoản VEO",
            filetypes=[("JSON / Text Files", "*.json *.txt"), ("All Files", "*.*")],
        )
        if not fpath:
            return
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            if into_textbox is not None:
                into_textbox.delete("1.0", "end")
                into_textbox.insert("1.0", content)
                return
            valid = self._parse_accounts_input(content)
            if not valid:
                messagebox.showerror("Lỗi", "File không chứa danh sách tài khoản VEO hợp lệ!", parent=parent_win or self)
                return
            added, updated, total = self._merge_and_save_accounts(valid, parent_win=parent_win)
            messagebox.showinfo(
                "Đã nhập file",
                f"Đã nhập từ {os.path.basename(fpath)}:\n• Thêm mới: {added}\n• Cập nhật: {updated}\n• Tổng số: {total} tài khoản",
                parent=parent_win or self,
            )
        except Exception as e:
            messagebox.showerror("Lỗi đọc file", str(e), parent=parent_win or self)

    def _reload_from_orig_dir(self, parent_win=None):
        accs = self._load_all_known_veo_accounts(include_orig=True)
        self._write_shared_veo_accounts(accs, notify_tabs=True)
        self._render_shared_acc_list()
        messagebox.showinfo(
            "Đã đọc lại",
            f"Đã quét và đồng bộ {len(accs)} tài khoản từ các file cấu hình tool!",
            parent=parent_win or self,
        )

    def open_gemini_api_dialog(self):
        """Hộp thoại Nhập API đa hãng (Gemini, OpenAI, Anthropic, DeepSeek, Groq, xAI, OpenRouter, Custom)."""
        import multi_llm_bridge as _mlb
        import threading

        win = dialog(
            self,
            "Nhập API",
            760,
            560,
            grab=True,
        )
        cfg = _mlb.load_config()

        # ── Thanh chọn Hãng Ưu Tiên trên cùng ──
        top_bar = card(win)
        top_bar.pack(fill="x", padx=16, pady=(14, 8))
        top_row = row(top_bar)
        top_row.pack(fill="x", padx=12, pady=10)

        lbl(
            top_row,
            "🤖 Hãng AI sử dụng:",
            T.TEXT_STRONG,
            F.ui_sb,
        ).pack(side="left", padx=(0, 8))

        mode_map = {"⚡ Tự động xoay vòng mọi hãng có Key": "auto"}
        rev_mode_map = {"auto": "⚡ Tự động xoay vòng mọi hãng có Key"}
        for pid, meta in _mlb.PROVIDERS_META.items():
            label_str = f"Ưu tiên {meta['short']}"
            mode_map[label_str] = pid
            rev_mode_map[pid] = label_str

        init_mode_label = rev_mode_map.get(
            cfg.get("active_provider", "auto"),
            "⚡ Tự động xoay vòng mọi hãng có Key",
        )
        cbo_active = opt(top_row, list(mode_map.keys()), width=280)
        cbo_active.set(init_mode_label)
        cbo_active.pack(side="left", padx=(0, 10))

        lbl_total = lbl(top_row, "", T.OK, F.label)
        lbl_total.pack(side="right")

        # ── Khung Tab 8 Hãng AI (dùng TabStrip.grid chuẩn của ui.py) ──
        body_card = card(win)
        body_card.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        body_card.grid_rowconfigure(1, weight=1)
        body_card.grid_columnconfigure(0, weight=1)

        strip = TabStrip(body_card, height=30, minw=72)
        strip.grid(row=0, column=0)

        widgets_by_pid = {}
        first_tab_title = None

        for pid, meta in _mlb.PROVIDERS_META.items():
            tab_title = meta["short"]
            if first_tab_title is None:
                first_tab_title = tab_title
            pane = strip.add(tab_title)
            pane.grid_columnconfigure(1, weight=1)
            pane.grid_rowconfigure(3, weight=1)

            p_saved = (cfg.get("providers") or {}).get(pid) or {}

            # Dòng 0: Chọn / nhập Model
            lbl(pane, "Mô hình (Model):", T.LABEL, F.label, anchor="w").grid(
                row=0, column=0, sticky="w", padx=(10, 8), pady=(6, 4)
            )
            cbo_m = ctk.CTkComboBox(
                pane,
                values=meta["models"],
                height=30,
                fg_color=T.INPUT,
                border_color=T.BORDER,
                button_color=T.ACCENT,
                text_color=T.TEXT_STRONG,
                font=F.ui,
            )
            cbo_m.set(p_saved.get("model") or meta["default_model"])
            cbo_m.grid(row=0, column=1, sticky="ew", padx=(0, 10), pady=(6, 4))

            # Dòng 1: Base URL Endpoint
            lbl(pane, "Endpoint URL:", T.LABEL, F.label, anchor="w").grid(
                row=1, column=0, sticky="w", padx=(10, 8), pady=4
            )
            ent_url = entry(pane, placeholder_text=meta["base_url"])
            ent_url.insert(0, p_saved.get("base_url") or meta["base_url"])
            ent_url.grid(row=1, column=1, sticky="ew", padx=(0, 10), pady=4)

            # Dòng 2: Hướng dẫn nhập API Key
            lbl(
                pane,
                f"🔑 Nhập API Key cho {meta['name']} — {meta['key_hint']}",
                "#38bdf8",
                F.tiny,
                anchor="w",
            ).grid(row=2, column=0, columnspan=2, sticky="w", padx=10, pady=(6, 2))

            # Dòng 3: Ô nhập API Key (mỗi dòng 1 key)
            txt_keys = ctk.CTkTextbox(
                pane,
                height=200,
                corner_radius=T.RADIUS,
                fg_color=T.INPUT,
                border_color=T.BORDER,
                border_width=1,
                text_color=T.TEXT,
                font=F.mono_sm,
            )
            txt_keys.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=10, pady=(2, 8))
            saved_keys = p_saved.get("keys") or []
            if saved_keys:
                txt_keys.insert("1.0", "\n".join(saved_keys) + "\n")

            widgets_by_pid[pid] = {
                "tab_title": tab_title,
                "model": cbo_m,
                "base_url": ent_url,
                "keys_box": txt_keys,
                "meta": meta,
            }

        init_pid = cfg.get("active_provider", "gemini")
        if init_pid in widgets_by_pid:
            strip.set(widgets_by_pid[init_pid]["tab_title"])
        elif first_tab_title:
            strip.set(first_tab_title)

        def _collect_current_cfg():
            new_cfg = {
                "active_provider": mode_map.get(cbo_active.get(), "auto"),
                "providers": {},
            }
            for pid, w in widgets_by_pid.items():
                raw_k = w["keys_box"].get("1.0", "end").strip()
                k_list = [ln.strip() for ln in raw_k.splitlines() if ln.strip() and not ln.strip().startswith("#")]
                new_cfg["providers"][pid] = {
                    "keys": k_list,
                    "model": w["model"].get().strip() or w["meta"]["default_model"],
                    "base_url": w["base_url"].get().strip() or w["meta"]["base_url"],
                }
            for pid, pdata in list(new_cfg["providers"].items()):
                kept = []
                for k in pdata["keys"]:
                    det = _mlb.detect_provider_from_key(k)
                    if det and det != pid and pid == "gemini":
                        if k not in new_cfg["providers"][det]["keys"]:
                            new_cfg["providers"][det]["keys"].append(k)
                    else:
                        kept.append(k)
                pdata["keys"] = kept
            return new_cfg

        def _update_summary_lbl():
            cur = _collect_current_cfg()
            tot = sum(len(v["keys"]) for v in cur["providers"].values())
            active_names = [
                _mlb.PROVIDERS_META[p]["short"]
                for p, v in cur["providers"].items()
                if v["keys"]
            ]
            lbl_total.configure(
                text=f"Đã nạp: {tot} Key ({', '.join(active_names) if active_names else 'Chưa có key'})"
            )

        _update_summary_lbl()

        # ── Thanh nút hành động dưới cùng ──
        bf = row(win)
        bf.pack(fill="x", padx=16, pady=(2, 12))

        lbl_test_status = lbl(bf, "Mẹo: Nhập mỗi dòng 1 API Key để tự động xoay vòng.", T.MUTED, F.tiny)
        lbl_test_status.pack(side="left", padx=4)

        def on_test_api():
            cur_tab_name = strip.get()
            target_pid = "gemini"
            for pid, w in widgets_by_pid.items():
                if w["tab_title"] == cur_tab_name:
                    target_pid = pid
                    break
            w = widgets_by_pid[target_pid]
            raw_k = w["keys_box"].get("1.0", "end").strip()
            k_list = [ln.strip() for ln in raw_k.splitlines() if ln.strip() and not ln.strip().startswith("#")]
            if not k_list and target_pid != "custom":
                messagebox.showwarning(
                    "Chưa nhập Key",
                    f"Hãy dán ít nhất 1 API Key vào tab {w['meta']['short']} trước khi bấm Test!",
                    parent=win,
                )
                return
            test_key = k_list[0] if k_list else ""
            test_model = w["model"].get().strip() or w["meta"]["default_model"]
            test_url = w["base_url"].get().strip() or w["meta"]["base_url"]
            lbl_test_status.configure(
                text=f"⏳ Đang kiểm tra {w['meta']['short']} ({test_model})...",
                text_color="#fbbf24",
            )

            def _worker():
                try:
                    reply = _mlb.call_single_provider(
                        pid=target_pid,
                        api_key=test_key,
                        model=test_model,
                        prompt="Reply with the exact short phrase: OK_CONNECTED",
                        base_url=test_url,
                        timeout=25,
                    )
                    self.after(
                        0,
                        lambda: (
                            lbl_test_status.configure(
                                text=f"✅ Kết nối {w['meta']['short']} ({test_model}) thành công!",
                                text_color=T.OK,
                            ),
                            messagebox.showinfo(
                                "Kết nối API thành công",
                                f"Hãng: {w['meta']['name']}\nModel: {test_model}\nPhản hồi: {reply[:120]}",
                                parent=win,
                            ),
                        ),
                    )
                except Exception as e:
                    err_str = str(e)
                    self.after(
                        0,
                        lambda: (
                            lbl_test_status.configure(
                                text=f"❌ Lỗi {w['meta']['short']}: {err_str[:75]}",
                                text_color=T.DANGER_TEXT,
                            ),
                            messagebox.showerror(
                                f"Lỗi kết nối {w['meta']['short']}",
                                err_str,
                                parent=win,
                            ),
                        ),
                    )

            threading.Thread(target=_worker, daemon=True).start()

        def on_save_all():
            new_cfg = _collect_current_cfg()
            _mlb.save_config(new_cfg)
            tot = sum(len(v["keys"]) for v in new_cfg["providers"].values())
            active_names = [
                _mlb.PROVIDERS_META[p]["short"]
                for p, v in new_cfg["providers"].items()
                if v["keys"]
            ]
            if hasattr(self, "btn_gemini_api") and self.btn_gemini_api.winfo_exists():
                self.btn_gemini_api.configure(text="Nhập API")
            messagebox.showinfo(
                "Đã lưu API",
                f"Đã lưu {tot} API Key ({', '.join(active_names) if active_names else 'Mặc định'})!",
                parent=win,
            )
            win.destroy()

        btn_primary(bf, "💾 Lưu API", on_save_all, width=120).pack(side="right")
        sbtn(bf, "⚡ Test API", on_test_api, width=105).pack(side="right", padx=6)
        sbtn(bf, "Đóng", win.destroy, width=76).pack(side="right")

    def _on_mcp_gui_event(self, event_type: str, data: dict):
        """Đồng bộ trực tiếp các lệnh AI gọi qua MCP lên giao diện Film Studio theo thời gian thực."""
        try:
            if event_type == "push_storyboard" and isinstance(data, dict):
                vid_prompts = data.get("video_motion_prompts") or []
                img_prompts = data.get("image_keyframe_prompts") or vid_prompts
                ref_lines = data.get("ref_lines") or []
                plain_prompts = [p.split("|", 1)[-1].strip() if "|" in p[:45] else p for p in vid_prompts]
                self.push_to_all_step2_tabs(
                    prompts_tagged=vid_prompts,
                    prompts_plain=plain_prompts,
                    ref_lines=ref_lines,
                    scene_lines_for_img_consist=img_prompts,
                    show_dialog=False,
                )
            if hasattr(self, "_mcp_log_box") and self._mcp_log_box is not None and self._mcp_log_box.winfo_exists():
                if event_type == "log" and isinstance(data, dict):
                    line = f"[{data.get('time', '')}] [{data.get('tool', 'MCP')}] {data.get('message', '')}\n"
                    self._mcp_log_box.configure(state="normal")
                    self._mcp_log_box.insert("end", line)
                    self._mcp_log_box.see("end")
                    self._mcp_log_box.configure(state="disabled")
        except Exception as e:
            print(f"[MCP-GUI-SYNC-WARN] {e}", flush=True)

    def open_mcp_control_center_dialog(self):
        """Hộp thoại Trung Tâm Kết Nối AI (MCP Server 1-Click Installer & Live Monitor) dành cho khách hàng."""
        import film_studio_mcp_server as _mcp

        win = dialog(self, "🔌 Trung Tâm Kết Nối AI Tự Động Hóa (MCP Server)", 820, 620, grab=True)
        port = getattr(getattr(self, "mcp_server", None), "port", 3100)
        http_url = f"http://127.0.0.1:{port}/mcp"
        sse_url = f"http://127.0.0.1:{port}/sse"

        # ── Khối 1: Trạng thái Server & Nút Cài Đặt Tự Động 1-Click ──
        top_card = card(win)
        top_card.pack(fill="x", padx=16, pady=(14, 8))

        r1 = row(top_card)
        r1.pack(fill="x", padx=14, pady=(10, 4))
        lbl(
            r1,
            f"🟢 MCP Server Đang Hoạt Động · {len(_mcp.MCP_TOOLS_SCHEMA)} Tools Tự Động Hóa Sẵn Sàng",
            T.OK,
            F.h,
        ).pack(side="left")
        lbl(r1, f"Endpoint: {http_url}", "#38bdf8", F.mono_sm).pack(side="right")

        lbl(
            top_card,
            "Chỉ cần bấm '⚡ Tự Động Kết Nối 1-Click' bên dưới, khách hàng có thể mở Claude Desktop, Cursor, Windsurf, ChatGPT hoặc n8n\n"
            "và ra lệnh bằng tiếng Việt: \"Hãy dùng Film Studio tạo cho tôi bộ phim 5 cảnh về chú mèo thám hiểm vũ trụ\"!",
            T.MUTED,
            F.tiny,
            anchor="w",
            justify="left",
        ).pack(fill="x", padx=14, pady=(0, 8))

        act_bar = row(top_card)
        act_bar.pack(fill="x", padx=14, pady=(0, 12))

        def _on_1click_install():
            res = _mcp.install_mcp_to_ai_clients()
            clients = res.get("installed_clients") or []
            names = "\n".join(f"  • {c['name']}\n    ({c['config_path']})" for c in clients)
            messagebox.showinfo(
                "Đã Cài Đặt & Kết Nối MCP Thành Công!",
                f"✅ Đã tự động gắn MCP Server của Film Studio vào {len(clients)} phần mềm AI:\n\n{names}\n\n"
                f"👉 Hãy khởi động lại Claude Desktop / Cursor / Windsurf để bắt đầu ra lệnh làm phim tự động!",
                parent=win,
            )
            _refresh_log()

        def _copy_stdio_json():
            cfg_obj = {"mcpServers": {_mcp.MCP_SERVER_NAME: _mcp.build_mcp_client_config_entry()}}
            raw_json = json.dumps(cfg_obj, ensure_ascii=False, indent=2)
            self.clipboard_clear()
            self.clipboard_append(raw_json)
            messagebox.showinfo(
                "Đã Copy Cấu Hình JSON",
                "📋 Đã sao chép cấu hình JSON chuẩn MCP vào bộ nhớ tạm (Clipboard)!\nBạn có thể dán vào bất kỳ ứng dụng AI nào hỗ trợ MCP.",
                parent=win,
            )

        def _copy_http_url():
            self.clipboard_clear()
            self.clipboard_append(http_url)
            messagebox.showinfo(
                "Đã Copy URL HTTP/SSE",
                f"📋 Đã sao chép địa chỉ MCP HTTP:\n{http_url}\n\n(SSE Endpoint: {sse_url})",
                parent=win,
            )

        btn_primary(
            act_bar,
            "⚡ Tự Động Kết Nối 1-Click (Claude / Cursor / Windsurf)",
            _on_1click_install,
            width=340,
        ).pack(side="left", padx=(0, 8))
        sbtn(act_bar, "📋 Copy JSON Config", _copy_stdio_json, width=148).pack(side="left", padx=(0, 6))
        sbtn(act_bar, "🌐 Copy HTTP/SSE URL", _copy_http_url, width=155).pack(side="left", padx=(0, 6))
        sbtn(
            act_bar,
            "📂 Mở Kho MCP Output",
            lambda: os.startfile(_mcp.MCP_OUTPUT_ROOT) if os.path.isdir(_mcp.MCP_OUTPUT_ROOT) else None,
            width=140,
        ).pack(side="right")

        # ── Khối 2: Danh sách 9 MCP Tools trang bị cho AI ──
        tools_card = card(win)
        tools_card.pack(fill="x", padx=16, pady=(0, 8))
        lbl(
            tools_card,
            "🛠️ DANH SÁCH 9 CÔNG CỤ MCP ĐƯỢC CẤP QUYỀN CHO AI BÊN NGOÀI:",
            "#38bdf8",
            F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 4))

        tools_summary = (
            "① film_studio_doctor (Kiểm tra hệ thống & tài khoản)   ·   "
            "② film_studio_write_storyboard (Biên kịch & tạo Prompt 3-Beat)\n"
            "③ film_studio_clone_video_prompts (Bóc tách Prompt từ Video mẫu)   ·   "
            "④ film_studio_generate_character_images (Tạo ảnh nhân vật & cảnh đồng nhất)\n"
            "⑤ film_studio_render_videos_async (Quay Veo 3.1 / Vids / Muse bất đồng bộ)   ·   "
            "⑥ film_studio_synthesize_voice (Đọc lời thoại AI + Xuất phụ đề .SRT)\n"
            "⑦ film_studio_post_production_merge (Ghép hậu kỳ FFmpeg GPU & chuyển cảnh)   ·   "
            "⑧ film_studio_job_status   ·   ⑨ film_studio_auto_pipeline (1 Lệnh Ra Phim)"
        )
        lbl(tools_card, tools_summary, T.TEXT, F.tiny, anchor="w", justify="left").pack(
            fill="x", padx=14, pady=(0, 10)
        )

        # ── Khối 3: Cấu hình JSON & Nhật ký hoạt động trực tiếp ──
        log_card = card(win)
        log_card.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        lbl(
            log_card,
            "📡 NHẬT KÝ ĐIỀU KHIỂN TỪ AI BÊN NGOÀI & CẤU HÌNH KẾT NỐI:",
            T.TEXT_STRONG,
            F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 4))

        self._mcp_log_box = ctk.CTkTextbox(
            log_card,
            height=210,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER,
            border_width=1,
            text_color="#7ce8ff",
            font=F.mono_sm,
        )
        self._mcp_log_box.pack(fill="both", expand=True, padx=14, pady=(0, 10))

        def _refresh_log():
            if not hasattr(self, "_mcp_log_box") or not self._mcp_log_box.winfo_exists():
                return
            cfg_preview = json.dumps(
                {"mcpServers": {_mcp.MCP_SERVER_NAME: _mcp.build_mcp_client_config_entry()}},
                ensure_ascii=False,
                indent=2,
            )
            recent_logs = _mcp.JOB_MANAGER.activity_logs[-35:]
            log_lines = [
                f"[{item.get('time', '')}] [{item.get('tool', 'MCP')}] {item.get('message', '')}"
                for item in recent_logs
            ]
            content = (
                f"=== CẤU HÌNH MCP STDIO (TỰ ĐỘNG GẮN VÀO CLAUDE / CURSOR / WINDSURF) ===\n"
                f"{cfg_preview}\n\n"
                f"=== NHẬT KÝ HOẠT ĐỘNG MCP GẦN ĐÂY ({len(log_lines)} sự kiện) ===\n"
                + ("\n".join(log_lines) if log_lines else "(Chưa có lệnh nào từ AI bên ngoài)")
                + "\n"
            )
            self._mcp_log_box.configure(state="normal")
            self._mcp_log_box.delete("1.0", "end")
            self._mcp_log_box.insert("1.0", content)
            self._mcp_log_box.see("end")
            self._mcp_log_box.configure(state="disabled")

        _refresh_log()

        footer = row(win)
        footer.pack(fill="x", padx=16, pady=(2, 12))
        sbtn(footer, "🔄 Làm mới nhật ký", _refresh_log, width=140).pack(side="left")
        sbtn(footer, "Đóng", win.destroy, width=90).pack(side="right")

    # ═══════════════════════════════════════════════════════════════════════
    # QUẢN LÝ BẢN QUYỀN THEO MÃ MÁY (HARDWARE MACHINE ID & WEB LICENSE KEY)
    # ═══════════════════════════════════════════════════════════════════════
    def _refresh_license_badge(self) -> dict:
        import license_manager

        st = license_manager.get_license_status(check_online=False)
        if hasattr(self, "btn_license_key") and self.btn_license_key.winfo_exists():
            if st.get("valid"):
                plan_short = "Lifetime" if st.get("is_lifetime") else (st.get("plan") or "PRO")
                rem = st.get("remaining_text", "")
                self.btn_license_key.configure(
                    text=f"🔑 Bản Quyền {plan_short} · {rem}",
                    fg_color="#0b2e21",
                    hover_color="#114633",
                    border_color="#10b981",
                    text_color="#6ee7b7",
                )
            else:
                self.btn_license_key.configure(
                    text="🔒 Chưa Kích Hoạt Key (Bấm Mở)",
                    fg_color="#3b1219",
                    hover_color="#521923",
                    border_color="#f43f5e",
                    text_color="#fda4af",
                )
        self._update_license_lock_overlay(st)
        return st

    def _update_license_lock_overlay(self, st: dict = None):
        import license_manager
        import webbrowser

        if st is None:
            st = license_manager.get_license_status(check_online=False)

        if st.get("valid"):
            if hasattr(self, "_license_lock_frame") and self._license_lock_frame is not None:
                try:
                    self._license_lock_frame.destroy()
                except Exception:
                    pass
                self._license_lock_frame = None
            return

        if not hasattr(self, "body") or not self.body.winfo_exists():
            return

        if getattr(self, "_license_lock_frame", None) is not None and self._license_lock_frame.winfo_exists():
            self._license_lock_frame.lift()
            return

        lock_fr = ctk.CTkFrame(self.body, fg_color="#090d14", corner_radius=0)
        lock_fr.place(relx=0, rely=0, relwidth=1, relheight=1)
        lock_fr.lift()
        self._license_lock_frame = lock_fr

        box = ctk.CTkFrame(
            lock_fr,
            fg_color="#111824",
            corner_radius=16,
            border_width=1,
            border_color="#334155",
            width=660,
        )
        box.place(relx=0.5, rely=0.5, anchor="center")

        hwid = st.get("machine_id") or license_manager.get_machine_id()
        portal_url = f"{license_manager.WEB_ACTIVATION_PORTAL_URL}?hwid={hwid}"

        ctk.CTkLabel(
            box,
            text="🔒 YÊU CẦU KÍCH HOẠT BẢN QUYỀN THEO MÃ MÁY",
            text_color="#fde047",
            font=ctk.CTkFont(family="Segoe UI", size=18, weight="bold"),
        ).pack(padx=32, pady=(26, 6))

        ctk.CTkLabel(
            box,
            text=(
                "Ứng dụng Film Studio được bảo vệ bản quyền theo từng thiết bị.\n"
                "Vui lòng sao chép Mã Máy bên dưới và truy cập trang Web để nhận Mã Kích Hoạt theo gói bạn đã mua."
            ),
            text_color="#94a3b8",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            justify="center",
        ).pack(padx=32, pady=(0, 16))

        hwid_row = ctk.CTkFrame(box, fg_color="#0b111b", corner_radius=10, border_width=1, border_color="#38bdf8")
        hwid_row.pack(fill="x", padx=32, pady=(0, 14))
        ctk.CTkLabel(
            hwid_row,
            text=f"MÃ MÁY CỦA BẠN:  {hwid}",
            text_color="#7ce8ff",
            font=ctk.CTkFont(family="Consolas", size=16, weight="bold"),
        ).pack(side="left", padx=16, pady=12)

        def _copy_hwid_overlay():
            self.clipboard_clear()
            self.clipboard_append(hwid)
            messagebox.showinfo("Đã sao chép Mã Máy", f"📋 Đã sao chép Mã Máy: {hwid}\nHãy dán vào trang kích hoạt trên Web!", parent=self)

        ctk.CTkButton(
            hwid_row,
            text="📋 Copy Mã Máy",
            width=130,
            height=32,
            fg_color="#0284c7",
            hover_color="#0369a1",
            command=_copy_hwid_overlay,
        ).pack(side="right", padx=12, pady=10)

        btn_row = ctk.CTkFrame(box, fg_color="transparent")
        btn_row.pack(padx=32, pady=(4, 26))

        ctk.CTkButton(
            btn_row,
            text="🔑 Nhập Mã Kích Hoạt / Đồng Bộ Tự Động",
            width=270,
            height=40,
            fg_color="#10b981",
            hover_color="#059669",
            text_color="#04130d",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            command=self.open_license_activation_dialog,
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            btn_row,
            text="🌐 Lấy Mã Kích Hoạt Trên Web ↗",
            width=230,
            height=40,
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color="#475569",
            text_color="#f8fafc",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            command=lambda: webbrowser.open(portal_url),
        ).pack(side="left")

    def _check_license_on_startup(self):
        st = self._refresh_license_badge()
        if not st.get("valid"):
            self.open_license_activation_dialog()

    def open_license_activation_dialog(self):
        """Hộp thoại Quản lý & Kích hoạt Bản quyền theo Mã Máy (Hardware ID + Web Subscription)."""
        import license_manager
        import webbrowser

        win = dialog(self, "🔑 Kích Hoạt Bản Quyền Theo Mã Máy (Hardware License)", 740, 540, grab=True)
        hwid = license_manager.get_machine_id()
        portal_url = f"{license_manager.WEB_ACTIVATION_PORTAL_URL}?hwid={hwid}"

        # ── Khối 1: Mã Máy của thiết bị ──
        hwid_card = card(win)
        hwid_card.pack(fill="x", padx=16, pady=(14, 8))

        lbl(
            hwid_card,
            "① MÃ MÁY CỦA THIẾT BỊ NÀY (HARDWARE MACHINE ID):",
            "#38bdf8",
            F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 4))

        r_hwid = row(hwid_card)
        r_hwid.pack(fill="x", padx=14, pady=(0, 8))

        ent_hwid = entry(r_hwid, "")
        ent_hwid.insert(0, hwid)
        ent_hwid.configure(state="readonly", font=ctk.CTkFont(family="Consolas", size=15, weight="bold"), text_color="#fde047")
        ent_hwid.pack(side="left", fill="x", expand=True, padx=(0, 8))

        def _copy_hwid():
            self.clipboard_clear()
            self.clipboard_append(hwid)
            messagebox.showinfo(
                "Đã sao chép Mã Máy",
                f"📋 Đã sao chép Mã Máy vào Clipboard:\n\n{hwid}\n\n"
                f"👉 Bước tiếp theo: Mở trang Web {license_manager.WEB_ACTIVATION_PORTAL_URL}, dán Mã Máy này vào để nhận Mã Kích Hoạt theo thời hạn gói mua của bạn!",
                parent=win,
            )

        btn_primary(r_hwid, "📋 Sao Chép Mã Máy", _copy_hwid, width=160).pack(side="left", padx=(0, 6))
        sbtn(
            r_hwid,
            "🌐 Mở Web Lấy Mã Kích Hoạt ↗",
            lambda: webbrowser.open(portal_url),
            width=210,
        ).pack(side="left")

        lbl(
            hwid_card,
            f"Hướng dẫn: Đăng nhập tài khoản đã mua gói (Premium 1 Tháng / Ultra 1 Năm / Ultra Lifetime) tại {license_manager.DEFAULT_WEB_BASE_URL}/kich-hoat,\n"
            f"nhập Mã Máy [{hwid}] để hệ thống cấp Mã Kích Hoạt tương ứng với thời hạn gói trên Web.",
            T.MUTED,
            F.tiny,
            anchor="w",
            justify="left",
        ).pack(fill="x", padx=14, pady=(0, 10))

        # ── Khối 2: Trạng thái gói bản quyền hiện tại ──
        status_card = card(win)
        status_card.pack(fill="x", padx=16, pady=(0, 8))

        lbl(
            status_card,
            "② TRẠNG THÁI BẢN QUYỀN & THỜI HẠN GÓI MUA:",
            T.TEXT_STRONG,
            F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 4))

        lbl_state_main = lbl(status_card, "Đang kiểm tra...", T.OK, F.h, anchor="w")
        lbl_state_main.pack(fill="x", padx=14, pady=(0, 2))

        lbl_state_sub = lbl(status_card, "", T.MUTED, F.body, anchor="w", justify="left")
        lbl_state_sub.pack(fill="x", padx=14, pady=(0, 10))

        # ── Khối 3: Nhập Mã Kích Hoạt từ Web ──
        input_card = card(win)
        input_card.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        lbl(
            input_card,
            "③ NHẬP MÃ KÍCH HOẠT (LICENSE KEY) NHẬN TỪ WEB:",
            "#fde047",
            F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 4))

        txt_key = ctk.CTkTextbox(
            input_card,
            height=84,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER,
            border_width=1,
            text_color="#f8fafc",
            font=F.mono_sm,
        )
        txt_key.pack(fill="x", padx=14, pady=(0, 8))

        saved_st = license_manager.get_license_status(check_online=False)
        if saved_st.get("license_key"):
            txt_key.insert("1.0", saved_st["license_key"])

        def _render_status_ui(st_data: dict):
            if st_data.get("valid"):
                lbl_state_main.configure(
                    text=f"🟢 ĐÃ KÍCH HOẠT HỢP LỆ — {st_data.get('plan_name')} ({st_data.get('remaining_text')})",
                    text_color=T.OK,
                )
                lbl_state_sub.configure(
                    text=(
                        f"• Chủ sở hữu: {st_data.get('email') or 'Khách hàng Forge Zone'}   |   Mã Giấy Phép: {st_data.get('license_id')}\n"
                        f"• Mã Máy gắn kết: {st_data.get('machine_id')}   |   Thời hạn đến: {st_data.get('expires_at_str')}"
                    ),
                    text_color=T.TEXT,
                )
            else:
                lbl_state_main.configure(
                    text=f"🔴 CHƯA KÍCH HOẠT HOẶC ĐÃ HẾT HẠN ({st_data.get('status')})",
                    text_color="#f43f5e",
                )
                lbl_state_sub.configure(
                    text=st_data.get("error") or "Vui lòng nhập Mã Kích Hoạt (FZKEY-...) lấy từ Web để mở khóa ứng dụng.",
                    text_color="#fda4af",
                )

        _render_status_ui(saved_st)

        act_row = row(input_card)
        act_row.pack(fill="x", padx=14, pady=(2, 12))

        def _do_activate():
            raw_k = txt_key.get("1.0", "end").strip()
            res = license_manager.activate_license(raw_k, check_online=True)
            _render_status_ui(res)
            self._refresh_license_badge()
            if res.get("valid"):
                messagebox.showinfo(
                    "Kích Hoạt Bản Quyền Thành Công!",
                    f"🎉 Chúc mừng! Thiết bị [{res['machine_id']}] đã được kích hoạt thành công!\n\n"
                    f"• Gói bản quyền: {res['plan_name']}\n"
                    f"• Thời hạn sử dụng: {res['expires_at_str']} ({res['remaining_text']})\n"
                    f"• Toàn bộ 11 chức năng làm phim và MCP Server đã được mở khóa!",
                    parent=win,
                )
            else:
                messagebox.showerror(
                    "Không Thể Kích Hoạt",
                    f"❌ {res.get('error')}",
                    parent=win,
                )

        def _do_paste_and_activate():
            try:
                clip = self.clipboard_get().strip()
            except Exception:
                clip = ""
            if clip:
                txt_key.delete("1.0", "end")
                txt_key.insert("1.0", clip)
            _do_activate()

        def _do_sync_from_web():
            res = license_manager.sync_license_from_web()
            if res.get("license_key"):
                txt_key.delete("1.0", "end")
                txt_key.insert("1.0", res["license_key"])
            _render_status_ui(res)
            self._refresh_license_badge()
            if res.get("valid"):
                messagebox.showinfo(
                    "Đồng Bộ Bản Quyền Thành Công!",
                    f"✅ Đã tự động nhận Mã Kích Hoạt từ Web cho Mã Máy [{res['machine_id']}]!\n\n"
                    f"• Gói bản quyền: {res['plan_name']}\n"
                    f"• Thời hạn: {res['expires_at_str']} ({res['remaining_text']})",
                    parent=win,
                )
            else:
                messagebox.showwarning(
                    "Chưa Tìm Thấy Key Trên Web",
                    f"{res.get('error')}",
                    parent=win,
                )

        btn_primary(act_row, "⚡ Kích Hoạt Bản Quyền Ngay", _do_activate, width=220).pack(side="left", padx=(0, 8))
        sbtn(act_row, "📋 Dán Key & Kích Hoạt", _do_paste_and_activate, width=165).pack(side="left", padx=(0, 8))
        sbtn(act_row, "🔄 Tự Động Lấy Key Từ Web", _do_sync_from_web, width=190).pack(side="left")
        sbtn(act_row, "Đóng", win.destroy, width=85).pack(side="right")


    def _ensure_tab_loaded(self, key: str):
        if key in self._tab_frames:
            return self._tab_frames[key]

        spec = next((s for s in TABS_SPEC if s[1] == key), None)
        if not spec:
            return None
        label, _, mod = spec

        holder = ctk.CTkFrame(self.body, fg_color=T.BG, corner_radius=0)
        holder.grid_rowconfigure(0, weight=1)
        holder.grid_columnconfigure(0, weight=1)

        try:
            inst = mod.build_tab(holder, pipeline=self)
            self._tab_instances[key] = inst
            src_code_map = {
                "veo3_t2v": "veo",
                "image_consist": "img6",
                "veo3_consist": "veo7",
                "muse_video": "muse",
                "veo3_i2v": "veo4",
            }
            if key in src_code_map and inst is not None:
                sc = src_code_map[key]
                inst.on_prompt_failed = lambda rid, txt, rsn="", _sc=sc: self._forward_failed_prompt(_sc, rid, txt, rsn)
        except Exception as e:
            tb = traceback.format_exc()
            print(f"[GUI-ERR] {label}: {e}\n{tb}")
            err_box = ctk.CTkTextbox(holder, fg_color=T.INPUT, text_color=T.DANGER_TEXT, font=F.mono)
            err_box.pack(fill="both", expand=True, padx=20, pady=20)
            err_box.insert("1.0", f"❌ Lỗi khởi tạo tab [{label}]: {e}\n\n{tb}")

        self._tab_frames[key] = holder
        return holder

    def _forward_failed_prompt(self, src_code: str, row_id: int, prompt_text: str, reason: str = ""):
        self._ensure_tab_loaded("prompt_review")
        rv = self._tab_instances.get("prompt_review")
        if rv and hasattr(rv, "add_prompt"):
            rv.add_prompt(src_code, row_id, prompt_text, reason)

    def push_prompts_to_review(
        self,
        src_code: str,
        items: list[tuple],
        switch_tab: bool = True,
        show_dialog: bool = True,
    ):
        """Đẩy danh sách câu lệnh từ Bước 1 (Prompt / Video to prompt / Image đồng nhất) sang thẳng tab '✨ Chuẩn hóa prompt'."""
        if not items:
            return
        self._ensure_tab_loaded("prompt_review")
        if switch_tab:
            self.select_tab("prompt_review")
        rv = self._tab_instances.get("prompt_review")
        if rv is None or not hasattr(rv, "add_prompt"):
            return
        added_cnt = 0
        for row_id, p_txt, reason in items:
            if rv.add_prompt(src_code, row_id, p_txt, reason or "Kiểm tra & Chuẩn hóa"):
                added_cnt += 1
        if show_dialog:
            messagebox.showinfo(
                "Đã đẩy sang Chuẩn hóa prompt",
                f"✨ Đã chuyển {added_cnt} câu lệnh sang tab '✨ Chuẩn hóa prompt' để rà soát & làm sạch từ khóa nhạy cảm!",
                parent=self,
            )

    def push_to_all_step2_tabs(
        self,
        prompts_tagged: list[str],
        prompts_plain: list[str],
        ref_paths: list[str] = None,
        ref_lines: list[str] = None,
        character_bible_text: str = "",
        scene_lines_for_img_consist: list[str] = None,
        i2v_tasks: list[dict] = None,
        skip_image_consist: bool = False,
        show_dialog: bool = True,
    ):
        """Đẩy đồng loạt Prompt & Ảnh tham chiếu sang TOÀN BỘ các chức năng ở Bước 2."""
        pushed_tabs = []

        if not skip_image_consist and (scene_lines_for_img_consist or prompts_tagged):
            self.push_prompts_to_tab(
                "image_consist",
                scene_lines_for_img_consist or prompts_tagged,
                ref_paths=ref_paths,
                ref_lines=ref_lines,
                character_bible_text=character_bible_text,
                switch_tab=False,
                show_dialog=False,
            )
            pushed_tabs.append("🎨 Image đồng nhất")

        if prompts_plain:
            self.push_prompts_to_tab(
                "veo3_t2v",
                prompts_plain,
                switch_tab=False,
                show_dialog=False,
            )
            pushed_tabs.append("🎬 Text to video")

        if prompts_tagged:
            self.push_prompts_to_tab(
                "veo3_consist",
                prompts_tagged,
                ref_paths=ref_paths,
                ref_lines=ref_lines,
                switch_tab=False,
                show_dialog=False,
            )
            pushed_tabs.append("🎭 Video đồng nhất")

            self.push_prompts_to_tab(
                "muse_video",
                prompts_tagged,
                ref_paths=ref_paths,
                ref_lines=ref_lines,
                switch_tab=False,
                show_dialog=False,
            )
            pushed_tabs.append("🎞 Video Muse")

        if i2v_tasks:
            self.push_scene_images_to_i2v(i2v_tasks, switch_tab=False, show_dialog=False)
            pushed_tabs.append("📷 Image to video")
        elif prompts_plain:
            self.push_prompts_to_tab(
                "veo3_i2v",
                prompts_plain,
                ref_paths=ref_paths,
                switch_tab=False,
                show_dialog=False,
            )
            pushed_tabs.append("📷 Image to video")

        if show_dialog and pushed_tabs:
            ref_info = f" (kèm {len(ref_paths)} ảnh tham chiếu)" if ref_paths else ""
            if skip_image_consist:
                messagebox.showinfo(
                    "Đã đẩy sang toàn bộ tab Tạo Video",
                    f"🎬 Đã đồng bộ đầy đủ {len(prompts_plain)} phân cảnh{ref_info} sang {len(pushed_tabs)} công cụ Tạo Video:\n\n"
                    + "\n".join(f"  • {name}" for name in pushed_tabs),
                    parent=self,
                )
            else:
                messagebox.showinfo(
                    "Đã đẩy sang toàn bộ chức năng Bước 2",
                    f"🌐 Đã đồng bộ kịch bản ({len(prompts_plain)} cảnh){ref_info} sang {len(pushed_tabs)} chức năng Bước 2:\n\n"
                    + "\n".join(f"  • {name}" for name in pushed_tabs),
                    parent=self,
                )

    def push_prompts_to_tab(
        self,
        target_key: str,
        prompts_list: list[str],
        ref_paths: list[str] = None,
        ref_lines: list[str] = None,
        character_bible_text: str = "",
        switch_tab: bool = True,
        show_dialog: bool = True,
    ):
        """Đẩy danh sách câu lệnh (kèm phân tích nhân vật tham chiếu & ảnh mẫu nếu có) sang thẳng Xưởng Quay."""
        if not prompts_list:
            return
        self._ensure_tab_loaded(target_key)
        if switch_tab:
            self.select_tab(target_key)
        inst = self._tab_instances.get(target_key)
        if inst is None:
            return
        joined = "\n".join(prompts_list)
        try:
            if ref_paths:
                if hasattr(inst, "_pipe_set_images"):
                    inst._pipe_set_images(ref_paths)
                elif hasattr(inst, "entry_img_folder") and len(ref_paths) > 0:
                    ref_dir = os.path.dirname(ref_paths[0])
                    if os.path.isdir(ref_dir):
                        inst.entry_img_folder.delete(0, "end")
                        inst.entry_img_folder.insert(0, ref_dir)
                        if hasattr(inst, "_refresh_images"):
                            inst._refresh_images()

            if hasattr(inst, "receive_pushed_prompts"):
                analysis = inst.receive_pushed_prompts(
                    prompts_list,
                    ref_lines=ref_lines,
                    character_bible_text=character_bible_text,
                )
                if show_dialog:
                    messagebox.showinfo(
                        "AI Đã Phân Tích Nhân Vật & Phân Cảnh",
                        f"🧠 AI đã đọc kịch bản và phân tách tự động:\n\n"
                        f"• Bước 1 (Ô ① — Ảnh Tham Chiếu): {analysis['num_chars']} Nhân vật & {analysis['num_locs']} Bối cảnh duy nhất (đã khử trùng lặp 100%).\n"
                        f"• Bước 2 (Ô ② — Ảnh Từng Phân Cảnh): {analysis['num_scenes']} Phân cảnh gắn đúng mã nhân vật tương ứng.\n\n"
                        f"👉 Bấm '⚡ Chạy Trọn Bộ (① ➔ ②)' để tạo ảnh tham chiếu cho các nhân vật trước rồi vẽ từng phân cảnh!",
                        parent=self,
                    )
                return

            if hasattr(inst, "txt_prompt_input"):
                inst.txt_prompt_input.delete("1.0", "end")
                inst.txt_prompt_input.insert("1.0", joined)
                if hasattr(inst, "scan_prompts_and_files"):
                    inst.scan_prompts_and_files()
            elif hasattr(inst, "txt_prompt"):
                inst.txt_prompt.delete("1.0", "end")
                inst.txt_prompt.insert("1.0", joined)
                if hasattr(inst, "_apply_manual_prompts"):
                    inst._apply_manual_prompts()
            if show_dialog:
                extra_msg = f" kèm {len(ref_paths)} ảnh tham chiếu" if ref_paths else ""
                messagebox.showinfo(
                    "Đã chuyển phân cảnh",
                    f"Đã nạp {len(prompts_list)} phân cảnh{extra_msg} vào danh sách!",
                    parent=self,
                )
        except Exception as e:
            print(f"[WARN] push_prompts_to_tab: {e}")

    def push_scene_images_to_i2v(self, ready_tasks: list[dict], switch_tab: bool = True, show_dialog: bool = True):
        """Đẩy danh sách ảnh phân cảnh + câu lệnh từ tab 'Image đồng nhất' sang thẳng tab 'Image to video'."""
        if not ready_tasks:
            return
        self._ensure_tab_loaded("veo3_i2v")
        if switch_tab:
            self.select_tab("veo3_i2v")
        inst = self._tab_instances.get("veo3_i2v")
        if inst is None:
            return
        try:
            img_paths = [t["image_path"] for t in ready_tasks if t.get("image_path")]
            prompts = [t["prompt"] for t in ready_tasks]
            inst.start_images = img_paths
            if hasattr(inst, "lbl_img1"):
                inst.lbl_img1.configure(text=f"Đã nạp {len(img_paths)} ảnh phân cảnh đồng nhất", text_color=T.OK)
            if hasattr(inst, "txt_prompt_input"):
                inst.txt_prompt_input.delete("1.0", "end")
                inst.txt_prompt_input.insert("1.0", "\n".join(prompts))
            if hasattr(inst, "scan_prompts_and_files"):
                inst.scan_prompts_and_files()
            if show_dialog:
                messagebox.showinfo(
                    "Đã chuyển sang Image to video",
                    f"Đã ghép {len(img_paths)} ảnh phân cảnh đồng nhất kèm {len(prompts)} câu lệnh vào Image to video!",
                    parent=self,
                )
        except Exception as e:
            print(f"[WARN] push_scene_images_to_i2v: {e}")

    def select_tab(self, key: str):
        fr = self._ensure_tab_loaded(key)
        if fr is None:
            return
        self._current_key = key
        for k, f in self._tab_frames.items():
            if k == key:
                f.grid(row=0, column=0, sticky="nsew")
            else:
                f.grid_forget()

        for k, b in self._tab_btns.items():
            if k == key:
                b.configure(fg_color=T.TAB_ACTIVE, text_color=T.TAB_HOVER_TXT, border_width=1, border_color=T.ACCENT)
            else:
                b.configure(fg_color="transparent", text_color=T.TEXT_DIM, border_width=0)

        meta = TAB_GUIDE_META.get(key)
        if meta and hasattr(self, "lbl_guide_title"):
            self.lbl_guide_stage.configure(text=meta["stage"])
            self.lbl_guide_title.configure(text=meta["title"])
            self.lbl_guide_steps.configure(text=meta["steps"])
            self._next_step_target = meta["next_key"]
            self.btn_next_step.configure(text=meta["next_label"])

        if getattr(self, "_license_lock_frame", None) is not None and self._license_lock_frame.winfo_exists():
            self._license_lock_frame.lift()


    def clear_current_tab_session(self, ask_confirm: bool = True, delete_files: bool = True):
        """Làm sạch toàn bộ ảnh, prompt, hàng đợi và cache cũ của tab đang mở."""
        if not self._current_key:
            return
        inst = self._tab_instances.get(self._current_key)
        if inst is not None and hasattr(inst, "clear_previous_session"):
            inst.clear_previous_session(ask_confirm=ask_confirm, delete_files=delete_files)

    def clear_all_tabs_session(self, ask_confirm: bool = True, delete_files: bool = True):
        """Làm sạch toàn bộ ảnh mẫu, ảnh phân cảnh, prompt kịch bản, cache nhân vật và hàng đợi cũ ở tất cả 11 chức năng."""
        if ask_confirm:
            ok = messagebox.askyesno(
                "Làm sạch toàn bộ dự án cũ",
                "Bạn có muốn xoá toàn bộ ảnh mẫu, ảnh phân cảnh, câu lệnh (prompt) kịch bản, bộ nhớ đệm (cache) và hàng đợi từ lần dùng trước ở TẤT CẢ các chức năng để bắt đầu dự án mới không?",
                parent=self,
            )
            if not ok:
                return
        # Xoá các file cache ảnh mẫu trên ổ đĩa ngay cả khi tab chưa được mở
        for cache_file in ("flow_ref_entities_cache.json", "uploaded_images.json"):
            cpath = os.path.join(SRC_DIR, cache_file)
            if os.path.isfile(cpath):
                try:
                    os.remove(cpath)
                except Exception:
                    pass
        try:
            tool7.IMAGE_CACHE.clear_all()
        except Exception:
            pass
        if delete_files:
            for sub in ("Scene_Images", os.path.join("Scene_Images", "Refs"), "characters"):
                dpath = os.path.join(SRC_DIR, sub)
                if os.path.isdir(dpath):
                    for fn in os.listdir(dpath):
                        if os.path.splitext(fn)[1].lower() in (".png", ".jpg", ".jpeg", ".webp"):
                            try:
                                os.remove(os.path.join(dpath, fn))
                            except Exception:
                                pass
        cleaned_count = 0
        for _, key, _ in TABS_SPEC:
            inst = self._tab_instances.get(key)
            if inst is not None and hasattr(inst, "clear_previous_session"):
                try:
                    inst.clear_previous_session(ask_confirm=False, delete_files=delete_files)
                    cleaned_count += 1
                except Exception as e:
                    print(f"[WARN] clear_all_tabs_session ({key}): {e}")
        if ask_confirm:
            messagebox.showinfo(
                "Đã làm sạch toàn bộ",
                f"Đã dọn sạch ảnh, prompt, cache và hàng đợi cũ trên {cleaned_count} tab đang mở cùng bộ nhớ đệm dự án!",
                parent=self,
            )

    def trigger_auto_shutdown_if_enabled(self):
        """Nếu người dùng bật '🔌 Tự tắt máy khi xong', tự động hẹn giờ tắt máy Windows sau 60 giây."""
        if getattr(self, "auto_shutdown_var", None) and self.auto_shutdown_var.get():
            try:
                import subprocess
                subprocess.Popen(["shutdown", "/s", "/t", "60", "/c", "Film Studio: Da hoan tat xuat hang loat, may tinh se tat sau 60 giay (go shutdown /a de huy)."])
            except Exception as e:
                print(f"[WARN] auto_shutdown failed: {e}")

    # Cầu nối giữa VEO 3 tabs và Tab Rà Soát Prompt (Phần 7)
    def retry_reviewed_prompt(self, src: str, row_id: int, new_prompt: str) -> bool:
        src_map = {
            "prompt1": "veo3_prompt",
            "veo": "veo3_t2v",
            "img6": "image_consist",
            "veo7": "veo3_consist",
            "muse": "muse_video",
            "veo4": "veo3_i2v",
        }
        target_key = src_map.get(src)
        if not target_key:
            return False
        inst = self._tab_instances.get(target_key)
        if inst and hasattr(inst, "apply_reviewed_prompt"):
            return bool(inst.apply_reviewed_prompt(row_id, new_prompt))
        return False


def main():
    app = ReconstructedAllToolApp()
    if "--self-test" in sys.argv:
        # 1. Khởi tạo toàn bộ 11 tab để xác minh 100% không lỗi widget
        for label, key, _ in TABS_SPEC:
            app.select_tab(key)
            app.update_idletasks()
            ok = key in app._tab_instances
            print(f"[{'GUI-PASS' if ok else 'GUI-FAIL'}] Loaded tab: {label} ({key})")
            assert ok, f"Tab {key} failed to load!"

        # 2. Kiểm thử chức năng thực tế của các module đã sửa lỗi
        # 2a. Biên kịch nội bộ & Xuất Excel Native (.xlsx)
        import tempfile
        p_master = veo3_prompt_tool2.create_gemini_prompt("Chú mèo máy thám hiểm rừng phát sáng", "3D Pixar / Disney", 3, "Phiêu lưu / Thám hiểm", "")
        local_sb = veo3_prompt_tool2._local_storyboard_fallback(p_master)
        assert "Prompt 1:" in local_sb and "Prompt 3:" in local_sb
        tmp_xlsx = os.path.join(tempfile.gettempdir(), "test_cineflow_export.xlsx")
        veo3_prompt_tool2._write_xlsx_native(tmp_xlsx, [["STT", "Prompt"], [1, "Scene 1"]], [["ID", "Name"], ["CHAR_01", "Astro"]])
        assert os.path.isfile(tmp_xlsx) and os.path.getsize(tmp_xlsx) > 500
        os.remove(tmp_xlsx)
        print("[FUNC-PASS] Tab 1 (Biên Kịch & Phân Cảnh + Xuất Excel .xlsx không cần openpyxl) OK")

        # 2b. Tách kịch bản từ video (Visual Analyzer Fallback)
        v_resp = videopromt._analyze_frames_locally(["Segment 1 [Aspect Ratio: 16:9] [Style: 3D Pixar / Disney]"])
        assert "[ Cảnh 1 ]" in v_resp
        print("[FUNC-PASS] Tab 2 (Tách Kịch Bản Từ Video Mẫu — Gemini REST + OpenCV Fallback) OK")

        # 2c. Cứu hộ câu lệnh lỗi (Policy Sanitizer Fallback)
        rv_res = prompt_review.call_router("http://127.0.0.1:20128/v1", "", "gemini-3.8-flash-high", "A little boy crying in blood in the dark forest", reason="PUBLIC_ERROR_MINOR 58061214")
        assert rv_res and rv_res.get("fixed_prompt") and "boy" not in rv_res["fixed_prompt"].lower()
        print("[FUNC-PASS] Tab 3 (Cứu Hộ Câu Lệnh Lỗi — Tự động làm sạch từ nhạy cảm) OK")

        # 2d. Phòng thu giọng đọc AI (Built-in Free Edge-TTS Voices)
        vc = openspeaker_tts.VoiceClient({})
        v_list = vc.voices("edge")
        assert len(v_list) >= 10
        print(f"[FUNC-PASS] Tab 8 (Voice — Nạp sẵn {len(v_list)} giọng Edge-TTS miễn phí) OK")

        # 2e. Kiểm thử FlowKit Engine (batchexecute RPC + 3-Beat 8s + Physics-Safe Choreography + Audio Ducking)
        import flowkit_engine
        assert "0-3s:" in local_sb and "3-6s:" in local_sb and "6-8s:" in local_sb
        for m_key, exp_rpc in (("t2v", "YhhmEf"), ("i2v", "eb1hJf"), ("i2v_chain", "nprQif"), ("consist", "MZZa6b")):
            env = flowkit_engine.build_flow_rpc_envelope(
                mode=m_key,
                project_id="c28b5fd0-027f-4a4c-a6de-6aa9fc83075a",
                prompt="0-3s: Wide shot. 3-6s: Tracking shot. 6-8s: Close-up.",
                start_media_id="11111111-2222-3333-4444-555555555555",
                end_media_id="66666666-7777-8888-9999-000000000000",
                ref_media_ids=["11111111-2222-3333-4444-555555555555"],
            )
            assert env["rpcid"] == exp_rpc and "__CAPTCHA__" in env["f_req"]
        print("[FUNC-PASS] FlowKit Engine (batchexecute YhhmEf/eb1hJf/nprQif/MZZa6b + 3-Beat 8s + Extension MV3) OK")

        # 2f. Kiểm thử tab Image đồng nhất (Model Nano Banana Pro / 2.1 / 2 Lite + 1K/2K/4K + 4:3/3:4)
        img_tab = app._tab_instances["image_consist"]
        test_scene_img = os.path.join(tempfile.gettempdir(), "test_consistent_scene_01.png")
        ok_img = img_tab._render_consistent_scene_image(
            scene_id=1,
            prompt="0-3s: Wide shot in glowing forest. 3-6s: Tracking shot. 6-8s: Close-up.",
            char_bible="CHAR_01: Cute robotic white cat with cyan eyes",
            style="3D Pixar / Disney",
            ratio_str="16:9 (Ngang)",
            seed=424242,
            ref_img_path=None,
            out_path=test_scene_img,
        )
        assert ok_img and os.path.isfile(test_scene_img) and os.path.getsize(test_scene_img) > 5000
        os.remove(test_scene_img)
        print("[FUNC-PASS] Tab 5 (Image đồng nhất — Nano Banana Pro / 2.1 / 2 Lite + 1K/2K/4K + 4:3/3:4) OK")

        # 2g. Kiểm thử tab Video Muse (resolve_tags + page_helper.js + style auto-detect + _root/nametowidget)
        muse_tab = app._tab_instances["muse_video"]
        assert callable(getattr(muse_tab, "_root", None)), "muse_tab._root bị ghi đè làm lỗi nametowidget!"
        assert muse_tab._nametowidget(str(muse_tab)) is muse_tab
        clean_p, m_tags = tool_muse_charvideo.resolve_tags("CHAR_01, CHAR_02 | [CHAR_03] Walking in neon street")
        assert m_tags == ["CHAR_01", "CHAR_02", "CHAR_03"] and "CHAR_03 Walking" in clean_p
        assert os.path.isfile(os.path.join(SRC_DIR, "engine", "page_helper.js"))
        print("[FUNC-PASS] Tab 7 (Video Muse — resolve_tags + engine/page_helper.js + Style Auto-Detect + Event Safe) OK")

        # 2h. Kiểm thử tab Voice Gemini 2 (Google Vids 23 Espresso Voices + split_text + parse_srt)
        vids_tab = app._tab_instances["vids_voice"]
        chunks = tool_vids_voice.split_text("Xin chào anh em. Hôm nay trời đẹp quá! Chúng ta cùng làm phim AI nhé.")
        srt_lines = tool_vids_voice.parse_srt("1\n00:00:01,000 --> 00:00:03,000\nCâu thoại số 1\n\n2\n00:00:03,500 --> 00:00:05,000\nCâu thoại số 2")
        assert len(chunks) >= 1 and srt_lines == ["Câu thoại số 1", "Câu thoại số 2"]
        assert len(tool_vids_voice.VOICES) == 23
        print("[FUNC-PASS] Tab 10 (Voice Gemini 2 — 23 giọng Google Vids + Thẻ cảm xúc + Chia đoạn .txt/.srt) OK")

        # 2i. Kiểm thử chức năng Làm sạch Ảnh & Prompt từ lần dùng trước trên toàn bộ 11 tab
        for label, key, _ in TABS_SPEC:
            inst = app._tab_instances[key]
            assert hasattr(inst, "clear_previous_session"), f"Tab {key} thiếu hàm clear_previous_session!"
            inst.clear_previous_session(ask_confirm=False, delete_files=False)
        app.clear_all_tabs_session(ask_confirm=False, delete_files=False)
        print("[FUNC-PASS] All 11 Tabs (Chức năng '🧹 Làm sạch' ảnh mẫu, ảnh phân cảnh, prompt & cache phiên trước) OK")

        # 2j. Kiểm thử AI Phân tích Prompt -> Nhận diện nhân vật duy nhất (Bước 1) & ĐỦ 10/10 phân cảnh (Bước 2) dù có prefix dài > 200 ký tự
        long_style = "[3D Pixar / Disney (Hoạt hình 3D điện ảnh, ánh sáng mềm mại, biểu cảm sống động)]"
        c1_bio = "CHAR_01: Petite youthful storybook heroine wearing a bright red hooded cloak over a cream peasant dress, warm hazel eyes, braided chestnut hair, carrying a woven wicker basket"
        c2_bio = "CHAR_02: Warm-hearted mother in a rustic linen apron and sky-blue dress with gentle smile"
        c3_bio = "CHAR_03: Anthropomorphic wolf with sleek grey fur, sharp amber eyes, wearing a tattered brown vest"
        c4_bio = "CHAR_04: Kindly elderly grandmother with round silver spectacles, white lace cap, and floral shawl"
        c5_bio = "CHAR_05: Brave woodsman with broad shoulders, thick beard, green woolen tunic and leather boots"
        sample_multi_char_scenes = [
            f"Prompt 1: {long_style} ({c1_bio}) 0-3s: Wide shot walking out of village cottage. 3-6s: Tracking shot. 6-8s: Waves goodbye.",
            f"Prompt 2: {long_style} ({c1_bio}) ({c2_bio}) 0-3s: Medium shot as mother hands over the wicker basket. 3-6s: Hugs. 6-8s: Smiles.",
            f"Prompt 3: {long_style} ({c1_bio}) 0-3s: Wide shot strolling along sunlit forest trail. 3-6s: Camera pans. 6-8s:Admires flowers.",
            f"Prompt 4: {long_style} ({c1_bio}) 0-3s: Close-up picking golden wildflowers under oak trees. 3-6s: Push-in. 6-8s: Laughs.",
            f"Prompt 5: {long_style} ({c3_bio}) ({c1_bio}) 0-3s: Medium shot of wolf emerging from behind a giant tree. 3-6s: Approaches. 6-8s: Polite bow.",
            f"Prompt 6: {long_style} ({c1_bio}) ({c3_bio}) 0-3s: Two-shot chatting on the winding woodland path. 3-6s: Points ahead. 6-8s: Nods.",
            f"Prompt 7: {long_style} ({c3_bio}) 0-3s: Tracking shot of wolf running ahead on a shortcut trail. 3-6s: Leaps over log. 6-8s: Arrives at cottage.",
            f"Prompt 8: {long_style} ({c4_bio}) ({c3_bio}) 0-3s: Interior shot inside grandmother's cozy wooden cottage. 3-6s: Door knocks. 6-8s: Surprised look.",
            f"Prompt 9: {long_style} ({c1_bio}) ({c3_bio}) 0-3s: Medium shot as heroine enters the cottage bedroom. 3-6s: Steps closer. 6-8s: Curious expression.",
            f"Prompt 10: {long_style} ({c3_bio}) ({c1_bio}) ({c5_bio}) ({c4_bio}) 0-3s: Wide shot as woodsman enters to rescue everyone. 3-6s: Wolf flees. 6-8s: Joyful reunion.",
        ]
        res_an = img_tab.receive_pushed_prompts(sample_multi_char_scenes)
        assert res_an["num_chars"] == 5 and len(img_tab.ref_entities) == 5, f"Expected 5 unique characters, got {len(img_tab.ref_entities)}"
        assert [e["uid"] for e in img_tab.ref_entities] == ["CHAR_01", "CHAR_02", "CHAR_03", "CHAR_04", "CHAR_05"]
        assert len(img_tab.tasks) == 10, f"Expected all 10 scene tasks preserved, got {len(img_tab.tasks)}"
        assert img_tab.tasks[4]["uids"] == ["CHAR_03", "CHAR_01"], f"Scene 5 should bind CHAR_03 & CHAR_01, got {img_tab.tasks[4]['uids']}"
        assert img_tab.tasks[9]["uids"] == ["CHAR_03", "CHAR_01", "CHAR_05", "CHAR_04"]
        safe_txt = flowkit_engine.sanitize_prompt_for_google_flow("7-year-old girl stalking the scary wolf", aggressive=True)
        assert "7-year-old" not in safe_txt and "stalking" not in safe_txt
        print("[FUNC-PASS] Smart Prompt & Character Analyzer (Tự động nhận diện 5 Nhân vật duy nhất ở ① + Đầy đủ 10/10 Phân cảnh ở ② không sót cảnh nào) OK")

        # 2k. Kiểm thử Đa Luồng (3-4 luồng/TK & Xoay vòng đa TK) + Ô chọn Đẩy sang Video (từ Image đồng nhất)
        assert hasattr(img_tab, "cbo_push_video") and hasattr(img_tab, "cbo_account_mode")
        assert img_tab._get_max_workers() == 3
        app.push_prompts_to_review("img6", [(-1, "CHAR_01 | Petite heroine in red cloak", "Test Step 1 Ref Review")], switch_tab=False, show_dialog=False)
        assert app.retry_reviewed_prompt("img6", -1, "CHAR_01 | Petite storybook heroine in crimson cloak")
        assert "crimson cloak" in img_tab.ref_entities[0]["desc"]
        app.push_to_all_step2_tabs(
            prompts_tagged=["CHAR_01 | Scene 1: Walking in forest"],
            prompts_plain=["Scene 1: Walking in forest"],
            ref_lines=["CHAR_01 | Petite storybook heroine in crimson cloak"],
            skip_image_consist=True,
            show_dialog=False,
        )
        app.clear_all_tabs_session(ask_confirm=False, delete_files=False)
        print("[FUNC-PASS] Multi-Threading (3-4 luồng/TK & Đa TK) + Unified Push to Video Tabs OK")

        # 2l. Kiểm thử Cấu trúc Prompt Đồng Nhất: Single-Frame Keyframe Image Prompt vs 8s Motion Video Prompt
        raw_3beat = (
            "Prompt 2: [3D Pixar / Disney] (CHAR_01: Petite youthful storybook heroine in crimson cloak) "
            "(CHAR_02: Kind mother in linen apron) "
            "0-3s: Medium shot of CHAR_01 standing in cozy kitchen holding a woven basket. "
            "3-6s: Camera pans to CHAR_02 handing a loaf of bread to CHAR_01. "
            "6-8s: Close-up on CHAR_01 smiling warmly. Audio: Warm acoustic guitar. Voiceover: Be careful on the path!"
        )
        sf_img_prompt = flowkit_engine.to_single_frame_image_prompt(raw_3beat)
        assert "0-3s" not in sf_img_prompt and "3-6s" not in sf_img_prompt and "6-8s" not in sf_img_prompt, f"Timeline tags leaked into image prompt: {sf_img_prompt}"
        assert "Audio:" not in sf_img_prompt and "Voiceover:" not in sf_img_prompt, f"Audio/Voiceover leaked into image prompt: {sf_img_prompt}"
        assert "Single unified full-frame composition" in sf_img_prompt, f"Missing single-frame lock: {sf_img_prompt}"
        assert "CHAR_02 handing a loaf of bread" in sf_img_prompt, f"Multi-character action lost in single-frame merge: {sf_img_prompt}"
        ref_portrait_prompt = img_tab._build_ref_entity_prompt({"uid": "CHAR_01", "kind": "CHAR", "name": "Red Riding Hood", "desc": "Petite heroine in crimson cloak"})
        assert "turnaround" not in ref_portrait_prompt.lower() and "multiple angles" not in ref_portrait_prompt.lower()
        assert "ONE single character only" in ref_portrait_prompt
        vid_motion_prompt = flowkit_engine.to_video_motion_prompt(sf_img_prompt)
        assert "Single unified full-frame composition" not in vid_motion_prompt
        print("[FUNC-PASS] Unified Prompt Architecture (Single-Frame Portrait/Keyframe for Image vs 8s Motion for Video — Chống chia 4 ô lưới) OK")

        # 2m. Kiểm thử Kiểm soát Nội dung Ảnh Tham Chiếu bằng SHA-256 & Chống dùng nhầm ảnh cũ ở Video đồng nhất (tool7)
        consist_tab = app._tab_instances["veo3_consist"]
        consist_tab.clear_previous_session(ask_confirm=False, delete_files=False)
        assert len(consist_tab._build_image_map()) == 0, "Sau khi làm sạch, _build_image_map phải rỗng tuyệt đối!"
        tmp_ref_a = os.path.join(tempfile.gettempdir(), "REF_CHAR_01.png")
        with open(tmp_ref_a, "wb") as f:
            f.write(b"FAKE_IMAGE_CONTENT_VERSION_1_RED_RIDING_HOOD")
        tool7.IMAGE_CACHE.put("default", tmp_ref_a, "media_id_v1_red_hood", custom_name="REF_CHAR_01")
        assert tool7.IMAGE_CACHE.get("default", tmp_ref_a, name="CHAR_01") == "media_id_v1_red_hood", "Chuẩn hoá REF_CHAR_01 -> CHAR_01 + khớp SHA-256 phải lấy được media_id!"
        # Ghi đè nội dung file ảnh mới (cùng tên file nhưng khác nội dung/SHA-256)
        with open(tmp_ref_a, "wb") as f:
            f.write(b"FAKE_IMAGE_CONTENT_VERSION_2_NEW_CHARACTER")
        assert not tool7.IMAGE_CACHE.get("default", tmp_ref_a, name="CHAR_01"), "Khi file ảnh thay đổi SHA-256, ImageCache bắt buộc huỷ media_id cũ!"
        os.remove(tmp_ref_a)
        print("[FUNC-PASS] Strict SHA-256 Reference Image Control & REF_CHAR_01 -> CHAR_01 Normalization (Chống dùng lại ảnh cũ) OK")

        # 2n. Kiểm thử Sửa Prompt Thủ Công ở toàn bộ các tab Bước 2 (Image đồng nhất, Video đồng nhất, Text to Video, Image to Video, Video Muse)
        img_tab.receive_pushed_prompts([raw_3beat])
        assert len(img_tab.ref_entities) >= 1 and len(img_tab.tasks) == 1
        img_tab.ref_entities[0]["desc"] = "Edited custom heroine description"
        img_tab._sync_txt_ref_from_entities()
        assert "Edited custom heroine description" in img_tab.txt_ref_prompts.get("1.0", "end")
        img_tab.tasks[0]["prompt"] = "Edited custom single-frame scene prompt"
        img_tab._sync_txt_prompt_from_tasks()
        assert "Edited custom single-frame scene prompt" in img_tab.txt_prompt.get("1.0", "end")

        consist_tab.all_prompts_data = [{"id": 0, "text": "CHAR_01 | Edited video consist prompt", "raw_text": "CHAR_01 | Edited video consist prompt", "status": "Waiting...", "file_path": ""}]
        consist_tab._sync_txt_prompt_from_data()
        assert "CHAR_01 | Edited video consist prompt" in consist_tab.txt_prompt.get("1.0", "end")

        t2v_tab = app._tab_instances["veo3_t2v"]
        t2v_tab.all_prompts_data = [{"id": 0, "text": "Edited T2V manual prompt", "status": "Waiting...", "file_path": ""}]
        t2v_tab._sync_txt_prompt_from_data()
        assert "Edited T2V manual prompt" in t2v_tab.txt_prompt_input.get("1.0", "end")

        i2v_tab = app._tab_instances["veo3_i2v"]
        i2v_tab.all_prompts_data = [{"id": 0, "text": "Edited I2V manual prompt", "status": "Waiting...", "file_path": ""}]
        i2v_tab._sync_txt_prompt_from_data()
        assert "Edited I2V manual prompt" in i2v_tab.txt_prompt_input.get("1.0", "end")

        muse_tab.all_prompts_data = [{"id": 0, "text": "CHAR_01 | Edited Muse manual prompt", "status": "Waiting...", "file_path": ""}]
        muse_tab._sync_txt_prompt_from_data()
        assert "CHAR_01 | Edited Muse manual prompt" in muse_tab.txt_prompt_input.get("1.0", "end")
        app.clear_all_tabs_session(ask_confirm=False, delete_files=False)
        print("[FUNC-PASS] Manual Prompt Editing & Textbox Sync across all Step 2 Tabs (Image đồng nhất, Video đồng nhất, T2V, I2V, Muse) OK")

        # 2o. Kiểm thử MCP Server tích hợp (10 Tools + Background HTTP/SSE + 1-Click Config Entry)
        import film_studio_mcp_server as _mcp_test
        assert getattr(app, "mcp_server", None) is not None and app.mcp_server.running, "Background MCP Server chưa chạy!"
        assert len(_mcp_test.MCP_TOOLS_SCHEMA) == 10
        cfg_entry = _mcp_test.build_mcp_client_config_entry()
        assert "--stdio" in cfg_entry["args"]
        print(f"[FUNC-PASS] Integrated MCP Server (Port {app.mcp_server.port} · 10 Tools · 1-Click AI Connector) OK")

        # 2p. Kiểm thử Bản quyền theo Mã Máy (Hardware Machine ID + Subscription Duration Enforcement)
        import time
        import license_manager

        hwid = license_manager.get_machine_id()
        assert hwid.startswith("FS-") and len(hwid) == 22
        wrong_hwid_key = license_manager.generate_license_key(
            machine_id="FS-1111-2222-3333-4444",
            plan="PRO",
            expires_at_ts=int(time.time()) + 86400,
        )
        res_wrong = license_manager.verify_license_key(wrong_hwid_key)
        assert not res_wrong["valid"] and res_wrong["status"] == "MACHINE_MISMATCH"
        exp_key = license_manager.generate_license_key(
            machine_id=hwid,
            plan="PRO",
            expires_at_ts=int(time.time()) - 3600,
        )
        res_exp = license_manager.verify_license_key(exp_key)
        assert not res_exp["valid"] and res_exp["status"] == "EXPIRED"
        valid_key = license_manager.generate_license_key(
            machine_id=hwid,
            plan="ULTRA",
            expires_at_ts=int(time.time()) + 365 * 86400,
            email="tiende@forgezone.store",
        )
        res_act = license_manager.activate_license(valid_key, check_online=False)
        assert res_act["valid"] and res_act["status"] == "ACTIVE"
        app._refresh_license_badge()
        assert getattr(app, "_license_lock_frame", None) is None
        print(f"[FUNC-PASS] Hardware Machine ID License System (HWID={hwid} · Anti-Mismatch · Expiry Gate · Web Sync) OK")


        print("ALL_11_TABS_GUI_VERIFIED", flush=True)
        sys.stdout.flush()
        os._exit(0)

    def _on_user_close():
        app._user_closing = True
        os._exit(0)

    app.protocol("WM_DELETE_WINDOW", _on_user_close)
    while not getattr(app, "_user_closing", False):
        try:
            app.mainloop()
            break
        except Exception as e:
            print(f"[MAINLOOP-RECOVER] Đã chặn lỗi thoát đột ngột: {e}", flush=True)
            traceback.print_exc()


if __name__ == "__main__":
    main()
