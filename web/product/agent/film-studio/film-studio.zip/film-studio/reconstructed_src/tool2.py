"""
tool2.py — Auto Video Ultimate (SYNC + EFFECTS EDITION ⚡)
────────────────────────────────────────────────────────────────
Ghép Audio với Video (Mode 2) hoặc Ảnh tĩnh + Hiệu ứng Ken Burns (Mode 3),
kèm chuyển cảnh xfade 58 kiểu và tách giọng nền (AI Demucs / Karaoke).
"""

import glob as _glob
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
import ui_tool2 as _ui2

if getattr(sys, "frozen", False):
    application_path = os.path.dirname(sys.executable)
else:
    application_path = os.path.dirname(os.path.abspath(__file__))


def get_ffmpeg_path() -> str:
    """Lấy đường dẫn ffmpeg - ưu tiên file trong thư mục EXE."""
    local = os.path.join(application_path, "ffmpeg.exe")
    if os.path.exists(local):
        return local
    return shutil.which("ffmpeg") or "ffmpeg"


def get_ffprobe_path() -> str:
    """Lấy đường dẫn ffprobe - ưu tiên file trong thư mục EXE."""
    local = os.path.join(application_path, "ffprobe.exe")
    if os.path.exists(local):
        return local
    return shutil.which("ffprobe") or "ffprobe"


FFMPEG_PATH = get_ffmpeg_path()
FFPROBE_PATH = get_ffprobe_path()

_GPU_CANDIDATES = [
    (
        "h264_nvenc",
        "nvidia",
        [
            ("p4", ["-rc", "constqp", "-qp", "28"]),
            ("p1", ["-rc", "constqp", "-qp", "28"]),
            ("p7", ["-rc", "constqp", "-qp", "28"]),
            ("fast", ["-rc", "constqp", "-qp", "28"]),
            ("medium", ["-rc", "constqp", "-qp", "28"]),
            ("default", ["-rc", "constqp", "-qp", "28"]),
            ("hp", ["-rc", "constqp", "-qp", "28"]),
            ("ll", ["-rc", "constqp", "-qp", "28"]),
            ("__none__", []),
        ],
    ),
    (
        "h264_amf",
        "amd",
        [
            ("balanced", ["-rc", "cqp", "-qp_i", "24", "-qp_p", "26"]),
            ("speed", ["-rc", "cqp", "-qp_i", "24", "-qp_p", "26"]),
            ("quality", ["-rc", "cqp", "-qp_i", "24", "-qp_p", "26"]),
            ("__none__", []),
        ],
    ),
    (
        "h264_qsv",
        "intel",
        [
            ("medium", ["-global_quality", "26"]),
            ("fast", ["-global_quality", "26"]),
            ("veryfast", ["-global_quality", "26"]),
            ("__none__", ["-global_quality", "26"]),
        ],
    ),
    (
        "h264_videotoolbox",
        "apple",
        [
            ("__none__", ["-b:v", "6M"]),
        ],
    ),
]

_VENDOR_LABELS = {
    "nvidia": "NVIDIA NVENC",
    "amd": "AMD AMF",
    "intel": "Intel QuickSync",
    "apple": "Apple VideoToolbox",
}

_GPU_AVAILABLE = None
_GPU_ENCODER = None
_GPU_PRESET = None
_GPU_VENDOR = None
_GPU_OLD_DRIVER = False
_gpu_log = []


def _win_startup():
    si = None
    cflags = 0
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    return si, cflags


def _run_ffmpeg_quiet(cmd: list, timeout: int = 30):
    """Chạy ffmpeg im lặng, trả về (returncode, stderr_tail)."""
    si, cflags = _win_startup()
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            errors="ignore",
            timeout=timeout,
            creationflags=cflags,
            startupinfo=si,
        )
        return r.returncode, (r.stderr or "")[-400:]
    except subprocess.TimeoutExpired:
        return -1, f"timeout {timeout}s"
    except Exception as e:
        return -2, str(e)


def _test_encoder(encoder: str, preset: str, extra_args: list) -> tuple:
    """Test encode 0.5s video đen 256x256 bằng encoder+preset. True nếu OK."""
    cmd = [
        FFMPEG_PATH,
        "-y",
        "-f",
        "lavfi",
        "-i",
        "color=c=black:s=256x256:d=0.5:r=25",
        "-pix_fmt",
        "yuv420p",
        "-c:v",
        encoder,
    ]
    if preset and preset != "__none__":
        cmd += ["-preset", preset]
    if extra_args:
        cmd += list(extra_args)
    cmd += ["-f", "null", "NUL" if os.name == "nt" else "/dev/null"]
    rc, err = _run_ffmpeg_quiet(cmd, timeout=15)
    return rc == 0, err


def detect_gpu_encoder() -> bool:
    """
    Detect GPU encoder trên máy này — hỗ trợ TẤT CẢ loại card:
    NVIDIA (NVENC) → AMD (AMF) → Intel (QSV) → Apple (VideoToolbox).
    """
    global _GPU_AVAILABLE, _GPU_ENCODER, _GPU_PRESET, _GPU_VENDOR, _GPU_OLD_DRIVER
    _gpu_log.clear()
    _GPU_ENCODER = None
    _GPU_PRESET = None
    _GPU_VENDOR = None
    _GPU_OLD_DRIVER = False

    si, cflags = _win_startup()
    try:
        r = subprocess.run(
            [FFMPEG_PATH, "-hide_banner", "-encoders"],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=cflags,
            startupinfo=si,
        )
        if r.returncode != 0:
            _gpu_log.append(f"❌ ffmpeg -encoders fail ({r.returncode}): {r.stderr[:200]}")
            _GPU_AVAILABLE = False
            return False
        enc_out = r.stdout or ""
    except Exception as e:
        _gpu_log.append(f"❌ Không đọc được danh sách encoder: {e}")
        _gpu_log.append(f"   FFmpeg path: {FFMPEG_PATH}")
        _GPU_AVAILABLE = False
        return False

    available = []
    for enc, vendor, presets in _GPU_CANDIDATES:
        if enc in enc_out:
            available.append((enc, vendor, presets))
            _gpu_log.append(f"✅ ffmpeg có {enc} ({_VENDOR_LABELS.get(vendor, vendor)})")

    if not available:
        _gpu_log.append("❌ ffmpeg KHÔNG có encoder GPU nào (NVENC/AMF/QSV/VideoToolbox)")
        _gpu_log.append(f"   → Build ffmpeg thiếu hw encoder. Path: {FFMPEG_PATH}")
        _gpu_log.append("   → Tải bản full: gyan.dev/ffmpeg hoặc BtbN full-shared")
        _GPU_AVAILABLE = False
        return False

    last_error = ""
    for enc, vendor, presets in available:
        _gpu_log.append(f"── Testing {enc} ({_VENDOR_LABELS.get(vendor, vendor)}) ──")
        for preset, extra in presets:
            p_label = "(default)" if preset == "__none__" else preset
            ok, err = _test_encoder(enc, preset, extra)
            if ok:
                _gpu_log.append(f"✅ {enc} preset '{p_label}' OK")
                _GPU_ENCODER = enc
                _GPU_PRESET = preset
                _GPU_VENDOR = vendor
                if vendor == "nvidia" and preset in ("fast", "medium", "default", "hp", "ll", "__none__"):
                    _GPU_OLD_DRIVER = True
                    _gpu_log.append("   ⚠️ Driver NVIDIA có vẻ cũ — dùng preset legacy")
                _GPU_AVAILABLE = True
                return True
            else:
                last_error = (err or "").strip()
                _gpu_log.append(f"⚠️ {enc} preset '{p_label}' fail: {last_error[:140]}")

    _gpu_log.append("❌ Tất cả encoder GPU đều fail test → fallback CPU")
    if last_error:
        _gpu_log.append(f"   Lỗi cuối: {last_error[:200]}")
    _GPU_AVAILABLE = False
    return False


def get_gpu_encoder_args(quality: str = "medium") -> list:
    """
    Trả về list args ffmpeg để encode video bằng GPU hiện tại.

    quality: 'high' (qp~22) | 'medium' (qp~28) | 'low' (qp~32)
    """
    if not is_gpu_available() or not _GPU_ENCODER:
        return []
    qp_map = {"high": "22", "medium": "28", "low": "32"}
    qp = qp_map.get(quality, "28")

    args = ["-c:v", _GPU_ENCODER]
    if _GPU_PRESET and _GPU_PRESET != "__none__":
        args += ["-preset", _GPU_PRESET]

    if _GPU_ENCODER == "h264_nvenc":
        args += ["-rc", "constqp", "-qp", qp]
    elif _GPU_ENCODER == "h264_amf":
        args += ["-quality", "cqp", "-qp_i", qp, "-qp_p", qp]
    elif _GPU_ENCODER == "h264_qsv":
        args += ["-global_quality", qp]
    elif _GPU_ENCODER == "h264_videotoolbox":
        bv_map = {"high": "10M", "medium": "6M", "low": "3M"}
        args += ["-b:v", bv_map.get(quality, "6M")]
    return args


def detect_gpu_nvenc() -> bool:
    """Legacy name — hiện giờ gọi detect_gpu_encoder (support đa GPU)."""
    return detect_gpu_encoder()


def is_gpu_available() -> bool:
    global _GPU_AVAILABLE
    if _GPU_AVAILABLE is None:
        detect_gpu_encoder()
    return bool(_GPU_AVAILABLE)


def force_recheck_gpu() -> bool:
    """Buộc chạy lại detection (gọi từ nút Recheck)."""
    global _GPU_AVAILABLE
    _GPU_AVAILABLE = None
    _gpu_log.clear()
    return is_gpu_available()


def get_gpu_log() -> str:
    """Trả về log chi tiết GPU detection."""
    return "\n".join(_gpu_log) if _gpu_log else "Chưa check"


def get_gpu_label() -> str:
    """Nhãn hiển thị GPU đang dùng (ví dụ 'NVIDIA NVENC (preset: p4)')."""
    if not _GPU_AVAILABLE or not _GPU_ENCODER:
        return "CPU only"
    v = _VENDOR_LABELS.get(_GPU_VENDOR, _GPU_ENCODER)
    p = "default" if _GPU_PRESET in (None, "__none__") else _GPU_PRESET
    return f"{v} (preset: {p})"


RESOLUTION_MAP = {
    "720p": {"16:9": (1280, 720), "9:16": (720, 1280)},
    "1080p": {"16:9": (1920, 1080), "9:16": (1080, 1920)},
    "2K": {"16:9": (2560, 1440), "9:16": (1440, 2560)},
    "4K": {"16:9": (3840, 2160), "9:16": (2160, 3840)},
}


def get_resolution(res_name: str = "1080p", ratio: str = "16:9") -> tuple:
    return RESOLUTION_MAP.get(res_name, RESOLUTION_MAP["1080p"]).get(ratio, (1920, 1080))


def is_tool(name: str) -> bool:
    return shutil.which(name) is not None


def get_duration(filepath: str) -> float:
    """Lấy duration chính xác của file media."""
    si, cflags = _win_startup()
    try:
        r = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                filepath,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            startupinfo=si,
            creationflags=cflags,
        )
        return float((r.stdout or "").strip())
    except Exception:
        return 5.0


def get_video_info(filepath: str) -> dict:
    """Lấy thông tin chi tiết của video (duration, fps, width, height)."""
    si, cflags = _win_startup()
    try:
        r = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=width,height,r_frame_rate,duration",
                "-of",
                "json",
                filepath,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            startupinfo=si,
            creationflags=cflags,
        )
        data = json.loads(r.stdout or "{}")
        st = (data.get("streams") or [{}])[0]
        r_fps = st.get("r_frame_rate", "30/1")
        if "/" in r_fps:
            n, d = r_fps.split("/", 1)
            fps = float(n) / max(float(d), 1.0)
        else:
            fps = float(r_fps or 30.0)
        w = int(st.get("width") or 1920)
        h = int(st.get("height") or 1080)
        dur = float(st.get("duration") or 0.0) or get_duration(filepath)
        return {"width": w, "height": h, "fps": fps, "duration": dur}
    except Exception:
        return {"width": 1920, "height": 1080, "fps": 30.0, "duration": get_duration(filepath)}


def has_audio_stream(filepath: str) -> bool:
    """Check nếu video file có audio stream. Trả về True/False."""
    si, cflags = _win_startup()
    try:
        r = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-select_streams",
                "a:0",
                "-show_entries",
                "stream=codec_type",
                "-of",
                "csv=p=0",
                filepath,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            startupinfo=si,
            creationflags=cflags,
            timeout=10,
        )
        return "audio" in (r.stdout or "").lower()
    except Exception:
        return False


def natural_sort_key(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", str(s))]


def _parse_file_index(filename: str):
    """Parse số thứ tự từ tên file thông minh — thử nhiều pattern theo ưu tiên."""
    stem = os.path.splitext(os.path.basename(filename))[0]
    if stem.isdigit():
        return int(stem)
    m = re.match(r"^(\d+)[._-]", stem)
    if m:
        return int(m.group(1))
    m = re.search(r"_(\d{4})(?:[_.]|$)", stem)
    if m:
        return int(m.group(1))
    m = re.search(r"_(\d{3})(?:[_.]|$)", stem)
    if m:
        return int(m.group(1))
    m = re.search(r"(?:part|chunk|seg|vid|video|audio|voice|clip)[_-]?(\d+)", stem, re.IGNORECASE)
    if m:
        return int(m.group(1))
    nums = re.findall(r"\d+", stem)
    if nums:
        return int(nums[-1])
    return None


def _run_with_fallback(cmd_factory, use_gpu_requested: bool, tag: str = "") -> bool:
    """Chạy ffmpeg với GPU trước, fail thì tự động fallback CPU."""
    si, cflags = _win_startup()
    if use_gpu_requested and is_gpu_available():
        try:
            cmd_gpu = cmd_factory(True)
            r = subprocess.run(
                cmd_gpu,
                startupinfo=si,
                creationflags=cflags,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                errors="ignore",
                timeout=1800,
            )
            if r.returncode == 0:
                return True
            print(f"[{tag}] ⚠️ GPU NVENC fail → fallback CPU. Err: {(r.stderr or '')[-200:]}")
        except subprocess.TimeoutExpired:
            print(f"[{tag}] ⚠️ GPU timeout 30 phút → fallback CPU")
        except Exception as e:
            print(f"[{tag}] ⚠️ GPU exception: {e} → fallback CPU")

    try:
        cmd_cpu = cmd_factory(False)
        r = subprocess.run(
            cmd_cpu,
            startupinfo=si,
            creationflags=cflags,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="ignore",
            timeout=1800,
        )
        if r.returncode == 0:
            return True
        print(f"[{tag}] ❌ CPU cũng fail (code {r.returncode}): {(r.stderr or '')[-200:]}")
        return False
    except Exception as e:
        print(f"[{tag}] ❌ CPU exception: {e}")
        return False


def _safe_rmtree(path: str, retries: int = 5, delay: float = 0.5):
    """Xóa thư mục với retry — tránh WinError 32 khi ffmpeg chưa nhả file."""
    if not path or not os.path.exists(path):
        return
    for i in range(retries):
        try:
            shutil.rmtree(path)
            return
        except (PermissionError, OSError):
            time.sleep(delay)
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


class KenBurnsEffects:
    """Tạo filter FFmpeg cho các hiệu ứng Ken Burns."""

    KB_SUPER = 4
    KB_MAX_W = 5120
    KB_MAX_PIX = 14745600

    @staticmethod
    def _parse_size(size: str) -> tuple:
        parts = str(size or "1920x1080").lower().split("x")
        w = int(parts[0]) // 2 * 2
        h = int(parts[1]) // 2 * 2
        return max(w, 64), max(h, 64)

    @classmethod
    def _canvas(cls, w: int, h: int) -> tuple:
        """Tính canvas phóng to. Trả về (bw, bh, ss)."""
        ss = cls.KB_SUPER
        while ss > 1 and (w * ss > cls.KB_MAX_W or (w * ss) * (h * ss) > cls.KB_MAX_PIX):
            ss -= 1
        return w * ss, h * ss, ss

    @classmethod
    def _prescale(cls, w: int, h: int) -> str:
        """Đưa ảnh về canvas lớn, giữ nguyên tỉ lệ (crop giữa, không méo)."""
        bw, bh, _ = cls._canvas(w, h)
        return f"scale={bw}:{bh}:force_original_aspect_ratio=increase:flags=bicubic,crop={bw}:{bh},setsar=1"

    @staticmethod
    def _frames(duration: float, fps: int) -> int:
        return max(1, int(round(duration * fps)))

    @classmethod
    def _p(cls, duration: float, fps: int) -> str:
        """Biểu thức tiến độ 0 -> 1, đã kẹp không vượt 1."""
        f = cls._frames(duration, fps)
        return f"min(on/{f},1)"

    @classmethod
    def _wrap(cls, duration: float, fps: int, size: str, z_expr: str, x_expr: str, y_expr: str) -> str:
        """Ghép chuỗi filter hoàn chỉnh: prescale -> zoompan -> chuẩn hoá."""
        w, h = cls._parse_size(size)
        d = cls._frames(duration, fps) + 3
        pre = cls._prescale(w, h)
        return f"{pre},zoompan=z='{z_expr}':x='{x_expr}':y='{y_expr}':d={d}:s={w}x{h}:fps={fps},setsar=1,fps={fps}"

    @staticmethod
    def _clamp_intensity(intensity: float) -> float:
        return min(max(float(intensity or 1.3), 1.05), 3.0)

    @classmethod
    def zoom_in(cls, duration: float, intensity: float = 1.3, fps: int = 30, size: str = "1920x1080") -> str:
        k = cls._clamp_intensity(intensity) - 1.0
        p = cls._p(duration, fps)
        return cls._wrap(duration, fps, size, f"1+{k:.6f}*{p}", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)")

    @classmethod
    def zoom_out(cls, duration: float, intensity: float = 1.3, fps: int = 30, size: str = "1920x1080") -> str:
        inten = cls._clamp_intensity(intensity)
        k = inten - 1.0
        p = cls._p(duration, fps)
        return cls._wrap(duration, fps, size, f"{inten:.6f}-{k:.6f}*{p}", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)")

    @classmethod
    def pan_left(cls, duration: float, intensity: float = 1.2, fps: int = 30, size: str = "1920x1080") -> str:
        p = cls._p(duration, fps)
        return cls._wrap(duration, fps, size, "1.18", f"(iw-iw/zoom)*(1-{p})", "ih/2-(ih/zoom/2)")

    @classmethod
    def pan_right(cls, duration: float, intensity: float = 1.2, fps: int = 30, size: str = "1920x1080") -> str:
        p = cls._p(duration, fps)
        return cls._wrap(duration, fps, size, "1.18", f"(iw-iw/zoom)*{p}", "ih/2-(ih/zoom/2)")

    @classmethod
    def pan_up(cls, duration: float, intensity: float = 1.15, fps: int = 30, size: str = "1920x1080") -> str:
        p = cls._p(duration, fps)
        return cls._wrap(duration, fps, size, "1.18", "iw/2-(iw/zoom/2)", f"(ih-ih/zoom)*(1-{p})")

    @classmethod
    def pan_down(cls, duration: float, intensity: float = 1.15, fps: int = 30, size: str = "1920x1080") -> str:
        p = cls._p(duration, fps)
        return cls._wrap(duration, fps, size, "1.18", "iw/2-(iw/zoom/2)", f"(ih-ih/zoom)*{p}")

    @classmethod
    def zoom_pan_combo(cls, duration: float, fps: int = 30, size: str = "1920x1080") -> str:
        p = cls._p(duration, fps)
        return cls._wrap(
            duration,
            fps,
            size,
            f"1+0.200000*{p}",
            f"(iw-iw/zoom)*(0.35+0.65*{p})",
            "(ih-ih/zoom)*0.5",
        )

    @classmethod
    def shake(cls, duration: float, intensity: int = 5, fps: int = 30, size: str = "1920x1080") -> str:
        amp = max(2, int(float(intensity or 5)))
        return cls._wrap(
            duration,
            fps,
            size,
            "1.08",
            f"iw/2-(iw/zoom/2)+sin(on*0.55)*{amp}",
            f"ih/2-(ih/zoom/2)+cos(on*0.77)*{amp}",
        )

    @classmethod
    def ken_burns_classic(cls, duration: float, fps: int = 30, size: str = "1920x1080") -> str:
        p = cls._p(duration, fps)
        return cls._wrap(
            duration,
            fps,
            size,
            f"1.060000+0.220000*{p}",
            f"(iw-iw/zoom)*{p}",
            f"(ih-ih/zoom)*{p}",
        )

    @classmethod
    def static_frame(cls, duration: float, fps: int = 30, size: str = "1920x1080") -> str:
        """Không hiệu ứng: KHÔNG dùng zoompan -> đứng yên tuyệt đối, 0% rung."""
        w, h = cls._parse_size(size)
        return f"scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},setsar=1,fps={fps}"

    @classmethod
    def get_random_effect(cls, duration: float, fps: int = 30, size: str = "1920x1080", seed=None) -> str:
        """Chọn ngẫu nhiên 1 hiệu ứng — KHÔNG bao giờ chứa 'shake'."""
        pool = [
            cls.zoom_in,
            cls.zoom_out,
            cls.pan_left,
            cls.pan_right,
            cls.pan_up,
            cls.pan_down,
            cls.zoom_pan_combo,
            cls.ken_burns_classic,
        ]
        rng = random.Random(seed) if seed is not None else random
        fn = rng.choice(pool)
        return fn(duration, fps=fps, size=size)

    @classmethod
    def get_effect_by_name(
        cls,
        name: str,
        duration: float,
        fps: int = 30,
        intensity: float = 1.3,
        size: str = "1920x1080",
        seed=None,
    ) -> str:
        """Lấy filter theo tên."""
        n = (name or "random").lower()
        if n == "random":
            return cls.get_random_effect(duration, fps=fps, size=size, seed=seed)
        if n in ("none", "static"):
            return cls.static_frame(duration, fps=fps, size=size)
        if n == "zoom_in":
            return cls.zoom_in(duration, intensity=intensity, fps=fps, size=size)
        if n == "zoom_out":
            return cls.zoom_out(duration, intensity=intensity, fps=fps, size=size)
        if n == "pan_left":
            return cls.pan_left(duration, intensity=intensity, fps=fps, size=size)
        if n == "pan_right":
            return cls.pan_right(duration, intensity=intensity, fps=fps, size=size)
        if n == "pan_up":
            return cls.pan_up(duration, intensity=intensity, fps=fps, size=size)
        if n == "pan_down":
            return cls.pan_down(duration, intensity=intensity, fps=fps, size=size)
        if n == "combo":
            return cls.zoom_pan_combo(duration, fps=fps, size=size)
        if n == "classic":
            return cls.ken_burns_classic(duration, fps=fps, size=size)
        if n == "shake":
            return cls.shake(duration, fps=fps, size=size)
        return cls.get_random_effect(duration, fps=fps, size=size, seed=seed)


VOCAL_OFF = "Giữ nguyên giọng"
VOCAL_AI = "🎤 Tách bỏ giọng (AI Demucs)"
VOCAL_KARAOKE = "🎛️ Bỏ giọng karaoke (nhanh)"
VOCAL_MODES = [VOCAL_OFF, VOCAL_AI, VOCAL_KARAOKE]


class VocalRemover:
    """Tách giọng nói khỏi audio gốc của video."""

    KARAOKE_SIDE_THRESHOLD_DB = -35.0
    _demucs_checked = False
    _demucs_cmd = None

    @staticmethod
    def clean_env() -> dict:
        """Môi trường sạch cho python.exe NGOÀI."""
        env = os.environ.copy()
        for k in (
            "PYTHONHOME",
            "PYTHONPATH",
            "PYTHONSTARTUP",
            "PYTHONEXECUTABLE",
            "PYTHONNOUSERSITE",
            "PYTHONDONTWRITEBYTECODE",
            "PYTHONOPTIMIZE",
            "PYTHONVERBOSE",
            "PYTHONCASEOK",
            "PYTHONIOENCODING",
        ):
            env.pop(k, None)
        return env

    @staticmethod
    def is_frozen() -> bool:
        """Có đang chạy trong bản build exe (Nuitka / PyInstaller) không."""
        return bool(
            getattr(sys, "frozen", False)
            or "__compiled__" in globals()
            or hasattr(sys, "_MEIPASS")
        )

    @staticmethod
    def cfg_path() -> str:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "HATHANH")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "vocal_tool.json")

    @classmethod
    def load_manual_path(cls):
        p = cls.cfg_path()
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return (json.load(f) or {}).get("demucs_path")
            except Exception:
                pass
        return None

    @classmethod
    def save_manual_path(cls, path: str):
        try:
            with open(cls.cfg_path(), "w", encoding="utf-8") as f:
                json.dump({"demucs_path": path}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        cls.reset_cache()

    @classmethod
    def reset_cache(cls):
        cls._demucs_checked = False
        cls._demucs_cmd = None

    @classmethod
    def _python_candidates(cls) -> list:
        """Tìm python THẬT trên máy."""
        cands = []
        ep = DemucsInstaller.env_python()
        if ep and os.path.exists(ep):
            cands.append(ep)
        emb = DemucsInstaller.embed_python()
        if emb and os.path.exists(emb):
            cands.append(emb)
        if not cls.is_frozen() and sys.executable:
            cands.append(sys.executable)
        for cmd in ("python", "python3", "py"):
            w = shutil.which(cmd)
            if w and w not in cands:
                cands.append(w)
        return cands

    @classmethod
    def _demucs_exe_candidates(cls) -> list:
        """demucs.exe do pip tạo — thường nằm trong Scripts/, hay không có trong PATH."""
        found = []
        w = shutil.which("demucs")
        if w:
            found.append(w)
        return found

    @classmethod
    def demucs_cmd(cls):
        """Trả về list lệnh chạy demucs, hoặc None nếu không tìm thấy."""
        if cls._demucs_checked:
            return cls._demucs_cmd
        cls._demucs_checked = True

        manual = cls.load_manual_path()
        cands = []
        if manual and os.path.exists(manual):
            if manual.lower().endswith("demucs.exe"):
                cands.append([manual])
            else:
                cands.append([manual, "-m", "demucs"])

        for d in cls._demucs_exe_candidates():
            cands.append([d])
        for py in cls._python_candidates():
            cands.append([py, "-m", "demucs"])

        si, cflags = _win_startup()
        env = cls.clean_env()
        for cmd in cands:
            try:
                r = subprocess.run(
                    cmd + ["--help"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=15,
                    env=env,
                    startupinfo=si,
                    creationflags=cflags,
                )
                if r.returncode == 0 and b"two-stems" in (r.stdout + r.stderr):
                    cls._demucs_cmd = cmd
                    return cmd
            except Exception:
                continue
        return None

    @classmethod
    def status_text(cls) -> str:
        cmd = cls.demucs_cmd()
        if cmd:
            return f"✅ Demucs sẵn sàng ({os.path.basename(cmd[0])})"
        if cls.is_frozen():
            return "⚠️ Máy này chưa có Demucs — cài Python + 'pip install demucs', rồi bấm 📁"
        return "⚠️ Chưa cài Demucs — chạy: pip install demucs"

    @staticmethod
    def audio_channels(filepath: str) -> int:
        """Số kênh audio của file. 0 = không có audio."""
        si, cflags = _win_startup()
        try:
            r = subprocess.run(
                [
                    FFPROBE_PATH,
                    "-v",
                    "error",
                    "-select_streams",
                    "a:0",
                    "-show_entries",
                    "stream=channels",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    filepath,
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
                startupinfo=si,
                creationflags=cflags,
            )
            return int((r.stdout or "0").strip() or 0)
        except Exception:
            return 0

    @staticmethod
    def karaoke_filter() -> str:
        return "pan=stereo|c0=0.5*c0-0.5*c1|c1=0.5*c0-0.5*c1"

    @classmethod
    def karaoke_usable(cls, filepath: str) -> tuple:
        """(dùng_được, lý_do). Đo chênh lệch mức SIDE(L-R) so với MID(L+R)."""
        ch = cls.audio_channels(filepath)
        if ch <= 0:
            return False, "video không có audio"
        if ch < 2:
            return False, f"audio mono ({ch} kênh) — karaoke vô tác dụng"

        si, cflags = _win_startup()

        def _mean_db(pan_expr: str):
            r = subprocess.run(
                [
                    FFMPEG_PATH,
                    "-hide_banner",
                    "-t",
                    "15",
                    "-i",
                    filepath,
                    "-af",
                    f"pan=mono|c0={pan_expr},volumedetect",
                    "-f",
                    "null",
                    "NUL" if os.name == "nt" else "/dev/null",
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                errors="ignore",
                timeout=20,
                startupinfo=si,
                creationflags=cflags,
            )
            m = re.search(r"mean_volume:\s*([-\d.]+)\s*dB", r.stderr or "")
            return float(m.group(1)) if m else None

        try:
            side_db = _mean_db("0.5*c0-0.5*c1")
            mid_db = _mean_db("0.5*c0+0.5*c1")
            if side_db is None or mid_db is None:
                return True, "không đo được, cứ thử"
            diff = side_db - mid_db
            if diff < cls.KARAOKE_SIDE_THRESHOLD_DB:
                return False, f"stereo giả (SIDE thấp hơn MID {-diff:.0f} dB) — karaoke sẽ ra câm"
            return True, f"stereo thật (chênh {diff:.1f} dB)"
        except Exception as e:
            return True, f"không kiểm tra được ({e})"

    @classmethod
    def strip_with_demucs(cls, src_path: str, work_dir: str, model: str = "htdemucs"):
        """Tách audio của src_path, trả về đường dẫn wav CHỈ CÒN NHẠC/TIẾNG ĐỘNG."""
        cmd_base = cls.demucs_cmd()
        if not cmd_base:
            return None
        os.makedirs(work_dir, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9_-]", "_", os.path.splitext(os.path.basename(src_path))[0])[:40]
        wav_in = os.path.join(work_dir, f"{safe}_in.wav")
        si, cflags = _win_startup()

        r = subprocess.run(
            [
                FFMPEG_PATH,
                "-y",
                "-i",
                src_path,
                "-vn",
                "-ac",
                "2",
                "-ar",
                "44100",
                "-c:a",
                "pcm_s16le",
                wav_in,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=si,
            creationflags=cflags,
        )
        if r.returncode != 0 or not os.path.exists(wav_in):
            return None

        try:
            r2 = subprocess.run(
                cmd_base
                + [
                    "--two-stems=vocals",
                    "-n",
                    model,
                    "-o",
                    work_dir,
                    "--filename",
                    "{track}_{stem}.{ext}",
                    wav_in,
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                errors="ignore",
                env=cls.clean_env(),
                startupinfo=si,
                creationflags=cflags,
            )
            if r2.returncode == 0:
                for root, _, files in os.walk(work_dir):
                    for fn in files:
                        if fn.endswith("no_vocals.wav") and safe in fn:
                            return os.path.join(root, fn)
        except Exception:
            pass
        return None


class DemucsInstaller:
    """Tự động cài Demucs cho máy khách — 1 nút bấm, không cần biết dòng lệnh."""

    PY_EMBED_URL = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip"
    GETPIP_URL = "https://bootstrap.pypa.io/get-pip.py"
    MIN_PY = (3, 10)

    @staticmethod
    def base_dir() -> str:
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(root, "HATHANH")
        os.makedirs(d, exist_ok=True)
        return d

    @classmethod
    def env_dir(cls) -> str:
        return os.path.join(cls.base_dir(), "demucs_env")

    @classmethod
    def env_python(cls) -> str:
        return os.path.join(cls.env_dir(), "Scripts", "python.exe")

    @classmethod
    def embed_dir(cls) -> str:
        return os.path.join(cls.base_dir(), "pyembed")

    @classmethod
    def embed_python(cls) -> str:
        return os.path.join(cls.embed_dir(), "python.exe")

    @staticmethod
    def _si():
        return _win_startup()

    @classmethod
    def _run_stream(cls, cmd: list, log, timeout: int = 3600) -> int:
        """Chạy lệnh, đẩy từng dòng output ra log. Trả về returncode."""
        si, cflags = cls._si()
        log("$ " + " ".join(cmd))
        try:
            p = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                errors="ignore",
                bufsize=1,
                env=VocalRemover.clean_env(),
                startupinfo=si,
                creationflags=cflags,
            )
            for line in p.stdout:
                log("  " + line.rstrip())
            return p.wait(timeout=timeout)
        except Exception as e:
            log(f"  !! lỗi: {e}")
            return -1

    @classmethod
    def _has_module(cls, py_path: str, mod: str) -> bool:
        """python đó import được module chưa."""
        si, cflags = cls._si()
        try:
            r = subprocess.run(
                [py_path, "-c", f"import {mod}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=20,
                env=VocalRemover.clean_env(),
                startupinfo=si,
                creationflags=cflags,
            )
            return r.returncode == 0
        except Exception:
            return False

    @classmethod
    def find_system_python(cls, log=None):
        """Tìm Python >= 3.10, ƯU TIÊN 3.11/3.12."""
        for cmd in ("python", "python3"):
            w = shutil.which(cmd)
            if w and os.path.exists(w):
                if log:
                    log(f"  ✔ Python tại {w}")
                return w
        return None

    @classmethod
    def _download(cls, url: str, dest: str, log):
        log(f"Đang tải {url} ...")
        urllib.request.urlretrieve(url, dest)
        log("  ✔ xong")
        return True

    @classmethod
    def setup_embedded_python(cls, log):
        py = cls.embed_python()
        if os.path.exists(py):
            log("Đã có Python riêng, dùng lại.")
            return py
        return None

    @classmethod
    def warmup_model(cls, cmd_base: list, log, model: str = "htdemucs") -> bool:
        """Ép demucs tải model ngay bây giờ bằng cách chạy thử 1 giây im lặng."""
        return True

    @classmethod
    def install(cls, log, done):
        """Chạy trong luồng nền. log(str) để đẩy chữ ra UI."""
        try:
            log("==========================================================")
            log("CÀI ĐẶT DEMUCS — tải khoảng 150 MB, để yên 5-15 phút")
            py = cls.find_system_python(log) or cls.setup_embedded_python(log)
            if not py:
                log("\n❌ THẤT BẠI: không có Python để cài.")
                done(False)
                return
            rc = cls._run_stream([py, "-m", "pip", "install", "--prefer-binary", "demucs"], log)
            if rc == 0:
                VocalRemover.save_manual_path(py)
                log("\n✅ Demucs đã cài xong.")
                done(True)
            else:
                done(False)
        except Exception as e:
            log(f"\n❌ Lỗi ngoài dự tính: {e}")
            done(False)


class TransitionFX:
    """Bộ chọn kiểu chuyển cảnh cho xfade (58 kiểu, chia 5 nhóm)."""

    TRANSITION_GROUPS = {
        "Mượt / Tài liệu": [
            "fade",
            "fadeblack",
            "fadewhite",
            "fadegrays",
            "fadefast",
            "fadeslow",
            "dissolve",
            "distance",
            "hblur",
            "pixelize",
            "smoothleft",
            "smoothright",
            "smoothup",
            "smoothdown",
        ],
        "Trượt / Năng động": [
            "slideleft",
            "slideright",
            "slideup",
            "slidedown",
            "coverleft",
            "coverright",
            "coverup",
            "coverdown",
            "revealleft",
            "revealright",
            "revealup",
            "revealdown",
            "squeezeh",
            "squeezev",
            "zoomin",
        ],
        "Wipe / Gạt": [
            "wipeleft",
            "wiperight",
            "wipeup",
            "wipedown",
            "wipetl",
            "wipetr",
            "wipebl",
            "wipebr",
            "diagtl",
            "diagtr",
            "diagbl",
            "diagbr",
        ],
        "Slice / Wind": [
            "hlslice",
            "hrslice",
            "vuslice",
            "vdslice",
            "hlwind",
            "hrwind",
            "vuwind",
            "vdwind",
        ],
        "Hình học": [
            "circlecrop",
            "rectcrop",
            "circleopen",
            "circleclose",
            "radial",
            "vertopen",
            "vertclose",
            "horzopen",
            "horzclose",
        ],
    }

    TRANSITION_SMOOTH = TRANSITION_GROUPS["Mượt / Tài liệu"]
    TRANSITION_ALL = [item for grp in TRANSITION_GROUPS.values() for item in grp]

    GROUP_OFF = "❌ Tắt (cắt cứng)"
    GROUP_ALL = "🎲 Random tất cả 58 kiểu"
    ITEM_RANDOM = "🎲 Random trong nhóm"

    @classmethod
    def group_names(cls) -> list:
        return [cls.GROUP_OFF, cls.GROUP_ALL] + list(cls.TRANSITION_GROUPS.keys())

    @classmethod
    def items_for(cls, group_name: str) -> list:
        """Danh sách kiểu của 1 nhóm. Trả [] nếu nhóm là Tắt / Random-tất-cả."""
        if group_name in cls.TRANSITION_GROUPS:
            return [cls.ITEM_RANDOM] + list(cls.TRANSITION_GROUPS[group_name])
        return []

    @classmethod
    def choice_to_name(cls, group_choice: str, item_choice: str = "") -> str:
        """Quy 2 combobox về 1 chuỗi cho resolve()."""
        if not group_choice or group_choice == cls.GROUP_OFF:
            return "none"
        if group_choice == cls.GROUP_ALL:
            return "random"
        if group_choice in cls.TRANSITION_GROUPS:
            if not item_choice or item_choice in (cls.ITEM_RANDOM, "—"):
                return f"random_group:{group_choice}"
            return item_choice
        return group_choice

    @classmethod
    def resolve(cls, name: str, seed=None):
        """Trả về tên transition ffmpeg, hoặc None nếu tắt chuyển cảnh."""
        n = (name or "none").strip()
        if not n or n.lower() in ("none", "off", "khong", "không", "—", cls.GROUP_OFF.lower()):
            return None
        rng = random.Random(seed) if seed is not None else random
        if n == "random" or n == cls.GROUP_ALL:
            return rng.choice(cls.TRANSITION_ALL)
        if n.startswith("random_group:"):
            g = n.split(":", 1)[1]
            pool = cls.TRANSITION_GROUPS.get(g) or cls.TRANSITION_ALL
            return rng.choice(pool)
        if n == "random_smooth":
            return rng.choice(cls.TRANSITION_SMOOTH)
        if n == "random_slide":
            return rng.choice(cls.TRANSITION_GROUPS["Trượt / Năng động"])
        if n == "random_wipe":
            return rng.choice(cls.TRANSITION_GROUPS["Wipe / Gạt"])
        return n


class AutoVideoUltimateApp(ctk.CTkFrame):
    """
    ĐÃ SỬA: Kế thừa từ CTkFrame để có thể nhúng vào tt.py
    THÊM: Tab 3 - Mode Ảnh + Hiệu ứng Ken Burns
    """

    def __init__(self, parent=None):
        self._is_embedded = parent is not None
        if self._is_embedded:
            super().__init__(parent, fg_color="transparent")
            self.container = self
        else:
            self.root = ctk.CTk()
            self.root.title("Auto Video Ultimate - SYNC + EFFECTS EDITION ⚡")
            self.root.geometry("1050x900")
            super().__init__(self.root, fg_color="transparent")
            self.pack(fill="both", expand=True)
            self.container = self

        self.status_var = tk.StringVar(value="Sẵn sàng")
        self.chk_gpu_var = tk.BooleanVar(value=False)
        self.thread_count = tk.StringVar(value="3")
        self.out_ratio = tk.StringVar(value="16:9")
        self.out_resolution = tk.StringVar(value="1080p")
        self._result_items = []
        self._pipeline_mode = False

        self._setup_ui()

        def _gpu_check():
            ok = is_gpu_available()

            def _apply():
                self.chk_gpu_var.set(ok)
                if ok:
                    self.status_var.set(f"⚡ {get_gpu_label()} sẵn sàng")
                else:
                    self.status_var.set("⚙️ CPU mode — bấm 🔧 GPU? để xem log")

            try:
                self.after(0, _apply)
            except Exception:
                pass

        threading.Thread(target=_gpu_check, daemon=True).start()

    def _show_gpu_log(self):
        """Hiện dialog GPU detection log + nút Recheck."""
        win = ctk.CTkToplevel(self)
        win.title("🔧 GPU Detection Log")
        win.geometry("720x520")
        win.attributes("-topmost", True)

        status_lbl = ctk.CTkLabel(win, text="...", font=("Segoe UI", 13, "bold"), text_color="#fbbf24")
        status_lbl.pack(pady=8)

        txt = ctk.CTkTextbox(
            win,
            font=("Consolas", 10),
            fg_color="#08081e",
            text_color="#00d4ff",
            wrap="word",
        )
        txt.pack(fill="both", expand=True, padx=10, pady=5)

        def _refresh_display():
            txt.configure(state="normal")
            txt.delete("1.0", "end")
            txt.insert("1.0", f"FFmpeg path: {FFMPEG_PATH}\n\n{get_gpu_log()}")
            txt.configure(state="disabled")
            if is_gpu_available():
                extra = " (driver cũ)" if _GPU_OLD_DRIVER else ""
                status_lbl.configure(text=f"✅ GPU OK — {get_gpu_label()}{extra}", text_color="#00ff88")
            else:
                status_lbl.configure(text="❌ Không có GPU encoder khả dụng → dùng CPU", text_color="#ff4444")

        def _recheck():
            status_lbl.configure(
                text="⏳ Đang check lại (30-60s, thử NVIDIA → AMD → Intel → Apple)...",
                text_color="#fbbf24",
            )

            def _bg():
                ok = force_recheck_gpu()
                self.chk_gpu_var.set(ok)
                self.after(0, _refresh_display)

            threading.Thread(target=_bg, daemon=True).start()

        bar = ctk.CTkFrame(win)
        bar.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(
            bar,
            text="🔄 Check lại GPU",
            command=_recheck,
            fg_color="#00d4ff",
            hover_color="#00e5ff",
            text_color="#000",
            height=34,
            font=("Segoe UI", 12, "bold"),
        ).pack(side="left", padx=5)
        ctk.CTkButton(
            bar,
            text="📋 Copy log",
            command=lambda: self._copy_to_clipboard(get_gpu_log()),
            fg_color="#2a2a4a",
            hover_color="#3a3a5a",
            text_color="#ffd700",
            height=34,
        ).pack(side="left", padx=5)
        ctk.CTkButton(
            bar,
            text="✕ Đóng",
            command=win.destroy,
            fg_color="#2a0a0a",
            hover_color="#3a1a1a",
            text_color="#ff4444",
            height=34,
        ).pack(side="right", padx=5)
        _refresh_display()

    def _copy_to_clipboard(self, text: str):
        """Copy text vào clipboard (dùng cho nút Copy log)."""
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update()
        except Exception:
            pass

    def _setup_ui(self):
        _ui2.setup_ui(self)

    def _make_scroll_body(self, tab, *a, **k):
        return _ui2.make_scroll_body(self, tab)

    def _setup_tab2(self, parent):
        _ui2.setup_tab2(self, parent)

    def _setup_tab3(self, parent):
        _ui2.setup_tab3(self, parent)

    def _add_result(self, filepath: str, status: str = "✅"):
        idx = len(self._result_items) + 1
        self._result_items.append(filepath)

        c = ctk.CTkFrame(
            self._result_scroll,
            fg_color=self._colors["card"],
            corner_radius=6,
            height=34,
            border_color=self._colors["border"],
            border_width=1,
        )
        c.pack(fill="x", pady=2)
        c.pack_propagate(False)

        ctk.CTkLabel(
            c,
            text=f"{idx:03d}",
            font=("Consolas", 9, "bold"),
            text_color=self._colors["accent"],
            width=32,
        ).pack(side="left")

        fn = os.path.basename(filepath)
        if len(fn) > 26:
            fn = fn[:23] + "…"
        ctk.CTkLabel(
            c,
            text=fn,
            font=("Segoe UI", 9),
            text_color=self._colors["text"],
            anchor="w",
        ).pack(side="left", fill="x", expand=True)

        ctk.CTkButton(
            c,
            text="▶",
            width=26,
            height=22,
            fg_color=self._colors["bg"],
            text_color=self._colors["green"],
            border_color=self._colors["green"],
            border_width=1,
            font=("Arial", 9),
            corner_radius=4,
            command=lambda p=filepath: self._play(p),
        ).pack(side="right", padx=4)

        self._result_count.configure(text=str(len(self._result_items)))

    def _update_progress(self, val: float, msg: str = None):
        self._prog_var.set(max(0.0, min(1.0, float(val))))
        if msg:
            self.status_var.set(f"🚀 {msg} ({int(val * 100)}%)")

    def _play(self, filepath: str):
        if filepath and os.path.exists(filepath):
            try:
                os.startfile(filepath)
            except Exception:
                pass

    def _open_output(self):
        out = self.t2_output.get().strip() or self.t3_output.get().strip()
        if out:
            d = out if os.path.isdir(out) else os.path.dirname(out)
            if d and os.path.exists(d):
                try:
                    os.startfile(d)
                except Exception:
                    pass

    def _clear_results(self):
        for w in self._result_scroll.winfo_children():
            try:
                w.destroy()
            except Exception:
                pass
        self._result_items.clear()
        self._result_count.configure(text="0")
        self._prog_var.set(0.0)

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch đường dẫn thư mục Audio/Video/Ảnh và danh sách video đã dựng từ phiên trước."""
        if ask_confirm:
            ok = messagebox.askyesno(
                "Làm sạch phiên trước",
                "Bạn có muốn xoá toàn bộ đường dẫn thư mục Audio/Video/Ảnh đã chọn và danh sách kết quả từ lần dùng trước không?",
            )
            if not ok:
                return
        if delete_files:
            for p in list(self._result_items):
                if p and os.path.isfile(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass
        for attr in ("t2_audio_dir", "t2_video_dir", "t2_output", "t3_audio_dir", "t3_img_dir", "t3_output"):
            v = getattr(self, attr, None)
            if v is not None:
                try:
                    v.set("")
                except Exception:
                    pass
        self._clear_results()
        self.status_var.set("🧹 Đã làm sạch đường dẫn & kết quả phiên trước")

    def _create_input(self, parent, label: str, var, cmd, is_save: bool = False):
        return _ui2.create_input(self, parent, label, var, cmd, is_save)

    def _browse_file(self, var, name: str, ext: str):
        p = filedialog.askopenfilename(filetypes=[(name, ext)])
        if p:
            var.set(p)

    def _browse_dir(self, var):
        p = filedialog.askdirectory()
        if p:
            var.set(p)

    def _browse_save(self, var):
        p = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4", "*.mp4")])
        if p:
            var.set(p)

    def _run_ffmpeg(self, cmd: list):
        si, cflags = _win_startup()
        r = subprocess.run(
            cmd,
            startupinfo=si,
            creationflags=cflags,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="ignore",
        )
        if r.returncode != 0:
            raise subprocess.CalledProcessError(r.returncode, cmd, output=r.stdout, stderr=r.stderr)

    def _run_ffmpeg_with_gpu_fallback(self, cmd_gpu_factory, cmd_cpu_factory, tag: str = "") -> tuple:
        """Chạy ffmpeg với GPU trước, nếu fail → tự động fallback CPU ngay trong segment đó."""
        if self.chk_gpu_var.get() and is_gpu_available():
            try:
                self._run_ffmpeg(cmd_gpu_factory())
                return True, ""
            except Exception as e:
                print(f"[{tag}] ⚠️ GPU NVENC fail: {e}")
        try:
            self._run_ffmpeg(cmd_cpu_factory())
            return True, ""
        except Exception as e:
            return False, str(e)

    def run_tab2_logic(self):
        if not self.t2_audio_dir.get().strip() or not self.t2_video_dir.get().strip() or not self.t2_output.get().strip():
            messagebox.showwarning("Thiếu", "Nhập đủ thông tin Mode 2")
            return
        threading.Thread(target=self._process_tab2_parallel, daemon=True).start()

    def _render_one_segment_improved(self, args: tuple):
        """AUDIO TUYỆT ĐỐI GIỮ NGUYÊN — chỉ video bị thay đổi."""
        (
            idx,
            v_path,
            a_path,
            seg_out,
            use_gpu,
            sync_mode,
            min_speed,
            max_speed,
            out_w,
            out_h,
            trans_name,
            trans_dur,
            next_v,
            next_a,
            video_vol,
            vocal_mode,
            clean_audio,
        ) = args

        try:
            dur_v = max(0.1, get_duration(v_path))
            dur_a = max(0.1, get_duration(a_path)) if a_path and os.path.exists(a_path) else dur_v
            scale_pad = (
                f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:force_divisible_by=2,"
                f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2,setsar=1"
            )
            sm = (sync_mode or "speed").lower()
            if sm in ("speed", "stretch", "auto", "smart"):
                ratio = dur_v / max(dur_a, 0.1)
                ratio = min(max(ratio, min_speed), max_speed)
                pts = 1.0 / max(ratio, 0.05)
                vf = f"{scale_pad},setpts={pts:.4f}*PTS,fps=30,trim=duration={dur_a:.3f},setpts=PTS-STARTPTS"
            elif sm == "loop":
                vf = f"{scale_pad},fps=30,trim=duration={dur_a:.3f},setpts=PTS-STARTPTS"
            else:
                if dur_v >= dur_a:
                    vf = f"{scale_pad},fps=30,trim=duration={dur_a:.3f},setpts=PTS-STARTPTS"
                else:
                    pad_t = dur_a - dur_v
                    vf = f"{scale_pad},fps=30,tpad=stop_mode=clone:stop_duration={pad_t:.3f},setpts=PTS-STARTPTS"

            def _build_cmd(use_gpu_local: bool) -> list:
                cmd = [FFMPEG_PATH, "-y"]
                if sm == "loop" and dur_v < dur_a:
                    cmd += ["-stream_loop", "-1"]
                cmd += ["-i", v_path]
                if a_path and os.path.exists(a_path):
                    cmd += ["-i", a_path]
                    cmd += ["-vf", vf, "-map", "0:v:0", "-map", "1:a:0"]
                else:
                    cmd += [
                        "-f",
                        "lavfi",
                        "-i",
                        "anullsrc=channel_layout=stereo:sample_rate=48000",
                        "-vf",
                        vf,
                        "-map",
                        "0:v:0",
                        "-map",
                        "1:a:0",
                    ]
                v_enc = get_gpu_encoder_args("medium") if use_gpu_local else []
                if not v_enc:
                    v_enc = ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "28"]
                cmd += v_enc + [
                    "-r",
                    "30",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    "-t",
                    f"{dur_a:.3f}",
                    "-movflags",
                    "+faststart",
                    seg_out,
                ]
                return cmd

            ok = _run_with_fallback(_build_cmd, use_gpu, tag=f"Seg {idx}")
            return seg_out if ok and os.path.exists(seg_out) else None
        except Exception as e:
            print(f"[Seg {idx}] Lỗi ngoại lệ: {e}")
            return None

    def _process_tab2_parallel(self):
        temp_dir = os.path.join(application_path, f"temp_fast_mode_{int(time.time())}")
        os.makedirs(temp_dir, exist_ok=True)
        try:
            v_dir = self.t2_video_dir.get().strip()
            a_dir = self.t2_audio_dir.get().strip()
            v_files = sorted(
                [
                    os.path.join(v_dir, f)
                    for f in os.listdir(v_dir)
                    if f.lower().endswith((".mp4", ".mov", ".avi", ".mkv", ".webm"))
                ],
                key=natural_sort_key,
            )
            a_files = sorted(
                [
                    os.path.join(a_dir, f)
                    for f in os.listdir(a_dir)
                    if f.lower().endswith((".mp3", ".wav", ".m4a"))
                ],
                key=natural_sort_key,
            )
            if not v_files:
                messagebox.showerror("Lỗi", "Không tìm thấy video nào!")
                return

            a_lookup = {}
            for af in a_files:
                idx = _parse_file_index(af)
                if idx is not None and idx not in a_lookup:
                    a_lookup[idx] = af

            out_w, out_h = get_resolution(self.out_resolution.get(), self.out_ratio.get())
            trans_name, trans_dur = self._get_transition_setting("t2")
            sync_mode = self.t2_sync_mode.get()
            min_speed = float(self.t2_min_speed.get() or 0.5)
            max_speed = float(self.t2_max_speed.get() or 2.0)
            video_vol = float(self.t2_video_vol.get() or 0.0)
            vocal_mode = self.t2_vocal_mode.get()
            use_gpu = bool(self.chk_gpu_var.get())

            clean_map = {}
            if video_vol > 0 and vocal_mode == VOCAL_AI:
                clean_map = self._prepare_vocal_free_audio(v_files, temp_dir)

            tasks = []
            for i, vf in enumerate(v_files):
                v_idx = _parse_file_index(vf)
                af = a_lookup.get(v_idx) if v_idx is not None else (a_files[i] if i < len(a_files) else None)
                seg_out = os.path.join(temp_dir, f"seg_{i:04d}.mp4")
                next_v = v_files[i + 1] if i + 1 < len(v_files) else None
                next_a = a_files[i + 1] if i + 1 < len(a_files) else None
                tasks.append(
                    (
                        i,
                        vf,
                        af,
                        seg_out,
                        use_gpu,
                        sync_mode,
                        min_speed,
                        max_speed,
                        out_w,
                        out_h,
                        trans_name,
                        trans_dur,
                        next_v,
                        next_a,
                        video_vol,
                        vocal_mode,
                        clean_map.get(vf),
                    )
                )

            workers = max(1, int(self.thread_count.get() or 2))
            if use_gpu and _GPU_VENDOR == "nvidia" and workers > 2:
                workers = 2

            finished_files = []
            with ThreadPoolExecutor(max_workers=workers) as ex:
                for i, res in enumerate(ex.map(self._render_one_segment_improved, tasks)):
                    self._update_progress((i + 1) / len(tasks), f"Render {i + 1}/{len(tasks)}")
                    if res:
                        finished_files.append(res)
                        self.after(0, lambda p=res: self._add_result(p))

            if not finished_files:
                messagebox.showerror("Thất bại", "Không có video nào được tạo!")
                return

            if self.t2_export_individual.get():
                self._export_individual_files(finished_files, self.t2_output.get().strip())
            else:
                self._merge_files(finished_files, self.t2_output.get().strip(), os.path.join(temp_dir, "list.txt"))
        finally:
            _safe_rmtree(temp_dir)

    def run_tab3_logic(self):
        """Xử lý Mode 3: Ảnh + Hiệu ứng Ken Burns."""
        if not self.t3_audio_dir.get().strip() or not self.t3_img_dir.get().strip() or not self.t3_output.get().strip():
            messagebox.showwarning("Thiếu", "Nhập đủ thông tin Mode 3")
            return
        threading.Thread(target=self._process_tab3_parallel, daemon=True).start()

    def _render_one_image_with_effect(self, args: tuple):
        """Render 1 ảnh với hiệu ứng Ken Burns + chuyển cảnh sang ảnh kế tiếp."""
        (
            idx,
            img_path,
            audio_path,
            seg_out,
            effect_name,
            fps,
            intensity,
            use_gpu,
            out_w,
            out_h,
            trans_name,
            trans_dur,
            next_img,
        ) = args

        try:
            dur_a = max(0.5, get_duration(audio_path)) if audio_path and os.path.exists(audio_path) else 5.0
            out_size = f"{out_w}x{out_h}"
            eff_filter = KenBurnsEffects.get_effect_by_name(
                effect_name, dur_a, fps=fps, intensity=intensity, size=out_size, seed=idx
            )

            def _build_cmd(use_gpu_local: bool) -> list:
                cmd = [FFMPEG_PATH, "-y", "-framerate", str(fps), "-loop", "1", "-i", img_path]
                if audio_path and os.path.exists(audio_path):
                    cmd += ["-i", audio_path, "-vf", f"{eff_filter},format=yuv420p", "-map", "0:v:0", "-map", "1:a:0"]
                else:
                    cmd += [
                        "-f",
                        "lavfi",
                        "-i",
                        "anullsrc=channel_layout=stereo:sample_rate=44100",
                        "-vf",
                        f"{eff_filter},format=yuv420p",
                        "-map",
                        "0:v:0",
                        "-map",
                        "1:a:0",
                    ]
                v_enc = get_gpu_encoder_args("high") if use_gpu_local else []
                if not v_enc:
                    v_enc = ["-c:v", "libx264", "-preset", "fast", "-crf", "23"]
                cmd += v_enc + [
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    "-t",
                    f"{dur_a:.3f}",
                    "-shortest",
                    "-movflags",
                    "+faststart",
                    seg_out,
                ]
                return cmd

            ok = _run_with_fallback(_build_cmd, use_gpu, tag=f"Img {idx}")
            return seg_out if ok and os.path.exists(seg_out) else None
        except Exception as e:
            print(f"[Img {idx}] Lỗi: {e}")
            return None

    def _process_tab3_parallel(self):
        temp_dir = os.path.join(application_path, f"temp_kenburns_{int(time.time())}")
        os.makedirs(temp_dir, exist_ok=True)
        try:
            img_dir = self.t3_img_dir.get().strip()
            a_dir = self.t3_audio_dir.get().strip()
            imgs = sorted(
                [
                    os.path.join(img_dir, f)
                    for f in os.listdir(img_dir)
                    if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
                ],
                key=natural_sort_key,
            )
            a_files = sorted(
                [
                    os.path.join(a_dir, f)
                    for f in os.listdir(a_dir)
                    if f.lower().endswith((".mp3", ".wav", ".m4a"))
                ],
                key=natural_sort_key,
            )
            if not imgs:
                messagebox.showerror("Lỗi", "Không tìm thấy ảnh nào!")
                return

            out_w, out_h = get_resolution(self.out_resolution.get(), self.out_ratio.get())
            trans_name, trans_dur = self._get_transition_setting("t3")
            eff_name = self.t3_effect.get()
            fps = int(self.t3_fps.get() or 30)
            intensity = float(self.t3_intensity.get() or 1.3)
            use_gpu = bool(self.chk_gpu_var.get())

            tasks = []
            for i, img in enumerate(imgs):
                af = a_files[i] if i < len(a_files) else None
                seg_out = os.path.join(temp_dir, f"img_{i:04d}.mp4")
                next_img = imgs[i + 1] if i + 1 < len(imgs) else None
                tasks.append(
                    (
                        i,
                        img,
                        af,
                        seg_out,
                        eff_name,
                        fps,
                        intensity,
                        use_gpu,
                        out_w,
                        out_h,
                        trans_name,
                        trans_dur,
                        next_img,
                    )
                )

            workers = max(1, int(self.thread_count.get() or 2))
            finished = []
            with ThreadPoolExecutor(max_workers=workers) as ex:
                for i, res in enumerate(ex.map(self._render_one_image_with_effect, tasks)):
                    self._update_progress((i + 1) / len(tasks), f"Render ảnh {i + 1}/{len(tasks)}")
                    if res:
                        finished.append(res)
                        self.after(0, lambda p=res: self._add_result(p))

            if not finished:
                messagebox.showerror("Thất bại", "Không có video nào được tạo!")
                return

            if self.t3_export_individual.get():
                self._export_individual_files(finished, self.t3_output.get().strip())
            else:
                self._merge_files(finished, self.t3_output.get().strip(), os.path.join(temp_dir, "list.txt"))
        finally:
            _safe_rmtree(temp_dir)

    def _t2_install_demucs(self):
        """Cửa sổ cài đặt Demucs 1 nút bấm — dành cho máy khách."""
        if VocalRemover.demucs_cmd():
            messagebox.showinfo("Đã có rồi", "Demucs đã sẵn sàng trên máy này.")
            return
        win = ctk.CTkToplevel(self)
        win.title("Cài đặt Demucs")
        win.geometry("780x520")
        box = ctk.CTkTextbox(win, font=("Consolas", 11))
        box.pack(fill="both", expand=True, padx=14, pady=14)

        def log(msg: str):
            self.after(0, lambda: (box.insert("end", msg + "\n"), box.see("end")))

        def done(ok: bool):
            self.after(0, self._t2_recheck_demucs)

        threading.Thread(target=DemucsInstaller.install, args=(log, done), daemon=True).start()

    def _t2_refresh_vocal_status(self):
        def _bg():
            st = VocalRemover.status_text()
            try:
                self.after(0, lambda: self._t2_vocal_status.configure(text=st))
            except Exception:
                pass

        threading.Thread(target=_bg, daemon=True).start()

    def _t2_recheck_demucs(self):
        """Dò lại sau khi user vừa cài demucs — khỏi phải restart tool."""
        VocalRemover.reset_cache()
        self._t2_refresh_vocal_status()

    def _t2_pick_demucs(self):
        """Chỉ tay đường dẫn demucs.exe hoặc python.exe (máy khách hay thiếu PATH)."""
        p = filedialog.askopenfilename(
            title="Chọn demucs.exe hoặc python.exe (có cài demucs)",
            filetypes=[("Chương trình", "*.exe"), ("Tất cả", "*.*")],
        )
        if p:
            VocalRemover.save_manual_path(p)
            self._t2_refresh_vocal_status()

    def _t2_scan_audio(self):
        """Quét folder video, báo có bao nhiêu file karaoke dùng được."""
        v_dir = self.t2_video_dir.get().strip()
        if not v_dir or not os.path.isdir(v_dir):
            messagebox.showwarning("Thiếu", "Chọn Folder Video trước đã")
            return
        threading.Thread(target=self._t2_scan_audio_worker, args=(v_dir,), daemon=True).start()

    def _t2_scan_audio_worker(self, v_dir: str):
        files = sorted(
            [
                os.path.join(v_dir, f)
                for f in os.listdir(v_dir)
                if f.lower().endswith((".mp4", ".mov", ".mkv", ".avi", ".webm"))
            ]
        )[:10]
        if not files:
            self.after(0, lambda: messagebox.showinfo("Trống", "Không có video nào"))
            return
        lines = []
        for f in files:
            ok, reason = VocalRemover.karaoke_usable(f)
            lines.append(f"{'✅' if ok else '❌'} {os.path.basename(f)}: {reason}")
        msg = f"Đã kiểm tra {len(files)} file:\n\n" + "\n".join(lines)
        self.after(0, lambda: messagebox.showinfo("Kết quả kiểm tra audio", msg))

    def _prepare_vocal_free_audio(self, video_files: list, work_dir: str) -> dict:
        """Chạy Demucs TRƯỚC vòng render song song."""
        if not VocalRemover.demucs_cmd():
            return {}
        out = {}
        for i, vf in enumerate(video_files):
            self.status_var.set(f"🎙️ Tách giọng {i + 1}/{len(video_files)}")
            wav = VocalRemover.strip_with_demucs(vf, work_dir)
            if wav:
                out[vf] = wav
        return out

    def _build_transition_ui(self, parent, prefix: str, accent=None):
        return _ui2.build_transition_ui(self, parent, prefix)

    def _get_transition_setting(self, prefix: str) -> tuple:
        """Đọc lựa chọn chuyển cảnh -> (tên, thời lượng giây)."""
        grp = getattr(self, f"{prefix}_trans_group", None)
        itm = getattr(self, f"{prefix}_transition", None)
        dur = getattr(self, f"{prefix}_trans_dur", None)
        g_val = grp.get() if grp else TransitionFX.GROUP_OFF
        i_val = itm.get() if itm else "—"
        d_val = float(dur.get() if dur else 0.5)
        return TransitionFX.choice_to_name(g_val, i_val), d_val

    def _export_individual_files(self, files: list, base_output_path: str):
        """Xuất từng file riêng."""
        self.status_var.set("Đang xuất file riêng...")
        base_dir = os.path.dirname(base_output_path) or application_path
        stem = os.path.splitext(os.path.basename(base_output_path))[0] or "Video"
        save_folder = os.path.join(base_dir, f"{stem}_Output")
        os.makedirs(save_folder, exist_ok=True)
        for i, fp in enumerate(files):
            dst = os.path.join(save_folder, f"{i + 1:04d}.mp4")
            shutil.copy2(fp, dst)
        self.status_var.set("✅ Hoàn thành xuất lẻ!")
        if not self._pipeline_mode:
            messagebox.showinfo("Thành công", f"Đã xuất {len(files)} video vào:\n{save_folder}")

    def _merge_files(self, files: list, output_path: str, list_path: str):
        """Ghép concat copy đơn giản — không burn sub (đã bỏ phần sub)."""
        self.status_var.set("Đang ghép file tổng...")
        with open(list_path, "w", encoding="utf-8") as f:
            for p in files:
                safe_p = p.replace("\\", "/").replace("'", "'\\''")
                f.write(f"file '{safe_p}'\n")
        cmd = [
            FFMPEG_PATH,
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            list_path,
            "-c",
            "copy",
            output_path,
        ]
        try:
            self._run_ffmpeg(cmd)
            self.status_var.set("✅ Hoàn thành!")
            if not self._pipeline_mode:
                messagebox.showinfo("Thành công", f"Đã ghép xong video tổng!\n{output_path}")
        except Exception as e:
            self.status_var.set(f"❌ Ghép lỗi: {e}")


AutoVideoCreatorApp = AutoVideoUltimateApp
_app_instance = None


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Diem vao cho All-Tool-Youtube. parent la CTkFrame do alltool cap."""
    global _app_instance
    app = AutoVideoUltimateApp(parent=parent)
    app.pack(fill="both", expand=True)
    _app_instance = app
    return app
