"""
tool4.py — VEO 3 ẢNH - VIDEO (Start/End Image-to-Video I2V — Tab #6 trong All-Tool-Youtube)
──────────────────────────────────────────────────────────────────────────────────────────
Hỗ trợ tạo video từ 1 ảnh bắt đầu (batchAsyncGenerateVideoStartImage) hoặc
chuyển cảnh từ ảnh bắt đầu sang ảnh kết thúc (batchAsyncGenerateVideoStartAndEndImage).
"""

import os
import sys
import re as _re_tag
import time
import json
import uuid
import math
import queue
import shutil
import random
import base64
import tempfile
import traceback
import itertools
import threading
import subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from tkinter import filedialog, messagebox
import customtkinter as ctk
import requests
from PIL import Image

import ui_tool4 as _ui4
from ui import T as _T, F as _F

try:
    from curl_cffi import requests as cffi_requests
    USE_CURL_CFFI = True
except ImportError:
    cffi_requests = requests
    USE_CURL_CFFI = False

CHROME_IMPERSONATE = "chrome131"
MIN_VIDEO_SIZE = 50 * 1024

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

import hashlib
file_lock = threading.Lock()
reset_lock = threading.Lock()
last_reset_time = 0.0
nestjs_process = None


def _prompt_hash(prompt_text: str) -> str:
    norm = _re_tag.sub(r"\s+", " ", (prompt_text or "").strip())
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()[:16]


def _load_prompt_manifest(out_dir: str) -> dict:
    mf_path = os.path.join(out_dir, ".prompt_manifest.json")
    if os.path.exists(mf_path):
        try:
            with open(mf_path, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, dict):
                    return d
        except Exception:
            pass
    return {}


def record_prompt_manifest(out_dir: str, file_path: str, prompt_text: str):
    if not out_dir or not file_path or not prompt_text:
        return
    with file_lock:
        try:
            os.makedirs(out_dir, exist_ok=True)
            mf_path = os.path.join(out_dir, ".prompt_manifest.json")
            data = _load_prompt_manifest(out_dir)
            data[os.path.basename(file_path)] = _prompt_hash(prompt_text)
            with open(mf_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass


def _is_existing_video_valid(out_dir: str, filename: str, prompt_text: str) -> bool:
    if not os.path.exists(filename):
        return False
    try:
        if os.path.getsize(filename) < MIN_VIDEO_SIZE:
            os.remove(filename)
            return False
    except Exception:
        return False
    manifest = _load_prompt_manifest(out_dir)
    if manifest.get(os.path.basename(filename)) != _prompt_hash(prompt_text):
        try:
            os.remove(filename)
        except Exception:
            pass
        return False
    return True

try:
    import captcha_server as _CAPSRV
except Exception as _e:
    _CAPSRV = None


def get_app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def start_nestjs_server(log_func=print, hidden=True, wait=30):
    """Bật server cầu nối Google Ultra & Captcha (port 3000)."""
    global nestjs_process
    try:
        import google_ultra_bridge
        google_ultra_bridge.init_global_bridge(get_app_dir())
        return
    except Exception:
        pass
    if _CAPSRV is not None and hasattr(_CAPSRV, "ensure"):
        try:
            _CAPSRV.ensure(log_func=log_func, hidden=hidden, wait=wait)
            nestjs_process = getattr(_CAPSRV, "_proc", None)
            return
        except Exception:
            pass
    base_dir = get_app_dir()
    nestjs_dir = os.path.join(base_dir, "captcha-solver-main", "captcha-solver-main")
    if os.path.exists(nestjs_dir):
        try:
            kwargs = {"creationflags": subprocess.CREATE_NEW_CONSOLE} if os.name == "nt" else {}
            nestjs_process = subprocess.Popen("npm run start:dev", cwd=nestjs_dir, shell=True, **kwargs)
        except Exception:
            pass


def rotate_ip():
    """Hàm ngắt và kết nối lại WARP để đổi IP mà không cần dùng app cũ."""
    try:
        subprocess.run(["warp-cli", "disconnect"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        subprocess.run(["warp-cli", "connect"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(6)
        return True
    except Exception as e:
        print(f"Không thể tự động đổi IP WARP: {e}")
        return False


def open_path(path):
    """Mở file hoặc folder, hỗ trợ cả Windows, Linux, macOS."""
    if not path or not os.path.exists(path):
        return
    try:
        os.startfile(path)
    except Exception as e:
        print(f"Không thể mở: {path} | Lỗi: {e}")


_TAG_ONE = r"(?:[A-Za-z]{1,8}_?\d{1,3})"
_CHAR_TAG_RE = _re_tag.compile(r"^\s*" + _TAG_ONE + r"(?:\s*[,+/&]\s*" + _TAG_ONE + r")*\s*\|\s*")


def strip_char_tags(text):
    """Cắt phần mã nhân vật đứng trước dấu | , chỉ giữ prompt thật."""
    if not text:
        return text
    s = str(text).strip()
    for _ in range(3):
        m = _CHAR_TAG_RE.match(s)
        if not m:
            break
        rest = s[m.end():].lstrip()
        if not rest:
            break
        s = rest
    return s


def crop_image_for_ratio(image_path: str, ratio_str: str) -> str:
    """Cắt ảnh tự động theo tỷ lệ (16:9 hoặc 9:16) trước khi upload."""
    try:
        with Image.open(image_path) as img:
            w, h = img.size
            target_ratio = (16.0 / 9.0) if "16:9" in str(ratio_str) else (9.0 / 16.0)
            current_ratio = w / float(h)
            if abs(current_ratio - target_ratio) < 0.02:
                return image_path
            if current_ratio > target_ratio:
                new_w = int(h * target_ratio)
                left = (w - new_w) // 2
                box = (left, 0, left + new_w, h)
            else:
                new_h = int(w / target_ratio)
                top = (h - new_h) // 2
                box = (0, top, w, top + new_h)
            cropped = img.crop(box)
            if cropped.mode != "RGB":
                cropped = cropped.convert("RGB")
            tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
            tmp_path = tmp.name
            tmp.close()
            cropped.save(tmp_path, format="JPEG", quality=95)
            return tmp_path
    except Exception as e:
        print(f"Lỗi crop ảnh: {e}")
        return image_path


class VeoBackend:
    def __init__(self, auth_token: str):
        self.auth_token = (auth_token or "").strip()
        self.headers = {
            "authorization": f"Bearer {self.auth_token}",
            "accept": "*/*",
            "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "text/plain;charset=UTF-8",
            "origin": "https://labs.google",
            "priority": "u=1, i",
            "referer": "https://labs.google/",
            "sec-ch-ua": '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "user-agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
            ),
        }
        self.cookies = self._load_app_cookies()
        self.token_session_map = {}

    def _load_app_cookies(self):
        cookies_dir = Path("cookies")
        if not cookies_dir.exists():
            return {}
        json_files = list(cookies_dir.glob("*.json"))
        if not json_files:
            return {}
        try:
            selected_file = random.choice(json_files)
            with open(selected_file, "r", encoding="utf-8") as f:
                cookie_data = json.load(f)
            return {
                c["name"]: c["value"]
                for c in cookie_data
                if isinstance(c, dict) and "name" in c and "value" in c
            }
        except Exception:
            return {}

    def _apply_fresh_headers(self, fresh: dict):
        """Merge fresh headers từ Chrome (qua extension webRequest hook).
        Lowercase wins vì HTTP case-insensitive."""
        if not fresh:
            return
        normalized = {k.lower(): v for k, v in self.headers.items()}
        for k, v in fresh.items():
            normalized[k.lower()] = v
        self.headers = normalized

    def _get_cdp_bridge(self):
        try:
            from google_ultra_bridge import get_global_bridge, init_global_bridge
            b = get_global_bridge()
            if b is None:
                b = init_global_bridge(get_app_dir())
            if self.auth_token.startswith("cdp_flow::") or (b and b.connected_accounts):
                return b
        except Exception:
            pass
        return None

    def get_recaptcha(self):
        """Gọi sang Server NestJS (Cổng 3000) để lấy Token + fresh headers từ Chrome."""
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return "CDP_FLOW_READY"
        try:
            response = requests.get(
                "http://127.0.0.1:3000/captcha",
                params={"action": "VIDEO_GENERATION"},
                timeout=65,
            )
            if response.status_code == 200:
                data = response.json()
                token = data.get("captcha")
                fresh_headers = data.get("headers", {}) or {}
                if fresh_headers:
                    self._apply_fresh_headers(fresh_headers)
                return token
            return None
        except requests.exceptions.Timeout:
            print("❌ Lỗi: Timeout (Trình duyệt Client chưa giải xong Captcha trong 60s).")
            return None
        except Exception as e:
            print(f"❌ Lỗi kết nối đến Server Captcha NestJS: {e}")
            return None

    def upload_user_image(self, image_path: str, recaptcha_token=None, project_id=None):
        """Upload ảnh lên Google Server dùng cho I2V."""
        try:
            with Image.open(image_path) as im:
                if im.mode != "RGB":
                    im = im.convert("RGB")
                tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                tmp_jpg = tmp.name
                tmp.close()
                im.save(tmp_jpg, format="JPEG", quality=95)

            with open(tmp_jpg, "rb") as f:
                encoded_string = base64.b64encode(f.read()).decode("utf-8")
            try:
                os.remove(tmp_jpg)
            except Exception:
                pass

            file_name = os.path.basename(image_path)
            if not file_name.lower().endswith((".jpg", ".jpeg")):
                file_name = os.path.splitext(file_name)[0] + ".jpeg"

            bridge = self._get_cdp_bridge()
            if bridge is not None:
                return bridge.cdp_upload_image(
                    image_b64=encoded_string,
                    mime_type="image/jpeg",
                    file_name=file_name,
                    project_id=project_id,
                )

            pid = (project_id or "").strip() or "14f83d9b-d4a6-48b7-9392-35084c962942"
            payload = {
                "clientContext": {
                    "projectId": pid,
                    "tool": "PINHOLE",
                },
                "fileName": file_name,
                "imageBytes": encoded_string,
                "isHidden": False,
                "isUserUploaded": True,
                "mimeType": "image/jpeg",
            }
            url = "https://aisandbox-pa.googleapis.com/v1/flow/uploadImage"
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=90,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code == 200:
                d = r.json()
                media_id = (d.get("media") or {}).get("name") or d.get("mediaGenerationId")
                return media_id
            print(f"[UPLOAD] LỖI {r.status_code}: {r.text[:300]}")
            return None
        except Exception as e:
            print(f"Upload Exception: {e}")
            traceback.print_exc()
            return None

    def send_request(
        self,
        recaptcha,
        prompt,
        model_key,
        ratio_key,
        start_media_id=None,
        end_media_id=None,
        account_type="Ultra",
        project_id=None,
    ):
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return bridge.cdp_generate_video(
                prompt=prompt,
                model_key=model_key,
                ratio_key=ratio_key,
                project_id=project_id,
                start_media_id=start_media_id,
                end_media_id=end_media_id,
            )
        ACCOUNT_CONFIG = {
            "Ultra": {
                "projectId": "14f83d9b-d4a6-48b7-9392-35084c962942",
                "userPaygateTier": "PAYGATE_TIER_TWO",
            },
            "Pro": {
                "projectId": "4ec7ee56-08c8-4bfe-ba92-f5bb96888bd8",
                "userPaygateTier": "PAYGATE_TIER_NOT_PAID",
            },
        }
        cfg = ACCOUNT_CONFIG.get(account_type, ACCOUNT_CONFIG["Ultra"])
        final_pid = project_id.strip() if project_id and project_id.strip() else cfg["projectId"]

        crop_coords = {"top": 0, "left": 0, "bottom": 1, "right": 1}
        req_item = {
            "aspectRatio": ratio_key,
            "seed": random.randint(10000, 999999),
            "textInput": {"structuredPrompt": {"parts": [{"text": prompt}]}},
            "videoModelKey": model_key,
            "metadata": {},
        }

        if start_media_id and end_media_id:
            url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoStartAndEndImage"
            req_item["startImage"] = {"mediaId": start_media_id, "cropCoordinates": crop_coords}
            req_item["endImage"] = {"mediaId": end_media_id, "cropCoordinates": crop_coords}
        elif start_media_id:
            url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoStartImage"
            req_item["startImage"] = {"mediaId": start_media_id, "cropCoordinates": crop_coords}
        else:
            url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoText"

        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha,
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": cfg["userPaygateTier"],
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS",
            },
            "requests": [req_item],
            "useV2ModelConfig": True,
        }

        try:
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=180,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code == 200:
                d = r.json()
                if "operations" in d:
                    op_name = d["operations"][0]["operation"]["name"]
                    scene_id = d["operations"][0].get("sceneId", "")
                    return "OK", op_name, scene_id
                if "workflows" in d and d.get("workflows"):
                    media_name = ""
                    media_pid = final_pid
                    if d.get("media") and len(d["media"]) > 0:
                        media_name = d["media"][0].get("name", "")
                        media_pid = d["media"][0].get("projectId", final_pid)
                    return "OK", media_name, media_pid
                return "FAIL", f"Schema lạ | keys={list(d.keys())} | {r.text[:250]}", ""
            return "FAIL", f"HTTP {r.status_code} | {r.text[:300]}", ""
        except requests.exceptions.Timeout:
            return "FAIL", "TIMEOUT — Google API chậm, đang retry", ""
        except Exception as e:
            return "FAIL", str(e), ""

    def upscale_video(self, recaptcha, media_id, ratio, resolution_key, model_key, output_path, project_id=None):
        """Upscale video lên 1080p hoặc 4K."""
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return bridge.cdp_upscale_video(
                media_id=media_id,
                ratio_key=ratio,
                resolution_key=resolution_key,
                model_key=model_key,
                project_id=project_id,
            )
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoUpsampleVideo"
        final_pid = project_id.strip() if project_id and project_id.strip() else "15db98c1-1b62-473e-b284-a354d46b4399"
        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha,
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": "PAYGATE_TIER_TWO",
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS",
            },
            "requests": [
                {
                    "aspectRatio": ratio,
                    "seed": random.randint(10000, 999999),
                    "resolution": resolution_key,
                    "videoInput": {"mediaId": media_id},
                    "videoModelKey": model_key,
                    "metadata": {"workflowId": str(uuid.uuid4())},
                }
            ],
            "useV2ModelConfig": True,
        }
        try:
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=180,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code != 200:
                return "FAIL", f"HTTP {r.status_code} | {r.text}", ""
            d = r.json()
            if "operations" in d:
                return "OK", d["operations"][0]["operation"]["name"], d["operations"][0].get("sceneId", "")
            return "FAIL", "No operations found", ""
        except Exception as e:
            return "FAIL", str(e), ""

    def download_video(self, op_name, scene_id, save_path, stop_event=None):
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return bridge.cdp_poll_and_download_video(
                media_id=op_name,
                save_path=save_path,
                stop_event=stop_event,
            )
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchCheckAsyncVideoGenerationStatus"

        def _find_all_urls(obj, path=""):
            found = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if isinstance(v, str) and ("http" in v.lower() or "fife" in k.lower() or "url" in k.lower()):
                        found.append((f"{path}.{k}", v))
                    found.extend(_find_all_urls(v, f"{path}.{k}"))
            elif isinstance(obj, list):
                for i, v in enumerate(obj):
                    found.extend(_find_all_urls(v, f"{path}[{i}]"))
            return found

        def _extract_status(d):
            if "operations" in d:
                return d["operations"][0].get("status", "")
            if "media" in d:
                return d["media"][0].get("mediaMetadata", {}).get("mediaStatus", {}).get("mediaGenerationStatus", "")
            return ""

        def _extract_video_url(d):
            vid_url = None
            media_id = None
            if "operations" in d:
                op = d["operations"][0]
                meta = op.get("operation", {}).get("metadata", {})
                video_meta = meta.get("video") or {}
                if isinstance(video_meta, dict):
                    vid_url = video_meta.get("fifeUrl") or video_meta.get("url") or video_meta.get("videoUrl")
                if not vid_url:
                    vid_url = op.get("videoUrl") or meta.get("videoUrl")
                if not vid_url:
                    vid_url = op.get("operation", {}).get("result", {}).get("videoUrl")
                media_id = op.get("sceneId") or (
                    video_meta.get("mediaGenerationId") if isinstance(video_meta, dict) else None
                )
            if not vid_url and "media" in d:
                m = d["media"][0]
                vid_meta = m.get("video", {}).get("generatedVideo", {})
                vid_url = vid_meta.get("fifeUrl") or vid_meta.get("url") or vid_meta.get("videoUrl")
                media_id = m.get("name")
            if not vid_url:
                for p, u in _find_all_urls(d):
                    if u.startswith("http") and ("video" in p.lower() or "fife" in p.lower() or "google" in u):
                        vid_url = u
                        break
            return vid_url, media_id

        delay = 5
        max_delay = 30
        poll_shape = "media"
        for attempt in range(60):
            if stop_event and stop_event.is_set():
                return "STOPPED", None
            try:
                poll_payload = (
                    {"media": [{"name": op_name, "projectId": scene_id}]}
                    if poll_shape == "media"
                    else {"operations": [{"operation": {"name": op_name}, "sceneId": scene_id}]}
                )
                r = cffi_requests.post(
                    url,
                    json=poll_payload,
                    headers=self.headers,
                    cookies=self.cookies,
                    timeout=90,
                    impersonate=CHROME_IMPERSONATE,
                )
                if r.status_code != 200:
                    if r.status_code in (400, 404) and poll_shape == "media":
                        poll_shape = "operations"
                        continue
                else:
                    d = r.json()
                    status = _extract_status(d)
                    if "SUCCESSFUL" in status:
                        vid_url, media_id = _extract_video_url(d)
                        if not vid_url and "media" in d and len(d["media"]) > 0:
                            media_obj = d["media"][0]
                            media_name = media_obj.get("name", "")
                            workflow_id = media_obj.get("workflowId", "")
                            project_id_real = media_obj.get("projectId", "")
                            if media_name:
                                redirect_url = (
                                    f"https://labs.google/fx/api/trpc/media.getMediaUrlRedirect?name={media_name}"
                                )
                                labs_session = self.token_session_map.get(self.auth_token, "")
                                cookies_dict = (
                                    {"__Secure-next-auth.session-token": labs_session} if labs_session else None
                                )
                                redirect_headers = {
                                    "Accept": "*/*",
                                    "Range": "bytes=0-",
                                    "Referer": f"https://labs.google/fx/tools/flow/project/{project_id_real}/edit/{workflow_id}",
                                    "Origin": "https://labs.google",
                                    "Sec-Fetch-Site": "same-origin",
                                    "User-Agent": self.headers.get("user-agent", ""),
                                }
                                rr = cffi_requests.get(
                                    redirect_url,
                                    headers=redirect_headers,
                                    cookies=cookies_dict,
                                    allow_redirects=False,
                                    timeout=30,
                                    impersonate=CHROME_IMPERSONATE,
                                )
                                if rr.status_code in (301, 302, 307, 308):
                                    vid_url = rr.headers.get("Location", "")
                                    media_id = media_name
                        if vid_url:
                            v = requests.get(vid_url, timeout=120)
                            if v.status_code != 200 or len(v.content) < MIN_VIDEO_SIZE:
                                time.sleep(delay)
                                delay = min(delay + 3, max_delay)
                                continue
                            part_path = save_path + ".part"
                            with open(part_path, "wb") as f:
                                f.write(v.content)
                            os.replace(part_path, save_path)
                            return "DONE", media_id
                        return "FAILED", None
                    elif "FAILED" in status or "BLOCKED" in status:
                        return f"FAILED: {status}"[:120], None
            except Exception as e:
                print(f"Poll exception: {e}")
            time.sleep(delay)
            delay = min(delay + 3, max_delay)
        return "TIMEOUT", None


class ProcessWorker(threading.Thread):
    FAIL_LIMIT = 5
    POLICY_LIMIT = 2
    POLICY_WORDS = (
        "policy", "safety", "blocked", "not allowed", "violat",
        "unsafe", "content restriction", "harmful", "prohibited",
        "bị chặn", "vi phạm", "gây hại", "chính sách",
    )

    MODEL_MAP = {
        "Ultra": {
            "Veo 3.1 - Lite": {
                "I2V": {"16:9": "veo_3_1_i2v_lite", "9:16": "veo_3_1_i2v_lite"},
                "I2V_FL": {"16:9": "veo_3_1_interpolation_lite", "9:16": "veo_3_1_interpolation_lite"},
            },
            "Veo 3.1 - Fast": {
                "I2V": {"16:9": "veo_3_1_i2v_s_fast_ultra", "9:16": "veo_3_1_i2v_s_fast_portrait_ultra"},
                "I2V_FL": {"16:9": "veo_3_1_i2v_s_fast_fl_ultra", "9:16": "veo_3_1_i2v_s_fast_fl_portrait_ultra"},
            },
            "Veo 3.1 - Quality": {
                "I2V": {"16:9": "veo_3_1_i2v_s_ultra", "9:16": "veo_3_1_i2v_s_portrait_ultra"},
                "I2V_FL": {"16:9": "veo_3_1_i2v_s_fl_ultra", "9:16": "veo_3_1_i2v_s_fl_portrait_ultra"},
            },
            "Veo 3.1 - Lite [Lower Priority]": {
                "I2V": {"16:9": "veo_3_1_i2v_lite_low_priority", "9:16": "veo_3_1_i2v_lite_low_priority"},
                "I2V_FL": {
                    "16:9": "veo_3_1_interpolation_lite_low_priority",
                    "9:16": "veo_3_1_interpolation_lite_low_priority",
                },
            },
        },
        "Pro": {
            "Veo 3.1 - Lite": {
                "I2V": {"16:9": "veo_3_1_i2v_lite", "9:16": "veo_3_1_i2v_lite"},
                "I2V_FL": {"16:9": "veo_3_1_interpolation_lite", "9:16": "veo_3_1_interpolation_lite"},
            },
            "Veo 3.1 - Fast": {
                "I2V": {"16:9": "veo_3_1_i2v_s_fast", "9:16": "veo_3_1_i2v_s_fast_portrait"},
                "I2V_FL": {"16:9": "veo_3_1_i2v_s_fast_fl", "9:16": "veo_3_1_i2v_s_fast_fl_portrait"},
            },
            "Veo 3.1 - Quality": {
                "I2V": {"16:9": "veo_3_1_i2v_s", "9:16": "veo_3_1_i2v_s_portrait"},
                "I2V_FL": {"16:9": "veo_3_1_i2v_s_fl", "9:16": "veo_3_1_i2v_s_fl_portrait"},
            },
            "Veo 3.1 - Lite [Lower Priority]": {
                "I2V": {"16:9": "veo_3_1_i2v_lite_low_priority", "9:16": "veo_3_1_i2v_lite_low_priority"},
                "I2V_FL": {
                    "16:9": "veo_3_1_interpolation_lite_low_priority",
                    "9:16": "veo_3_1_interpolation_lite_low_priority",
                },
            },
        },
    }

    def __init__(self, task_queue, config, logger_func, status_func, finish_func, on_prompt_failed=None):
        super().__init__(daemon=True)
        self.on_prompt_failed = on_prompt_failed
        self.task_queue = task_queue
        self.config = config
        self.log = logger_func
        self.update_status = status_func
        self.finish_func = finish_func
        self.stop_event = threading.Event()
        self.executor = None
        self.tokens = []
        self.token_pid_map = {}
        self.token_session_map = {}
        self.token_cycle = None
        self._last_acc_mtime = 0

    def stop(self):
        self.stop_event.set()
        with self.task_queue.mutex:
            self.task_queue.queue.clear()

    def add_task(self, p_data):
        self.task_queue.put(p_data)

    def get_model_key(self, model_name: str, has_end_image: bool, raw_ratio: str, account_type: str = "Ultra") -> str:
        tier_map = self.MODEL_MAP.get(account_type, self.MODEL_MAP["Ultra"])
        m_entry = tier_map.get(model_name) or tier_map.get("Veo 3.1 - Lite [Lower Priority]")
        mode_key = "I2V_FL" if has_end_image else "I2V"
        r_key = "9:16" if "9:16" in str(raw_ratio) else "16:9"
        return m_entry.get(mode_key, {}).get(r_key, "veo_3_1_i2v_lite_low_priority")

    def _pol_lim(self):
        try:
            return max(1, int(self.config.get("policy_limit", self.POLICY_LIMIT)))
        except Exception:
            return self.POLICY_LIMIT

    def _is_policy_block(self, msg):
        """Google báo prompt vi phạm chính sách — thử lại bao nhiêu cũng hỏng."""
        t = str(msg or "").lower()
        return any(k in t for k in self.POLICY_WORDS)

    def _give_up(self, row_id, prompt_text, reason):
        """Bỏ prompt này và đẩy sang tab Rà soát prompt."""
        self.update_status(row_id, f"🛡 Chờ rà soát ({reason})", "")
        self.log(f"[{row_id + 1}] 🛡 Hỏng ({reason}) → đưa sang tab Rà soát prompt.")
        if self.on_prompt_failed:
            try:
                self.on_prompt_failed(row_id, prompt_text, reason)
            except Exception:
                pass

    def _reload_accounts(self, force=False):
        """Đọc lại tool4.json. Update tokens nếu file đã thay đổi."""
        af = os.path.join(get_app_dir(), "tool4.json")
        if not os.path.exists(af):
            return
        try:
            mtime = os.path.getmtime(af)
            if not force and mtime == self._last_acc_mtime:
                return
            self._last_acc_mtime = mtime
            with open(af, "r", encoding="utf-8") as f:
                data = json.load(f)
            new_tokens = []
            new_pid = {}
            new_session = {}
            for acc in data.get("accounts", []):
                tok = (acc.get("token") or "").strip()
                pid = (acc.get("project_id") or "").strip()
                sess = (acc.get("labs_session") or "").strip()
                if tok:
                    new_tokens.append(tok)
                    if pid:
                        new_pid[tok] = pid
                    if sess:
                        new_session[tok] = sess
            if new_tokens:
                self.tokens = new_tokens
                self.token_pid_map = new_pid
                self.token_session_map = new_session
                self.token_cycle = itertools.cycle(self.tokens)
        except Exception as e:
            self.log(f"⚠️ Lỗi reload tool4.json: {e}")

    def _do_upscale(self, backend, row_id, orig_filename, media_id, ratio_key, upscale_mode, project_id=None):
        UPSCALE_MODEL = {
            "1080p": "veo_3_1_upsampler_1080p",
            "4K": "veo_3_1_upsampler_4k",
        }
        UPSCALE_RES = {
            "1080p": "VIDEO_RESOLUTION_1080P",
            "4K": "VIDEO_RESOLUTION_4K",
        }
        model_key = UPSCALE_MODEL.get(upscale_mode)
        res_key = UPSCALE_RES.get(upscale_mode)
        if not model_key or not media_id:
            self.update_status(row_id, "✅ Hoàn thành (không upscale)", orig_filename)
            return
        up_pid = (project_id or "").strip() or self.token_pid_map.get(backend.auth_token, "")
        st, op, sc = "FAIL", "", ""
        for attempt in range(3):
            self.update_status(row_id, f"⬆ Tự động nâng nét {upscale_mode} ({attempt+1}/3)...", orig_filename)
            cap = backend.get_recaptcha()
            if not cap:
                time.sleep(3)
                continue
            st, op, sc = backend.upscale_video(cap, media_id, ratio_key, res_key, model_key, orig_filename, project_id=up_pid)
            if st == "OK":
                break
            time.sleep(4)
        if st != "OK":
            self.update_status(row_id, "✅ Có video gốc, lỗi upscale", orig_filename)
            self.log(f"[{row_id + 1}] ⚠️ Upscale {upscale_mode} lỗi ({op}), giữ bản gốc.")
            return
        self.update_status(row_id, f"🔄 Đang nâng nét & tải {upscale_mode}...", orig_filename)
        base, ext = os.path.splitext(orig_filename)
        up_filename = f"{base}_tmp_up{ext}"
        res, _ = backend.download_video(op, sc, up_filename, stop_event=self.stop_event)
        if res == "DONE":
            try:
                os.replace(up_filename, orig_filename)
            except Exception:
                pass
            self.update_status(row_id, f"✅ Xong ({upscale_mode})", orig_filename)
            self.log(f"[{row_id + 1}] ✅ Đã tự động tải bản {upscale_mode}: {os.path.basename(orig_filename)}")
        else:
            self.update_status(row_id, "✅ Có video gốc, lỗi upscale", orig_filename)
            self.log(f"[{row_id + 1}] ⚠️ Tải bản {upscale_mode} thất bại ({res}), giữ bản gốc.")

    def process_single_prompt(self, p_data, token, ui_model_name, ratio_key, raw_ratio, out_dir, account_type):
        if self.stop_event.is_set():
            return
        row_id = p_data["id"]
        prompt = p_data["text"].strip()
        try:
            import flowkit_engine

            style_val = self.cbo_style.get() if hasattr(self, "cbo_style") else ""
            prompt, _, _ = flowkit_engine.apply_style_to_prompt(prompt, style_val)
        except Exception:
            pass
        force_regen = p_data.get("force_regen", False)
        start_img = p_data.get("start_img")
        end_img = p_data.get("end_img")

        filename = os.path.join(out_dir, f"{row_id + 1:04d}.mp4")
        if _is_existing_video_valid(out_dir, filename, prompt) and not force_regen:
            self.update_status(row_id, "✅ Đã có file", filename)
            return

        token_label = token[-5:] if len(token) > 5 else "..."
        backend = VeoBackend(token)
        backend.token_session_map = self.token_session_map
        project_id_for_token = self.token_pid_map.get(token, "")
        model_key = self.get_model_key(ui_model_name, bool(end_img), raw_ratio, account_type)

        retry_count = 0
        render_fail_count = 0
        policy_fail = 0

        while not self.stop_event.is_set():
            try:
                start_media_id = None
                end_media_id = None

                if start_img and os.path.exists(start_img):
                    self.update_status(row_id, f"🖼 [..{token_label}] Xử lý ảnh 1...", "")
                    cropped_1 = crop_image_for_ratio(start_img, raw_ratio)
                    cap_1 = backend.get_recaptcha()
                    self.update_status(row_id, f"⬆ [..{token_label}] Up Ảnh 1...", "")
                    start_media_id = backend.upload_user_image(cropped_1, cap_1, project_id_for_token)
                    if cropped_1 != start_img:
                        try:
                            os.remove(cropped_1)
                        except Exception:
                            pass
                    if not start_media_id:
                        self.update_status(row_id, "❌ Lỗi Up Ảnh 1 -> Thử lại", "")
                        time.sleep(3)
                        continue

                if end_img and os.path.exists(end_img):
                    self.update_status(row_id, f"🖼 [..{token_label}] Xử lý ảnh 2...", "")
                    cropped_2 = crop_image_for_ratio(end_img, raw_ratio)
                    cap_2 = backend.get_recaptcha()
                    self.update_status(row_id, f"⬆ [..{token_label}] Up Ảnh 2...", "")
                    end_media_id = backend.upload_user_image(cropped_2, cap_2, project_id_for_token)
                    if cropped_2 != end_img:
                        try:
                            os.remove(cropped_2)
                        except Exception:
                            pass
                    if not end_media_id:
                        self.update_status(row_id, "❌ Lỗi Up Ảnh 2 -> Thử lại", "")
                        time.sleep(3)
                        continue

                self.update_status(row_id, "⏳ [API] Lấy Captcha...", "")
                recaptcha = backend.get_recaptcha()
                if not recaptcha:
                    self.update_status(row_id, "❌ Lỗi Cap -> Tạm dừng, hãy bấm Reset WARP...", "")
                    time.sleep(5)
                    continue

                self.update_status(row_id, f"📡 [..{token_label}] Gửi API...", "")
                status, op_name, scene_id = backend.send_request(
                    recaptcha,
                    prompt,
                    model_key,
                    ratio_key,
                    start_media_id=start_media_id,
                    end_media_id=end_media_id,
                    account_type=account_type,
                    project_id=project_id_for_token,
                )

                if status == "OK":
                    self.update_status(row_id, "🔄 Rendering...", "")
                    res, media_id = backend.download_video(op_name, scene_id, filename, stop_event=self.stop_event)
                    if res == "DONE":
                        record_prompt_manifest(out_dir, filename, prompt)
                        upscale_mode = self.config.get("upscale_mode", "1080p")
                        if upscale_mode != "Không":
                            self._do_upscale(
                                backend,
                                row_id,
                                filename,
                                op_name or media_id,
                                ratio_key,
                                upscale_mode,
                                project_id=scene_id,
                            )
                            record_prompt_manifest(out_dir, filename, prompt)
                        else:
                            self.update_status(row_id, "✅ Hoàn thành", filename)
                            self.log(f"[{row_id + 1}] Xong: {os.path.basename(filename)}")
                        break
                    elif res == "STOPPED":
                        self.update_status(row_id, "⏹ Đã dừng", "")
                        break
                    else:
                        render_fail_count += 1
                        _lim = self._pol_lim()
                        if render_fail_count >= _lim:
                            self._give_up(
                                row_id,
                                prompt,
                                f"render hỏng {render_fail_count} lần ({res}) — nhiều khả năng prompt vi phạm chính sách",
                            )
                            break
                        retry_count += 1
                        time.sleep(2)
                        continue
                else:
                    err_msg = str(op_name)
                    if self._is_policy_block(err_msg):
                        policy_fail += 1
                        if policy_fail >= self._pol_lim():
                            self._give_up(row_id, prompt, f"VEO từ chối vì chính sách nội dung: {err_msg[:200]}")
                            break
                        time.sleep(3)
                        continue
                    retry_count += 1
                    if retry_count >= self.FAIL_LIMIT:
                        self._give_up(row_id, prompt, err_msg[:120])
                        break
                    time.sleep(4)
            except Exception as e:
                retry_count += 1
                if retry_count > 6:
                    self._give_up(row_id, prompt, f"lỗi lặp: {e}")
                    break
                time.sleep(3)

    def run(self):
        self._reload_accounts(force=True)
        if not self.tokens:
            self.log("❌ KHÔNG TÌM THẤY token hợp lệ trong tool4.json!")
            self.finish_func()
            return

        raw_ratio = self.config.get("ratio", "16:9")
        ratio_map = {
            "16:9": "VIDEO_ASPECT_RATIO_LANDSCAPE",
            "9:16": "VIDEO_ASPECT_RATIO_PORTRAIT",
        }
        ratio_key = ratio_map.get(raw_ratio, "VIDEO_ASPECT_RATIO_LANDSCAPE")
        ui_model_name = self.config.get("model_name", "Veo 3.1 - Fast")
        account_type = self.config.get("account_type", "Ultra")
        out_dir = self.config.get("out_dir", "Video_Result")
        os.makedirs(out_dir, exist_ok=True)
        max_workers = max(1, int(self.config.get("threads", 1)))

        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        submitted = 0
        while not self.stop_event.is_set():
            try:
                p_data = self.task_queue.get(block=False)
                tok = next(self.token_cycle)
                self.executor.submit(
                    self.process_single_prompt,
                    p_data,
                    tok,
                    ui_model_name,
                    ratio_key,
                    raw_ratio,
                    out_dir,
                    account_type,
                )
                submitted += 1
                time.sleep(random.uniform(1.0, 2.5))
            except queue.Empty:
                break
            except Exception as e:
                print(f"Worker Loop Error: {e}")

        self.executor.shutdown(wait=True)
        self.finish_func()


class VeoApp(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.all_prompts_data = []
        self.rows_ui = {}
        self.worker = None
        self.task_queue = queue.Queue()
        self.current_page = 1
        self.items_per_page = 15
        self.start_images = []
        self.end_images = []
        self.on_prompt_failed = None

        _ui4.setup_ui(self)

    def _on_account_type_change(self, selected):
        """Cập nhật danh sách model theo loại tài khoản."""
        models = [
            "Veo 3.1 - Lite",
            "Veo 3.1 - Fast",
            "Veo 3.1 - Quality",
            "Veo 3.1 - Lite [Lower Priority]",
        ]
        self.cbo_model_ver.configure(values=models)

    def reset_system(self):
        if not messagebox.askyesno("Xác nhận", "Bạn có muốn Reset IP (WARP) không?"):
            return
        self.btn_reset.configure(state="disabled")
        self.log("♻️ Đang thực hiện Đổi IP (WARP)...")

        def _run_reset():
            try:
                rotate_ip()
                try:
                    requests.post("http://127.0.0.1:3000/captcha/force-refresh", timeout=5)
                except Exception:
                    pass
                self.log("✅ Đổi IP thành công!")
            except Exception as e:
                self.log(f"❌ Lỗi Reset: {e}")
            finally:
                self.after(0, lambda: self.btn_reset.configure(state="normal"))

        threading.Thread(target=_run_reset, daemon=True).start()

    def choose_file(self):
        f = filedialog.askopenfilename(filetypes=[("Prompts", "*.txt *.json"), ("All Files", "*.*")])
        if not f:
            return
        self.lbl_file.configure(text=os.path.basename(f))
        try:
            with open(f, "r", encoding="utf-8", errors="ignore") as fp:
                content = fp.read()
            self.txt_prompt_input.delete("1.0", "end")
            self.txt_prompt_input.insert("1.0", content)
            self.scan_prompts_and_files()
        except Exception as e:
            messagebox.showerror("Lỗi", f"Lỗi đọc file: {e}")

    def choose_output_folder(self):
        d = filedialog.askdirectory()
        if d:
            self.entry_out_dir.delete(0, "end")
            self.entry_out_dir.insert(0, d)
            self.scan_prompts_and_files()

    def choose_start_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp")])
        if files:
            self.start_images = list(files)
            self.lbl_img1.configure(text=f"đã chọn {len(self.start_images)} ảnh", text_color=_T.OK)

    def choose_end_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp")])
        if files:
            self.end_images = list(files)
            self.lbl_img2.configure(text=f"đã chọn {len(self.end_images)} ảnh", text_color=_T.OK)

    def clear_selected_images(self):
        """Xoá danh sách ảnh bắt đầu & ảnh kết thúc đã chọn từ lần trước."""
        self.start_images = []
        self.end_images = []
        if hasattr(self, "lbl_img1"):
            self.lbl_img1.configure(text="chưa chọn ảnh nào", text_color=_T.MUTED)
        if hasattr(self, "lbl_img2"):
            self.lbl_img2.configure(text="chưa chọn ảnh nào", text_color=_T.MUTED)
        self.scan_prompts_and_files()
        self.log("🧹 Đã xoá danh sách ảnh bắt đầu & kết thúc đã chọn.")

    def clear_prompts_only(self):
        """Xoá trắng ô câu lệnh và hàng đợi."""
        self.txt_prompt_input.delete("1.0", "end")
        if hasattr(self, "lbl_file"):
            self.lbl_file.configure(text="chưa chọn file")
        self.all_prompts_data = []
        self.render_pagination()
        self.log("🧹 Đã xoá trắng danh sách câu lệnh trên tab Image to video.")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ ảnh đầu-cuối, câu lệnh, hàng đợi và video cũ từ lần dùng trước."""
        if self.worker and self.worker.is_alive():
            if ask_confirm:
                messagebox.showwarning("Đang chạy", "Hãy bấm Dừng tạo trước khi làm sạch dữ liệu!")
            return
        if ask_confirm:
            ans = messagebox.askyesnocancel(
                "Làm sạch dữ liệu Image to video",
                "Bạn muốn làm sạch toàn bộ Ảnh đầu/cuối, Prompt & Hàng đợi từ lần dùng trước?\n\n"
                "• Chọn YES: Xoá sạch Ảnh đã chọn + Prompt + Xoá các file video .mp4 cũ trong thư mục xuất\n"
                "• Chọn NO: Chỉ xoá sạch Ảnh đã chọn & Prompt trên giao diện (giữ file trong ổ đĩa)\n"
                "• Chọn CANCEL: Huỷ bỏ",
            )
            if ans is None:
                return
            delete_files = bool(ans)

        self.start_images = []
        self.end_images = []
        if hasattr(self, "lbl_img1"):
            self.lbl_img1.configure(text="chưa chọn ảnh nào", text_color=_T.MUTED)
        if hasattr(self, "lbl_img2"):
            self.lbl_img2.configure(text="chưa chọn ảnh nào", text_color=_T.MUTED)
        self.txt_prompt_input.delete("1.0", "end")
        if hasattr(self, "lbl_file"):
            self.lbl_file.configure(text="chưa chọn file")
        self.all_prompts_data = []
        self.render_pagination()

        removed = 0
        if delete_files:
            out_dir = self.entry_out_dir.get().strip() or "Video_Result"
            if not os.path.isabs(out_dir):
                out_dir = os.path.join(get_app_dir(), out_dir)
            if os.path.isdir(out_dir):
                for fn in os.listdir(out_dir):
                    if fn.lower().endswith(".mp4") or fn in (".prompt_manifest.json", "list.txt"):
                        try:
                            os.remove(os.path.join(out_dir, fn))
                            removed += 1
                        except Exception:
                            pass

        extra = f" (đã xoá {removed} file cũ)" if delete_files else ""
        self.log(f"🧹 Đã làm sạch toàn bộ Ảnh, Prompt & Hàng đợi cũ trên Image to video{extra}.")

    def create_group_header(self, *args, **kwargs):
        """Giữ lại cho tương thích — giao diện mới tự chia nhóm trong ui_tool4.py."""
        pass

    def _load_accounts_from_json(self):
        p = os.path.join(get_app_dir(), "tool4.json")
        if not os.path.exists(p):
            return []
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f).get("accounts", [])
        except Exception:
            return []

    def _save_accounts_to_json(self, accounts):
        p = os.path.join(get_app_dir(), "tool4.json")
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump({"accounts": accounts}, f, indent=2, ensure_ascii=False)
        except Exception as e:
            messagebox.showerror("Lỗi lưu", str(e))

    def _update_acc_count_label(self):
        if not hasattr(self, "lbl_acc_count"):
            return
        accs = self._load_accounts_from_json()
        full = sum(1 for a in accs if a.get("token") and a.get("project_id"))
        if not accs:
            self.lbl_acc_count.configure(text="Chưa có tài khoản nào.", text_color=_T.MUTED)
        else:
            self.lbl_acc_count.configure(
                text=f"{len(accs)} tài khoản · {full} cái đủ thông tin",
                text_color=_T.OK if full == len(accs) else "#e0a458",
            )

    def _render_account_list(self):
        self._update_acc_count_label()
        target = getattr(self, "_current_acc_list_frame", None)
        if target is None:
            return
        for w in target.winfo_children():
            w.destroy()
        accounts = self._load_accounts_from_json()
        if not accounts:
            ctk.CTkLabel(
                target,
                text="Chưa có tài khoản nào — bấm “Thêm tài khoản mới”.",
                text_color=_T.MUTED,
                font=_F.ui,
            ).pack(pady=24)
            return
        for i, acc in enumerate(accounts):
            _ui4.account_row(self, target, i, acc)

    def _delete_account(self, idx):
        accounts = self._load_accounts_from_json()
        if 0 <= idx < len(accounts):
            removed = accounts.pop(idx)
            self._save_accounts_to_json(accounts)
            self._render_account_list()
            tail = (removed.get("token") or "")[-8:]
            self.log(f"🗑 Đã xóa acc #{idx + 1} (..{tail})")

    def _close_acc_mgr(self, dlg):
        self._current_acc_list_frame = None
        dlg.destroy()

    def open_account_manager(self):
        """Bảng quản lý tài khoản Veo."""
        top = self.winfo_toplevel()
        if hasattr(top, "open_shared_veo_accounts"):
            top.open_shared_veo_accounts()
            return
        dlg = _ui4.dialog(self, "Tài khoản Veo 3", 640, 560)
        head = _ui4.row(dlg)
        head.pack(fill="x", padx=18, pady=(16, 4))
        _ui4.lbl(head, "TÀI KHOẢN VEO 3", _T.TEXT_STRONG, _F.title).pack(side="left")
        _ui4.btn(dlg, "Thêm tài khoản mới", self.on_add_account).pack(fill="x", padx=18, pady=10)
        box = _ui4.card(dlg)
        box.pack(fill="both", expand=True, padx=18, pady=4)
        list_frame = ctk.CTkScrollableFrame(
            box,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_fg_color=_T.CARD,
            scrollbar_button_color="#3a3d4d",
            scrollbar_button_hover_color=_T.ACCENT,
        )
        list_frame.pack(fill="both", expand=True, padx=8, pady=8)
        self._current_acc_list_frame = list_frame
        self._render_account_list()
        footer = _ui4.row(dlg)
        footer.pack(fill="x", padx=18, pady=12)
        _ui4.sbtn(footer, "Đóng", lambda: self._close_acc_mgr(dlg), width=96).pack(side="right")
        dlg.protocol("WM_DELETE_WINDOW", lambda: self._close_acc_mgr(dlg))

    def on_add_account(self):
        dlg = _ui4.dialog(self, "Thêm tài khoản Veo", 600, 500, grab=True)
        _ui4.lbl(dlg, "Dán JSON — một hoặc nhiều tài khoản", _T.TEXT_STRONG, _F.ui_sb).pack(
            anchor="w", padx=20, pady=(16, 6)
        )
        txt = ctk.CTkTextbox(
            dlg,
            height=200,
            corner_radius=_T.RADIUS,
            fg_color=_T.INPUT,
            border_color=_T.BORDER,
            border_width=1,
            text_color=_T.TEXT,
            font=_F.mono_sm,
        )
        txt.pack(fill="both", expand=True, padx=20, pady=4)

        def on_save():
            raw = txt.get("1.0", "end").strip()
            if not raw:
                return
            try:
                data = json.loads(raw)
                accs = data.get("accounts", [])
                existing = self._load_accounts_from_json()
                existing_keys = {(a.get("token"), a.get("project_id")) for a in existing}
                added = 0
                for a in accs:
                    tok = (a.get("token") or "").strip()
                    pid = (a.get("project_id") or "").strip()
                    if tok and (tok, pid) not in existing_keys:
                        existing.append(
                            {
                                "email": a.get("email", ""),
                                "token": tok,
                                "project_id": pid,
                                "credits": a.get("credits", "Unknown"),
                                "labs_session": (a.get("labs_session") or "").strip(),
                            }
                        )
                        existing_keys.add((tok, pid))
                        added += 1
                self._save_accounts_to_json(existing)
                self._render_account_list()
                dlg.destroy()
            except Exception as e:
                messagebox.showerror("JSON không hợp lệ", str(e), parent=dlg)

        bar = _ui4.row(dlg)
        bar.pack(fill="x", padx=20, pady=14)
        _ui4.btn_primary(bar, "Lưu tài khoản", on_save, width=126).pack(side="right")
        _ui4.sbtn(bar, "Huỷ", dlg.destroy, width=86).pack(side="right", padx=(0, 6))

    def log(self, msg):
        self.after(0, lambda m=msg: self._log_ui(m))

    def _log_ui(self, msg):
        try:
            self.log_box.configure(state="normal")
            self.log_box.insert("end", f"{msg}\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        except Exception:
            pass

    def clear_log(self):
        try:
            self.log_box.configure(state="normal")
            self.log_box.delete("1.0", "end")
            self.log_box.configure(state="disabled")
        except Exception:
            pass

    def scan_prompts_and_files(self, *args):
        raw_txt = self.txt_prompt_input.get("1.0", "end").strip()
        lines = [strip_char_tags(l) for l in raw_txt.split("\n") if l.strip()]
        sig = tuple(lines)
        if getattr(self, "_last_prompts_sig", None) != sig:
            self._last_prompts_sig = sig
            self.clear_log()
        out_dir = self.entry_out_dir.get().strip() or "Video_Result"
        new_data = []
        for i, text in enumerate(lines):
            filename = os.path.join(out_dir, f"{i + 1:04d}.mp4")
            ok = _is_existing_video_valid(out_dir, filename, text)
            status = "✅ Đã có file" if ok else "Waiting..."
            f_path = filename if ok else ""
            new_data.append(
                {
                    "id": i,
                    "text": text,
                    "status": status,
                    "file_path": f_path,
                    "force_regen": False,
                    "start_img": self.start_images[i] if i < len(self.start_images) else None,
                    "end_img": self.end_images[i] if i < len(self.end_images) else None,
                }
            )
        self.all_prompts_data = new_data
        self.render_pagination()

    def get_total_pages(self):
        return max(1, math.ceil(len(self.all_prompts_data) / self.items_per_page))

    def render_pagination(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.rows_ui.clear()
        total_pages = self.get_total_pages()
        self.current_page = max(1, min(self.current_page, total_pages))
        self.lbl_page_info.configure(text=f"Trang {self.current_page}/{total_pages}")
        start_idx = (self.current_page - 1) * self.items_per_page
        for item in self.all_prompts_data[start_idx : start_idx + self.items_per_page]:
            self.create_result_row(item)

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.render_pagination()

    def next_page(self):
        if self.current_page < self.get_total_pages():
            self.current_page += 1
            self.render_pagination()

    def create_result_row(self, item):
        _ui4.result_row(self, item, open_cmd=open_path)

    def _set_status_color(self, lbl_w, text):
        _ui4.status_color(lbl_w, text)

    def _sync_txt_prompt_from_data(self):
        """Đồng bộ ngược danh sách all_prompts_data về ô txt_prompt_input để sửa thủ công không bị ghi đè."""
        lines = [str(x.get("text") or "").strip() for x in self.all_prompts_data if str(x.get("text") or "").strip()]
        self._last_prompts_sig = tuple(lines)
        self.txt_prompt_input.delete("1.0", "end")
        if lines:
            self.txt_prompt_input.insert("1.0", "\n".join(lines))

    def on_edit_prompt(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item:
            return
        dlg = _ui4.dialog(self, f"✏️ Sửa thủ công Prompt #{row_id + 1}", 640, 340, grab=True)
        txt_edit = ctk.CTkTextbox(dlg, height=210, wrap="word")
        txt_edit.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        txt_edit.insert("1.0", item["text"])

        def _apply_edit(run_now: bool = False):
            new_t = txt_edit.get("1.0", "end").strip()
            if new_t:
                item["text"] = new_t
                self._sync_txt_prompt_from_data()
                self.render_pagination()
                self.log(f"✏️ Đã lưu chỉnh sửa thủ công cho Prompt #{row_id + 1}")
                if run_now:
                    self.on_regen_prompt(row_id)
            dlg.destroy()

        bar = _ui4.row(dlg)
        bar.pack(fill="x", padx=16, pady=(0, 14))
        _ui4.btn_primary(bar, "▶ Lưu & Tạo lại ngay", lambda: _apply_edit(True), width=160).pack(side="right", padx=(6, 0))
        _ui4.sbtn(bar, "💾 Lưu thay đổi", lambda: _apply_edit(False), width=124).pack(side="right", padx=(6, 0))
        _ui4.sbtn(bar, "Huỷ", dlg.destroy, width=76).pack(side="right")

    def on_regen_prompt(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item:
            return
        if not self.start_images:
            messagebox.showerror("Lỗi", "Chưa chọn ảnh bắt đầu!\nVui lòng chọn ít nhất 1 ảnh để chạy I2V.")
            return
        item["status"] = "Waiting Regen..."
        item["force_regen"] = True
        idx = int(item.get("id", 0))
        item["start_img"] = self.start_images[idx] if idx < len(self.start_images) else self.start_images[-1]
        item["end_img"] = self.end_images[idx] if idx < len(self.end_images) else None
        self.render_pagination()
        if self.worker and self.worker.is_alive():
            self.worker.add_task(item)
        else:
            self.task_queue = queue.Queue()
            self.task_queue.put(item)
            config = {
                "model_name": self.cbo_model_ver.get(),
                "ratio": self.cbo_ratio.get(),
                "account_type": self.cbo_account_type.get(),
                "upscale_mode": self.cbo_upscale.get(),
                "out_dir": self.entry_out_dir.get(),
                "threads": 1,
            }
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
            self.worker = ProcessWorker(
                self.task_queue,
                config,
                self.log,
                self.update_row_status,
                self.on_process_finish,
                on_prompt_failed=self._prompt_failed,
            )
            self.worker.start()

    def on_delete_video(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item or not item.get("file_path") or not os.path.exists(item["file_path"]):
            messagebox.showinfo("Thông báo", "Chưa có video để xóa!")
            return
        if messagebox.askyesno("Xác nhận", f"Bạn muốn xóa video #{row_id + 1}?"):
            try:
                os.remove(item["file_path"])
                item["file_path"] = ""
                item["status"] = "Đã xóa file"
                self.render_pagination()
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def update_row_status(self, row_id, status_text, file_path):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if item:
            item["status"] = status_text
            if file_path:
                item["file_path"] = file_path
        self.after(0, lambda: self._update_row_ui_safe(row_id, status_text, file_path))

    def _update_row_ui_safe(self, row_id, status_text, file_path):
        if row_id not in self.rows_ui:
            return
        widgets = self.rows_ui[row_id]
        self._set_status_color(widgets["status_lbl"], status_text)
        if any(k in status_text for k in ("Hoàn thành", "Đã có", "Xong")) and file_path and os.path.exists(file_path):
            widgets["view_btn"].configure(state="normal", command=lambda fp=file_path: open_path(fp))

    def _sync_token_to_file(self):
        pass

    def start_process(self):
        self.clear_log()
        self.scan_prompts_and_files()
        if not self.all_prompts_data:
            messagebox.showerror("Lỗi", "Chưa có prompt nào!")
            return
        if not self.start_images:
            messagebox.showerror("Lỗi", "Chưa chọn ảnh bắt đầu!\nVui lòng chọn ít nhất 1 ảnh để chạy I2V.")
            return

        self.task_queue = queue.Queue()
        for idx, p in enumerate(self.all_prompts_data):
            p["start_img"] = self.start_images[idx] if idx < len(self.start_images) else self.start_images[-1]
            p["end_img"] = self.end_images[idx] if idx < len(self.end_images) else None
            self.task_queue.put(p)

        try:
            threads = int(self.entry_thread.get())
        except Exception:
            threads = 1

        config = {
            "model_name": self.cbo_model_ver.get(),
            "ratio": self.cbo_ratio.get(),
            "account_type": self.cbo_account_type.get(),
            "upscale_mode": self.cbo_upscale.get(),
            "out_dir": self.entry_out_dir.get(),
            "threads": threads,
        }
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        mode_lbl = "I2V (2 ảnh)" if self.end_images else "I2V (1 ảnh)"
        self.log(f"🚀 Bắt đầu ({mode_lbl}) với {threads} luồng (API)...")

        self.worker = ProcessWorker(
            self.task_queue,
            config,
            self.log,
            self.update_row_status,
            self.on_process_finish,
            on_prompt_failed=self._prompt_failed,
        )
        self.worker.start()

    def _prompt_failed(self, row_id, text, reason=""):
        if self.on_prompt_failed:
            try:
                self.on_prompt_failed(row_id, text, reason)
            except Exception:
                pass

    def stop_process(self):
        if self.worker:
            self.worker.stop()
            self.log("🛑 Đang dừng...")
        self.log("✅ Đã ngắt hàng đợi API.")

    def on_process_finish(self):
        self.after(0, self._finish_ui)

    def _finish_ui(self):
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.log("🏁 Đã hoàn thành (hoặc đã dừng).")

    def merge_video(self):
        folder = self.entry_out_dir.get().strip() or "Video_Result"
        if not os.path.isabs(folder) and not os.path.exists(folder):
            folder = os.path.join(get_app_dir(), folder)
        if not os.path.exists(folder):
            messagebox.showwarning("Chưa có thư mục", f"Thư mục đầu ra chưa tồn tại:\n{folder}")
            return
        videos = sorted([
            f for f in os.listdir(folder)
            if f.lower().endswith(".mp4") and "merged" not in f.lower() and "_tmp" not in f.lower()
        ])
        if len(videos) < 2:
            messagebox.showwarning("Chú ý", "Cần ít nhất 2 file video (.mp4) trong thư mục đầu ra để nối thành phim dài.")
            return
        list_file = os.path.join(folder, "list.txt")
        with open(list_file, "w", encoding="utf-8") as f:
            for vid in videos:
                safe_p = os.path.join(os.path.abspath(folder), vid).replace("'", "'\\''")
                f.write(f"file '{safe_p}'\n")
        output = os.path.join(folder, f"merged_{int(time.time())}.mp4")
        try:
            flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            subprocess.run(
                ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", list_file, "-c", "copy", output],
                check=True,
                creationflags=flags,
            )
            messagebox.showinfo("Hoàn tất nối phim", f"Đã nối {len(videos)} cảnh thành công:\n{output}")
            open_path(folder)
        except Exception as e:
            messagebox.showerror("Lỗi FFmpeg", f"Không thể nối video:\n{e}")
        finally:
            if os.path.exists(list_file):
                os.remove(list_file)


_app_instance = None


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Điểm vào cho All-Tool-Youtube. parent là CTkFrame do alltool cấp."""
    global _app_instance
    try:
        start_nestjs_server()
    except Exception:
        pass
    _app_instance = VeoApp(parent)
    _app_instance.pack(fill="both", expand=True)
    return _app_instance
