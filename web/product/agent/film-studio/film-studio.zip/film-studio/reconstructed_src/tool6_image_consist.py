"""
tool6_image_consist.py — IMAGE ĐỒNG NHẤT (Luồng 2 Bước Chuẩn Google Flow: Tạo Ref Nhân Vật Đa Góc & Bối Cảnh ➔ Tạo Ảnh Từng Phân Cảnh)
────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
Quy trình hoạt động chuẩn Flow:
  • BƯỚC 1 (Tạo Loạt Ảnh Tham Chiếu Gốc):
    - Nhân vật (`CHAR_01`, `CHAR_02`...): Tạo ảnh Character Turnaround Sheet (theo các góc: chính diện, 3/4, góc nghiêng, toàn thân) trên Google Flow (`ogiZ0b`) và khóa `media_id`.
    - Bối cảnh (`LOC_01`, `LOC_02`...): Tạo ảnh Location Master Reference đồng nhất ánh sáng/kiến trúc trên Google Flow (`ogiZ0b`) và khóa `media_id`.
    - Hoặc tải ảnh có sẵn từ máy lên Google Flow (`maseQ`) để lấy `media_id`.
  • BƯỚC 2 (Tạo Ảnh Từng Phân Cảnh Bám Sát Ref Đã Tạo):
    - Với từng phân cảnh (`Scene 1`, `Scene 2`...), tự động truyền danh sách `ref_media_ids` của Nhân vật & Bối cảnh xuất hiện trong cảnh đó vào `ogiZ0b` (`flow_batch.image_request`), giúp AI vẽ ra từng phân cảnh mới 100% nhưng giữ nguyên mặt, trang phục nhân vật và không gian bối cảnh.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import queue
import random
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Any, Dict, List, Optional

import customtkinter as ctk
import requests
from PIL import Image, ImageDraw, ImageFont

import flow_batch
import ui_tool6 as _ui6
from ui import T as _T, F as _F, row, lbl, sbtn

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
REF_CACHE_FILE = os.path.join(SRC_DIR, "flow_ref_entities_cache.json")


class ConsistentSceneImageApp(ctk.CTkFrame):
    """Tab 'Image đồng nhất' — Luồng 2 Bước: ① Tạo Ảnh Tham Chiếu (Nhân vật đa góc & Bối cảnh) ➔ ② Tạo Ảnh Từng Phân Cảnh."""

    def __init__(self, master, pipeline=None):
        super().__init__(master, fg_color=_T.BG)
        self.pipeline = pipeline
        self.on_prompt_failed = None

        self.ref_entities: List[Dict[str, Any]] = []
        self.tasks: List[Dict[str, Any]] = []
        self.is_running = False
        self.stop_requested = False
        self.ui_queue: queue.Queue = queue.Queue()
        self._ref_lock = threading.Lock()
        self._ref_thumb_cache: Dict[str, ctk.CTkImage] = {}
        self._scene_thumb_cache: Dict[int, ctk.CTkImage] = {}

        _ui6.setup_ui(self)
        self._apply_ref_prompts(silent=True)
        self._apply_manual_prompts(silent=True)
        self.after(150, self._process_ui_queue)

    # ─────────────────────────────────────────────────────────────────────────
    # 1. ĐỒNG BỘ TÀI KHOẢN GOOGLE ULTRA / FLOW
    # ─────────────────────────────────────────────────────────────────────────
    def _load_accounts(self) -> List[Dict[str, Any]]:
        for fname in ("veo_accounts.json", "tool6.json", "tool7.json", "tool5.json", "accounts.json"):
            fpath = os.path.join(SRC_DIR, fname)
            if os.path.isfile(fpath):
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        d = json.load(f)
                    accs = d.get("accounts", []) if isinstance(d, dict) else (d if isinstance(d, list) else [])
                    if accs:
                        return [a for a in accs if isinstance(a, dict) and a.get("token")]
                except Exception:
                    pass
        return []

    def _update_acc_count_label(self):
        accs = self._load_accounts()
        if hasattr(self, "lbl_acc_count") and self.lbl_acc_count.winfo_exists():
            if accs:
                if len(accs) == 1:
                    em = accs[0].get("email") or "Google Ultra"
                    cr = accs[0].get("credits") or "Ultra"
                    self.lbl_acc_count.configure(
                        text=f"🟢 1 TK: {em} ({cr})",
                        text_color=_T.OK,
                    )
                else:
                    self.lbl_acc_count.configure(
                        text=f"🟢 Đã kết nối {len(accs)} Tài khoản (Chế độ Xoay vòng Đa luồng)",
                        text_color=_T.OK,
                    )
            else:
                self.lbl_acc_count.configure(
                    text="🟡 Chưa kết nối TK — Bấm '👥 Quản lý / Thêm TK'",
                    text_color="#fbbf24",
                )
        if hasattr(self, "cbo_account_mode") and self.cbo_account_mode.winfo_exists():
            opts = ["⚡ Xoay vòng tất cả TK (Đa luồng)"]
            for idx, a in enumerate(accs, start=1):
                em = a.get("email") or f"Tài khoản #{idx}"
                opts.append(f"TK #{idx}: {em}")
            for s in (1, 2, 3, 4):
                opts.append(f"➕ Mở thêm TK Ultra #{s}")
            self.cbo_account_mode.configure(values=opts)

    def _on_account_mode_selected(self, choice: str):
        val = str(choice or "").strip()
        try:
            from google_ultra_bridge import get_global_bridge

            bridge = get_global_bridge()
        except Exception:
            bridge = None

        if val.startswith("➕ Mở thêm TK Ultra #"):
            m = re.search(r"#(\d+)", val)
            slot = int(m.group(1)) if m else 2
            if bridge is not None:
                ok, msg = bridge.open_google_ultra_browser(slot=slot)
                self.log(f"🌐 {msg}" if ok else f"❌ {msg}")
            if hasattr(self, "cbo_account_mode"):
                self.cbo_account_mode.set("⚡ Xoay vòng tất cả TK (Đa luồng)")
            if bridge is not None:
                bridge.preferred_account_filter = "ALL"
            return

        if bridge is not None:
            if "Xoay vòng" in val:
                bridge.preferred_account_filter = "ALL"
                self.log("⚡ Chế độ Tài khoản: Xoay vòng tự động tất cả tài khoản (Đa luồng).")
            else:
                bridge.preferred_account_filter = val
                self.log(f"🎯 Chế độ Tài khoản: Ưu tiên chạy trên [{val}] (Hỗ trợ tối đa 4 luồng song song).")

    def open_multi_account_manager(self):
        self.open_account_manager()

    def _get_max_workers(self) -> int:
        try:
            raw = self.entry_thread.get().strip() if hasattr(self, "entry_thread") else "3"
            m = re.search(r"\d+", raw)
            val = int(m.group(0)) if m else 3
            return max(1, min(8, val))
        except Exception:
            return 3

    def _render_account_list(self):
        self._update_acc_count_label()

    def open_account_manager(self):
        top = self.pipeline or self.winfo_toplevel()
        if hasattr(top, "open_shared_veo_accounts"):
            top.open_shared_veo_accounts()

    # ─────────────────────────────────────────────────────────────────────────
    # 2. BƯỚC 1: QUẢN LÝ & PHÂN TÍCH THỰC THỂ THAM CHIẾU (CHAR_01, LOC_01...)
    # ─────────────────────────────────────────────────────────────────────────
    @staticmethod
    def _file_sha256(path: str) -> str:
        if not path or not os.path.isfile(path):
            return ""
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    def _load_saved_ref_cache(self) -> Dict[str, Dict[str, str]]:
        if os.path.isfile(REF_CACHE_FILE):
            try:
                with open(REF_CACHE_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_ref_cache(self):
        cache = self._load_saved_ref_cache()
        for ent in self.ref_entities:
            if ent.get("media_id") and ent.get("image_path") and os.path.isfile(ent["image_path"]):
                f_sha = self._file_sha256(ent["image_path"])
                rec = {
                    "media_id": ent["media_id"],
                    "image_path": ent["image_path"],
                    "file_sha256": f_sha,
                    "desc": ent.get("desc", ""),
                }
                cache[f"{ent['uid']}::{ent['desc'][:80]}"] = rec
                cache[ent["uid"]] = rec
        for t in self.tasks:
            if t.get("image_path") and os.path.isfile(t["image_path"]):
                cache[f"SCENE::{t['id']}::{t['prompt'][:80]}"] = {
                    "media_id": t.get("media_id", ""),
                    "image_path": t["image_path"],
                    "file_sha256": self._file_sha256(t["image_path"]),
                }
        try:
            with open(REF_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(cache, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _parse_ref_line(self, idx: int, line: str) -> Dict[str, Any]:
        import flowkit_engine

        s = line.strip()
        uid = f"CHAR_{idx:02d}"
        desc = s
        if "|" in s[:35]:
            left, right = s.split("|", 1)
            uid = flowkit_engine._normalize_entity_uid(left)
            desc = right.strip()
        elif ":" in s[:25] and re.match(r"^(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*:", s, flags=re.I):
            left, right = s.split(":", 1)
            uid = flowkit_engine._normalize_entity_uid(left)
            desc = right.strip()

        # Nếu bên trong desc có nhúng mã thực sự như (CHAR_03: talking wolf...) thì ưu tiên lấy đúng mã đó
        m_embedded = re.search(r"[\(\[]\s*(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*:\s*([^\)\]]{4,350})[\)\]]", desc, flags=re.I)
        if m_embedded:
            uid = flowkit_engine._normalize_entity_uid(m_embedded.group(1))
            desc = m_embedded.group(2).strip()

        desc = flowkit_engine._clean_entity_desc(desc) or desc
        etype = "LOC" if uid.startswith(("LOC", "BG", "SET", "ENV")) else "CHAR"
        # Giữ nguyên media_id & image_path nếu cùng uid và cùng mô tả đang có sẵn trong bộ nhớ hoặc cache (và file thật khớp SHA-256)
        for old in self.ref_entities:
            if old["uid"] == uid and old["desc"] == desc and old.get("media_id") and os.path.isfile(old.get("image_path", "")):
                return old

        cache = self._load_saved_ref_cache()
        cached = cache.get(f"{uid}::{desc[:80]}")
        if cached and cached.get("media_id") and os.path.isfile(cached.get("image_path", "")):
            cur_sha = self._file_sha256(cached["image_path"])
            if not cached.get("file_sha256") or cached.get("file_sha256") == cur_sha:
                mid = cached["media_id"]
                return {
                    "uid": uid,
                    "type": etype,
                    "desc": desc,
                    "media_id": mid,
                    "image_path": cached["image_path"],
                    "status": f"✅ Đã khóa Ref (Google Flow) · ID: {mid[:18]}…",
                }

        return {
            "uid": uid,
            "type": etype,
            "desc": desc,
            "media_id": "",
            "image_path": "",
            "status": "Chưa tạo ảnh tham chiếu (Bấm nút ① để tạo)",
        }

    def _apply_ref_prompts(self, silent: bool = False):
        import flowkit_engine

        raw = self.txt_ref_prompts.get("1.0", "end").strip()
        lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        # Nếu phát hiện người dùng hoặc hệ thống cũ đẩy nhầm các câu lệnh phân cảnh vào ô Ref (Bước 1),
        # tự động kích hoạt bộ phân tích AI để tách riêng Nhân vật duy nhất (Bước 1) và Phân cảnh (Bước 2)!
        if any(flowkit_engine.is_scene_prompt_line(ln) for ln in lines):
            self.smart_analyze_and_split_prompts(silent=silent)
            return

        parsed_list = [self._parse_ref_line(i, ln) for i, ln in enumerate(lines, start=1)]
        # Khử trùng lặp tuyệt đối theo uid (mỗi CHAR_01, CHAR_02, LOC_01 chỉ xuất hiện đúng 1 lần ở Bước 1)
        dedup_map: Dict[str, Dict[str, Any]] = {}
        for item in parsed_list:
            u = item["uid"]
            if u not in dedup_map:
                dedup_map[u] = item
            else:
                if len(item.get("desc", "")) > len(dedup_map[u].get("desc", "")) and not dedup_map[u].get("media_id"):
                    dedup_map[u] = item

        self.ref_entities = list(dedup_map.values())
        # Cập nhật lại ô text Bước 1 cho gọn sạch nếu trước đó có dòng trùng lặp
        if len(self.ref_entities) < len(lines):
            clean_ref_txt = "\n".join(f"{e['uid']} | {e['desc']}" for e in self.ref_entities)
            self.txt_ref_prompts.delete("1.0", "end")
            self.txt_ref_prompts.insert("1.0", clean_ref_txt)

        self._render_refs()
        if not silent:
            self.log(f"👤 Đã nạp {len(self.ref_entities)} thực thể tham chiếu duy nhất (Nhân vật đa góc & Bối cảnh).")

    def clear_refs_only(self):
        """Xoá trắng ô Prompt Tham Chiếu Gốc (Bước 1) và danh sách thực thể tham chiếu."""
        self.txt_ref_prompts.delete("1.0", "end")
        self.ref_entities.clear()
        self._ref_thumb_cache.clear()
        self._render_refs()
        self.log("🧹 Đã làm sạch danh sách Prompt & Ảnh Tham Chiếu (Bước 1).")

    def clear_scenes_only(self):
        """Xoá trắng ô Prompt Phân Cảnh (Bước 2) và danh sách phân cảnh."""
        self.txt_prompt.delete("1.0", "end")
        self.tasks.clear()
        self._scene_thumb_cache.clear()
        self._render_tasks()
        if hasattr(self, "lbl_summary"):
            self.lbl_summary.configure(text="Đã làm sạch")
        self.log("🧹 Đã làm sạch danh sách Prompt & Ảnh Phân Cảnh (Bước 2).")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ ảnh, prompt, hàng đợi và cache từ lần dùng trước."""
        if self.is_running:
            if ask_confirm:
                messagebox.showwarning("Đang chạy", "Hãy bấm Dừng trước khi làm sạch dữ liệu!")
            return
        if ask_confirm:
            ans = messagebox.askyesnocancel(
                "Làm sạch dữ liệu lần dùng trước",
                "Bạn muốn làm sạch toàn bộ Prompt & Ảnh đã dùng từ lần trước ở tab Image đồng nhất?\n\n"
                "• Chọn YES: Xoá sạch Prompt + Danh sách + Xoá luôn các file ảnh cũ trong Scene_Images\n"
                "• Chọn NO: Chỉ xoá sạch Prompt & Danh sách trên giao diện (giữ lại file ảnh trong ổ đĩa)\n"
                "• Chọn CANCEL: Huỷ bỏ",
            )
            if ans is None:
                return
            delete_files = bool(ans)

        self.txt_ref_prompts.delete("1.0", "end")
        self.txt_prompt.delete("1.0", "end")
        self.ref_entities.clear()
        self.tasks.clear()
        self._ref_thumb_cache.clear()
        self._scene_thumb_cache.clear()

        if os.path.isfile(REF_CACHE_FILE):
            try:
                os.remove(REF_CACHE_FILE)
            except Exception:
                pass

        removed_files = 0
        if delete_files:
            out_dir = self._get_output_dir()
            refs_dir = os.path.join(out_dir, "Refs")
            for folder in (out_dir, refs_dir):
                if os.path.isdir(folder):
                    for fn in os.listdir(folder):
                        if fn.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
                            try:
                                os.remove(os.path.join(folder, fn))
                                removed_files += 1
                            except Exception:
                                pass

        self._render_refs()
        self._render_tasks()
        if hasattr(self, "lbl_summary"):
            self.lbl_summary.configure(text="Sẵn sàng (Đã làm sạch)")
        extra = f" và xoá {removed_files} file ảnh cũ" if delete_files else ""
        self.log(f"🧹 Đã làm sạch toàn bộ Prompt, Ảnh tham chiếu & Phân cảnh cũ{extra}.")

    def add_images(self):
        """Cho phép chọn ảnh nhân vật / bối cảnh có sẵn từ máy và tự động upload lên Google Flow lấy media_id."""
        paths = filedialog.askopenfilenames(
            title="Chọn ảnh nhân vật / bối cảnh mẫu từ máy",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp")],
        )
        if not paths:
            return
        for p in paths:
            ab = os.path.abspath(p)
            stem = Path(p).stem.strip().upper()
            uid = stem if re.match(r"^[A-Z0-9_]+$", stem) else f"CHAR_{len(self.ref_entities)+1:02d}"
            etype = "LOC" if uid.startswith(("LOC", "BG")) else "CHAR"
            ent = {
                "uid": uid,
                "type": etype,
                "desc": f"Ảnh mẫu tải từ máy ({os.path.basename(ab)})",
                "media_id": "",
                "image_path": ab,
                "status": "⏳ Đang upload lên Google Flow lấy media_id...",
            }
            self.ref_entities.append(ent)
            threading.Thread(target=self._upload_existing_ref_file, args=(ent, ab), daemon=True).start()
        self._render_refs()

    def _upload_existing_ref_file(self, ent: Dict[str, Any], file_path: str):
        try:
            from google_ultra_bridge import get_global_bridge

            bridge = get_global_bridge()
            with open(file_path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode("ascii")
            mime = "image/png" if file_path.lower().endswith(".png") else "image/jpeg"
            if bridge is not None:
                mid = bridge.cdp_upload_image(b64, mime_type=mime, file_name=os.path.basename(file_path))
                if mid:
                    ent["media_id"] = mid
                    ent["status"] = f"✅ Đã khóa Ref ID: {mid[:18]}…"
                    self._save_ref_cache()
                    self.ui_queue.put(("refresh_all", None))
                    self.ui_queue.put(("log", f"✅ Đã upload ảnh '{ent['uid']}' -> media_id={mid}"))
                    return
            ent["status"] = "⚠️ Đã nạp ảnh máy (Chưa lấy được media_id từ Google Flow)"
            self.ui_queue.put(("refresh_all", None))
        except Exception as e:
            ent["status"] = f"❌ Lỗi upload: {e}"
            self.ui_queue.put(("refresh_all", None))

    def _replace_ref_with_local_file(self, ent: Dict[str, Any]):
        p = filedialog.askopenfilename(
            title=f"Chọn ảnh từ máy cho {ent['uid']}",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp")],
        )
        if not p:
            return
        ent["image_path"] = os.path.abspath(p)
        ent["status"] = "⏳ Đang upload ảnh lên Google Flow..."
        self._render_refs()
        threading.Thread(target=self._upload_existing_ref_file, args=(ent, ent["image_path"]), daemon=True).start()

    def _render_refs(self):
        for w in self.ref_frame.winfo_children():
            w.destroy()
        self._ref_thumb_cache.clear()

        ready_cnt = sum(1 for r in self.ref_entities if r.get("media_id"))
        self.lbl_ref_summary.configure(
            text=f"Đã khóa {ready_cnt}/{len(self.ref_entities)} ảnh tham chiếu",
            text_color=_T.OK if (self.ref_entities and ready_cnt == len(self.ref_entities)) else "#38bdf8",
        )

        if not self.ref_entities:
            lbl(
                self.ref_frame,
                "Chưa có thực thể tham chiếu — Hãy nhập CHAR_01 | ... hoặc LOC_01 | ... ở ô ① bên trái.",
                _T.MUTED,
                _F.label,
            ).pack(pady=18)
            return

        for idx, ent in enumerate(self.ref_entities):
            uid = ent["uid"]
            st = ent.get("status", "")
            has_mid = bool(ent.get("media_id"))
            bg = _ui6.CARD_DONE if has_mid else _ui6.CARD_IDLE

            item = ctk.CTkFrame(
                self.ref_frame,
                fg_color=bg,
                corner_radius=8,
                border_width=1,
                border_color="#1f6feb" if has_mid else _T.BORDER,
            )
            item.pack(fill="x", padx=4, pady=3)
            item.grid_columnconfigure(1, weight=1)

            # Thumbnail 92x52
            thumb_box = ctk.CTkFrame(item, width=96, height=54, fg_color="#0b1118", corner_radius=6)
            thumb_box.grid(row=0, column=0, rowspan=2, padx=8, pady=6)
            thumb_box.grid_propagate(False)

            img_p = ent.get("image_path") or ""
            if img_p and os.path.isfile(img_p):
                try:
                    pil_im = Image.open(img_p)
                    ctk_im = ctk.CTkImage(light_image=pil_im, dark_image=pil_im, size=(92, 50))
                    self._ref_thumb_cache[uid] = ctk_im
                    ctk.CTkLabel(thumb_box, text="", image=ctk_im).place(relx=0.5, rely=0.5, anchor="center")
                except Exception:
                    ctk.CTkLabel(thumb_box, text=uid, font=_F.ui_sb, text_color="#38bdf8").place(
                        relx=0.5, rely=0.5, anchor="center"
                    )
            else:
                badge_txt = f"👤 {uid}" if ent["type"] == "CHAR" else f"🏛 {uid}"
                ctk.CTkLabel(thumb_box, text=badge_txt, font=_F.ui_sb, text_color="#38bdf8").place(
                    relx=0.5, rely=0.5, anchor="center"
                )

            role_lbl = "Nhân vật (1 Khung Chuẩn Toàn Thân)" if ent["type"] == "CHAR" else "Bối cảnh đồng nhất (Master Location)"
            lbl(
                item,
                f"[{uid} · {role_lbl}]  {ent['desc'][:95]}{'…' if len(ent['desc']) > 95 else ''}",
                _T.TEXT_STRONG,
                _F.ui_sb,
                anchor="w",
            ).grid(row=0, column=1, sticky="ew", padx=4, pady=(6, 1))

            st_col = _T.OK if has_mid else ("#fbbf24" if "⏳" in st else (_T.DANGER_TEXT if "❌" in st else _T.MUTED))
            lbl(item, st, st_col, _F.tiny, anchor="w").grid(row=1, column=1, sticky="ew", padx=4, pady=(0, 6))

            act = row(item)
            act.grid(row=0, column=2, rowspan=2, padx=8, pady=6)
            if img_p and os.path.isfile(img_p):
                sbtn(
                    act,
                    "👁 Xem",
                    lambda p=img_p: os.startfile(p) if os.path.exists(p) else None,
                    width=54,
                ).pack(side="left", padx=(0, 3))
                sbtn(
                    act,
                    "⬆ Up",
                    lambda e_obj=ent, p=img_p: threading.Thread(
                        target=self._upload_existing_ref_file, args=(e_obj, p), daemon=True
                    ).start(),
                    width=46,
                ).pack(side="left", padx=(0, 3))
            sbtn(
                act,
                "✏️ Sửa",
                lambda e_obj=ent: self.on_edit_ref(e_obj),
                width=54,
            ).pack(side="left", padx=(0, 3))
            sbtn(
                act,
                "↻ Tạo Ref",
                lambda e_obj=ent: threading.Thread(target=self._run_single_ref, args=(e_obj, True), daemon=True).start(),
                width=68,
            ).pack(side="left", padx=(0, 3))
            sbtn(
                act,
                "📂 Ảnh máy",
                lambda e_obj=ent: self._replace_ref_with_local_file(e_obj),
                width=70,
            ).pack(side="left")

    def _sync_txt_ref_from_entities(self):
        """Đồng bộ ngược danh sách ref_entities hiện tại về ô văn bản ① (để sửa thủ công không bị ghi đè)."""
        clean_ref_txt = "\n".join(f"{e['uid']} | {e['desc']}" for e in self.ref_entities)
        self.txt_ref_prompts.delete("1.0", "end")
        if clean_ref_txt:
            self.txt_ref_prompts.insert("1.0", clean_ref_txt)

    def _sync_txt_prompt_from_tasks(self):
        """Đồng bộ ngược danh sách tasks hiện tại về ô văn bản ② (để sửa thủ công không bị ghi đè)."""
        lines = []
        for idx, t in enumerate(self.tasks, start=1):
            uids_str = ", ".join(t.get("uids") or ["CHAR_01"])
            p_txt = re.sub(r"^Prompt\s*\d+\s*:\s*", "", str(t.get("prompt") or "").strip(), flags=re.I).strip()
            lines.append(f"{uids_str} | Prompt {idx}: {p_txt}")
        self.txt_prompt.delete("1.0", "end")
        if lines:
            self.txt_prompt.insert("1.0", "\n".join(lines))

    def on_edit_ref(self, ent: Dict[str, Any]):
        """Hộp thoại sửa thủ công mã nhận diện & câu lệnh mô tả Nhân vật / Bối cảnh ở Bước 1."""
        import flowkit_engine
        from ui import dialog as _dlg, btn_primary as _btn_p

        uid_cur = ent.get("uid", "CHAR_01")
        win = _dlg(self, f"✏️ Sửa câu lệnh Ảnh Tham Chiếu [{uid_cur}]", w=660, h=340, grab=True)

        head_r = row(win)
        head_r.pack(fill="x", padx=16, pady=(14, 4))
        lbl(head_r, "Mã nhận diện (CHAR_01 / LOC_01):", _T.TEXT_STRONG, _F.ui_sb).pack(side="left")
        entry_uid = ctk.CTkEntry(head_r, width=140, fg_color=_T.INPUT, border_color=_T.BORDER, text_color=_T.TEXT, font=_F.ui_sb)
        entry_uid.pack(side="left", padx=(8, 0))
        entry_uid.insert(0, uid_cur)

        lbl(win, "Mô tả ngoại hình Nhân vật / Bối cảnh chuẩn (1 khung hình đơn):", _T.MUTED, _F.tiny, anchor="w").pack(
            fill="x", padx=16, pady=(4, 2)
        )
        txt = ctk.CTkTextbox(
            win, height=160, wrap="word", fg_color=_T.INPUT, border_color=_T.BORDER, border_width=1, text_color=_T.TEXT, font=_F.ui
        )
        txt.pack(fill="both", expand=True, padx=16, pady=(0, 10))
        txt.insert("1.0", ent.get("desc", ""))

        def _apply_save(run_now: bool = False):
            new_uid = flowkit_engine._normalize_entity_uid(entry_uid.get().strip() or uid_cur)
            new_desc = txt.get("1.0", "end").strip()
            if new_desc:
                if new_desc != ent.get("desc") or new_uid != ent.get("uid"):
                    ent["uid"] = new_uid
                    ent["type"] = "LOC" if new_uid.startswith("LOC") else "CHAR"
                    ent["desc"] = new_desc
                    if run_now:
                        ent["media_id"] = ""
                self._sync_txt_ref_from_entities()
                self._render_refs()
                self.log(f"✏️ Đã cập nhật thủ công prompt tham chiếu [{new_uid}].")
                if run_now:
                    threading.Thread(target=self._run_single_ref, args=(ent, True), daemon=True).start()
            win.destroy()

        bar = row(win)
        bar.pack(fill="x", padx=16, pady=(0, 14))
        _btn_p(bar, "▶ Lưu & Tạo lại Ref ngay", lambda: _apply_save(True), width=176).pack(side="right", padx=(6, 0))
        sbtn(bar, "💾 Lưu thay đổi", lambda: _apply_save(False), width=124).pack(side="right", padx=(6, 0))
        sbtn(bar, "Huỷ", win.destroy, width=76).pack(side="right")

    # ─────────────────────────────────────────────────────────────────────────
    # 3. BƯỚC 2: QUẢN LÝ DANH SÁCH PHÂN CẢNH (SCENE PROMPTS)
    # ─────────────────────────────────────────────────────────────────────────
    def _parse_scene_line(self, idx: int, line: str, video_line: str = "") -> Dict[str, Any]:
        import flowkit_engine

        s = re.sub(r"^Prompt\s*\d+\s*:\s*", "", line.strip(), flags=re.IGNORECASE).strip()
        uids = []
        if "|" in s[:45]:
            left, right = s.split("|", 1)
            uids = [flowkit_engine._normalize_entity_uid(u.strip()) for u in re.split(r"[,+&]", left) if u.strip()]
            s = right.strip()
        else:
            found = re.findall(r"\b(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\b", s, flags=re.IGNORECASE)
            if found:
                uids = list(dict.fromkeys(flowkit_engine._normalize_entity_uid(u) for u in found))
        if not uids:
            uids = [r["uid"] for r in self.ref_entities] if self.ref_entities else ["CHAR_01"]

        s = re.sub(r"^(?:Prompt|Scene|Cảnh)\s*\d+\s*:\s*", "", s, flags=re.IGNORECASE).strip()

        # Xác định bản Video Prompt (Chuyển động 8s) và bản Image Prompt (1 Khung Hình Đơn)
        raw_vid = (video_line or "").strip()
        if raw_vid and "|" in raw_vid[:45]:
            _, raw_vid = raw_vid.split("|", 1)
        raw_vid = re.sub(r"^(?:Prompt|Scene|Cảnh)\s*\d+\s*:\s*", "", raw_vid, flags=re.IGNORECASE).strip()
        video_prompt = raw_vid if raw_vid else flowkit_engine.to_video_motion_prompt(s)

        # Nếu câu lệnh s vẫn đang ở dạng 3 nhịp 0-3s / 3-6s / 6-8s, tự động chuyển sang chuẩn 1 Khung Hình Đơn cho Tạo Ảnh!
        if re.search(r"\b(?:0-3s|3-6s|6-8s|Audio\s*:)\b", s, flags=re.I):
            img_prompt = flowkit_engine.to_single_frame_image_prompt(s)
        else:
            img_prompt = s

        # Giữ nguyên trạng thái của task cũ nếu người dùng vừa sửa hoặc đã tạo xong
        for old_t in self.tasks:
            if old_t.get("id") == idx and old_t.get("prompt") == img_prompt and old_t.get("image_path") and os.path.isfile(old_t["image_path"]):
                old_t["uids"] = uids
                if not old_t.get("video_prompt"):
                    old_t["video_prompt"] = video_prompt
                return old_t

        cache = self._load_saved_ref_cache()
        cached_scene = cache.get(f"SCENE::{idx}::{img_prompt[:80]}")
        if cached_scene and os.path.isfile(cached_scene.get("image_path", "")):
            ip = cached_scene["image_path"]
            cur_sha = self._file_sha256(ip)
            if not cached_scene.get("file_sha256") or cached_scene.get("file_sha256") == cur_sha:
                return {
                    "id": idx,
                    "uids": uids,
                    "prompt": img_prompt,
                    "video_prompt": video_prompt,
                    "status": f"✅ Hoàn thành (Google Flow · {len(uids)} Ref) → {os.path.basename(ip)}",
                    "image_path": ip,
                    "media_id": cached_scene.get("media_id", ""),
                    "seed": 202600 + idx * 131,
                }

        return {
            "id": idx,
            "uids": uids,
            "prompt": img_prompt,
            "video_prompt": video_prompt,
            "status": "Chờ tạo (Sẽ tự gắn ảnh tham chiếu từ Bước 1)",
            "image_path": "",
            "media_id": "",
            "seed": 202600 + idx * 131,
        }

    def receive_pushed_prompts(
        self,
        prompts_list: List[str],
        ref_lines: Optional[List[str]] = None,
        character_bible_text: str = "",
    ) -> Dict[str, Any]:
        """
        Điểm nhận kịch bản được đẩy từ tab '📝 Prompt' hoặc '🔍 Video to prompt':
        Tự động đọc toàn bộ câu lệnh, nhận diện có bao nhiêu Nhân vật / Bối cảnh duy nhất
        để đưa vào Bước 1 (Ô ① — Ảnh Tham Chiếu), và nạp danh sách từng phân cảnh (1 Khung Hình Đơn) vào Bước 2 (Ô ②).
        """
        import flowkit_engine

        analysis = flowkit_engine.analyze_prompts_and_extract_entities(
            raw_lines_or_text=prompts_list,
            character_bible_text=character_bible_text,
            existing_ref_lines=ref_lines,
        )
        final_refs = analysis["ref_lines"]
        final_scenes = analysis["scene_lines"]
        final_video_scenes = analysis.get("video_scene_lines") or final_scenes

        self.txt_ref_prompts.delete("1.0", "end")
        if final_refs:
            self.txt_ref_prompts.insert("1.0", "\n".join(final_refs))
        self.txt_prompt.delete("1.0", "end")
        if final_scenes:
            self.txt_prompt.insert("1.0", "\n".join(final_scenes))

        self.ref_entities = [self._parse_ref_line(i, ln) for i, ln in enumerate(final_refs, start=1)]
        self._render_refs()
        self.tasks = [
            self._parse_scene_line(
                i,
                ln,
                video_line=final_video_scenes[i - 1] if (i - 1) < len(final_video_scenes) else "",
            )
            for i, ln in enumerate(final_scenes, start=1)
        ]
        self._render_tasks()
        if hasattr(self, "lbl_summary"):
            self.lbl_summary.configure(text=f"Phân cảnh: 0/{len(self.tasks)}")
        self.log(
            f"🧠 AI đã phân tích kịch bản: Nhận diện {analysis['num_chars']} nhân vật & {analysis['num_locs']} bối cảnh duy nhất (Bước 1) cho {analysis['num_scenes']} phân cảnh ảnh đơn 1 khung (Bước 2)."
        )
        return analysis

    @staticmethod
    def _is_default_steampunk_sample(line: str) -> bool:
        low = line.lower()
        sample_markers = (
            "sky-mechanic with messy silver-white hair",
            "floating steampunk sky-city with giant brass airships",
            "floating steampunk sky-dock at sunrise",
            "small bronze dragon's chest with a brass wrench",
            "small bronze dragon's eyes ignite with bright cyan light",
            "wooden sky-bridge as storm clouds gather",
            "sleek brass sky-glider through a canyon of floating rock islands",
        )
        return any(m in low for m in sample_markers)

    def smart_analyze_and_split_prompts(self, silent: bool = False) -> Dict[str, Any]:
        """
        Đọc toàn bộ nội dung đang có ở cả ô ① và ô ②, tự động bóc tách danh sách Nhân vật / Bối cảnh
        duy nhất (khử trùng lặp 100%) lên ô ① và đưa đầy đủ 100% các câu lệnh phân cảnh xuống ô ②.
        """
        import flowkit_engine

        raw_ref_txt = self.txt_ref_prompts.get("1.0", "end").strip()
        raw_scn_txt = self.txt_prompt.get("1.0", "end").strip()
        ref_lines_cur = [ln.strip() for ln in raw_ref_txt.splitlines() if ln.strip()]
        scn_lines_cur = [ln.strip() for ln in raw_scn_txt.splitlines() if ln.strip()]

        # Nếu người dùng dán kịch bản mới vào ô ① trong khi ô ② vẫn đang là 5 cảnh mẫu steampunk mặc định,
        # tự động bỏ 5 cảnh mẫu mặc định để lấy đúng 100% kịch bản mới của người dùng
        has_user_scenes_in_ref = any(
            flowkit_engine.is_scene_prompt_line(ln) and not self._is_default_steampunk_sample(ln)
            for ln in ref_lines_cur
        )
        if has_user_scenes_in_ref and all(self._is_default_steampunk_sample(ln) for ln in scn_lines_cur):
            scn_lines_cur = []

        # Nếu trong kịch bản của người dùng đã có nội dung mới (không phải mẫu steampunk mặc định),
        # loại bỏ 2 dòng mẫu mặc định (sky-mechanic & steampunk sky-city) khỏi ô ① để không bị trộn lẫn
        has_custom_content = has_user_scenes_in_ref or any(
            not self._is_default_steampunk_sample(ln) for ln in scn_lines_cur
        )
        keep_existing_refs = []
        for rln in ref_lines_cur:
            if has_custom_content and self._is_default_steampunk_sample(rln):
                continue
            keep_existing_refs.append(rln)

        analysis = flowkit_engine.analyze_prompts_and_extract_entities(
            raw_lines_or_text=scn_lines_cur,
            existing_ref_lines=keep_existing_refs,
        )
        final_refs = analysis["ref_lines"]
        final_scenes = analysis["scene_lines"]
        final_video_scenes = analysis.get("video_scene_lines") or final_scenes

        if final_refs:
            self.txt_ref_prompts.delete("1.0", "end")
            self.txt_ref_prompts.insert("1.0", "\n".join(final_refs))
        if final_scenes:
            self.txt_prompt.delete("1.0", "end")
            self.txt_prompt.insert("1.0", "\n".join(final_scenes))

        self.ref_entities = [self._parse_ref_line(i, ln) for i, ln in enumerate(final_refs, start=1)]
        self._render_refs()
        self.tasks = [
            self._parse_scene_line(
                i,
                ln,
                video_line=final_video_scenes[i - 1] if (i - 1) < len(final_video_scenes) else "",
            )
            for i, ln in enumerate(final_scenes, start=1)
        ]
        self._render_tasks()
        if hasattr(self, "lbl_summary"):
            self.lbl_summary.configure(text=f"Phân cảnh: 0/{len(self.tasks)}")
        if not silent:
            self.log(
                f"🧠 Đã đọc & phân tích Prompt: Tách {analysis['num_chars']} nhân vật + {analysis['num_locs']} bối cảnh duy nhất (Bước 1) và {analysis['num_scenes']} phân cảnh ảnh 1 khung (Bước 2)."
            )
        return analysis

    def _apply_manual_prompts(self, silent: bool = False):
        """
        Phân tích thông minh khi người dùng nạp/dán câu lệnh vào ô Phân cảnh (Bước 2):
        Tự động nhận diện có bao nhiêu nhân vật/bối cảnh duy nhất cần tạo ảnh tham chiếu ở Bước 1,
        khử trùng lặp hoàn toàn và giữ nguyên danh sách phân cảnh ở Bước 2.
        """
        import flowkit_engine

        raw = self.txt_prompt.get("1.0", "end").strip()
        raw_lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        if not raw_lines:
            self.tasks = []
            self._render_tasks()
            return

        # Kiểm tra xem trong danh sách câu lệnh có dòng định nghĩa CHAR_XX riêng hoặc có nhúng (CHAR_XX: ...) không
        has_embedded_or_ref_defs = any(
            (
                re.match(r"^(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*[\|:]", ln, flags=re.I)
                and not flowkit_engine.is_scene_prompt_line(ln)
            )
            or re.search(r"[\(\[]\s*(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\s*:", ln, flags=re.I)
            for ln in raw_lines
        )

        if has_embedded_or_ref_defs:
            self.smart_analyze_and_split_prompts(silent=silent)
            return

        self.tasks = [self._parse_scene_line(i, ln) for i, ln in enumerate(raw_lines, start=1)]
        self._render_tasks()
        if not silent:
            self.log(
                f"📋 Đã nạp {len(self.ref_entities)} thực thể Tham chiếu (Bước 1) và {len(self.tasks)} Phân cảnh (Bước 2)."
            )

    def choose_file(self):
        fpath = filedialog.askopenfilename(
            title="Chọn file kịch bản phân cảnh",
            filetypes=[("Text / JSON Files", "*.txt *.json"), ("All Files", "*.*")],
        )
        if not fpath:
            return
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read().strip()
            self.txt_prompt.delete("1.0", "end")
            self.txt_prompt.insert("1.0", content)
            self._apply_manual_prompts()
        except Exception as e:
            messagebox.showerror("Lỗi đọc file", str(e))

    def choose_output_folder(self):
        d = filedialog.askdirectory(title="Chọn thư mục lưu ảnh")
        if d:
            self.entry_out.delete(0, "end")
            self.entry_out.insert(0, d)

    def _get_output_dir(self) -> str:
        raw = self.entry_out.get().strip() or "Scene_Images"
        out = raw if os.path.isabs(raw) else os.path.join(SRC_DIR, raw)
        os.makedirs(out, exist_ok=True)
        return out

    def open_output_folder(self):
        out = self._get_output_dir()
        try:
            os.startfile(out)
        except Exception:
            pass

    def _render_tasks(self):
        for w in self.task_frame.winfo_children():
            w.destroy()
        self._scene_thumb_cache.clear()

        if not self.tasks:
            lbl(
                self.task_frame,
                "Chưa có phân cảnh nào — Hãy nhập danh sách Scene ở ô ② bên trái.",
                _T.MUTED,
                _F.ui,
            ).pack(pady=28)
            return

        for t in self.tasks:
            tid = t["id"]
            st = t["status"]
            bg = _ui6.CARD_DONE if "✅" in st else _ui6.CARD_IDLE
            item = ctk.CTkFrame(
                self.task_frame,
                fg_color=bg,
                corner_radius=8,
                border_width=1,
                border_color=_T.BORDER,
            )
            item.pack(fill="x", padx=4, pady=3)
            item.grid_columnconfigure(1, weight=1)

            thumb_holder = ctk.CTkFrame(item, width=96, height=54, fg_color="#0d131a", corner_radius=6)
            thumb_holder.grid(row=0, column=0, rowspan=2, padx=8, pady=6)
            thumb_holder.grid_propagate(False)

            img_path = t.get("image_path") or ""
            if img_path and os.path.isfile(img_path):
                try:
                    pil_im = Image.open(img_path)
                    ctk_im = ctk.CTkImage(light_image=pil_im, dark_image=pil_im, size=(92, 50))
                    self._scene_thumb_cache[tid] = ctk_im
                    ctk.CTkLabel(thumb_holder, text="", image=ctk_im).place(relx=0.5, rely=0.5, anchor="center")
                except Exception:
                    ctk.CTkLabel(thumb_holder, text=f"Cảnh {tid:02d}", font=_F.ui_sb, text_color=_T.ACCENT).place(
                        relx=0.5, rely=0.5, anchor="center"
                    )
            else:
                ctk.CTkLabel(thumb_holder, text=f"Cảnh {tid:02d}", font=_F.ui_sb, text_color=_T.ACCENT).place(
                    relx=0.5, rely=0.5, anchor="center"
                )

            uid_badge = " + ".join(t.get("uids") or ["CHAR_01"])
            lbl(
                item,
                f"🔗 Ref: [{uid_badge}]  |  {t['prompt'][:105]}{'…' if len(t['prompt']) > 105 else ''}",
                _T.TEXT_STRONG,
                _F.ui_sb,
                anchor="w",
            ).grid(row=0, column=1, sticky="ew", padx=4, pady=(6, 1))

            st_col = _T.OK if "✅" in st else ("#fbbf24" if "⏳" in st else (_T.DANGER_TEXT if "❌" in st else _T.MUTED))
            lbl(item, f"Trạng thái: {st}", st_col, _F.tiny, anchor="w").grid(
                row=1, column=1, sticky="ew", padx=4, pady=(0, 6)
            )

            act = row(item)
            act.grid(row=0, column=2, rowspan=2, padx=8, pady=6)
            if img_path and os.path.isfile(img_path):
                sbtn(
                    act,
                    "👁 Xem ảnh",
                    lambda p=img_path: os.startfile(p) if os.path.exists(p) else None,
                    width=76,
                ).pack(side="left", padx=(0, 3))
            sbtn(
                act,
                "✏️ Sửa",
                lambda task_obj=t: self.on_edit_task(task_obj),
                width=56,
            ).pack(side="left", padx=(0, 3))
            sbtn(
                act,
                "↻ Tạo lại",
                lambda task_obj=t: threading.Thread(target=self._run_single_task, args=(task_obj,), daemon=True).start(),
                width=70,
            ).pack(side="left")

    def on_edit_task(self, task: Dict[str, Any]):
        """Hộp thoại sửa thủ công câu lệnh Tạo Ảnh Phân Cảnh (1 Khung Hình Đơn) & Video Prompt của từng cảnh."""
        import flowkit_engine
        from ui import dialog as _dlg, btn_primary as _btn_p

        tid = task["id"]
        win = _dlg(self, f"✏️ Sửa thủ công Phân cảnh #{tid:02d}", w=720, h=430, grab=True)

        head_r = row(win)
        head_r.pack(fill="x", padx=16, pady=(14, 4))
        lbl(head_r, "Mã Nhân vật / Bối cảnh gắn vào cảnh:", _T.TEXT_STRONG, _F.ui_sb).pack(side="left")
        entry_uids = ctk.CTkEntry(
            head_r, width=240, fg_color=_T.INPUT, border_color=_T.BORDER, text_color=_T.TEXT, font=_F.ui_sb
        )
        entry_uids.pack(side="left", padx=(8, 0))
        entry_uids.insert(0, ", ".join(task.get("uids") or ["CHAR_01"]))

        lbl(
            win,
            "🎨 Prompt Tạo Ảnh Phân Cảnh (Chuẩn 1 Khung Hình Đơn — Không chia 4 góc):",
            "#38bdf8",
            _F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=16, pady=(6, 2))
        txt_img = ctk.CTkTextbox(
            win, height=130, wrap="word", fg_color=_T.INPUT, border_color=_T.BORDER, border_width=1, text_color=_T.TEXT, font=_F.ui
        )
        txt_img.pack(fill="x", padx=16, pady=(0, 6))
        txt_img.insert("1.0", task.get("prompt", ""))

        lbl(
            win,
            "🎬 Prompt Tạo Video 8s (Dùng khi đẩy cảnh này sang Video đồng nhất / Video Muse / Image to video):",
            "#a78bfa",
            _F.ui_sb,
            anchor="w",
        ).pack(fill="x", padx=16, pady=(2, 2))
        txt_vid = ctk.CTkTextbox(
            win, height=110, wrap="word", fg_color=_T.INPUT, border_color=_T.BORDER, border_width=1, text_color=_T.TEXT, font=_F.ui
        )
        txt_vid.pack(fill="both", expand=True, padx=16, pady=(0, 10))
        txt_vid.insert("1.0", task.get("video_prompt") or flowkit_engine.to_video_motion_prompt(task.get("prompt", "")))

        def _apply_save(run_now: bool = False):
            raw_u = entry_uids.get().strip()
            new_uids = [flowkit_engine._normalize_entity_uid(u.strip()) for u in re.split(r"[,+&]", raw_u) if u.strip()]
            if not new_uids:
                new_uids = ["CHAR_01"]
            new_img_p = txt_img.get("1.0", "end").strip()
            new_vid_p = txt_vid.get("1.0", "end").strip()
            if new_img_p:
                task["uids"] = new_uids
                task["prompt"] = new_img_p
                task["video_prompt"] = new_vid_p or flowkit_engine.to_video_motion_prompt(new_img_p)
                task["_manual_edited"] = True
                self._sync_txt_prompt_from_tasks()
                self._render_tasks()
                self.log(f"✏️ Đã cập nhật thủ công câu lệnh Phân cảnh #{tid:02d}.")
                if run_now:
                    threading.Thread(target=self._run_single_task, args=(task,), daemon=True).start()
            win.destroy()

        bar = row(win)
        bar.pack(fill="x", padx=16, pady=(0, 14))
        _btn_p(bar, "▶ Lưu & Tạo lại Ảnh ngay", lambda: _apply_save(True), width=184).pack(side="right", padx=(6, 0))
        sbtn(bar, "💾 Lưu thay đổi", lambda: _apply_save(False), width=124).pack(side="right", padx=(6, 0))
        sbtn(bar, "Huỷ", win.destroy, width=76).pack(side="right")

    # ─────────────────────────────────────────────────────────────────────────
    # 4. ENGINE THỰC THI LUỒNG 2 BƯỚC TRÊN GOOGLE FLOW (RPC ogiZ0b)
    # ─────────────────────────────────────────────────────────────────────────
    def start_generate_refs(self):
        """Bước ①: Chỉ tạo loạt ảnh Tham Chiếu (Nhân vật 1 khung chuẩn & Bối cảnh đồng nhất)."""
        if self.is_running:
            return
        self._apply_ref_prompts(silent=True)
        if not self.ref_entities:
            messagebox.showwarning("Chưa có thực thể", "Hãy nhập CHAR_01 | ... hoặc LOC_01 | ... vào ô ① trước!")
            return
        self.is_running = True
        self.stop_requested = False
        self._set_buttons_running("refs")
        threading.Thread(target=self._worker_refs_only, daemon=True).start()

    def start_process(self):
        """Bước ②: Tạo ảnh cho từng phân cảnh (Tự động tạo Ref ở Bước 1 nếu Ref nào chưa có media_id)."""
        if self.is_running:
            return
        self._apply_ref_prompts(silent=True)
        self._apply_manual_prompts(silent=True)
        if not self.tasks:
            messagebox.showwarning("Chưa có phân cảnh", "Hãy nhập danh sách phân cảnh vào ô ② trước!")
            return
        self.is_running = True
        self.stop_requested = False
        self._set_buttons_running("scenes")
        threading.Thread(target=self._worker_scenes_flow, args=(False,), daemon=True).start()

    def start_full_flow(self):
        """Chạy trọn bộ: Bước ① Tạo toàn bộ Ảnh Tham Chiếu ➔ Bước ② Tạo toàn bộ Ảnh Phân Cảnh."""
        if self.is_running:
            return
        self._apply_ref_prompts(silent=True)
        self._apply_manual_prompts(silent=True)
        if not self.tasks:
            messagebox.showwarning("Chưa có phân cảnh", "Hãy nhập danh sách phân cảnh vào ô ② trước!")
            return
        self.is_running = True
        self.stop_requested = False
        self._set_buttons_running("full")
        threading.Thread(target=self._worker_scenes_flow, args=(True,), daemon=True).start()

    def stop_process(self):
        self.stop_requested = True
        self.log("⏹ Đã yêu cầu dừng tiến trình.")

    def _set_buttons_running(self, mode: str):
        self.btn_gen_refs.configure(
            state="disabled",
            text="⏳ Đang tạo Ảnh Tham Chiếu..." if mode == "refs" else "① Tạo Ảnh Tham Chiếu (Nhân vật/Bối cảnh)",
        )
        self.btn_start.configure(
            state="disabled",
            text="⏳ Đang tạo Ảnh Phân Cảnh..." if mode == "scenes" else "② Tạo Ảnh Từng Phân Cảnh (Theo Ref)",
        )
        self.btn_full_flow.configure(
            state="disabled",
            text="⏳ Đang chạy Flow ① ➔ ②..." if mode == "full" else "⚡ Chạy Trọn Bộ (① ➔ ②)",
        )
        self.btn_stop.configure(state="normal")

    def _worker_refs_only(self):
        max_workers = self._get_max_workers()
        self.ui_queue.put(
            (
                "log",
                f"👤 [BƯỚC 1] Bắt đầu tạo {len(self.ref_entities)} ảnh tham chiếu gốc (Đa luồng: {max_workers} luồng song song)...",
            )
        )
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(self._run_single_ref, ent, True) for ent in self.ref_entities]
            for f in futures:
                if self.stop_requested:
                    break
                try:
                    f.result()
                except Exception as e:
                    self.ui_queue.put(("log", f"❌ Lỗi luồng tạo Ref: {e}"))
        self.is_running = False
        self.ui_queue.put(("done_all", None))

    def _worker_scenes_flow(self, force_regen_refs: bool = False):
        max_workers = self._get_max_workers()
        # GIAI ĐOẠN 1: Đảm bảo toàn bộ ảnh tham chiếu (CHAR_*, LOC_*) đã được tạo & có media_id trên Google Flow
        missing_refs = [
            e
            for e in self.ref_entities
            if force_regen_refs or not e.get("media_id") or not os.path.isfile(e.get("image_path", ""))
        ]
        if missing_refs:
            self.ui_queue.put(
                (
                    "log",
                    f"👤 [BƯỚC 1/2] Tạo {len(missing_refs)} ảnh tham chiếu gốc (Đa luồng: {max_workers} luồng) trước khi vào phân cảnh...",
                )
            )
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = [pool.submit(self._run_single_ref, ent, force_regen_refs) for ent in missing_refs]
                for f in futures:
                    if self.stop_requested:
                        break
                    try:
                        f.result()
                    except Exception as e:
                        self.ui_queue.put(("log", f"❌ Lỗi luồng tạo Ref: {e}"))

        if self.stop_requested:
            self.is_running = False
            self.ui_queue.put(("done_all", None))
            return

        # GIAI ĐOẠN 2: Tạo ảnh cho từng phân cảnh với ref_media_ids đã khóa ở Bước 1
        self.ui_queue.put(
            (
                "log",
                f"🎨 [BƯỚC 2/2] Bắt đầu tạo {len(self.tasks)} ảnh phân cảnh đồng nhất (gắn Ref ID từ Bước 1, số luồng={max_workers})...",
            )
        )
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(self._run_single_task, t) for t in self.tasks]
            for f in futures:
                if self.stop_requested:
                    break
                try:
                    f.result()
                except Exception as e:
                    self.ui_queue.put(("log", f"❌ Lỗi luồng phân cảnh: {e}"))

        self.is_running = False
        self.ui_queue.put(("done_all", None))

    def _build_ref_entity_prompt(self, ent: Dict[str, Any]) -> str:
        """
        Tạo prompt chuẩn để sinh Ảnh Tham Chiếu Nhân Vật Toàn Thân 1 Khung Hình Duy Nhất
        (tuyệt đối không tạo 4 góc turnaround gây chia 4 khung tranh ở cả Bước 1 lẫn Bước 2)
        hoặc Ảnh Bối Cảnh Đồng Nhất.
        """
        import flowkit_engine

        desc = ent["desc"].strip()
        all_scenes_txt = " ".join(t.get("prompt", "") for t in self.tasks[:3])
        style, _ = flowkit_engine.resolve_effective_style(
            f"{desc} {all_scenes_txt}",
            self.cbo_style.get().strip(),
        )
        if (ent.get("type") or ent.get("kind") or "CHAR") == "CHAR":
            return (
                f"[{style}] Single full-body standing character reference portrait of {desc}. "
                f"Clear 3/4 front-facing view showing exact facial features, hairstyle, and complete outfit from head to toe "
                f"on a clean neutral studio background. ONE single character only in a single unified undivided camera frame, "
                f"solo subject centered, masterpiece 8k, clean frame."
            )
        else:
            return (
                f"[{style}] Master environment concept reference plate: {desc}. "
                f"Single wide establishing architectural and atmospheric view showing key landmarks, "
                f"locked color palette and volumetric lighting, empty environment without people, "
                f"single unified undivided frame, 8k ultra-detailed environment plate."
            )

    def _run_single_ref(self, ent: Dict[str, Any], force_regen: bool = False) -> bool:
        """Sinh ảnh tham chiếu cho 1 Nhân vật hoặc 1 Bối cảnh gốc trên Google Flow (ogiZ0b) — Hỗ trợ Đa Luồng."""
        if self.stop_requested:
            return False
        if not force_regen and ent.get("media_id") and os.path.isfile(ent.get("image_path", "")):
            return True

        uid = ent["uid"]
        ent["status"] = "⏳ Đang tạo ảnh tham chiếu trên Google Flow..."
        self.ui_queue.put(("refresh_all", None))

        refs_dir = os.path.join(self._get_output_dir(), "Refs")
        os.makedirs(refs_dir, exist_ok=True)
        out_path = os.path.join(refs_dir, f"REF_{uid}.jpg")

        prompt = self._build_ref_entity_prompt(ent)
        ratio_str = self.cbo_ratio.get()
        model_choice = self.cbo_model.get()
        seed_val = 777000 + abs(hash(uid)) % 10000

        ok, media_id, msg = self._generate_via_flow_or_gemini(
            prompt=prompt,
            ratio_str=ratio_str,
            model_choice=model_choice,
            seed=seed_val,
            ref_media_ids=None,
            out_path=out_path,
        )
        if ok and os.path.isfile(out_path):
            ent["image_path"] = out_path
            ent["media_id"] = media_id or f"local_{uid}"
            ent["status"] = f"✅ Đã khóa Ref ({msg}) · ID: {ent['media_id'][:18]}…"
            with self._ref_lock:
                self._save_ref_cache()
            self.ui_queue.put(
                ("log", f"✅ [BƯỚC 1] Đã tạo ảnh tham chiếu {uid} -> {os.path.basename(out_path)} (ID: {ent['media_id'][:16]}…)")
            )
            self.ui_queue.put(("refresh_all", None))
            return True
        else:
            ent["status"] = f"❌ Lỗi tạo Ref: {msg}"
            self.ui_queue.put(("log", f"❌ [BƯỚC 1] Lỗi tạo ảnh tham chiếu {uid}: {msg}"))
            self.ui_queue.put(("refresh_all", None))
            return False

    def _run_single_task(self, task: Dict[str, Any]):
        """Bước 2: Tạo ảnh cho 1 phân cảnh (1 Khung Hình Đơn), truyền media_id của Nhân vật & Bối cảnh từ Bước 1 vào ogiZ0b."""
        if self.stop_requested:
            return
        tid = task["id"]
        task["status"] = "⏳ Đang kiểm tra ảnh tham chiếu..."
        self.ui_queue.put(("refresh_all", None))

        # Thu thập media_id và mô tả của các thực thể tham chiếu gắn với cảnh này
        bound_media_ids: List[str] = []
        bound_descs: List[str] = []
        for u in task.get("uids") or []:
            matched_ent = next((e for e in self.ref_entities if e["uid"].upper() == u.upper()), None)
            if matched_ent is not None:
                if not matched_ent.get("media_id"):
                    self._run_single_ref(matched_ent, force_regen=False)
                if matched_ent.get("media_id") and not matched_ent["media_id"].startswith("local_"):
                    bound_media_ids.append(matched_ent["media_id"])
                bound_descs.append(f"[{matched_ent['uid']}: {matched_ent['desc']}]")

        # Nếu cảnh không ghi rõ mã hoặc chưa khớp, mặc định gắn toàn bộ Ref đã có ở Bước 1
        if not bound_media_ids:
            for e in self.ref_entities:
                if e.get("media_id") and not e["media_id"].startswith("local_"):
                    bound_media_ids.append(e["media_id"])
                if not bound_descs:
                    bound_descs.append(f"[{e['uid']}: {e['desc']}]")

        import flowkit_engine

        single_frame_body = flowkit_engine.to_single_frame_image_prompt(task.get("prompt", ""))
        style, _ = flowkit_engine.resolve_effective_style(
            f"{single_frame_body} {' '.join(bound_descs)}",
            self.cbo_style.get().strip(),
        )
        scene_prompt = (
            f"[{style}] {' '.join(bound_descs)} "
            f"{single_frame_body} "
            f"Maintain exact character face, hair, outfit and environment from the reference images. "
            f"Single unified full-frame cinematic still shot (one continuous undivided camera frame only, seamless widescreen composition), "
            f"cinematic lighting, 8k masterpiece."
        )

        out_dir = self._get_output_dir()
        out_path = os.path.join(out_dir, f"Scene_{tid:03d}.jpg")
        ratio_str = self.cbo_ratio.get()
        model_choice = self.cbo_model.get()

        task["status"] = f"⏳ Đang tạo ảnh phân cảnh (Gắn {len(bound_media_ids)} Ref ID)..."
        self.ui_queue.put(("refresh_all", None))

        ok, media_id, msg = self._generate_via_flow_or_gemini(
            prompt=scene_prompt,
            ratio_str=ratio_str,
            model_choice=model_choice,
            seed=task.get("seed", 202600 + tid),
            ref_media_ids=bound_media_ids or None,
            out_path=out_path,
        )

        if ok and os.path.isfile(out_path):
            task["image_path"] = out_path
            task["media_id"] = media_id
            task["status"] = f"✅ Hoàn thành ({msg} · {len(bound_media_ids)} Ref) → {os.path.basename(out_path)}"
            self._save_ref_cache()
            self.ui_queue.put(
                ("log", f"✅ [BƯỚC 2] Cảnh {tid:02d}: Đã tạo {os.path.basename(out_path)} (Gắn {len(bound_media_ids)} Ref ID)")
            )
        else:
            task["status"] = f"❌ Thất bại: {msg}"
            self.ui_queue.put(("log", f"❌ [BƯỚC 2] Cảnh {tid:02d} lỗi: {msg}"))

        self.ui_queue.put(("refresh_all", None))

    def _generate_via_flow_or_gemini(
        self,
        prompt: str,
        ratio_str: str,
        model_choice: str,
        seed: int,
        ref_media_ids: Optional[List[str]],
        out_path: str,
    ) -> tuple[bool, str, str]:
        """Gọi trực tiếp Google Flow `ogiZ0b` qua GoogleUltraBridge CDP (hoặc Gemini Imagen 3 nếu có key)."""
        wire_model = (
            "NARWHAL"
            if "NARWHAL" in model_choice
            else ("HARBOR_SEAL" if "HARBOR_SEAL" in model_choice else "GEM_PIX_2")
        )
        # 1. Gọi trực tiếp Google Flow ogiZ0b qua Chrome CDP (tài khoản Google Ultra đang đăng nhập)
        import flowkit_engine

        safe_prompt = flowkit_engine.sanitize_prompt_for_google_flow(prompt, aggressive=False)
        try:
            from google_ultra_bridge import get_global_bridge, init_global_bridge

            bridge = get_global_bridge() or init_global_bridge(SRC_DIR)
            if bridge is not None:
                ok_cdp, mid, label_or_err = bridge.cdp_generate_image(
                    prompt=safe_prompt,
                    model_key=wire_model,
                    aspect_ratio=ratio_str,
                    seed=seed,
                    ref_media_ids=ref_media_ids,
                    save_path=out_path,
                )
                if ok_cdp and os.path.isfile(out_path):
                    return True, mid, label_or_err

                # Nếu gặp lỗi bộ lọc an toàn (UNSAFE / MINOR) hoặc lỗi hậu kiểm / quá tải RPC ogiZ0b Error: [5], [8], [13], [3]
                err_up = str(label_or_err or "").upper()
                retryable_tokens = (
                    "UNSAFE",
                    "MINOR",
                    "PUBLIC_ERROR",
                    "POLICY",
                    "ERROR: [5",
                    "ERROR: [8",
                    "ERROR: [13",
                    "ERROR: [3",
                    "ERROR: [4",
                    "NOT_FOUND",
                    "KHÔNG TÌM THẤY",
                )
                if any(k in err_up for k in retryable_tokens):
                    self.ui_queue.put(
                        (
                            "log",
                            f"🛡️ Google Flow trả mã ({label_or_err}) — Đang tự động chuẩn hóa Prompt an toàn + đổi Seed và tạo lại (Lần 2)...",
                        )
                    )
                    time.sleep(1.2)
                    ultra_safe_prompt = flowkit_engine.sanitize_prompt_for_google_flow(prompt, aggressive=True)
                    ok_cdp2, mid2, label_or_err2 = bridge.cdp_generate_image(
                        prompt=ultra_safe_prompt,
                        model_key=wire_model,
                        aspect_ratio=ratio_str,
                        seed=seed + 77,
                        ref_media_ids=ref_media_ids,
                        save_path=out_path,
                    )
                    if ok_cdp2 and os.path.isfile(out_path):
                        return True, mid2, label_or_err2

                    # Lần 3: Tự động chuyển đổi sang mô hình dự phòng (GEM_PIX_2 <-> NARWHAL) nếu vẫn bị Error: [5] / [8]
                    fallback_model = "NARWHAL" if wire_model == "GEM_PIX_2" else "GEM_PIX_2"
                    self.ui_queue.put(
                        (
                            "log",
                            f"🔄 Đang tự động chuyển sang mô hình dự phòng ({fallback_model}) để vượt lỗi {label_or_err2} (Lần 3)...",
                        )
                    )
                    time.sleep(1.5)
                    ok_cdp3, mid3, label_or_err3 = bridge.cdp_generate_image(
                        prompt=ultra_safe_prompt,
                        model_key=fallback_model,
                        aspect_ratio=ratio_str,
                        seed=seed + 157,
                        ref_media_ids=ref_media_ids,
                        save_path=out_path,
                    )
                    if ok_cdp3 and os.path.isfile(out_path):
                        return True, mid3, label_or_err3
                    last_err = label_or_err3
                else:
                    last_err = label_or_err
            else:
                last_err = "Chưa khởi tạo GoogleUltraBridge"
        except Exception as e:
            last_err = str(e)

        # 2. Dự phòng qua Gemini Imagen 3 REST API (nếu người dùng cấu hình gemini.txt)
        ok_gem, msg_gem = self._try_gemini_imagen_api(prompt, ratio_str, out_path)
        if ok_gem and os.path.isfile(out_path):
            return True, f"gemini_{seed}", msg_gem

        return False, "", last_err

    def _try_gemini_imagen_api(self, prompt: str, ratio_str: str, out_path: str) -> tuple[bool, str]:
        gem_file = os.path.join(SRC_DIR, "gemini.txt")
        if not os.path.isfile(gem_file):
            return False, ""
        try:
            with open(gem_file, "r", encoding="utf-8") as f:
                keys = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]
        except Exception:
            keys = []
        if not keys:
            return False, ""

        aspect = "9:16" if "9:16" in ratio_str else ("1:1" if "1:1" in ratio_str else "16:9")
        for key in keys[:2]:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key={key}"
            payload = {
                "instances": [{"prompt": prompt}],
                "parameters": {"sampleCount": 1, "aspectRatio": aspect},
            }
            try:
                r = requests.post(url, json=payload, timeout=25)
                if r.status_code == 200:
                    preds = r.json().get("predictions") or []
                    if preds and preds[0].get("bytesBase64Encoded"):
                        with open(out_path, "wb") as f:
                            f.write(base64.b64decode(preds[0]["bytesBase64Encoded"]))
                        return True, "Gemini Imagen 3"
            except Exception:
                pass
        return False, ""

    def _render_consistent_scene_image(
        self,
        scene_id: int,
        prompt: str,
        char_bible: str,
        style: str,
        ratio_str: str,
        seed: int,
        ref_img_path: Optional[str],
        out_path: str,
    ) -> bool:
        """Hàm phục vụ --self-test kiểm tra khả năng ghi file ảnh của module."""
        try:
            img = Image.new("RGB", (1280, 720), (16, 28, 44))
            draw = ImageDraw.Draw(img)
            for y in range(0, 720, 4):
                draw.line([(0, y), (1280, y)], fill=((y * 3) % 255, (y * 5 + 40) % 255, (y * 7 + 80) % 255), width=2)
            draw.text((24, 24), f"SelfTest Scene {scene_id}: {prompt[:80]}", fill=(255, 255, 255))
            img.save(out_path, format="PNG")
            return True
        except Exception:
            return False

    # ─────────────────────────────────────────────────────────────────────────
    # 5. BỘ ĐẨY SANG CÁC TAB TẠO VIDEO & CHUẨN HÓA PROMPT (ĐẦY ĐỦ 100% CÁC CẢNH)
    # ─────────────────────────────────────────────────────────────────────────
    def _collect_step1_and_step2_payload(self, source_step: int = 2) -> Dict[str, Any]:
        import flowkit_engine

        if not self.ref_entities:
            self._apply_ref_prompts(silent=True)
        if not self.tasks:
            self._apply_manual_prompts(silent=True)

        ref_lines = [f"{r['uid']} | {r['desc']}" for r in self.ref_entities]
        ref_paths = [r["image_path"] for r in self.ref_entities if r.get("image_path") and os.path.isfile(r["image_path"])]
        ref_img_by_uid = {
            r["uid"].upper(): r["image_path"]
            for r in self.ref_entities
            if r.get("image_path") and os.path.isfile(r["image_path"])
        }

        scene_lines_tagged = []
        scene_lines_plain = []
        for t in self.tasks:
            vid_p = flowkit_engine.to_video_motion_prompt(t.get("video_prompt") or t["prompt"])
            uids_str = ", ".join(t.get("uids") or ["CHAR_01"])
            scene_lines_tagged.append(f"{uids_str} | {vid_p}")
            scene_lines_plain.append(vid_p)

        # Đảm bảo 100% số lượng phân cảnh đều được đẩy sang Image to video:
        # Nếu cảnh đã có ảnh riêng (Scene_XXX.jpg) thì lấy ảnh cảnh đó; nếu chưa tạo ảnh cảnh thì lấy ảnh Ref của nhân vật trong cảnh đó
        full_i2v_tasks = []
        for idx_t, t in enumerate(self.tasks):
            sc_img = t.get("image_path") if (t.get("image_path") and os.path.isfile(t["image_path"])) else ""
            if not sc_img:
                for u in t.get("uids") or []:
                    if u.upper() in ref_img_by_uid:
                        sc_img = ref_img_by_uid[u.upper()]
                        break
            if not sc_img and ref_paths:
                sc_img = ref_paths[0]
            vid_p = scene_lines_plain[idx_t] if idx_t < len(scene_lines_plain) else t["prompt"]
            full_i2v_tasks.append(
                {
                    "id": t["id"],
                    "uids": t.get("uids") or ["CHAR_01"],
                    "prompt": vid_p,
                    "image_path": sc_img,
                }
            )

        return {
            "ref_lines": ref_lines,
            "ref_paths": ref_paths,
            "scene_lines_tagged": scene_lines_tagged or ref_lines,
            "scene_lines_plain": scene_lines_plain or [r["desc"] for r in self.ref_entities],
            "ready_i2v_tasks": full_i2v_tasks,
        }

    def push_refs_to_review(self):
        """Đẩy danh sách Prompt Tham Chiếu Gốc (Nhân vật & Bối cảnh ở ô ①) sang tab '✨ Chuẩn hóa prompt'."""
        if not self.ref_entities:
            self._apply_ref_prompts(silent=True)
        if not self.ref_entities:
            messagebox.showwarning("Chưa có prompt", "Chưa có câu lệnh nhân vật/bối cảnh nào ở ô ① để chuẩn hóa!")
            return
        top = self.pipeline or self.winfo_toplevel()
        items = [(-idx, f"{e['uid']} | {e['desc']}", str(e.get("status") or "")) for idx, e in enumerate(self.ref_entities, start=1)]
        if hasattr(top, "push_prompts_to_review"):
            top.push_prompts_to_review("img6", items)

    def execute_push_to_video(self):
        """Thực thi lựa chọn đẩy Ảnh & Prompt từ '🎨 Image đồng nhất' sang các công cụ Tạo Video hoặc Chuẩn hóa prompt."""
        choice = self.cbo_push_video.get() if hasattr(self, "cbo_push_video") else ""
        self._dispatch_unified_push(choice, source_step=2)

    def execute_push_from_step1(self):
        self.push_refs_to_review()

    def execute_push_from_step2(self):
        self.execute_push_to_video()

    def _dispatch_unified_push(self, choice: str, source_step: int = 2):
        data = self._collect_step1_and_step2_payload(source_step=source_step)
        top = self.pipeline or self.winfo_toplevel()
        ch = str(choice or "")

        if "Chuẩn hóa prompt" in ch:
            if source_step == 1 and self.ref_entities:
                items = [(-idx, f"{e['uid']} | {e['desc']}", str(e.get("status") or "")) for idx, e in enumerate(self.ref_entities, start=1)]
            else:
                items = [(t["id"], t["prompt"], str(t.get("status") or "")) for t in self.tasks]
            if not items:
                messagebox.showwarning("Chưa có prompt", "Chưa có câu lệnh nào để đẩy sang Chuẩn hóa prompt!")
                return
            if hasattr(top, "push_prompts_to_review"):
                top.push_prompts_to_review("img6", items)
            return

        if "TẤT CẢ tab Tạo Video" in ch or "TẤT CẢ chức năng Bước 2" in ch:
            if hasattr(top, "push_to_all_step2_tabs"):
                top.push_to_all_step2_tabs(
                    prompts_tagged=data["scene_lines_tagged"],
                    prompts_plain=data["scene_lines_plain"],
                    ref_paths=data["ref_paths"],
                    ref_lines=data["ref_lines"],
                    i2v_tasks=data["ready_i2v_tasks"],
                    skip_image_consist=True,
                )
            return

        if "Image to video" in ch:
            if data["ready_i2v_tasks"] and hasattr(top, "push_scene_images_to_i2v"):
                top.push_scene_images_to_i2v(data["ready_i2v_tasks"])
            elif hasattr(top, "push_prompts_to_tab"):
                top.push_prompts_to_tab("veo3_i2v", data["scene_lines_plain"], ref_paths=data["ref_paths"])
            return

        if "Video Muse" in ch:
            if hasattr(top, "push_prompts_to_tab"):
                top.push_prompts_to_tab("muse_video", data["scene_lines_tagged"], ref_paths=data["ref_paths"])
            return

        if "Video đồng nhất" in ch:
            if hasattr(top, "push_prompts_to_tab"):
                top.push_prompts_to_tab("veo3_consist", data["scene_lines_tagged"], ref_paths=data["ref_paths"])
            return

        if "Text to video" in ch:
            if hasattr(top, "push_prompts_to_tab"):
                top.push_prompts_to_tab("veo3_t2v", data["scene_lines_plain"])
            return

    def push_images_to_i2v(self):
        self._dispatch_unified_push("📷 Đẩy sang Image to video", source_step=2)

    def push_to_video_consist(self):
        self._dispatch_unified_push("🎭 Đẩy sang Video đồng nhất", source_step=2)

    def push_to_video_muse(self):
        self._dispatch_unified_push("🎞 Đẩy sang Video Muse", source_step=2)

    def apply_reviewed_prompt(self, row_id: int, new_prompt: str) -> bool:
        if row_id < 0:
            ref_idx = abs(row_id) - 1
            if 0 <= ref_idx < len(self.ref_entities):
                s = new_prompt.strip()
                if "|" in s[:35]:
                    _, s = s.split("|", 1)
                self.ref_entities[ref_idx]["desc"] = s.strip()
                clean_ref_txt = "\n".join(f"{e['uid']} | {e['desc']}" for e in self.ref_entities)
                self.txt_ref_prompts.delete("1.0", "end")
                self.txt_ref_prompts.insert("1.0", clean_ref_txt)
                self._render_refs()
                return True
        for t in self.tasks:
            if t["id"] == row_id:
                t["prompt"] = new_prompt
                t["video_prompt"] = new_prompt
                self._sync_txt_prompt_from_tasks()
                self._render_tasks()
                return True
        return False

    # ─────────────────────────────────────────────────────────────────────────
    # 6. HÀNG ĐỢI CẬP NHẬT GIAO DIỆN
    # ─────────────────────────────────────────────────────────────────────────
    def log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        if hasattr(self, "log_box") and self.log_box.winfo_exists():
            self.log_box.insert("end", f"[{ts}] {msg}\n")
            if getattr(self, "_log_follow", True):
                self.log_box.see("end")

    def _process_ui_queue(self):
        try:
            while True:
                kind, payload = self.ui_queue.get_nowait()
                if kind == "log":
                    self.log(str(payload))
                elif kind == "refresh_all":
                    self._render_refs()
                    self._render_tasks()
                    done_cnt = sum(1 for t in self.tasks if "✅" in t.get("status", ""))
                    self.lbl_summary.configure(text=f"Phân cảnh: {done_cnt}/{len(self.tasks)}")
                elif kind == "done_all":
                    self.btn_gen_refs.configure(
                        state="normal", text="① Tạo Ảnh Tham Chiếu (Nhân vật/Bối cảnh)"
                    )
                    self.btn_start.configure(
                        state="normal", text="② Tạo Ảnh Từng Phân Cảnh (Theo Ref)"
                    )
                    self.btn_full_flow.configure(state="normal", text="⚡ Chạy Trọn Bộ (① ➔ ②)")
                    self.btn_stop.configure(state="disabled")
                    self._render_refs()
                    self._render_tasks()
                    done_cnt = sum(1 for t in self.tasks if "✅" in t.get("status", ""))
                    self.lbl_summary.configure(text=f"✅ Hoàn thành {done_cnt}/{len(self.tasks)} phân cảnh")
                    top = self.winfo_toplevel()
                    if hasattr(top, "trigger_auto_shutdown_if_enabled"):
                        top.trigger_auto_shutdown_if_enabled()
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(150, self._process_ui_queue)


def build_tab(parent, pipeline=None, *args, **kwargs):
    """Điểm vào cho Film studio."""
    frame = ConsistentSceneImageApp(parent, pipeline=pipeline)
    frame.grid(row=0, column=0, sticky="nsew")
    return frame
