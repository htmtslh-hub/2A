"""
tool7.py — VEO 3 ĐỒNG NHẤT (Reference-Image / Ingredients Consistency Video — Tab #5 trong All-Tool-Youtube)
────────────────────────────────────────────────────────────────────────────────────────────────────────────
Tạo video Veo 3 đồng nhất nhân vật & bối cảnh bằng ảnh tham chiếu (batchAsyncGenerateVideoReferenceImages),
tích hợp ImageCache lưu mediaId theo từng token (uploaded_images.json), kéo dài video (+8s/+16s/+24s),
ghép chuỗi video trên server (runVideoFxConcatenation) và khoá giọng nói/seed (30 giọng chuẩn Veo 3).
"""

import os
import sys
import re
import time
import json
import uuid
import math
import queue
import base64
import random
import hashlib
import tempfile
import itertools
import threading
import subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from tkinter import filedialog, messagebox
import customtkinter as ctk
import requests
from PIL import Image

import ui_tool7 as _ui7
from ui import T as _T, F as _F

try:
    from curl_cffi import requests as cffi_requests
    USE_CURL_CFFI = True
except ImportError:
    cffi_requests = requests
    USE_CURL_CFFI = False

CHROME_IMPERSONATE = "chrome131"
MIN_VIDEO_SIZE = 50 * 1024
CACHE_FILE = "uploaded_images.json"

PROJECT_FALLBACK = {
    "Ultra": "0155fece-7957-43b6-bba9-8f2f7a672845",
    "Pro": "4ec7ee56-08c8-4bfe-ba92-f5bb96888bd8",
}

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

file_lock = threading.Lock()
nestjs_process = None

try:
    import captcha_server as _CAPSRV
except Exception:
    _CAPSRV = None


def get_app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def start_nestjs_server(log_func=print, hidden=True, wait=30):
    """Bật server cầu nối Google Ultra & Captcha (port 3000)."""
    global nestjs_process
    try:
        import google_ultra_bridge
        google_ultra_bridge.init_global_bridge(get_app_dir())
        return
    except Exception:
        pass
    if _CAPSRV is not None and hasattr(_CAPSRV, "ensure"):
        try:
            _CAPSRV.ensure(log_func=log_func, hidden=hidden, wait=wait)
            nestjs_process = getattr(_CAPSRV, "_proc", None)
            return
        except Exception:
            pass
    base_dir = get_app_dir()
    nestjs_dir = os.path.join(base_dir, "captcha-solver-main", "captcha-solver-main")
    if os.path.exists(nestjs_dir):
        try:
            kwargs = {"creationflags": subprocess.CREATE_NEW_CONSOLE} if os.name == "nt" else {}
            nestjs_process = subprocess.Popen("npm run start:dev", cwd=nestjs_dir, shell=True, **kwargs)
        except Exception:
            pass


class ImageCache:
    """
    Lưu trữ persistent mediaId của các ảnh đã upload theo từng token trong uploaded_images.json,
    kèm kiểm soát chặt chẽ mã băm nội dung file (SHA-256) để tuyệt đối không bao giờ dùng nhầm
    ảnh tham chiếu cũ từ các phiên trước.
    """

    def __init__(self, cache_file: str = CACHE_FILE):
        self.cache_file = cache_file if os.path.isabs(cache_file) else os.path.join(get_app_dir(), cache_file)
        self._lock = threading.Lock()
        self.data = self._load()

    @staticmethod
    def _token_hash(token: str) -> str:
        return hashlib.sha256((token or "").strip().encode("utf-8")).hexdigest()[:12]

    @staticmethod
    def _normalize_ref_id(raw: str) -> str:
        u = (raw or "").strip().upper().replace(" ", "_")
        while u.startswith("REF_"):
            u = u[4:].strip("_")
        m_c = re.match(r"^(?:CHAR|NV)_?(\d+)$", u)
        if m_c:
            return f"CHAR_{int(m_c.group(1)):02d}"
        m_l = re.match(r"^(?:LOC|BG|SET|ENV)_?(\d+)$", u)
        if m_l:
            return f"LOC_{int(m_l.group(1)):02d}"
        return u

    @classmethod
    def _image_name(cls, path: str) -> str:
        return cls._normalize_ref_id(Path(path).stem)

    @staticmethod
    def _file_sha256(path: str) -> str:
        if not path or str(path).startswith("__cache__/") or not os.path.isfile(path):
            return ""
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    def _load(self) -> dict:
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, "r", encoding="utf-8") as f:
                    d = json.load(f)
                    if isinstance(d, dict):
                        return d
            except Exception:
                pass
        return {}

    def _save(self):
        try:
            with open(self.cache_file, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[ImageCache] Lỗi save: {e}")

    def put(self, token: str, image_path: str, media_id: str, custom_name: str = None):
        if not media_id:
            return
        tk = self._token_hash(token or "default")
        name = self._normalize_ref_id(custom_name or self._image_name(image_path))
        abs_p = os.path.abspath(image_path) if (image_path and not str(image_path).startswith("__cache__/")) else str(image_path)
        f_sha = self._file_sha256(abs_p)
        entry_obj = {
            "mediaId": media_id,
            "path": abs_p,
            "file_sha256": f_sha,
            "upload_time": time.time(),
            "upload_iso": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        with self._lock:
            for bucket_key in (tk, "__default__"):
                tok_bucket = self.data.setdefault(bucket_key, {})
                # Xoá các entry cũ của cùng mã nhân vật nếu nội dung file ảnh đã thay đổi (khác SHA-256)
                old_entries = tok_bucket.get(name) or []
                if f_sha:
                    kept = [e for e in old_entries if isinstance(e, dict) and e.get("file_sha256") == f_sha]
                else:
                    kept = [e for e in old_entries if isinstance(e, dict)]
                existing_ids = {e.get("mediaId") for e in kept}
                if media_id not in existing_ids:
                    kept.append(dict(entry_obj))
                tok_bucket[name] = kept
            self._save()

    def _check_flow_ref_cache_sha(self, key: str, expected_sha: str) -> str:
        """Đồng bộ media_id từ flow_ref_entities_cache.json (tab Image đồng nhất) NẾU khớp đúng SHA-256 của file ảnh."""
        if not expected_sha:
            return ""
        flow_cache_file = os.path.join(get_app_dir(), "flow_ref_entities_cache.json")
        if not os.path.isfile(flow_cache_file):
            return ""
        try:
            with open(flow_cache_file, "r", encoding="utf-8") as f:
                fc = json.load(f)
            rec = fc.get(key)
            if isinstance(rec, dict):
                mid = str(rec.get("media_id") or "").strip()
                r_sha = str(rec.get("file_sha256") or "").strip()
                r_path = str(rec.get("image_path") or "").strip()
                if not r_sha and r_path and os.path.isfile(r_path):
                    r_sha = self._file_sha256(r_path)
                if mid and not mid.startswith("local_") and r_sha == expected_sha:
                    return mid
        except Exception:
            pass
        return ""

    def get(self, token: str, image_path: str = None, name: str = None) -> str:
        tk = self._token_hash(token or "default")
        key = self._normalize_ref_id(name or (self._image_name(image_path) if image_path else ""))
        expected_sha = ""
        if image_path and not str(image_path).startswith("__cache__/"):
            if not os.path.isfile(image_path):
                return ""
            expected_sha = self._file_sha256(image_path)

        with self._lock:
            entries = (self.data.get(tk) or {}).get(key) or (self.data.get("__default__") or {}).get(key) or []
            valid_entries = []
            for e in entries:
                if not isinstance(e, dict) or not e.get("mediaId"):
                    continue
                epath = str(e.get("path") or "")
                esha = str(e.get("file_sha256") or "")
                # Bắt buộc file gốc phải tồn tại và có mã SHA-256 khớp tuyệt đối với file hiện tại
                if expected_sha:
                    if esha and esha == expected_sha:
                        valid_entries.append(e)
                else:
                    if epath and os.path.isfile(epath) and esha and esha == self._file_sha256(epath):
                        valid_entries.append(e)

            if valid_entries:
                latest = max(valid_entries, key=lambda x: x.get("upload_time", 0))
                return latest.get("mediaId", "")

        # Kiểm tra xem ảnh này vừa được tạo/upload bên tab 'Image đồng nhất' với cùng SHA-256 chưa
        if expected_sha:
            flow_mid = self._check_flow_ref_cache_sha(key, expected_sha)
            if flow_mid:
                self.put(token, image_path, flow_mid, custom_name=key)
                return flow_mid
        return ""

    def get_all_for_token(self, token: str) -> dict:
        tk = self._token_hash(token or "default")
        result = {}
        with self._lock:
            merged = dict(self.data.get("__default__") or {})
            merged.update(self.data.get(tk) or {})
            for name, entries in merged.items():
                valid = [
                    e
                    for e in (entries or [])
                    if isinstance(e, dict)
                    and e.get("path")
                    and os.path.isfile(e["path"])
                    and e.get("file_sha256")
                    and e.get("file_sha256") == self._file_sha256(e["path"])
                ]
                if valid:
                    latest = max(valid, key=lambda x: x.get("upload_time", 0))
                    if latest.get("mediaId"):
                        result[self._normalize_ref_id(name)] = latest["mediaId"]
        return result

    def get_detail(self, token: str) -> list:
        tk = self._token_hash(token or "default")
        all_items = []
        with self._lock:
            merged = dict(self.data.get("__default__") or {})
            merged.update(self.data.get(tk) or {})
            for name, entries in merged.items():
                for e in entries:
                    if not isinstance(e, dict):
                        continue
                    all_items.append(
                        {
                            "name": self._normalize_ref_id(name),
                            "mediaId": e.get("mediaId", ""),
                            "path": e.get("path", ""),
                            "file_sha256": str(e.get("file_sha256", ""))[:12],
                            "upload_iso": e.get("upload_iso", ""),
                            "upload_ts": e.get("upload_time", 0),
                        }
                    )
        all_items.sort(key=lambda x: x["upload_ts"], reverse=True)
        return all_items

    def resolve_for_prompt(self, token: str, image_paths: list) -> tuple:
        cached = []
        need_upload = []
        for path in image_paths:
            if str(path).startswith("__cache__/"):
                cname = str(path).split("/", 1)[1]
                mid = self.get(token, name=cname)
            else:
                mid = self.get(token, image_path=path)
            if mid:
                cached.append((path, mid))
            else:
                need_upload.append(path)
        return cached, need_upload

    def remove(self, token: str, name: str, media_id: str = None):
        tk = self._token_hash(token or "default")
        raw_k = (name or "").strip().upper()
        norm_k = self._normalize_ref_id(raw_k)
        with self._lock:
            for bucket_key in (tk, "__default__"):
                tok_bucket = self.data.get(bucket_key) or {}
                for k in {raw_k, norm_k}:
                    if k in tok_bucket:
                        if media_id:
                            tok_bucket[k] = [e for e in tok_bucket[k] if e.get("mediaId") != media_id]
                        else:
                            tok_bucket.pop(k, None)
            self._save()

    def clear_token(self, token: str):
        tk = self._token_hash(token)
        with self._lock:
            self.data.pop(tk, None)
            self._save()

    def clear_all(self):
        with self._lock:
            self.data.clear()
            self._save()
            if os.path.isfile(self.cache_file):
                try:
                    os.remove(self.cache_file)
                except Exception:
                    pass


IMAGE_CACHE = ImageCache()


class TokenRateLimiter:
    def __init__(self, tokens, delay_seconds=12):
        self.tokens = list(tokens)
        self.delay = delay_seconds
        self.lock = threading.Lock()
        self.last_used = {t: 0.0 for t in self.tokens}
        self.token_cycle = itertools.cycle(self.tokens)

    def get_token(self):
        with self.lock:
            token = next(self.token_cycle)
            now = time.time()
            elapsed = now - self.last_used.get(token, 0.0)
            wait_time = max(0.0, self.delay - elapsed)
            self.last_used[token] = now + wait_time
        if wait_time > 0:
            time.sleep(wait_time)
        with self.lock:
            self.last_used[token] = time.time()
        return token


class VeoBackend:
    def __init__(self, auth_token: str, account_email: str = "", labs_session: str = ""):
        self.auth_token = (auth_token or "").strip()
        self.account_email = (account_email or "").strip()
        self.labs_session = (labs_session or "").strip()
        self.headers = {
            "authorization": f"Bearer {self.auth_token}",
            "accept": "*/*",
            "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "text/plain;charset=UTF-8",
            "origin": "https://labs.google",
            "priority": "u=1, i",
            "referer": "https://labs.google/",
            "sec-ch-ua": '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "user-agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
            ),
        }
        self.cookies = self._load_app_cookies()

    def _load_app_cookies(self):
        cookies_dir = Path("cookies")
        if not cookies_dir.exists():
            return {}
        json_files = sorted(cookies_dir.glob("*.json"))
        if not json_files:
            return {}
        try:
            selected_file = json_files[0]
            with open(selected_file, "r", encoding="utf-8") as f:
                cookie_data = json.load(f)
            return {
                c["name"]: c["value"]
                for c in cookie_data
                if isinstance(c, dict) and "name" in c and "value" in c
            }
        except Exception:
            return {}

    def _apply_fresh_headers(self, fresh: dict):
        if not fresh:
            return
        normalized = {k.lower(): v for k, v in self.headers.items()}
        for k, v in fresh.items():
            normalized[k.lower()] = v
        self.headers = normalized

    def _get_cdp_bridge(self):
        try:
            from google_ultra_bridge import get_global_bridge, init_global_bridge
            b = get_global_bridge()
            if b is None:
                b = init_global_bridge(get_app_dir())
            if self.auth_token.startswith("cdp_flow::") or (b and b.connected_accounts):
                return b
        except Exception:
            pass
        return None

    def get_recaptcha(self):
        """Gọi sang API NestJS cổng 3000 để lấy Token + fresh headers từ Chrome."""
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return "CDP_FLOW_READY"
        try:
            response = requests.get(
                "http://127.0.0.1:3000/captcha",
                params={"action": "VIDEO_GENERATION"},
                timeout=65,
            )
            if response.status_code == 200:
                data = response.json()
                token = data.get("captcha")
                fresh_headers = data.get("headers", {}) or {}
                if fresh_headers:
                    self._apply_fresh_headers(fresh_headers)
                return token
            return None
        except Exception:
            return None

    def upload_user_image(
        self,
        image_path: str,
        aspect_ratio_enum: str = "IMAGE_ASPECT_RATIO_LANDSCAPE",
        recaptcha_token: str = None,
        project_id: str = None,
        account_type: str = "Ultra",
    ):
        try:
            with Image.open(image_path) as im:
                if im.mode != "RGB":
                    im = im.convert("RGB")
                tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                tmp_jpg = tmp.name
                tmp.close()
                im.save(tmp_jpg, format="JPEG", quality=95)

            with open(tmp_jpg, "rb") as f:
                encoded_string = base64.b64encode(f.read()).decode("utf-8")
            try:
                os.remove(tmp_jpg)
            except Exception:
                pass

            bridge = self._get_cdp_bridge()
            if bridge is not None:
                return bridge.cdp_upload_image(
                    image_b64=encoded_string,
                    mime_type="image/jpeg",
                    file_name=os.path.basename(image_path) or "image.jpg",
                    project_id=project_id,
                )

            pid = (project_id or "").strip() or PROJECT_FALLBACK.get(account_type, PROJECT_FALLBACK["Ultra"])
            payload = {
                "clientContext": {
                    "projectId": pid,
                    "tool": "PINHOLE",
                },
                "imageBytes": encoded_string,
                "isUserUploaded": True,
                "isHidden": False,
                "mimeType": "image/jpeg",
                "fileName": "image.jpg",
            }
            url = "https://aisandbox-pa.googleapis.com/v1/flow/uploadImage"
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=90,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code == 200:
                d = r.json()
                media_id = (d.get("media") or {}).get("name") or d.get("mediaGenerationId")
                if not media_id:
                    m = re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", r.text)
                    if m:
                        media_id = m.group(0)
                return media_id
            return None
        except Exception:
            return None

    def send_request(
        self,
        recaptcha,
        prompt,
        ing_ids,
        ratio_key,
        model_key,
        project_id=None,
        account_type="Ultra",
        voice_id=None,
        fixed_seed=None,
    ):
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return bridge.cdp_generate_video(
                prompt=prompt,
                model_key=model_key,
                ratio_key=ratio_key,
                project_id=project_id,
                ref_media_ids=ing_ids,
                seed=fixed_seed,
            )
        final_pid = (project_id or "").strip() or PROJECT_FALLBACK.get(account_type, PROJECT_FALLBACK["Ultra"])
        paygate_tier = "PAYGATE_TIER_TWO" if account_type == "Ultra" else "PAYGATE_TIER_NOT_PAID"

        if str(model_key).startswith("abra_t2v_"):
            url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoText"
            if account_type == "Pro":
                paygate_tier = "PAYGATE_TIER_ONE"
            ref_images = []
        else:
            url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoReferenceImages"
            ref_images = [
                {"imageUsageType": "IMAGE_USAGE_TYPE_ASSET", "mediaId": mid}
                for mid in (ing_ids or [])
                if mid
            ]

        seed_val = int(fixed_seed) if fixed_seed is not None else random.randint(10000, 999999)
        req_item = {
            "aspectRatio": ratio_key,
            "seed": seed_val,
            "textInput": {"structuredPrompt": {"parts": [{"text": prompt}]}},
            "videoModelKey": model_key,
            "metadata": {},
        }
        if ref_images:
            req_item["referenceImages"] = ref_images
        if voice_id:
            req_item["referenceAudio"] = {"voiceId": voice_id}

        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha,
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": paygate_tier,
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS",
            },
            "requests": [req_item],
            "useV2ModelConfig": True,
        }

        try:
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=180,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code == 200:
                d = r.json()
                if "media" in d and d["media"]:
                    media_name = d["media"][0].get("name", "")
                    media_pid = d["media"][0].get("projectId", final_pid)
                    return "OK", media_name, media_pid
                if "operations" in d and d["operations"]:
                    op_name = d["operations"][0]["operation"]["name"]
                    scene_id = d["operations"][0].get("sceneId", final_pid)
                    return "OK", op_name, scene_id
                return "FAIL", f"LỖI API: {r.text[:250]}", ""
            return "FAIL", f"HTTP {r.status_code} | {r.text[:300]}", ""
        except requests.exceptions.Timeout:
            return "FAIL", "TIMEOUT — Google API chậm, đang retry", ""
        except Exception as e:
            return "FAIL", str(e), ""

    def upscale_video(self, recaptcha, media_id, ratio, resolution_key, model_key, output_path, project_id=None):
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return bridge.cdp_upscale_video(
                media_id=media_id,
                ratio_key=ratio,
                resolution_key=resolution_key,
                model_key=model_key,
                project_id=project_id,
            )
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoUpsampleVideo"
        final_pid = (project_id or "").strip() or "15db98c1-1b62-473e-b284-a354d46b4399"
        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha,
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": "PAYGATE_TIER_TWO",
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS",
            },
            "requests": [
                {
                    "aspectRatio": ratio,
                    "seed": random.randint(10000, 999999),
                    "resolution": resolution_key,
                    "videoInput": {"mediaId": media_id},
                    "videoModelKey": model_key,
                    "metadata": {"workflowId": str(uuid.uuid4())},
                }
            ],
            "useV2ModelConfig": True,
        }
        try:
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=180,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code != 200:
                return "FAIL", f"HTTP {r.status_code} | {r.text}", ""
            d = r.json()
            if "operations" in d:
                return "OK", d["operations"][0]["operation"]["name"], d["operations"][0].get("sceneId", "")
            return "FAIL", "No operations found", ""
        except Exception as e:
            return "FAIL", str(e), ""

    def extend_video(
        self,
        recaptcha,
        source_media_id,
        prompt,
        ratio_key,
        model_key,
        project_id=None,
        account_type="Ultra",
        voice_id=None,
        fixed_seed=None,
    ):
        """Kéo dài video từ mediaId của video gốc. Tự chuyển model key sang extend."""
        if str(model_key).startswith("abra_t2v_"):
            return "FAIL", "Omni Flash chưa hỗ trợ kéo dài video — chọn model Veo 3.1 để extend", ""
        ext_model = (
            str(model_key)
            .replace("_r2v_", "_extend_")
            .replace("_fast_", "_extend_fast_")
            .replace("_high_", "_extend_high_")
        )
        final_pid = (project_id or "").strip() or PROJECT_FALLBACK.get(account_type, PROJECT_FALLBACK["Ultra"])
        paygate_tier = "PAYGATE_TIER_TWO" if account_type == "Ultra" else "PAYGATE_TIER_NOT_PAID"
        req_item = {
            "aspectRatio": ratio_key,
            "seed": int(fixed_seed) if fixed_seed is not None else random.randint(10000, 999999),
            "textInput": {"structuredPrompt": {"parts": [{"text": prompt}]}},
            "videoInput": {"mediaId": source_media_id},
            "videoModelKey": ext_model,
            "metadata": {},
        }
        if voice_id:
            req_item["referenceAudio"] = {"voiceId": voice_id}
        payload = {
            "clientContext": {
                "recaptchaContext": {
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                    "token": recaptcha,
                },
                "sessionId": f";{int(time.time() * 1000)}",
                "projectId": final_pid,
                "tool": "PINHOLE",
                "userPaygateTier": paygate_tier,
            },
            "mediaGenerationContext": {
                "batchId": str(uuid.uuid4()),
                "audioFailurePreference": "BLOCK_SILENCED_VIDEOS",
            },
            "requests": [req_item],
            "useV2ModelConfig": True,
        }
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchAsyncGenerateVideoExtendVideo"
        try:
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=180,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code == 200:
                d = r.json()
                if "media" in d and d["media"]:
                    return "OK", d["media"][0].get("name", ""), d["media"][0].get("projectId", final_pid)
                if "operations" in d and d["operations"]:
                    return (
                        "OK",
                        d["operations"][0]["operation"]["name"],
                        d["operations"][0].get("sceneId", final_pid),
                    )
            return "FAIL", f"HTTP {r.status_code} | {r.text[:250]}", ""
        except Exception as e:
            return "FAIL", str(e), ""

    def concatenate_videos(self, media_ids: list):
        """Gửi request ghép video — trả operation name."""
        input_videos = []
        for idx, mid in enumerate(media_ids):
            input_videos.append(
                {
                    "mediaGenerationId": mid,
                    "lengthNanos": 8000000000,
                    "startTimeOffset": "0s" if idx == 0 else "1s",
                    "endTimeOffset": "8s",
                }
            )
        payload = {"inputVideos": input_videos}
        url = "https://aisandbox-pa.googleapis.com/v1:runVideoFxConcatenation"
        try:
            r = cffi_requests.post(
                url,
                json=payload,
                headers=self.headers,
                cookies=self.cookies,
                timeout=90,
                impersonate=CHROME_IMPERSONATE,
            )
            if r.status_code == 200:
                d = r.json()
                op_name = (d.get("operation") or {}).get("name") or d.get("name", "")
                if op_name:
                    return "OK", op_name
            return "FAIL", f"HTTP {r.status_code}: {r.text[:200]}"
        except Exception as e:
            return "FAIL", str(e)

    def download_concatenation(self, op_name: str, save_path: str, stop_event=None, progress_callback=None):
        """Poll concat status — khi SUCCESSFUL, video nằm trong response dạng base64."""
        url = "https://aisandbox-pa.googleapis.com/v1:runVideoFxCheckConcatenationStatus"
        for attempt in range(60):
            if stop_event and stop_event.is_set():
                return "STOPPED"
            if progress_callback:
                progress_callback(min(95, attempt * 3))
            try:
                r = cffi_requests.post(
                    url,
                    json={"operation": {"name": op_name}},
                    headers=self.headers,
                    cookies=self.cookies,
                    timeout=60,
                    impersonate=CHROME_IMPERSONATE,
                )
                if r.status_code == 200:
                    d = r.json()
                    st = d.get("status", "")
                    if "SUCCESSFUL" in st:
                        enc = (d.get("operation") or {}).get("metadata", {}).get("encodedVideo") or d.get(
                            "encodedVideo", ""
                        )
                        if enc:
                            with open(save_path, "wb") as f:
                                f.write(base64.b64decode(enc))
                            return "DONE"
                        return "FAILED"
                    if "FAILED" in st:
                        return "FAILED"
            except Exception:
                pass
            time.sleep(4)
        return "TIMEOUT"

    def download_extend_video(self, op_name, scene_id, save_path, stop_event=None, progress_callback=None):
        """Poll extend video — thử media endpoint, lấy operation name, rồi poll qua operations endpoint."""
        res, mid = self.download_video(
            op_name, scene_id, save_path, stop_event=stop_event, progress_callback=progress_callback
        )
        return res, mid

    def download_video(self, op_name, scene_id, save_path, stop_event=None, progress_callback=None):
        """Poll status & download video."""
        bridge = self._get_cdp_bridge()
        if bridge is not None:
            return bridge.cdp_poll_and_download_video(
                media_id=op_name,
                save_path=save_path,
                stop_event=stop_event,
                progress_callback=progress_callback,
            )
        url = "https://aisandbox-pa.googleapis.com/v1/video:batchCheckAsyncVideoGenerationStatus"

        def _find_all_urls(obj, path=""):
            found = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if isinstance(v, str) and ("http" in v.lower() or "fife" in k.lower() or "url" in k.lower()):
                        found.append((f"{path}.{k}", v))
                    found.extend(_find_all_urls(v, f"{path}.{k}"))
            elif isinstance(obj, list):
                for i, v in enumerate(obj):
                    found.extend(_find_all_urls(v, f"{path}[{i}]"))
            return found

        def _extract_status(d):
            if "operations" in d:
                return d["operations"][0].get("status", "")
            if "media" in d:
                return d["media"][0].get("mediaMetadata", {}).get("mediaStatus", {}).get("mediaGenerationStatus", "")
            return ""

        def _extract_video_url(d):
            vid_url = None
            media_id = None
            if "operations" in d:
                op = d["operations"][0]
                meta = op.get("operation", {}).get("metadata", {})
                video_meta = meta.get("video") or {}
                if isinstance(video_meta, dict):
                    vid_url = video_meta.get("fifeUrl") or video_meta.get("url") or video_meta.get("videoUrl")
                media_id = op.get("sceneId") or (
                    video_meta.get("mediaGenerationId") if isinstance(video_meta, dict) else None
                )
            if not vid_url and "media" in d:
                m = d["media"][0]
                vid_meta = m.get("video", {}).get("generatedVideo", {})
                vid_url = vid_meta.get("fifeUrl") or vid_meta.get("url") or vid_meta.get("videoUrl")
                media_id = m.get("name")
            if not vid_url:
                for p, u in _find_all_urls(d):
                    if u.startswith("http") and ("video" in p.lower() or "fife" in p.lower() or "google" in u):
                        vid_url = u
                        break
            return vid_url, media_id

        delay = 5
        max_delay = 30
        poll_shape = "media"
        for attempt in range(60):
            if stop_event and stop_event.is_set():
                return "STOPPED", None
            if progress_callback:
                progress_callback(min(95, int((attempt + 1) * 100 / 25)))
            try:
                poll_payload = (
                    {"media": [{"name": op_name, "projectId": scene_id}]}
                    if poll_shape == "media"
                    else {"operations": [{"operation": {"name": op_name}, "sceneId": scene_id}]}
                )
                r = cffi_requests.post(
                    url,
                    json=poll_payload,
                    headers=self.headers,
                    cookies=self.cookies,
                    timeout=90,
                    impersonate=CHROME_IMPERSONATE,
                )
                if r.status_code != 200:
                    if r.status_code in (400, 404) and poll_shape == "media":
                        poll_shape = "operations"
                        continue
                else:
                    d = r.json()
                    status = _extract_status(d)
                    if "SUCCESSFUL" in status:
                        vid_url, media_id = _extract_video_url(d)
                        if not vid_url and "media" in d and len(d["media"]) > 0:
                            media_obj = d["media"][0]
                            media_name = media_obj.get("name", "")
                            workflow_id = media_obj.get("workflowId", "")
                            project_id_real = media_obj.get("projectId", "")
                            if media_name:
                                redirect_url = (
                                    f"https://labs.google/fx/api/trpc/media.getMediaUrlRedirect?name={media_name}"
                                )
                                cookies_dict = (
                                    {"__Secure-next-auth.session-token": self.labs_session}
                                    if self.labs_session
                                    else self.cookies
                                )
                                redirect_headers = {
                                    "Accept": "*/*",
                                    "Range": "bytes=0-",
                                    "Referer": f"https://labs.google/fx/tools/flow/project/{project_id_real}/edit/{workflow_id}",
                                    "Origin": "https://labs.google",
                                    "Sec-Fetch-Site": "same-origin",
                                    "User-Agent": self.headers.get("user-agent", ""),
                                }
                                rr = cffi_requests.get(
                                    redirect_url,
                                    headers=redirect_headers,
                                    cookies=cookies_dict,
                                    allow_redirects=False,
                                    timeout=30,
                                    impersonate=CHROME_IMPERSONATE,
                                )
                                if rr.status_code in (301, 302, 307, 308):
                                    vid_url = rr.headers.get("Location", "")
                                    media_id = media_name
                        if vid_url:
                            v = requests.get(vid_url, timeout=120)
                            if v.status_code != 200 or len(v.content) < MIN_VIDEO_SIZE:
                                time.sleep(delay)
                                delay = min(delay + 3, max_delay)
                                continue
                            part_path = save_path + ".part"
                            with open(part_path, "wb") as f:
                                f.write(v.content)
                            os.replace(part_path, save_path)
                            return "DONE", media_id or op_name
                        return "FAILED", None
                    elif "FAILED" in status or "BLOCKED" in status:
                        return f"FAILED: {status}"[:120], None
            except Exception:
                pass
            time.sleep(delay)
            delay = min(delay + 3, max_delay)
        return "TIMEOUT", None


def _path_available(p: str) -> bool:
    """Check path tồn tại: file thật HOẶC cache placeholder."""
    return bool(p) and (str(p).startswith("__cache__/") or os.path.exists(p))


def resolve_images_for_prompt(
    prompt_text: str,
    image_map: dict,
    group_map: dict = None,
    logger=None,
    prompt_id: int = 0,
) -> tuple:
    """
    Phân giải ảnh tham chiếu cho 1 prompt. Ưu tiên:
      1. CHAR_01, CHAR_02 | prompt text  -> prefix tên ảnh trước dấu | (chuẩn hóa bỏ REF_)
      2. [ten_nhom]                      -> nhóm ảnh từ image_groups.json
      3. {uid} hoặc (CHAR_01) inline     -> tag ảnh trong text
      4. Không có gì                     -> dùng tất cả ảnh đang nạp trên giao diện
    Trả về: (found_paths, clean_prompt)
    """
    stripped = (prompt_text or "").strip()
    norm_map = {}
    for k, v in (image_map or {}).items():
        if _path_available(v):
            raw_k = str(k).strip().upper()
            norm_k = ImageCache._normalize_ref_id(raw_k)
            norm_map[raw_k] = v
            if norm_k:
                norm_map[norm_k] = v
                norm_map[f"REF_{norm_k}"] = v

    # Xoá nhãn đầu dòng "Prompt 1:" / "Scene 1:" nếu có
    stripped = re.sub(r"^(?:Prompt|Scene|Cảnh)\s*\d+\s*:\s*", "", stripped, flags=re.IGNORECASE).strip()

    # 1. Prefix trước dấu |
    m_pipe = re.match(r"^([^|{\[\n]+)\|(.+)$", stripped, flags=re.DOTALL)
    if m_pipe:
        ids_part = m_pipe.group(1).strip()
        clean_text = re.sub(r"^(?:Prompt|Scene|Cảnh)\s*\d+\s*:\s*", "", m_pipe.group(2).strip(), flags=re.I).strip()
        uids = [ImageCache._normalize_ref_id(u) for u in re.split(r"[,+/&\s]+", ids_part) if u.strip()]
        paths = []
        seen = set()
        for uid in uids:
            p = norm_map.get(uid)
            if p and p not in seen:
                paths.append(p)
                seen.add(p)
        if paths:
            if logger:
                logger(f"✅ [#{prompt_id + 1}] Khớp ảnh tham chiếu: {', '.join(uids)} -> {', '.join(os.path.basename(x) for x in paths)}")
            return paths, clean_text
        stripped = clean_text

    # 2. Nhóm [ten_nhom]
    m_grp = re.match(r"^\[([^\]]+)\]", stripped)
    if m_grp and group_map:
        grp_name = m_grp.group(1).strip()
        clean_text = re.sub(r"^\[[^\]]+\]\s*", "", stripped).strip()
        grp_uids = group_map.get(grp_name) or group_map.get(grp_name.upper()) or []
        paths = [norm_map[ImageCache._normalize_ref_id(u)] for u in grp_uids if ImageCache._normalize_ref_id(u) in norm_map]
        if paths:
            return paths, clean_text

    # 3. Inline {uid} hoặc (CHAR_XX) / CHAR_XX
    inline_tags = re.findall(r"\{([^}]+)\}|\b(CHAR_\d+|LOC_\d+|NV_?\d+|BG_?\d+)\b", stripped, flags=re.IGNORECASE)
    if inline_tags:
        paths = []
        seen = set()
        for t1, t2 in inline_tags:
            raw_t = (t1 or t2 or "").strip()
            u = ImageCache._normalize_ref_id(raw_t)
            p = norm_map.get(u)
            if p and p not in seen:
                paths.append(p)
                seen.add(p)
        clean_text = re.sub(r"\{([^}]+)\}", r"\1", stripped)
        if paths:
            return paths, clean_text

    # 4. Fallback: dùng tối đa 3 ảnh đầu tiên (không trùng lặp đường dẫn)
    unique_paths = list(dict.fromkeys(norm_map.values()))[:3]
    return unique_paths, stripped


def crop_image_for_ratio(image_path: str, ratio_str: str) -> str:
    """Cắt ảnh theo tỷ lệ 16:9 hoặc 9:16."""
    if str(image_path).startswith("__cache__/"):
        return image_path
    try:
        with Image.open(image_path) as img:
            w, h = img.size
            target_ratio = (16.0 / 9.0) if "16:9" in str(ratio_str) else (9.0 / 16.0)
            current_ratio = w / float(h)
            if abs(current_ratio - target_ratio) < 0.02:
                return image_path
            if current_ratio > target_ratio:
                new_w = int(h * target_ratio)
                left = (w - new_w) // 2
                box = (left, 0, left + new_w, h)
            else:
                new_h = int(w / target_ratio)
                top = (h - new_h) // 2
                box = (0, top, w, top + new_h)
            cropped = img.crop(box)
            if cropped.mode != "RGB":
                cropped = cropped.convert("RGB")
            tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
            tmp_path = tmp.name
            tmp.close()
            cropped.save(tmp_path, format="JPEG", quality=95)
            return tmp_path
    except Exception:
        return image_path


def _prompt_hash(prompt_text: str) -> str:
    norm = re.sub(r"\s+", " ", (prompt_text or "").strip())
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()[:16]


def _load_prompt_manifest(out_dir: str) -> dict:
    mf_path = os.path.join(out_dir, ".prompt_manifest.json")
    if os.path.exists(mf_path):
        try:
            with open(mf_path, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, dict):
                    return d
        except Exception:
            pass
    return {}


def record_prompt_manifest(out_dir: str, file_path: str, prompt_text: str):
    if not out_dir or not file_path or not prompt_text:
        return
    with file_lock:
        try:
            os.makedirs(out_dir, exist_ok=True)
            mf_path = os.path.join(out_dir, ".prompt_manifest.json")
            data = _load_prompt_manifest(out_dir)
            data[os.path.basename(file_path)] = _prompt_hash(prompt_text)
            with open(mf_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass


def resolve_existing_video(idx: int, out_dir: str, existing: dict = None, prompt_text: str = None) -> tuple:
    """
    Kiểm tra video của prompt #idx đã tồn tại & khớp đúng nội dung prompt hiện tại chưa.
    Nếu file cũ của prompt khác vẫn nằm trong thư mục, tự động xoá bỏ để tạo video mới.
    """
    manifest = _load_prompt_manifest(out_dir) if prompt_text is not None else None
    expected_hash = _prompt_hash(prompt_text) if prompt_text is not None else None
    candidates = [f"{idx + 1:04d}.mp4", f"veo_ing_{idx + 1:04d}.mp4"]
    for name in candidates:
        full_p = os.path.join(out_dir, name)
        file_exists = (name in existing) if existing is not None else os.path.exists(full_p)
        if not file_exists:
            continue
        try:
            fsize = existing[name] if existing is not None else os.path.getsize(full_p)
        except Exception:
            fsize = 0
        if fsize < MIN_VIDEO_SIZE:
            try:
                os.remove(full_p)
            except Exception:
                pass
            if existing is not None:
                existing.pop(name, None)
            continue
        if expected_hash is not None and manifest is not None:
            if manifest.get(name) != expected_hash:
                # File cũ từ đợt prompt trước -> xoá để tạo mới cho prompt mới
                try:
                    os.remove(full_p)
                except Exception:
                    pass
                if existing is not None:
                    existing.pop(name, None)
                continue
        return full_p, True
    return None, False


class IngredientsWorker(threading.Thread):
    MAX_RETRIES = 5
    POLICY_LIMIT = 2

    def __init__(
        self,
        task_queue,
        config,
        logger_func,
        status_func,
        finish_func,
        global_image_cache=None,
        on_prompt_failed=None,
        shared_stop=None,
    ):
        super().__init__(daemon=True)
        self.task_queue = task_queue
        self.config = config
        self.log = logger_func
        self.update_status = status_func
        self.finish_func = finish_func
        self.stop_event = shared_stop or threading.Event()
        self.executor = None
        self.token_specific_cache = global_image_cache if global_image_cache is not None else {}
        self.on_prompt_failed = on_prompt_failed
        self.token_pid_map = {}
        self.token_email_map = {}
        self.token_session_map = {}
        self._upload_lock = threading.Lock()

    def _pol_lim(self):
        try:
            return max(1, int(self.config.get("policy_limit", self.POLICY_LIMIT)))
        except Exception:
            return self.POLICY_LIMIT

    def _get_pid(self, token: str) -> str:
        """Lấy project_id của token này (rỗng = dùng PROJECT_FALLBACK)."""
        return self.token_pid_map.get(token, "")

    def _get_email(self, token: str) -> str:
        """Email của token này → giúp VeoBackend nạp đúng cookie account."""
        return self.token_email_map.get(token, "")

    def _new_backend(self, token: str) -> VeoBackend:
        """Tạo VeoBackend gắn đúng email + labs_session của account."""
        return VeoBackend(
            token,
            account_email=self._get_email(token),
            labs_session=self.token_session_map.get(token, ""),
        )

    def stop(self):
        self.stop_event.set()
        with self.task_queue.mutex:
            self.task_queue.queue.clear()

    def _sleep_stop(self, seconds: float):
        """Ngủ nhưng cứ 0.3s ngó cờ dừng — bấm Dừng là thoát ngay, không đợi hết giờ."""
        end = time.time() + seconds
        while time.time() < end:
            if self.stop_event.is_set():
                return
            time.sleep(0.3)

    @staticmethod
    def get_progress_bar(percent: int, width: int = 8) -> str:
        filled = max(0, min(width, int(round(percent * width / 100.0))))
        return "█" * filled + "░" * (width - filled) + f" {percent}%"

    def _do_upscale(self, backend, row_id, orig_filename, media_id, ratio_key, upscale_mode, account_type, video_pid=""):
        UPSCALE_MODEL = {
            "1080p": "veo_3_1_upsampler_1080p",
            "4K": "veo_3_1_upsampler_4k",
        }
        UPSCALE_RES = {
            "1080p": "VIDEO_RESOLUTION_1080P",
            "4K": "VIDEO_RESOLUTION_4K",
        }
        model_key = UPSCALE_MODEL.get(upscale_mode)
        res_key = UPSCALE_RES.get(upscale_mode)
        if not model_key or not media_id:
            self.update_status(row_id, "✅ Hoàn thành (không upscale)", orig_filename)
            return
        up_pid = (video_pid or "").strip() or self._get_pid(backend.auth_token)
        st, op, sc = "FAIL", "", ""
        for attempt in range(3):
            self.update_status(row_id, f"⬆ Tự động nâng nét {upscale_mode} ({attempt+1}/3)...", orig_filename)
            cap = backend.get_recaptcha()
            if not cap:
                time.sleep(3)
                continue
            st, op, sc = backend.upscale_video(cap, media_id, ratio_key, res_key, model_key, orig_filename, project_id=up_pid)
            if st == "OK":
                break
            time.sleep(4)
        if st != "OK":
            self.update_status(row_id, "✅ Có video gốc, lỗi upscale", orig_filename)
            self.log(f"[{row_id + 1}] ⚠️ Upscale {upscale_mode} lỗi ({op}), giữ bản gốc.")
            return
        self.update_status(row_id, f"🔄 Đang nâng nét & tải {upscale_mode}...", orig_filename)
        base, ext = os.path.splitext(orig_filename)
        up_filename = f"{base}_tmp_up{ext}"
        res, _ = backend.download_video(op, sc, up_filename, stop_event=self.stop_event)
        if res == "DONE":
            try:
                os.replace(up_filename, orig_filename)
            except Exception:
                pass
            self.update_status(row_id, f"✅ Xong ({upscale_mode})", orig_filename)
            self.log(f"[{row_id + 1}] ✅ Đã tự động tải bản {upscale_mode}: {os.path.basename(orig_filename)}")
        else:
            self.update_status(row_id, "✅ Có video gốc, lỗi upscale", orig_filename)
            self.log(f"[{row_id + 1}] ⚠️ Tải bản {upscale_mode} thất bại ({res}), giữ bản gốc.")

    def _resolve_and_upload_ingredients(
        self,
        row_id: int,
        token: str,
        backend: VeoBackend,
        input_files: list,
        raw_ratio: str,
        img_ratio_enum: str,
        project_id: str,
        account_type: str,
        force_reupload: bool = False,
    ) -> list:
        with self._upload_lock:
            if force_reupload:
                for p in input_files:
                    cname = str(p).split("/", 1)[1] if str(p).startswith("__cache__/") else Path(p).stem
                    IMAGE_CACHE.remove(token, cname)
            cached_pairs, need_upload = IMAGE_CACHE.resolve_for_prompt(token, input_files)
            ing_ids = [mid for _, mid in cached_pairs]
            for path in need_upload:
                if self.stop_event.is_set():
                    break
                real_path = path
                if str(path).startswith("__cache__/"):
                    cname = str(path).split("/", 1)[1].strip()
                    char_dir = os.path.join(get_app_dir(), "characters")
                    if os.path.isdir(char_dir):
                        for fn in os.listdir(char_dir):
                            if os.path.splitext(fn)[0].upper() == cname.upper():
                                real_path = os.path.join(char_dir, fn)
                                break
                    if str(real_path).startswith("__cache__/"):
                        continue
                self.update_status(row_id, f"⏳ Lấy Cap Upload ({os.path.basename(real_path)})...", "")
                cap_up = backend.get_recaptcha()
                if not cap_up:
                    continue
                cropped_p = crop_image_for_ratio(real_path, raw_ratio)
                self.update_status(row_id, f"⬆ Upload ({os.path.basename(real_path)})...", "")
                mid = backend.upload_user_image(
                    cropped_p,
                    aspect_ratio_enum=img_ratio_enum,
                    recaptcha_token=cap_up,
                    project_id=project_id,
                    account_type=account_type,
                )
                if cropped_p != real_path:
                    try:
                        os.remove(cropped_p)
                    except Exception:
                        pass
                if mid:
                    IMAGE_CACHE.put(token, real_path, mid)
                    ing_ids.append(mid)
            return ing_ids

    def process_task(
        self,
        item: dict,
        token: str,
        ratio_key: str,
        img_ratio_enum: str,
        raw_ratio: str,
        model_key: str,
        out_dir: str,
        account_type: str = "Ultra",
    ):
        if self.stop_event.is_set():
            return
        row_id = item["id"]
        prompt = item["text"]
        raw_prompt = item.get("raw_text") or prompt
        input_files = item.get("ingredient_files") or []
        force_regen = item.get("force_regen", False)

        existing_fp, is_ok = resolve_existing_video(row_id, out_dir, prompt_text=raw_prompt)
        if is_ok and not force_regen:
            self.update_status(row_id, "✅ Đã có file", existing_fp)
            return

        filename = os.path.join(out_dir, f"{row_id + 1:04d}.mp4")
        backend = self._new_backend(token)
        project_id = self._get_pid(token)

        for attempt in range(2):
            if self.stop_event.is_set():
                return
            ing_ids = self._resolve_and_upload_ingredients(
                row_id=row_id,
                token=token,
                backend=backend,
                input_files=input_files,
                raw_ratio=raw_ratio,
                img_ratio_enum=img_ratio_enum,
                project_id=project_id,
                account_type=account_type,
                force_reupload=(attempt > 0),
            )

            self.update_status(row_id, "⏳ [API] Lấy Captcha Render...", "")
            recaptcha = backend.get_recaptcha()
            if not recaptcha:
                self.update_status(row_id, "❌ Lỗi Captcha Render", "")
                return

            voice_id = self.config.get("voice_id")
            fixed_seed = self.config.get("fixed_seed")
            self.update_status(row_id, f"📡 [..{token[-5:]}] Tạo video...", "")
            status, op_name, scene_id = backend.send_request(
                recaptcha,
                prompt,
                ing_ids,
                ratio_key,
                model_key,
                project_id=project_id,
                account_type=account_type,
                voice_id=voice_id,
                fixed_seed=fixed_seed,
            )
            if status == "OK":
                def update_progress_ui(pct):
                    self.update_status(row_id, f"🔄 {self.get_progress_bar(pct)}", "")

                res, media_id = backend.download_video(
                    op_name,
                    scene_id,
                    filename,
                    stop_event=self.stop_event,
                    progress_callback=update_progress_ui,
                )
                if res == "DONE":
                    record_prompt_manifest(out_dir, filename, raw_prompt)
                    item["_media_id"] = media_id or op_name
                    upscale_mode = self.config.get("upscale_mode", "1080p")
                    if upscale_mode != "Không":
                        self._do_upscale(
                            backend,
                            row_id,
                            filename,
                            media_id or op_name,
                            ratio_key,
                            upscale_mode,
                            account_type,
                            video_pid=scene_id,
                        )
                        record_prompt_manifest(out_dir, filename, raw_prompt)
                    else:
                        self.update_status(row_id, "✅ Hoàn thành", filename)
                        self.log(f"[{row_id + 1}] Xong: {os.path.basename(filename)}")
                    return
                elif res == "STOPPED":
                    self.update_status(row_id, "⏹ Đã dừng", "")
                    return
                elif attempt == 0 and ("NOT_FOUND" in str(res) or "code=4" in str(res)):
                    self.log(f"[{row_id + 1}] 🔄 Tự động upload lại ảnh nhân vật và thử lại...")
                    continue
                else:
                    self.update_status(row_id, f"❌ Lỗi Render ({res})", "")
                    return
            else:
                if attempt == 0 and input_files:
                    continue
                self.update_status(row_id, f"❌ Lỗi API: {str(op_name)[:40]}", "")
                return

    def run(self):
        try:
            from google_ultra_bridge import get_global_bridge
            br = get_global_bridge()
            if br:
                br.scan_and_sync_from_browsers()
        except Exception:
            pass
        accounts_file = os.path.join(get_app_dir(), "tool7.json")
        tokens = []
        self.token_pid_map = {}
        self.token_email_map = {}
        self.token_session_map = {}

        if os.path.exists(accounts_file):
            try:
                with open(accounts_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for acc in data.get("accounts", []):
                    tok = (acc.get("token") or "").strip()
                    pid = (acc.get("project_id") or "").strip()
                    email = (acc.get("email") or "").strip()
                    sess = (acc.get("labs_session") or "").strip()
                    if tok:
                        tokens.append(tok)
                        if pid:
                            self.token_pid_map[tok] = pid
                        if email:
                            self.token_email_map[tok] = email
                        if sess:
                            self.token_session_map[tok] = sess
            except Exception as e:
                self.log(f"❌ Lỗi đọc tool7.json: {e}")
                self.finish_func()
                return
        else:
            self.log("❌ KHÔNG TÌM THẤY tool7.json!")
            self.finish_func()
            return

        if not tokens:
            self.log("❌ tool7.json không có token nào.")
            self.finish_func()
            return

        token_limiter = TokenRateLimiter(tokens, delay_seconds=12)
        selected_model = self.config.get("model", "Veo 3.1 - Fast")
        raw_ratio = self.config.get("ratio", "16:9")
        account_type = self.config.get("account_type", "Ultra")

        MODEL_TABLE = {
            "Ultra": {
                "Veo 3.1 - Lite": {"16:9": "veo_3_1_r2v_lite", "9:16": "veo_3_1_r2v_lite"},
                "Veo 3.1 - Fast": {
                    "16:9": "veo_3_1_r2v_fast_landscape_ultra",
                    "9:16": "veo_3_1_r2v_fast_portrait_ultra",
                },
                "Veo 3.1 - Quality": {
                    "16:9": "veo_3_1_r2v_high_landscape_ultra",
                    "9:16": "veo_3_1_r2v_high_portrait_ultra",
                },
                "Veo 3.1 - Lite [Lower Priority]": {
                    "16:9": "veo_3_1_r2v_lite_low_priority",
                    "9:16": "veo_3_1_r2v_lite_low_priority",
                },
                "Veo 4": {"16:9": "abra_t2v_10s", "9:16": "abra_t2v_10s"},
            },
            "Pro": {
                "Veo 3.1 - Lite": {"16:9": "veo_3_1_r2v_lite", "9:16": "veo_3_1_r2v_lite"},
                "Veo 3.1 - Fast": {"16:9": "veo_3_1_r2v_fast_landscape", "9:16": "veo_3_1_r2v_fast_portrait"},
                "Veo 3.1 - Quality": {"16:9": "veo_3_1_r2v_high_landscape", "9:16": "veo_3_1_r2v_high_portrait"},
                "Veo 3.1 - Lite [Lower Priority]": {
                    "16:9": "veo_3_1_r2v_lite_low_priority",
                    "9:16": "veo_3_1_r2v_lite_low_priority",
                },
                "Veo 4": {"16:9": "abra_t2v_10s", "9:16": "abra_t2v_10s"},
            },
        }
        r_key = "9:16" if "9:16" in str(raw_ratio) else "16:9"
        model_key = (
            MODEL_TABLE.get(account_type, MODEL_TABLE["Ultra"])
            .get(selected_model, {})
            .get(r_key, "veo_3_1_r2v_lite_low_priority")
        )
        if model_key.startswith("abra_t2v_"):
            dur = (self.config.get("duration") or "10s").strip().lower()
            if dur not in ("4s", "6s", "8s", "10s"):
                dur = "10s"
            model_key = f"abra_t2v_{dur}"

        ratio_key = "VIDEO_ASPECT_RATIO_PORTRAIT" if r_key == "9:16" else "VIDEO_ASPECT_RATIO_LANDSCAPE"
        img_ratio_enum = "IMAGE_ASPECT_RATIO_PORTRAIT" if r_key == "9:16" else "IMAGE_ASPECT_RATIO_LANDSCAPE"
        out_dir = self.config.get("out_dir", "Video_Ingredients")
        os.makedirs(out_dir, exist_ok=True)
        max_workers = max(1, int(self.config.get("threads", 1)))

        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        while not self.stop_event.is_set():
            try:
                p_data = self.task_queue.get(block=False)
                current_token = token_limiter.get_token()
                self.executor.submit(
                    self.process_task,
                    p_data,
                    current_token,
                    ratio_key,
                    img_ratio_enum,
                    r_key,
                    model_key,
                    out_dir,
                    account_type,
                )
            except queue.Empty:
                break
            except Exception as e:
                print(f"Worker Loop Error: {e}")

        self.executor.shutdown(wait=True)
        self.finish_func()


class ModernImageCard(ctk.CTkFrame):
    def __init__(self, master, image_path: str, image_id: str, delete_command):
        super().__init__(master)
        self.image_path = image_path
        self.remote_media_id = None
        self._original_id = image_id

        ctk_img = None
        if os.path.exists(image_path):
            try:
                pil_img = Image.open(image_path)
                pil_img.thumbnail((46, 46))
                ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(46, 46))
            except Exception:
                ctk_img = None

        self.entry_id, self.lbl_status, self.btn_del = _ui7.build_image_card(
            self, image_path, image_id, delete_command, img=ctk_img
        )
        self.entry_id.bind("<FocusOut>", self._on_id_changed)
        self.entry_id.bind("<Return>", self._on_id_changed)

    def _on_id_changed(self, event=None):
        new_id = self.get_id()
        if new_id != self._original_id:
            self._original_id = new_id
            self.mark_needs_reupload()

    def mark_needs_reupload(self):
        self.remote_media_id = None
        _ui7.card_idle(self, self.lbl_status)

    def get_id(self) -> str:
        return self.entry_id.get().strip()

    def get_path(self) -> str:
        return self.image_path

    def set_uploaded(self, media_id: str = "cached"):
        self.remote_media_id = media_id
        _ui7.card_done(self, self.lbl_status)


class TaskRow(ctk.CTkFrame):
    def __init__(self, master, item: dict, f_edit, f_regen, f_del, f_view):
        super().__init__(master)
        self._f_edit = f_edit
        self._f_regen = f_regen
        self._f_del = f_del
        self._f_view = f_view
        self._current_item = item
        w = _ui7.build_task_row(self, item, f_edit, f_regen, f_del, f_view)
        self.lbl_idx = w["lbl_idx"]
        self.lbl_preview = w["lbl_preview"]
        self.lbl_status = w["lbl_status"]
        self.btn_edit = w["btn_edit"]
        self.btn_regen = w["btn_regen"]
        self.btn_del = w["btn_del"]
        self.btn_view = w["btn_view"]

    def reset_for_item(self, item: dict):
        """Dùng lại widget cho item mới — không destroy/create."""
        self._current_item = item
        rid = item["id"]
        self.lbl_idx.configure(text=f"{rid + 1:03d}")
        p_text = item.get("text", "").replace("\n", " ")
        if len(p_text) > 66:
            p_text = p_text[:66] + "…"
        self.lbl_preview.configure(text=p_text)
        self.btn_edit.configure(command=lambda r=rid: self._f_edit(r))
        self.btn_regen.configure(command=lambda r=rid: self._f_regen(r))
        self.btn_del.configure(command=lambda r=rid: self._f_del(r))
        fp = item.get("file_path")
        self.btn_view.configure(
            state="normal" if fp else "disabled",
            command=(lambda p=fp: self._f_view(p)) if fp else None,
        )
        self._apply_status_color(item.get("status", "Waiting..."))

    def _apply_status_color(self, st: str):
        self.lbl_status.configure(text=st, text_color=_ui7.task_status_color(st))

    def update_status(self, status_text: str, file_path: str = ""):
        self._apply_status_color(status_text)
        if any(k in status_text for k in ("Hoàn thành", "Đã có", "Xong", "Có video")) and file_path:
            self.btn_view.configure(state="normal", command=lambda p=file_path: self._f_view(p))


class IngredientsAppPro(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.all_prompts_data = []
        self.task_rows = {}
        self.image_cards = []
        self.current_page = 1
        self.items_per_page = 15
        self.worker = None
        self._shared_stop = threading.Event()
        self._all_stops = []
        self.uploaded_cache_map = {}
        self.image_groups = {}
        self._row_pool_t7 = []
        self.on_prompt_failed = None

        if os.path.exists("image_groups.json"):
            try:
                with open("image_groups.json", "r", encoding="utf-8") as f:
                    self.image_groups = json.load(f)
            except Exception:
                pass

        _ui7.setup_ui(self)
        self._last_prompts_sig = None
        self.load_image_folder()
        self._refresh_cache_hint()
        sample_file = os.path.join(get_app_dir(), "5_prompt_mau_dong_nhat.txt")
        if os.path.exists(sample_file):
            try:
                with open(sample_file, "r", encoding="utf-8") as f:
                    sample_lines = [
                        ln.strip()
                        for ln in f.read().splitlines()
                        if ln.strip() and not ln.strip().startswith("#")
                    ]
                if sample_lines:
                    self.txt_prompt.delete("1.0", "end")
                    self.txt_prompt.insert("1.0", "\n".join(sample_lines))
                    self._apply_manual_prompts()
            except Exception:
                pass

    def create_group_header(self, *args, **kwargs):
        """Giữ lại cho tương thích — giao diện mới tự chia nhóm trong ui_tool7.py."""
        pass

    def _refresh_cache_hint(self):
        """Cập nhật dòng 'x ảnh đã nhớ' ở tab Ảnh."""
        if not hasattr(self, "lbl_cache_hint"):
            return
        total = sum(len(v) for v in IMAGE_CACHE.data.values() if isinstance(v, dict))
        if total > 0:
            self.lbl_cache_hint.configure(text=f"{total} ảnh đã nhớ — lần sau khỏi tải lên lại", text_color=_T.OK)
        else:
            self.lbl_cache_hint.configure(text="Chưa nhớ ảnh nào", text_color=_T.MUTED)

    def _load_accounts_from_json(self):
        p = os.path.join(get_app_dir(), "tool7.json")
        if not os.path.exists(p):
            return []
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f).get("accounts", [])
        except Exception:
            return []

    def _save_accounts_to_json(self, accounts):
        p = os.path.join(get_app_dir(), "tool7.json")
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump({"accounts": accounts}, f, indent=2, ensure_ascii=False)
        except Exception as e:
            messagebox.showerror("Lỗi lưu", str(e))

    def _update_acc_count_label(self):
        if not hasattr(self, "lbl_acc_count"):
            return
        accs = self._load_accounts_from_json()
        full = sum(1 for a in accs if a.get("token") and a.get("project_id"))
        if not accs:
            self.lbl_acc_count.configure(text="Chưa có tài khoản nào.", text_color=_T.MUTED)
        else:
            self.lbl_acc_count.configure(
                text=f"{len(accs)} tài khoản · {full} cái đủ thông tin",
                text_color=_T.OK if full == len(accs) else "#e0a458",
            )

    def _render_account_list(self):
        self._update_acc_count_label()
        target = getattr(self, "_current_acc_list_frame", None)
        if target is None:
            return
        for w in target.winfo_children():
            w.destroy()
        accounts = self._load_accounts_from_json()
        if not accounts:
            ctk.CTkLabel(
                target,
                text="Chưa có tài khoản nào — bấm “Thêm tài khoản mới”.",
                text_color=_T.MUTED,
                font=_F.ui,
            ).pack(pady=24)
            return
        for i, acc in enumerate(accounts):
            _ui7.account_row(self, target, i, acc)

    def _delete_account(self, idx):
        accounts = self._load_accounts_from_json()
        if 0 <= idx < len(accounts):
            accounts.pop(idx)
            self._save_accounts_to_json(accounts)
            self._render_account_list()

    def _close_acc_mgr(self, dlg):
        self._current_acc_list_frame = None
        dlg.destroy()

    def open_account_manager(self):
        top = self.winfo_toplevel()
        if hasattr(top, "open_shared_veo_accounts"):
            top.open_shared_veo_accounts()
            return
        dlg = _ui7.dialog(self, "Tài khoản Veo 3", 640, 560)
        head = _ui7.row(dlg)
        head.pack(fill="x", padx=18, pady=(16, 4))
        _ui7.lbl(head, "TÀI KHOẢN VEO 3", _T.TEXT_STRONG, _F.title).pack(side="left")
        _ui7.btn(dlg, "Thêm tài khoản mới", self.on_add_account).pack(fill="x", padx=18, pady=10)
        box = _ui7.card(dlg)
        box.pack(fill="both", expand=True, padx=18, pady=4)
        list_frame = ctk.CTkScrollableFrame(box, fg_color="transparent", corner_radius=0)
        list_frame.pack(fill="both", expand=True, padx=8, pady=8)
        self._current_acc_list_frame = list_frame
        self._render_account_list()
        footer = _ui7.row(dlg)
        footer.pack(fill="x", padx=18, pady=12)
        _ui7.sbtn(footer, "Đóng", lambda: self._close_acc_mgr(dlg), width=96).pack(side="right")
        dlg.protocol("WM_DELETE_WINDOW", lambda: self._close_acc_mgr(dlg))

    def on_add_account(self):
        dlg = _ui7.dialog(self, "Thêm tài khoản Veo", 600, 500, grab=True)
        txt = ctk.CTkTextbox(dlg, height=220)
        txt.pack(fill="both", expand=True, padx=20, pady=12)

        def on_save():
            raw = txt.get("1.0", "end").strip()
            if not raw:
                return
            try:
                data = json.loads(raw)
                existing = self._load_accounts_from_json()
                existing_tokens = {a.get("token") for a in existing}
                for a in data.get("accounts", []):
                    tok = (a.get("token") or "").strip()
                    if tok and tok not in existing_tokens:
                        existing.append(
                            {
                                "email": a.get("email", ""),
                                "token": tok,
                                "project_id": (a.get("project_id") or "").strip(),
                                "credits": a.get("credits", "Unknown"),
                                "labs_session": (a.get("labs_session") or "").strip(),
                            }
                        )
                        existing_tokens.add(tok)
                self._save_accounts_to_json(existing)
                self._render_account_list()
                dlg.destroy()
            except Exception as e:
                messagebox.showerror("JSON không hợp lệ", str(e), parent=dlg)

        bar = _ui7.row(dlg)
        bar.pack(fill="x", padx=20, pady=14)
        _ui7.btn_primary(bar, "Lưu tài khoản", on_save, width=126).pack(side="right")

    def import_cache_dialog(self):
        """Import mediaId ảnh cũ - hỗ trợ nhập đơn giản TÊN = mediaId."""
        win = _ui7.dialog(self, "Nhớ lại ảnh đã tải lên", 620, 480, grab=True)
        txt = ctk.CTkTextbox(win, height=200)
        txt.pack(fill="both", expand=True, padx=16, pady=12)
        txt.insert("1.0", "CHAR_01 = 99148e49-a953-49b3-a038-30f26ee61d03\n")

        def do_import():
            raw = txt.get("1.0", "end").strip()
            accs = self._load_accounts_from_json()
            tokens = [a.get("token") for a in accs if a.get("token")]
            for line in raw.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                name, mid = [x.strip() for x in line.split("=", 1)]
                if name and mid:
                    for tok in tokens:
                        IMAGE_CACHE.put(tok, f"imported/{name}", mid, custom_name=name)
            self._refresh_cache_hint()
            win.destroy()

        bar = _ui7.row(win)
        bar.pack(fill="x", padx=16, pady=10)
        _ui7.btn_primary(bar, "Nhớ vào cache", do_import, width=130).pack(side="right")

    def show_cache_viewer(self):
        """Hiển thị danh sách ảnh đã cache persistent (uploaded_images.json)."""
        win = _ui7.dialog(self, "Ảnh đã tải lên (nhớ sẵn)", 640, 460)
        txt = ctk.CTkTextbox(win, wrap="none", font=_F.mono_sm)
        txt.pack(fill="both", expand=True, padx=16, pady=12)
        txt.insert("1.0", json.dumps(IMAGE_CACHE.data, ensure_ascii=False, indent=2))

        def clear_cache():
            if messagebox.askyesno("Xác nhận", "Xóa toàn bộ image cache?", parent=win):
                IMAGE_CACHE.clear_all()
                self._refresh_cache_hint()
                win.destroy()

        bar = _ui7.row(win)
        bar.pack(fill="x", padx=16, pady=10)
        _ui7.btn_danger(bar, "Xoá hết cache", clear_cache, width=126).pack(side="right")

    def _pipe_set_images(self, paths: list):
        """
        Điểm nhận danh sách ảnh tham chiếu đẩy từ '🎨 Image đồng nhất' hoặc '📝 Prompt':
        Xoá sạch thẻ ảnh cũ, chuẩn hóa mã nhân vật (REF_CHAR_01 -> CHAR_01), và đối chiếu SHA-256
        để tuyệt đối không dùng lại ảnh cũ từ các phiên trước.
        """
        valid_paths = [os.path.abspath(p) for p in (paths or []) if p and os.path.isfile(p)]
        if not valid_paths:
            return
        self.clear_images(manual=False)
        first_dir = os.path.dirname(valid_paths[0])
        if os.path.isdir(first_dir):
            self.entry_img_folder.delete(0, "end")
            self.entry_img_folder.insert(0, first_dir)

        for fp in valid_paths:
            raw_stem = os.path.splitext(os.path.basename(fp))[0]
            default_id = ImageCache._normalize_ref_id(raw_stem) or raw_stem
            card = ModernImageCard(self.img_scroll, fp, default_id, self.remove_image_card)
            mid = IMAGE_CACHE.get("default", fp, name=default_id)
            if mid:
                card.set_uploaded(mid)
            self.image_cards.append(card)
        self._refresh_cache_hint()
        self.log(
            f"📥 Đã nạp {len(self.image_cards)} ảnh tham chiếu mới ({', '.join(c.get_id() for c in self.image_cards)})."
        )

    def load_image_folder(self):
        """Auto-load tất cả ảnh từ thư mục vào sidebar (tự chuẩn hóa REF_CHAR_01 -> CHAR_01)."""
        folder = self.entry_img_folder.get().strip()
        if not folder:
            return
        if not os.path.isabs(folder) and not os.path.exists(folder):
            folder = os.path.join(get_app_dir(), folder)
        if not os.path.exists(folder):
            return
        exts = {".jpeg", ".jpg", ".png", ".webp", ".bmp"}
        files = sorted(
            [os.path.join(folder, f) for f in os.listdir(folder) if os.path.splitext(f)[1].lower() in exts]
        )
        self.clear_images(manual=False)
        for fp in files:
            raw_stem = os.path.splitext(os.path.basename(fp))[0]
            default_id = ImageCache._normalize_ref_id(raw_stem) or raw_stem
            card = ModernImageCard(self.img_scroll, fp, default_id, self.remove_image_card)
            mid = IMAGE_CACHE.get("default", fp, name=default_id)
            if mid:
                card.set_uploaded(mid)
            self.image_cards.append(card)
        self._refresh_cache_hint()

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.webp")])
        if not files:
            return
        self._images_manually_cleared = False
        for fp in files:
            raw_stem = os.path.splitext(os.path.basename(fp))[0]
            default_id = ImageCache._normalize_ref_id(raw_stem) or raw_stem
            # Nếu đã có thẻ cùng mã nhân vật trên giao diện, thay thế thẻ cũ và xoá cache cũ của mã đó
            for old_c in list(self.image_cards):
                if ImageCache._normalize_ref_id(old_c.get_id()) == default_id:
                    self.image_cards.remove(old_c)
                    old_c.destroy()
            IMAGE_CACHE.remove("default", default_id)
            card = ModernImageCard(self.img_scroll, fp, default_id, self.remove_image_card)
            mid = IMAGE_CACHE.get("default", fp, name=default_id)
            if mid:
                card.set_uploaded(mid)
            self.image_cards.append(card)
        self._refresh_cache_hint()

    def remove_image_card(self, card):
        if card in self.image_cards:
            uid = card.get_id()
            IMAGE_CACHE.remove("default", uid)
            self.image_cards.remove(card)
            card.destroy()
            if not self.image_cards:
                self._images_manually_cleared = True

    def clear_images(self, manual: bool = True):
        for c in list(self.image_cards):
            c.destroy()
        self.image_cards.clear()
        if manual:
            self._images_manually_cleared = True
            IMAGE_CACHE.clear_all()
            self.uploaded_cache_map.clear()
            self._refresh_cache_hint()
        else:
            self._images_manually_cleared = False

    def clear_prompts_only(self):
        """Xoá trắng ô prompt và danh sách hàng đợi phân cảnh."""
        self.txt_prompt.delete("1.0", "end")
        self.all_prompts_data.clear()
        self.render_pagination()
        self.log("🧹 Đã xoá trắng danh sách Prompt trên tab Video đồng nhất.")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ ảnh nhân vật, cache mediaId, prompt và hàng đợi từ lần dùng trước."""
        if self.worker and self.worker.is_alive():
            if ask_confirm:
                messagebox.showwarning("Đang chạy", "Hãy bấm Dừng tạo trước khi làm sạch dữ liệu!")
            return
        if ask_confirm:
            ans = messagebox.askyesnocancel(
                "Làm sạch dữ liệu Video đồng nhất",
                "Bạn muốn làm sạch toàn bộ Ảnh nhân vật mẫu, Cache ảnh, Prompt & Hàng đợi từ lần dùng trước?\n\n"
                "• Chọn YES: Xoá sạch Ảnh mẫu + Cache + Prompt + Xoá các file ảnh/video cũ trong ổ đĩa\n"
                "• Chọn NO: Chỉ xoá sạch Ảnh mẫu, Cache & Prompt trên giao diện (giữ file trong ổ đĩa)\n"
                "• Chọn CANCEL: Huỷ bỏ",
            )
            if ans is None:
                return
            delete_files = bool(ans)

        self.clear_images(manual=True)
        IMAGE_CACHE.clear_all()
        self.uploaded_cache_map.clear()
        self._refresh_cache_hint()
        self.txt_prompt.delete("1.0", "end")
        self.all_prompts_data.clear()
        self.render_pagination()

        removed_cnt = 0
        if delete_files:
            folders_to_clean = set()
            cur_char_dir = self.entry_img_folder.get().strip() or "characters"
            if not os.path.isabs(cur_char_dir):
                cur_char_dir = os.path.join(get_app_dir(), cur_char_dir)
            folders_to_clean.add(cur_char_dir)
            folders_to_clean.add(os.path.join(get_app_dir(), "characters"))

            for char_dir in folders_to_clean:
                if os.path.isdir(char_dir):
                    for fn in os.listdir(char_dir):
                        if fn.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp")):
                            try:
                                os.remove(os.path.join(char_dir, fn))
                                removed_cnt += 1
                            except Exception:
                                pass

            out_dir = self.entry_out.get().strip() or "Video_Result"
            if not os.path.isabs(out_dir):
                out_dir = os.path.join(get_app_dir(), out_dir)
            if os.path.isdir(out_dir):
                for fn in os.listdir(out_dir):
                    if fn.lower().endswith(".mp4") or fn in (".prompt_manifest.json", "list.txt"):
                        try:
                            os.remove(os.path.join(out_dir, fn))
                            removed_cnt += 1
                        except Exception:
                            pass

        extra = f" (đã xoá {removed_cnt} file cũ)" if delete_files else ""
        self.log(f"🧹 Đã làm sạch toàn bộ Ảnh mẫu, Cache & Prompt cũ{extra}.")

    def batch_upload_thread(self):
        threading.Thread(target=self.run_batch_upload, daemon=True).start()

    def run_batch_upload(self):
        accs = self._load_accounts_from_json()
        tokens = [a.get("token") for a in accs if a.get("token")]
        if not tokens or not self.image_cards:
            return
        raw_ratio = self.cbo_ratio.get()
        img_ratio_enum = "IMAGE_ASPECT_RATIO_PORTRAIT" if "9:16" in raw_ratio else "IMAGE_ASPECT_RATIO_LANDSCAPE"
        for tok in tokens:
            backend = VeoBackend(tok)
            for card in list(self.image_cards):
                path = card.get_path()
                uid = ImageCache._normalize_ref_id(card.get_id()) or card.get_id()
                if IMAGE_CACHE.get(tok, path, name=uid):
                    card.set_uploaded()
                    continue
                cap = backend.get_recaptcha()
                if not cap:
                    continue
                mid = backend.upload_user_image(path, aspect_ratio_enum=img_ratio_enum, recaptcha_token=cap)
                if mid:
                    IMAGE_CACHE.put(tok, path, mid, custom_name=uid)
                    card.set_uploaded(mid)
        self._refresh_cache_hint()

    def _build_image_map(self) -> dict:
        """
        Chỉ lấy danh sách ảnh tham chiếu ĐANG HIỂN THỊ TRÊN GIAO DIỆN (self.image_cards),
        đồng thời ánh xạ cả mã chuẩn CHAR_01 lẫn REF_CHAR_01.
        Tuyệt đối không tự ý quét ngầm thư mục characters/ cũ hay cache cũ đã xoá!
        """
        if not self.image_cards and not getattr(self, "_images_manually_cleared", False):
            self.load_image_folder()
        current_map = {}
        for card in self.image_cards:
            p = card.get_path()
            if not p or not os.path.isfile(p):
                continue
            raw_uid = card.get_id().strip().upper()
            norm_uid = ImageCache._normalize_ref_id(raw_uid)
            if raw_uid:
                current_map[raw_uid] = p
            if norm_uid:
                current_map[norm_uid] = p
                current_map[f"REF_{norm_uid}"] = p
        return current_map

    def clear_log(self):
        lg = getattr(self, "_logger", None)
        if lg is not None and hasattr(lg, "_buf") and hasattr(lg, "_lock"):
            try:
                with lg._lock:
                    lg._buf.clear()
            except Exception:
                pass
        try:
            self.log_box.configure(state="normal")
            self.log_box.delete("1.0", "end")
            self.log_box.configure(state="disabled")
        except Exception:
            pass

    def _sync_txt_prompt_from_data(self):
        """Đồng bộ ngược danh sách all_prompts_data về ô txt_prompt để sửa thủ công không bao giờ bị ghi đè."""
        lines = [str(x.get("text") or "").strip() for x in self.all_prompts_data if str(x.get("text") or "").strip()]
        self._last_prompts_sig = tuple(lines)
        self.txt_prompt.delete("1.0", "end")
        if lines:
            self.txt_prompt.insert("1.0", "\n".join(lines))

    def _apply_manual_prompts(self):
        raw = self.txt_prompt.get("1.0", "end").strip()
        if not raw:
            messagebox.showwarning("Chú ý", "Ô prompt đang trống!")
            return
        lines = [ln.strip() for ln in raw.splitlines() if ln.strip() and not ln.strip().startswith("#")]
        sig = tuple(lines)
        if getattr(self, "_last_prompts_sig", None) != sig:
            self._last_prompts_sig = sig
            self.clear_log()
        out_dir = self.entry_out.get().strip() or "Video_Result"
        os.makedirs(out_dir, exist_ok=True)
        existing = {
            f: os.path.getsize(os.path.join(out_dir, f))
            for f in os.listdir(out_dir)
            if f.endswith(".mp4")
        }
        self.all_prompts_data = []
        for idx, ln in enumerate(lines):
            fp, ok = resolve_existing_video(idx, out_dir, existing=existing, prompt_text=ln)
            self.all_prompts_data.append(
                {
                    "id": idx,
                    "text": ln,
                    "raw_text": ln,
                    "status": "✅ Đã có file" if ok else "Waiting...",
                    "file_path": fp or "",
                    "force_regen": False,
                }
            )
        self.render_pagination()

    def choose_file(self):
        f = filedialog.askopenfilename(filetypes=[("Data Files", "*.json *.txt"), ("All Files", "*.*")])
        if not f:
            return
        try:
            with open(f, "r", encoding="utf-8", errors="ignore") as fp:
                content = fp.read()
            self.clear_log()
            self.txt_prompt.delete("1.0", "end")
            self.txt_prompt.insert("1.0", content)
            self._apply_manual_prompts()
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không đọc được file: {e}")

    def choose_output_folder(self):
        d = filedialog.askdirectory()
        if d:
            self.entry_out.delete(0, "end")
            self.entry_out.insert(0, d)

    def render_pagination(self):
        """Tái sử dụng TaskRow pool thay vì destroy/rebuild."""
        total_pages = max(1, math.ceil(len(self.all_prompts_data) / self.items_per_page))
        self.current_page = max(1, min(self.current_page, total_pages))
        self.lbl_page.configure(text=f"Trang {self.current_page}/{total_pages}")

        start_idx = (self.current_page - 1) * self.items_per_page
        page_items = self.all_prompts_data[start_idx : start_idx + self.items_per_page]
        self.task_rows.clear()

        while len(self._row_pool_t7) < len(page_items):
            dummy = {"id": 0, "text": "", "status": "Waiting...", "file_path": ""}
            tr = TaskRow(self.task_frame, dummy, self.on_edit, self.on_regen, self.on_delete, self.on_view)
            self._row_pool_t7.append(tr)

        for idx, item in enumerate(page_items):
            row_w = self._row_pool_t7[idx]
            row_w.reset_for_item(item)
            row_w.pack(fill="x", pady=3, padx=5)
            self.task_rows[item["id"]] = row_w

        for extra in self._row_pool_t7[len(page_items) :]:
            extra.pack_forget()

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.render_pagination()

    def next_page(self):
        total_pages = max(1, math.ceil(len(self.all_prompts_data) / self.items_per_page))
        if self.current_page < total_pages:
            self.current_page += 1
            self.render_pagination()

    def on_edit(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item:
            return
        dlg = _ui7.dialog(self, f"✏️ Sửa thủ công Prompt #{row_id + 1}", 640, 340, grab=True)
        txt = ctk.CTkTextbox(dlg, height=210, wrap="word")
        txt.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        txt.insert("1.0", item["text"])

        def _apply_edit(run_now: bool = False):
            nw = txt.get("1.0", "end").strip()
            if nw:
                item["text"] = nw
                item["raw_text"] = nw
                self._sync_txt_prompt_from_data()
                self.render_pagination()
                self.log(f"✏️ Đã lưu chỉnh sửa thủ công cho Prompt #{row_id + 1}.")
                if run_now:
                    self.submit_single_task(item, force_regen=True)
            dlg.destroy()

        bar = _ui7.row(dlg)
        bar.pack(fill="x", padx=16, pady=(0, 14))
        _ui7.btn_primary(bar, "▶ Lưu và chạy ngay", lambda: _apply_edit(True), width=150).pack(side="right", padx=(6, 0))
        _ui7.sbtn(bar, "💾 Lưu thay đổi", lambda: _apply_edit(False), width=124).pack(side="right", padx=(6, 0))
        _ui7.sbtn(bar, "Huỷ", dlg.destroy, width=76).pack(side="right")

    def on_regen(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if item:
            self.submit_single_task(item, force_regen=True)

    def on_delete(self, row_id):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if item and item.get("file_path") and os.path.exists(item["file_path"]):
            if messagebox.askyesno("Confirm", "Xóa video này?"):
                try:
                    os.remove(item["file_path"])
                    item["file_path"] = ""
                    item["status"] = "Deleted"
                    self.render_pagination()
                except Exception as e:
                    messagebox.showerror("Error", str(e))

    def on_view(self, path):
        if path and os.path.exists(path):
            try:
                os.startfile(path)
            except Exception:
                pass

    def submit_single_task(self, item: dict, force_regen: bool = True):
        image_map = self._build_image_map()
        files, clean_p = resolve_images_for_prompt(
            item["text"], image_map, group_map=self.image_groups, logger=self.log, prompt_id=item["id"]
        )
        task_copy = dict(item)
        task_copy["raw_text"] = item.get("raw_text") or item["text"]
        task_copy["text"] = clean_p
        task_copy["ingredient_files"] = files
        task_copy["force_regen"] = force_regen
        if self.worker and self.worker.is_alive():
            self.worker.task_queue.put(task_copy)
        else:
            q = queue.Queue()
            q.put(task_copy)
            self._start_worker_with_queue(q)

    def _start_worker_with_queue(self, q: queue.Queue):
        try:
            threads = int(self.entry_thread.get())
        except Exception:
            threads = 1

        voice_raw = self.cbo_voice.get()
        voice_id = None
        if not voice_raw.startswith("(Không"):
            voice_id = voice_raw.split(" — ")[0].replace("⭐", "").strip().lower()

        fixed_seed = random.randint(10000, 999999) if self.chk_fixed_seed_var.get() else None
        ext_str = self.cbo_extend.get()
        extend_count = 1 if "1 lần" in ext_str else (2 if "2 lần" in ext_str else (3 if "3 lần" in ext_str else 0))

        config = {
            "model": self.cbo_model.get(),
            "ratio": self.cbo_ratio.get(),
            "duration": self.cbo_duration.get(),
            "account_type": self.cbo_account_type.get(),
            "upscale_mode": self.cbo_upscale.get(),
            "out_dir": self.entry_out.get().strip() or "Video_Result",
            "threads": threads,
            "voice_id": voice_id,
            "fixed_seed": fixed_seed,
            "extend_count": extend_count,
        }
        self._shared_stop = threading.Event()
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.worker = IngredientsWorker(
            q,
            config,
            self.log,
            self.update_status_ui,
            self.on_finish,
            global_image_cache=self.uploaded_cache_map,
            on_prompt_failed=self.on_prompt_failed,
            shared_stop=self._shared_stop,
        )
        self.worker.start()

    def start_process(self):
        self.clear_log()
        self._apply_manual_prompts()
        if not self.all_prompts_data:
            messagebox.showerror("Lỗi", "Chưa có prompt nào!")
            return
        image_map = self._build_image_map()
        q = queue.Queue()
        for item in self.all_prompts_data:
            files, clean_p = resolve_images_for_prompt(
                item["text"], image_map, group_map=self.image_groups, logger=self.log, prompt_id=item["id"]
            )
            try:
                import flowkit_engine

                style_val = self.cbo_style.get() if hasattr(self, "cbo_style") else ""
                clean_p, _, _ = flowkit_engine.apply_style_to_prompt(clean_p, style_val)
            except Exception:
                pass
            task_copy = dict(item)
            task_copy["raw_text"] = item.get("raw_text") or item["text"]
            task_copy["text"] = clean_p
            task_copy["ingredient_files"] = files
            q.put(task_copy)
        self._start_worker_with_queue(q)

    def stop_process(self):
        self._shared_stop.set()
        if self.worker:
            self.worker.stop()
        self.log("✅ Đã ngắt hàng đợi API.")

    def update_status_ui(self, row_id, status, path=""):
        self.after(0, lambda: self._apply_row_status(row_id, status, path))

    def _apply_row_status(self, row_id, status, path=""):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if item:
            item["status"] = status
            if path:
                item["file_path"] = path
        if row_id in self.task_rows:
            self.task_rows[row_id].update_status(status, path)

    def on_finish(self):
        self.after(0, lambda: (self.btn_start.configure(state="normal"), self.btn_stop.configure(state="disabled")))
        self.log("🏁 ĐÃ XONG (FINISHED).")
        try:
            top = self.winfo_toplevel()
            if hasattr(top, "trigger_auto_shutdown_if_enabled"):
                top.after(0, top.trigger_auto_shutdown_if_enabled)
        except Exception:
            pass

    def log(self, msg):
        lg = getattr(self, "_logger", None)
        if lg is None:
            try:
                from log_utils import attach_logger
                attach_logger(self, self.log_box, tk_master=self)
                lg = self._logger
            except Exception:
                return
        lg.log(f"> {msg}")

    def merge_video(self):
        folder = self.entry_out.get().strip() or "Video_Result"
        if not os.path.isabs(folder) and not os.path.exists(folder):
            folder = os.path.join(get_app_dir(), folder)
        if not os.path.exists(folder):
            messagebox.showwarning("Chưa có thư mục", f"Thư mục đầu ra chưa tồn tại:\n{folder}")
            return
        videos = sorted([
            f for f in os.listdir(folder)
            if f.lower().endswith(".mp4") and "merged" not in f.lower() and "_tmp" not in f.lower()
        ])
        if len(videos) < 2:
            messagebox.showinfo("Thông báo", "Cần ít nhất 2 file video (.mp4) trong thư mục đầu ra để nối thành phim dài.")
            return
        list_file = os.path.join(folder, "list.txt")
        with open(list_file, "w", encoding="utf-8") as f:
            for vid in videos:
                safe_p = os.path.join(os.path.abspath(folder), vid).replace("'", "'\\''")
                f.write(f"file '{safe_p}'\n")
        output = os.path.join(folder, f"merged_{int(time.time())}.mp4")
        try:
            flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            subprocess.run(
                ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", list_file, "-c", "copy", output],
                check=True,
                creationflags=flags,
            )
            messagebox.showinfo("Hoàn tất nối phim", f"Đã nối {len(videos)} cảnh thành công:\n{output}")
        except Exception as e:
            messagebox.showerror("Lỗi FFmpeg", str(e))
        finally:
            if os.path.exists(list_file):
                os.remove(list_file)


_app_instance = None


def create_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Điểm vào cho All-Tool-Youtube. parent là CTkFrame do alltool cấp."""
    global _app_instance
    try:
        start_nestjs_server()
    except Exception:
        pass
    _app_instance = IngredientsAppPro(parent)
    _app_instance.pack(fill="both", expand=True)
    return _app_instance


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Tên gọi cũ, giữ cho tương thích ngược."""
    return create_tab(parent, openai_client=openai_client, gemini_model=gemini_model, *args, **kwargs)
