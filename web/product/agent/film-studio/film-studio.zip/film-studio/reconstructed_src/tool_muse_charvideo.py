"""
tool_muse_charvideo.py — Tạo VIDEO NHÂN VẬT ĐỒNG NHẤT bằng MUSE (muse.ai).

Mọi video ở tab này do Muse dựng:
  • Chrome/Edge chạy ngầm với profile đã đăng nhập muse.ai (thư mục muse_profiles/).
  • Ảnh nhân vật gửi THẲNG kèm tin nhắn (base64) — không phải upload trước,
    nên không còn chuyện blob hết hạn làm sai nhân vật.
  • Mỗi luồng là một tab Muse riêng; nhiều tài khoản thì xoay vòng profile.
  • Tích hợp nhận diện Phong cách từ Prompt + cho phép gõ phong cách tùy chỉnh từ bàn phím.
"""

import contextlib
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
from PIL import Image

from ui import (
    T,
    F,
    set_density_early,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    lbl,
    TabStrip,
    sbtn,
    opt,
    combo,
    entry,
    grid_field,
    note,
    group,
    _scroll,
    dialog,
    status_color,
    track_log_follow,
)
import muse_backend as muse
from flowkit_engine import DEFAULT_STYLE_VALUES, resolve_effective_style, apply_style_to_prompt

APP_DIR = os.path.dirname(os.path.abspath(__file__))

RATIOS = {
    "Ngang 16:9": "16:9",
    "Dọc 9:16": "9:16",
    "Vuông 1:1": "1:1",
    "Ngang 4:3": "4:3",
    "Dọc 3:4": "3:4",
}
DURATIONS = ["4s", "6s", "8s", "10s", "15s", "20s", "30s"]
IMG_EXTS = (".png", ".jpg", ".jpeg", ".webp")
VIDEO_MIN_SIZE = 3500

_CHAR_TAG_IN_PROMPT = re.compile(r"\[([A-Za-z0-9_\-]{1,32})\]")
_CHAR_PREFIX = re.compile(r"^\s*([A-Za-z0-9_\-]+(?:\s*,\s*[A-Za-z0-9_\-]+)*)\s*\|\s*(.*)$", re.DOTALL)


def _in_dir(path: str, root: str) -> bool:
    p = os.path.normcase(os.path.abspath(path)).rstrip("\\/")
    r = os.path.normcase(os.path.abspath(root)).rstrip("\\/")
    return p == r or p.startswith(r + os.sep)


def resolve_tags(prompt: str):
    """Tách nhân vật khỏi prompt, nhận CẢ 2 kiểu:
      • Prefix:  'CHAR_01,CHAR_03 | nội dung'   (NOCHAR = không gắn ảnh)
      • Ngoặc:   '[CHAR_01] nội dung'
    Trả (prompt_sạch, [TAG…]) — giữ thứ tự, bỏ trùng, bỏ NOCHAR."""
    text = (prompt or "").strip()
    tags = []
    m = _CHAR_PREFIX.match(text)
    if m:
        raw_tags, text = m.group(1), m.group(2).strip()
        for t in raw_tags.split(","):
            tu = t.strip().upper()
            if tu and tu != "NOCHAR" and tu not in tags:
                tags.append(tu)
    for mm in _CHAR_TAG_IN_PROMPT.finditer(text):
        tu = mm.group(1).strip().upper()
        if tu and tu != "NOCHAR" and tu not in tags:
            tags.append(tu)
    clean = _CHAR_TAG_IN_PROMPT.sub(lambda x: x.group(1), text).strip()
    return clean, tags


class _AliveProbe:
    def __init__(self, app):
        self._app = app

    def is_alive(self) -> bool:
        return bool(self._app.running or self._app._single_busy)


class App(ctk.CTkFrame):
    def __init__(self, master=None, **kw):
        self._standalone = master is None
        if self._standalone:
            set_density_early()
            root = ctk.CTk()
            root.title("Video Nhân Vật — Muse")
            root.geometry("1240x800")
            root.minsize(1000, 660)
            root.configure(fg_color=T.BG)
            F.init()
            super().__init__(root, fg_color=T.BG, **kw)
            self.pack(fill="both", expand=True)
            self._top_win = root
        else:
            F.init()
            super().__init__(master, fg_color=T.BG, **kw)
            self._top_win = master.winfo_toplevel()

        self.accounts = []
        self.pool = None
        self.all_prompts_data = []
        self.rows_ui = {}
        self.current_page = 1
        self.items_per_page = 15
        self.running = False
        self._single_busy = 0
        self.stop_flag = threading.Event()
        self._send_lock = threading.Lock()
        self._last_send = 0.0
        self.send_gap = 1.5
        self.worker = _AliveProbe(self)
        self._busy_lock = threading.Lock()
        self._run_tok = 0
        self._busy_dst = set()
        self._pipe_root = ""
        self.on_prompt_failed = None
        self._review_on = False
        self._pipeline_mode = False
        self._pipe_img_map = {}
        self._pipe_img_folder = ""
        self._out_dir = os.path.join(APP_DIR, "Video_Muse_Result")
        self._img_snap = {}
        self._style_snap = DEFAULT_STYLE_VALUES[0]
        self._show_browser_snap = False
        self._thumb_refs = []
        self._row_thumb_cache = {}

        sw = self.winfo_screenwidth()
        self._left_w = 420 if sw >= 1400 else 380

        self.grid_columnconfigure(0, weight=0, minsize=self._left_w)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_left()
        self._build_right()
        self._load_accounts()
        self._refresh_images()

    def _build_left(self):
        col = row(self)
        col.grid(row=0, column=0, sticky="nsew", padx=(T.PAD, T.GAP), pady=T.PAD)
        col.rowconfigure(0, weight=1)
        col.columnconfigure(0, weight=1)

        holder = card(col)
        holder.grid(row=0, column=0, sticky="nsew")
        holder.rowconfigure(1, weight=1)
        holder.columnconfigure(0, weight=1)

        self.tabs = TabStrip(holder, height=28, minw=80)
        t_acc = self.tabs.add("👤 Tài khoản & Ảnh")
        t_cfg = self.tabs.add("⚙️ Cấu hình & Prompt")
        self.tabs.grid(row=0, column=0)

        self._acc_img_tab(_scroll(t_acc))
        self._cfg_tab(_scroll(t_cfg))
        self.tabs.set("⚙️ Cấu hình & Prompt")

        self._action_bar(col)

    def _acc_img_tab(self, box):
        box.columnconfigure(1, weight=1)
        r = 0
        group(box, r, "Tài khoản Muse (Chrome Profile)"); r += 1

        btn(
            box,
            "👤  Quản lý tài khoản Muse",
            command=self._account_manager,
            fg_color="#0f293a",
            hover_color="#163b52",
            border_color=T.ACCENT,
            text_color="#7ce8ff",
        ).grid(row=r, column=0, columnspan=2, sticky="ew", pady=(2, 4)); r += 1

        self.lbl_acc_count = lbl(box, "đang đọc…", T.MUTED, F.label, anchor="w")
        self.lbl_acc_count.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(2, 4)); r += 1

        br = row(box)
        br.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(0, 6)); r += 1
        br.columnconfigure(0, weight=1)
        br.columnconfigure(1, weight=1)
        sbtn(br, "🔄 Nạp lại", self._load_accounts).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        sbtn(br, "🔎 Kiểm tra", self._check_accounts).grid(row=0, column=1, sticky="ew", padx=(3, 0))

        group(box, r, "Ảnh nhân vật (TAG)"); r += 1
        frm = row(box)
        frm.grid(row=r, column=0, columnspan=2, sticky="ew", pady=2); r += 1
        frm.columnconfigure(0, weight=1)

        self.entry_img_folder = entry(frm, placeholder_text="Thư mục ảnh (vd: characters)")
        default_chars = os.path.join(APP_DIR, "Scene_Images", "Refs")
        if not os.path.isdir(default_chars):
            default_chars = os.path.join(APP_DIR, "characters")
        os.makedirs(default_chars, exist_ok=True)
        self.entry_img_folder.insert(0, default_chars)
        self.entry_img_folder.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.entry_img_folder.bind("<FocusOut>", lambda _e: self._on_img_folder_edit())

        sbtn(frm, "Chọn…", self._pick_img_folder, width=58).grid(row=0, column=1, padx=(0, 3))
        sbtn(frm, "🧹 Xoá ảnh", self.clear_character_images, width=76).grid(row=0, column=2)

        self.lbl_imgs = lbl(box, "chưa có ảnh", T.MUTED, F.tiny, anchor="w", justify="left", wraplength=320)
        self.lbl_imgs.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(2, 4)); r += 1

        self.img_gallery = ctk.CTkScrollableFrame(
            box,
            height=210,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            scrollbar_fg_color=T.CARD,
            scrollbar_button_color="#3a3d4d",
            scrollbar_button_hover_color=T.ACCENT,
        )
        self.img_gallery.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(2, 6)); r += 1

        note(
            box,
            r,
            "Đặt tên ảnh theo TAG: CHAR_01.png, KING.jpg… Prompt gọi ảnh bằng prefix "
            "'CHAR_01,CHAR_03 | nội dung cảnh' hoặc [CHAR_01]. Ảnh được gửi thẳng kèm prompt sang Muse.",
        )

    def _cfg_tab(self, outer):
        outer.columnconfigure(1, weight=1)
        r = 0
        group(outer, r, "Thông số Video Muse"); r += 1

        self.cbo_duration = opt(outer, DURATIONS)
        self.cbo_duration.set("8s")
        grid_field(outer, r, "Thời lượng", self.cbo_duration); r += 1

        self.cbo_ratio = opt(outer, list(RATIOS.keys()))
        self.cbo_ratio.set("Ngang 16:9")
        grid_field(outer, r, "Tỷ lệ khung", self.cbo_ratio); r += 1

        self.cbo_style = combo(outer, DEFAULT_STYLE_VALUES, state="normal")
        self.cbo_style.set(DEFAULT_STYLE_VALUES[0])
        grid_field(outer, r, "Phong cách", self.cbo_style); r += 1

        self.entry_thread = entry(outer, width=80)
        self.entry_thread.insert(0, "2")
        grid_field(outer, r, "Số luồng", self.entry_thread); r += 1

        self.chk_show_browser_var = tk.BooleanVar(value=False)
        chk = ctk.CTkCheckBox(
            outer,
            text="Hiện cửa sổ Chrome khi chạy",
            variable=self.chk_show_browser_var,
            checkbox_height=18,
            checkbox_width=18,
            corner_radius=4,
            fg_color=T.ACCENT,
            hover_color=T.ACCENT_HOVER,
            border_color=T.BORDER,
            text_color=T.TEXT_DIM,
            font=F.label,
        )
        chk.grid(row=r, column=0, columnspan=2, sticky="w", pady=(4, 4)); r += 1

        note(
            outer,
            r,
            "Mỗi luồng là 1 tab Muse chạy ngầm. Phong cách có thể tự nhận diện từ Prompt hoặc gõ trực tiếp từ bàn phím.",
        ); r += 1

        ctk.CTkFrame(outer, height=1, fg_color=T.DIVIDER).grid(row=r, column=0, columnspan=2, sticky="ew", pady=6); r += 1

        group(outer, r, "Danh sách Prompt (Mỗi dòng 1 cảnh)"); r += 1
        f_row = row(outer)
        f_row.grid(row=r, column=0, columnspan=2, sticky="ew", pady=2); r += 1
        sbtn(f_row, "📂 Chọn file prompt (TXT)", self.choose_file, width=155).pack(side="left")
        sbtn(f_row, "🧹 Xoá trắng", self.clear_prompts_only, width=82).pack(side="right")
        self.lbl_file = lbl(f_row, "chưa chọn file", T.MUTED, F.tiny)
        self.lbl_file.pack(side="left", padx=6)

        lbl(outer, "Mỗi dòng 1 video:  CHAR_01,CHAR_03 | nội dung cảnh", T.LABEL, F.tiny, anchor="w").grid(
            row=r, column=0, columnspan=2, sticky="ew", pady=(2, 2)
        ); r += 1

        self.txt_prompt_input = ctk.CTkTextbox(
            outer,
            height=175,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER,
            border_width=1,
            text_color=T.TEXT,
            font=F.ui,
            wrap="word",
        )
        self.txt_prompt_input.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(2, 6)); r += 1
        self.txt_prompt_input.bind("<KeyRelease>", lambda _e: self.scan_prompts_and_files())

        out_row = row(outer)
        out_row.grid(row=r, column=0, columnspan=2, sticky="ew", pady=2); r += 1
        out_row.columnconfigure(0, weight=1)
        self.entry_out_dir = entry(out_row)
        os.makedirs(self._out_dir, exist_ok=True)
        self.entry_out_dir.insert(0, self._out_dir)
        self.entry_out_dir.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.entry_out_dir.bind("<FocusOut>", lambda _e: self.scan_prompts_and_files())
        sbtn(out_row, "Chọn…", self.choose_output_folder, width=64).grid(row=0, column=1)

    def _action_bar(self, col):
        inner = card(col)
        inner.grid(row=1, column=0, sticky="ew", pady=(T.GAP, 0))
        inner.columnconfigure(0, weight=1)
        inner.columnconfigure(1, weight=1)

        self.btn_start = btn_primary(inner, "Tạo video", command=self.start_process)
        self.btn_start.grid(row=0, column=0, sticky="ew", padx=(T.PADC, 4), pady=(T.PADC, 6))

        self.btn_stop = btn_danger(inner, "Dừng tạo", command=self.stop_process, state="disabled")
        self.btn_stop.grid(row=0, column=1, sticky="ew", padx=(4, T.PADC), pady=(T.PADC, 6))

        self.progress = ctk.CTkProgressBar(inner, height=6, corner_radius=3, fg_color=T.INPUT, progress_color=T.ACCENT)
        self.progress.set(0)
        self.progress.grid(row=1, column=0, columnspan=2, sticky="ew", padx=T.PADC, pady=(0, T.PADC))

    def _build_right(self):
        right = row(self)
        right.grid(row=0, column=1, sticky="nsew", padx=(0, T.PAD), pady=T.PAD)
        right.rowconfigure(0, weight=3)
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)

        holder = card(right)
        holder.grid(row=0, column=0, sticky="nsew", pady=(0, T.GAP))
        holder.rowconfigure(1, weight=1)
        holder.columnconfigure(0, weight=1)

        head = row(holder)
        head.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(T.PADC, 6))

        lbl(head, "DANH SÁCH PROMPT (MUSE AI)", T.TEXT_STRONG, F.ui_sb).pack(side="left", padx=(0, 12))
        self.btn_prev_page = sbtn(head, "‹", self.prev_page, width=30)
        self.btn_prev_page.pack(side="left")
        self.lbl_page_info = lbl(head, "Trang 0/0", T.MUTED, F.tiny)
        self.lbl_page_info.pack(side="left", padx=8)
        self.btn_next_page = sbtn(head, "›", self.next_page, width=30)
        self.btn_next_page.pack(side="left")

        sbtn(head, "📂 Mở thư mục", self._open_out, width=92).pack(side="right", padx=(4, 0))
        sbtn(head, "🧹 Làm sạch cũ", lambda: self.clear_previous_session(ask_confirm=True), width=104).pack(side="right", padx=4)
        sbtn(head, "📝 Lý do từ chối", self._open_refusals, width=108).pack(side="right", padx=4)
        sbtn(head, "🎞 Ghép video", self.merge_video, width=92).pack(side="right", padx=4)

        self.list_frame = ctk.CTkScrollableFrame(
            holder,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_fg_color=T.CARD,
            scrollbar_button_color="#3a3d4d",
            scrollbar_button_hover_color=T.ACCENT,
        )
        self.list_frame.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        self._log_card(right)

    def _log_card(self, right):
        lc = card(right)
        lc.grid(row=1, column=0, sticky="nsew")
        lc.rowconfigure(1, weight=1)
        lc.columnconfigure(0, weight=1)

        lh = row(lc)
        lh.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(8, 4))
        lbl(lh, "NHẬT KÝ HOẠT ĐỘNG", T.TEXT_STRONG, F.h).pack(side="left")
        sbtn(lh, "Xoá", self._clear_log, width=48, height=24).pack(side="right")

        self.log_box = ctk.CTkTextbox(
            lc,
            height=115,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER_SOFT,
            border_width=1,
            text_color="#b6bbc8",
            font=F.mono_sm,
        )
        self.log_box.grid(row=1, column=0, sticky="nsew", padx=T.PADC, pady=(0, T.PADC))
        track_log_follow(self, self.log_box)

    def _clear_log(self):
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")

    def log(self, text: str):
        def _w():
            try:
                ts = time.strftime("%H:%M:%S")
                self.log_box.configure(state="normal")
                self.log_box.insert("end", f"[{ts}] {text}\n")
                if getattr(self, "_log_follow", True):
                    self.log_box.see("end")
            except Exception:
                pass

        self.after(0, _w)

    def _open_out(self):
        d = self.entry_out_dir.get().strip() or self._out_dir
        os.makedirs(d, exist_ok=True)
        try:
            os.startfile(d)
        except Exception:
            pass

    def _open_refusals(self):
        d = self.entry_out_dir.get().strip() or self._out_dir
        path = os.path.join(d, muse.REFUSAL_FILE)
        if not os.path.isfile(path):
            self.log("📝 Chưa có prompt nào bị Muse từ chối.")
            return
        try:
            os.startfile(path)
        except Exception as e:
            self.log(f"⚠️ Không mở được {path}: {e}")

    def _pick_img_folder(self):
        d = filedialog.askdirectory(title="Chọn thư mục ảnh nhân vật")
        if d:
            self.entry_img_folder.delete(0, "end")
            self.entry_img_folder.insert(0, d)
            self._on_img_folder_edit()

    def _on_img_folder_edit(self):
        self._pipe_img_map.clear()
        self._refresh_images()

    def _pipe_set_images(self, paths: list[str]):
        self._pipe_img_map.clear()
        dirs = set()
        for p in paths or []:
            if p and os.path.isfile(p):
                stem = os.path.splitext(os.path.basename(p))[0].strip().upper()
                if stem.startswith("REF_"):
                    stem = stem[4:]
                self._pipe_img_map[stem] = p
                dirs.add(os.path.dirname(p))
        if len(dirs) == 1:
            folder = dirs.pop()
            self.entry_img_folder.delete(0, "end")
            self.entry_img_folder.insert(0, folder)
        self._refresh_images()

    def _img_map_all(self) -> dict[str, str]:
        if self._pipe_img_map:
            return dict(self._pipe_img_map)
        folder = self.entry_img_folder.get().strip()
        out = {}
        if folder and os.path.isdir(folder):
            for fn in sorted(os.listdir(folder)):
                stem, ext = os.path.splitext(fn)
                if ext.lower() in IMG_EXTS:
                    clean_stem = stem.strip().upper()
                    if clean_stem.startswith("REF_"):
                        clean_stem = clean_stem[4:]
                    out[clean_stem] = os.path.join(folder, fn)
        return out

    def _img_map(self) -> dict[str, str]:
        m = self._img_map_all()
        if self._pipeline_mode and self._pipe_root:
            return {k: v for k, v in m.items() if _in_dir(v, self._pipe_root)}
        return m

    def _refresh_images(self):
        m = self._img_map()
        if m:
            self.lbl_imgs.configure(text=f"✅ {len(m)} ảnh nhân vật: {', '.join(list(m.keys())[:10])}", text_color=T.OK)
        else:
            self.lbl_imgs.configure(text="⚠️ chưa có ảnh trong thư mục", text_color=T.MUTED)
        self._row_thumb_cache.clear()
        for w in self.img_gallery.winfo_children():
            w.destroy()
        self._thumb_refs.clear()
        cols = 3
        for idx in range(cols):
            self.img_gallery.columnconfigure(idx, weight=1)
        for idx, (tag, path) in enumerate(m.items()):
            card_box = ctk.CTkFrame(
                self.img_gallery,
                fg_color=T.CARD,
                corner_radius=6,
                border_color=T.BORDER_SOFT,
                border_width=1,
            )
            card_box.grid(row=idx // cols, column=idx % cols, padx=3, pady=3, sticky="nsew")
            try:
                im = Image.open(path).convert("RGBA")
                im.thumbnail((88, 88))
                cim = ctk.CTkImage(light_image=im, dark_image=im, size=im.size)
                self._thumb_refs.append(cim)
                ctk.CTkLabel(card_box, image=cim, text="").pack(padx=4, pady=(4, 2))
            except Exception:
                ctk.CTkLabel(card_box, text="🖼", font=F.title).pack(pady=12)
            ctk.CTkLabel(card_box, text=tag, font=F.tiny, text_color=T.TEXT_STRONG).pack(pady=(0, 4))
            ctk.CTkButton(
                card_box,
                text="✕",
                width=20,
                height=18,
                corner_radius=4,
                fg_color=T.DANGER_BG,
                hover_color="#3a2029",
                border_color=T.DANGER_BORDER,
                border_width=1,
                text_color=T.DANGER_TEXT,
                font=F.tiny,
                command=lambda p=path, t=tag: self._delete_image(p, t),
            ).place(relx=1.0, rely=0.0, x=-3, y=3, anchor="ne")
        self.render_pagination()

    def _delete_image(self, path: str, tag: str):
        if messagebox.askyesno("Xoá ảnh", f"Xoá ảnh [{tag}] khỏi thư mục?\n{path}"):
            try:
                os.remove(path)
                self._pipe_img_map.pop(tag, None)
                self.log(f"🗑 Đã xoá ảnh [{tag}]")
                self._refresh_images()
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def clear_character_images(self, ask_confirm: bool = True):
        """Xoá sạch danh sách ảnh nhân vật TAG đã nạp từ lần dùng trước."""
        m = self._img_map()
        if not m:
            self.log("ℹ️ Thư mục ảnh nhân vật hiện đã trống.")
            return
        if ask_confirm:
            ans = messagebox.askyesnocancel(
                "Làm sạch ảnh nhân vật cũ",
                f"Đang có {len(m)} ảnh nhân vật ({', '.join(list(m.keys())[:6])}).\n\n"
                "• Chọn YES: Xoá hẳn các file ảnh cũ trong thư mục đang chọn để nạp bộ mới\n"
                "• Chọn NO: Chỉ bỏ nạp trên giao diện (giữ file trong ổ đĩa)\n"
                "• Chọn CANCEL: Huỷ bỏ",
            )
            if ans is None:
                return
            delete_disk = bool(ans)
        else:
            delete_disk = True

        removed = 0
        if delete_disk:
            for p in list(m.values()):
                if p and os.path.isfile(p):
                    try:
                        os.remove(p)
                        removed += 1
                    except Exception:
                        pass
        else:
            self.entry_img_folder.delete(0, "end")
        self._pipe_img_map.clear()
        self._refresh_images()
        self.log(f"🧹 Đã làm sạch danh sách ảnh nhân vật cũ ({removed} file đã xoá).")

    def clear_prompts_only(self):
        """Xoá trắng ô danh sách prompt và hàng đợi cảnh trên giao diện."""
        self.txt_prompt_input.delete("1.0", "end")
        self.lbl_file.configure(text="chưa chọn file")
        self.all_prompts_data.clear()
        self.render_pagination()
        self.log("🧹 Đã xoá trắng danh sách Prompt trên tab Video Muse.")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ ảnh nhân vật, prompt và video cũ từ lần dùng trước."""
        if self.running:
            if ask_confirm:
                messagebox.showwarning("Đang chạy", "Hãy bấm Dừng tạo trước khi làm sạch dữ liệu!")
            return
        if ask_confirm:
            ans = messagebox.askyesnocancel(
                "Làm sạch dữ liệu Video Muse",
                "Bạn muốn làm sạch toàn bộ Ảnh nhân vật, Prompt & Video từ lần dùng trước?\n\n"
                "• Chọn YES: Xoá sạch Prompt + Ảnh nhân vật cũ + Các file .mp4 cũ trong thư mục xuất\n"
                "• Chọn NO: Chỉ xoá trắng Prompt & danh sách trên giao diện (giữ file trong ổ đĩa)\n"
                "• Chọn CANCEL: Huỷ bỏ",
            )
            if ans is None:
                return
            delete_files = bool(ans)

        self.txt_prompt_input.delete("1.0", "end")
        self.lbl_file.configure(text="chưa chọn file")
        self.all_prompts_data.clear()

        removed_imgs = 0
        removed_vids = 0
        if delete_files:
            m = self._img_map_all()
            for p in list(m.values()):
                if p and os.path.isfile(p):
                    try:
                        os.remove(p)
                        removed_imgs += 1
                    except Exception:
                        pass
            out_dir = self.entry_out_dir.get().strip() or self._out_dir
            if out_dir and os.path.isdir(out_dir):
                for fn in os.listdir(out_dir):
                    if fn.lower().endswith((".mp4", ".webm", ".mov")) or fn == muse.REFUSAL_FILE or fn == "list.txt":
                        try:
                            os.remove(os.path.join(out_dir, fn))
                            removed_vids += 1
                        except Exception:
                            pass
        else:
            self.entry_img_folder.delete(0, "end")

        self._pipe_img_map.clear()
        self._refresh_images()
        self.render_pagination()
        self.progress.set(0)
        extra = f" (đã xoá {removed_imgs} ảnh cũ & {removed_vids} file video cũ)" if delete_files else ""
        self.log(f"🧹 Đã làm sạch toàn bộ Ảnh & Prompt cũ trên Video Muse{extra}.")

    def choose_file(self):
        f = filedialog.askopenfilename(title="Chọn file prompt", filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if f:
            try:
                with open(f, "r", encoding="utf-8", errors="ignore") as fp:
                    data = fp.read()
                self.txt_prompt_input.delete("1.0", "end")
                self.txt_prompt_input.insert("1.0", data)
                self.lbl_file.configure(text=os.path.basename(f))
                self.scan_prompts_and_files()
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def choose_output_folder(self):
        d = filedialog.askdirectory(title="Chọn thư mục lưu video")
        if d:
            self.entry_out_dir.delete(0, "end")
            self.entry_out_dir.insert(0, d)
            self.scan_prompts_and_files()

    def scan_prompts_and_files(self, *args):
        raw = self.txt_prompt_input.get("1.0", "end").strip()
        lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        out_dir = self.entry_out_dir.get().strip() or self._out_dir
        self._out_dir = out_dir
        new_data = []
        for i, text in enumerate(lines):
            filename = f"{i + 1:04d}.mp4"
            f_path = os.path.join(out_dir, filename)
            exists = os.path.isfile(f_path) and os.path.getsize(f_path) >= VIDEO_MIN_SIZE
            old = next((x for x in self.all_prompts_data if x["id"] == i), None)
            if exists:
                status = "✅ Đã có file"
            elif old and old.get("status") and not old["status"].startswith("✅"):
                status = old["status"]
            else:
                status = "Waiting..."
            new_data.append(
                {
                    "id": i,
                    "text": text,
                    "status": status,
                    "file_path": f_path if exists else None,
                    "force_regen": False,
                }
            )
        self.all_prompts_data = new_data
        self.render_pagination()

    def get_total_pages(self) -> int:
        return max(1, math.ceil(len(self.all_prompts_data) / self.items_per_page))

    def render_pagination(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.rows_ui.clear()
        total = self.get_total_pages()
        self.current_page = max(1, min(self.current_page, total))
        self.lbl_page_info.configure(text=f"Trang {self.current_page}/{total} ({len(self.all_prompts_data)} cảnh)")
        start = (self.current_page - 1) * self.items_per_page
        end = start + self.items_per_page
        for item in self.all_prompts_data[start:end]:
            self._make_row(item)

    def _row_thumb(self, tag: str, size: int = 28):
        key = (tag, size)
        if key in self._row_thumb_cache:
            return self._row_thumb_cache[key]
        path = self._img_map().get(tag)
        if not path or not os.path.isfile(path):
            return None
        try:
            im = Image.open(path).convert("RGBA")
            im.thumbnail((size, size))
            cim = ctk.CTkImage(light_image=im, dark_image=im, size=im.size)
            self._row_thumb_cache[key] = cim
            return cim
        except Exception:
            return None

    def _make_row(self, item: dict):
        row_id = item["id"]
        text = item.get("text", "")
        status = item.get("status", "Waiting...")
        file_path = item.get("file_path")
        clean, tags = resolve_tags(text)

        r = card(self.list_frame, fg_color=T.INPUT, corner_radius=T.RADIUS)
        r.pack(fill="x", pady=3, padx=2)

        lbl(r, f"{row_id + 1:02d}", T.MUTED, F.mono_sm, width=28).pack(side="left", padx=(10, 4), pady=6)

        if tags:
            tf = row(r)
            tf.pack(side="left", padx=4)
            for t in tags[:4]:
                cim = self._row_thumb(t)
                if cim:
                    ctk.CTkLabel(tf, image=cim, text="").pack(side="left", padx=1)
                else:
                    lbl(tf, f"[{t}]", "#e0a458", F.tiny).pack(side="left", padx=2)

        preview = clean.replace("\n", " ")
        if len(preview) > 64:
            preview = preview[:64] + "…"
        lbl_prev = lbl(r, preview, T.TEXT, F.ui, anchor="w")
        lbl_prev.pack(side="left", fill="x", expand=True, padx=6)

        bf = row(r)
        bf.pack(side="right", padx=8, pady=4)

        lbl_status = lbl(r, status, status_color(status), F.tiny, width=118, anchor="w")
        lbl_status.pack(side="right", padx=6)

        sbtn(bf, "Sửa", lambda rid=row_id: self.on_edit_prompt(rid), width=48).pack(side="left", padx=2)
        sbtn(bf, "Tạo lại", lambda rid=row_id: self.on_regen_prompt(rid), width=62).pack(side="left", padx=2)
        sbtn(bf, "Xoá", lambda rid=row_id: self.on_delete_video(rid), width=46).pack(side="left", padx=2)

        btn_view = sbtn(
            bf,
            "Xem",
            (lambda fp=file_path: self._view(fp)) if file_path else None,
            width=50,
            state="normal" if file_path else "disabled",
        )
        btn_view.pack(side="left", padx=2)

        self.rows_ui[row_id] = {
            "frame": r,
            "status_lbl": lbl_status,
            "view_btn": btn_view,
            "text_preview": lbl_prev,
        }

    def _view(self, path):
        if path and os.path.isfile(path):
            try:
                os.startfile(path)
            except Exception:
                pass

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.render_pagination()

    def next_page(self):
        if self.current_page < self.get_total_pages():
            self.current_page += 1
            self.render_pagination()

    def _sync_txt_prompt_from_data(self):
        """Đồng bộ ngược danh sách all_prompts_data về ô txt_prompt_input để sửa thủ công không bị ghi đè."""
        lines = [str(x.get("text") or "").strip() for x in self.all_prompts_data if str(x.get("text") or "").strip()]
        self.txt_prompt_input.delete("1.0", "end")
        if lines:
            self.txt_prompt_input.insert("1.0", "\n".join(lines))

    def on_edit_prompt(self, row_id: int):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item:
            return
        d = dialog(self, f"✏️ Sửa thủ công Prompt #{row_id + 1}", w=680, h=340, grab=True)
        txt = ctk.CTkTextbox(d, height=210, fg_color=T.INPUT, text_color=T.TEXT, font=F.ui, wrap="word")
        txt.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        txt.insert("1.0", item["text"])

        def _apply_save(run_now: bool = False):
            new = txt.get("1.0", "end").strip()
            if new:
                item["text"] = new
                self._sync_txt_prompt_from_data()
                self.render_pagination()
                self.log(f"✏️ Đã lưu chỉnh sửa thủ công cho Prompt #{row_id + 1}")
                if run_now:
                    self.on_regen_prompt(row_id)
            d.destroy()

        bar = row(d)
        bar.pack(fill="x", padx=16, pady=(0, 14))
        btn_primary(bar, "▶ Lưu & Tạo lại ngay", lambda: _apply_save(True), width=160).pack(side="right", padx=(6, 0))
        btn(bar, "💾 Lưu thay đổi", lambda: _apply_save(False), width=126).pack(side="right", padx=(6, 0))
        btn(bar, "Huỷ", d.destroy, width=80).pack(side="right")

    def on_regen_prompt(self, row_id: int):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item:
            return
        if not self.accounts:
            self.log("⚠️ Chưa có tài khoản Muse.")
            return
        self.update_row_status(row_id, "Waiting Regen...")
        dur = self.cbo_duration.get().strip() or "8s"
        ratio = RATIOS.get(self.cbo_ratio.get(), "16:9")
        self._snap_run_state()
        tok = self._run_tok

        def _one():
            self._single_busy += 1
            try:
                self._process_one(item, dur, ratio, tok)
            finally:
                self._single_busy = max(0, self._single_busy - 1)

        threading.Thread(target=_one, daemon=True).start()

    def on_delete_video(self, row_id: int):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if not item or not item.get("file_path") or not os.path.isfile(item["file_path"]):
            messagebox.showinfo("Thông báo", "Chưa có video để xoá!")
            return
        if messagebox.askyesno("Xác nhận", f"Xoá video #{row_id + 1}?\n{item['file_path']}"):
            try:
                os.remove(item["file_path"])
                item["file_path"] = None
                self.update_row_status(row_id, "Đã xoá file")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def update_row_status(self, row_id: int, status_text: str, file_path: str = None):
        item = next((x for x in self.all_prompts_data if x["id"] == row_id), None)
        if item:
            item["status"] = status_text
            if file_path:
                item["file_path"] = file_path
        self.after(0, lambda: self._update_row_ui_safe(row_id, status_text, file_path))

    def _update_row_ui_safe(self, row_id: int, status_text: str, file_path: str = None):
        w = self.rows_ui.get(row_id)
        if not w:
            return
        try:
            status_color(w["status_lbl"], status_text)
            if file_path and any(k in status_text for k in ("Hoàn thành", "Đã có", "Xong", "✅")):
                w["view_btn"].configure(state="normal", command=lambda fp=file_path: self._view(fp))
        except Exception:
            pass

    def _throttle(self):
        with self._send_lock:
            wait = self.send_gap - (time.time() - self._last_send)
            if wait > 0:
                time.sleep(wait)
            self._last_send = time.time()

    def _ensure_pool(self, nthreads: int, max_workers: int = None):
        self._close_pool()
        self.pool = muse.MusePool(
            threads=nthreads,
            visible=self._show_browser_snap,
            log=self.log,
            stop_event=self.stop_flag,
            max_workers=max_workers,
        )
        self.pool.open()
        return self.pool

    def _close_pool(self):
        p = self.pool
        self.pool = None
        if p:
            try:
                p.close()
            except Exception:
                pass

    @contextlib.contextmanager
    def _muse_worker(self):
        p = self.pool
        if p is not None:
            with p.acquire(stop_event=self.stop_flag) as w:
                yield w
            return
        temp = muse.MusePool(threads=1, visible=self._show_browser_snap, log=self.log, stop_event=self.stop_flag, max_workers=1)
        temp.open()
        try:
            with temp.acquire(stop_event=self.stop_flag) as w:
                yield w
        finally:
            temp.close()

    def _snap_run_state(self):
        self._out_dir = self.entry_out_dir.get().strip() or self._out_dir
        self._img_snap = self._img_map()
        self._style_snap = self.cbo_style.get().strip() if hasattr(self, "cbo_style") else DEFAULT_STYLE_VALUES[0]
        self._show_browser_snap = bool(self.chk_show_browser_var.get())

    def start_process(self, _auto: bool = False):
        if self.running:
            self.log("⚠️ Đang chạy rồi — bấm Dừng tạo trước nếu muốn chạy lại.")
            return
        self._load_accounts()
        if not self.accounts:
            self.log("❌ Chưa có tài khoản Muse nào! → 👤 Quản lý tài khoản Muse")
            if not _auto:
                messagebox.showerror("Lỗi", "Chưa có tài khoản Muse nào! Hãy bấm '👤 Quản lý tài khoản Muse' để thêm.")
            return

        self.scan_prompts_and_files()
        pending = [x for x in self.all_prompts_data if x.get("force_regen") or not x.get("file_path")]
        if not pending:
            self.log("✅ Không có video nào cần tạo (đã đủ).")
            if not _auto:
                messagebox.showinfo("Xong", "Không có video nào cần tạo (đã đủ).")
            return

        try:
            nthreads = max(1, int(self.entry_thread.get().strip() or "1"))
        except ValueError:
            nthreads = 1
        dur = self.cbo_duration.get().strip() or "8s"
        ratio = RATIOS.get(self.cbo_ratio.get(), "16:9")

        self._snap_run_state()
        self.running = True
        self.stop_flag.clear()
        self._run_tok += 1
        tok = self._run_tok
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.progress.set(0)

        threading.Thread(
            target=self._worker,
            args=(pending, dur, ratio, nthreads, tok),
            daemon=True,
        ).start()

    def stop_process(self):
        self.stop_flag.set()
        self.running = False
        self.log("⏹ Đang dừng — đóng các tab Muse…")
        threading.Thread(target=self._close_pool, daemon=True).start()
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")

    def _halted(self, tok: int) -> bool:
        return self.stop_flag.is_set() or tok != self._run_tok

    def _worker(self, items, duration: str, ratio: str, nthreads: int, tok: int):
        total = len(items)
        done = 0
        dlock = threading.Lock()
        try:
            self.log(f"▶ Bắt đầu {total} video nhân vật · {duration} · {ratio} · {nthreads} luồng")
            self.log("🌐 Đang mở Chrome và chờ Muse sẵn sàng…")
            self._ensure_pool(nthreads, max_workers=total)
            workers = max(1, len(self.pool.workers))
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = [ex.submit(self._process_one, it, duration, ratio, tok) for it in items]
                for fut in as_completed(futs):
                    try:
                        fut.result()
                    except Exception as e:
                        self.log(f"❌ Lỗi luồng: {e}")
                    with dlock:
                        done += 1
                        pct = done / max(1, total)
                        self.after(0, lambda v=pct: self.progress.set(v))
            if not self._halted(tok):
                self.log(f"🏁 Xong. Đã xử lý {done}/{total} cảnh.")
        except muse.MuseStopped:
            self.log("⏹ Đã dừng khi đang mở Chrome.")
        except Exception as e:
            self.log(f"❌ Lỗi: {e}")
        finally:
            self._close_pool()
            if tok == self._run_tok:
                self.running = False
                self.after(0, lambda: (self.btn_start.configure(state="normal"), self.btn_stop.configure(state="disabled")))

    def _process_one(self, item: dict, duration: str, ratio: str, tok: int):
        if self._halted(tok):
            return
        row_id = item["id"]
        dst = os.path.join(self._out_dir, f"{row_id + 1:04d}.mp4")
        with self._busy_lock:
            if dst in self._busy_dst:
                self.log(f"⏭ #{row_id + 1:02d}: đang có luồng khác tạo dòng này — bỏ qua.")
                return
            self._busy_dst.add(dst)
        try:
            self._process_one_inner(item, duration, ratio, tok, dst)
        finally:
            with self._busy_lock:
                self._busy_dst.discard(dst)

    def _process_one_inner(self, item: dict, duration: str, ratio: str, tok: int, dst: str):
        row_id = item["id"]

        def _st(text: str, fp: str = None):
            if not self._halted(tok):
                self.update_row_status(row_id, text, fp)

        clean_prompt, tags = resolve_tags(item["text"])
        clean_prompt, eff_style, _ = apply_style_to_prompt(clean_prompt, self._style_snap)

        img_map = self._img_snap
        present = [Path(img_map[t]) for t in tags if t in img_map and os.path.isfile(img_map[t])]
        missing = [t for t in tags if t not in img_map or not os.path.isfile(img_map[t])]
        if missing:
            self.log(f"⚠️ #{row_id + 1:02d}: thiếu ảnh {', '.join(missing)} trong thư mục.")
        if present:
            self.log(f"🖼 #{row_id + 1:02d}: gửi kèm {', '.join(tags)} ({len(present)} ảnh)")

        attempts = 2
        last_err = ""
        last_refusal = ""
        last_ghi = None
        for att in range(1, attempts + 1):
            if self._halted(tok):
                _st("⏹ Đã dừng")
                return
            try:
                with self._muse_worker() as w:
                    self._throttle()
                    _st(f"🎬 [{w.label}] Đang tạo…")
                    self.log(f"🎬 #{row_id + 1:02d} [{w.label}] tạo ({len(present)} nhân vật)…")
                    w.generate_video(
                        clean_prompt,
                        ratio=ratio,
                        image_paths=present,
                        out_path=Path(dst),
                        status=lambda s: _st(s),
                        stop_event=self.stop_flag,
                        duration=duration,
                    )
                    if os.path.isfile(dst) and os.path.getsize(dst) >= VIDEO_MIN_SIZE:
                        mb = os.path.getsize(dst) / (1024 * 1024)
                        self.log(f"✅ #{row_id + 1:02d}: XONG → {os.path.basename(dst)} ({mb:.1f} MB)")
                        _st("✅ Hoàn thành", dst)
                        return
                    raise muse.MuseError("video tải về quá nhỏ / hỏng")
            except muse.MuseStopped:
                _st("⏹ Đã dừng")
                return
            except muse.MuseRefused as ref_exc:
                last_refusal = ref_exc.message
                last_ghi = muse.ghi_tu_choi(self._out_dir, row_id + 1, clean_prompt, last_refusal)
                self.log(f"🚫 #{row_id + 1:02d}: Muse từ chối — {last_refusal[:120]}")
                if att < attempts:
                    _st(f"🚫 Bị từ chối → mở chat mới ({att}/{attempts})")
                    with self._muse_worker() as w:
                        w.new_chat(log=self.log)
            except Exception as e2:
                last_err = str(e2)
                self.log(f"⚠️ #{row_id + 1:02d}: lỗi ({last_err}), thử lại {att}/{attempts}")
                if att < attempts:
                    _st(f"↻ thử lại {att}/{attempts}")
                    time.sleep(2.0)

        if last_refusal:
            if last_ghi:
                self.log(f"📝 Đã thử {attempts} chat đều bị từ chối. Lý do ghi ở {last_ghi}")
            if callable(self.on_prompt_failed):
                _st("🛡 Chờ rà soát (Muse từ chối)")
                self.on_prompt_failed(row_id, item["text"], f"Muse từ chối nội dung: {last_refusal}")
            else:
                _st("🚫 Muse từ chối nội dung")
        else:
            if callable(self.on_prompt_failed):
                _st("🛡 Chờ rà soát (Muse không tạo được)")
                self.on_prompt_failed(row_id, item["text"], last_err or "Muse không tạo được")
            else:
                _st("❌ Lỗi tạo")

    def merge_video(self):
        folder = self.entry_out_dir.get().strip() or self._out_dir
        if not os.path.isdir(folder):
            messagebox.showwarning("Chú ý", "Chưa có thư mục video.")
            return
        vids = sorted(
            [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(".mp4") and not f.startswith("merged_")]
        )
        if len(vids) < 2:
            messagebox.showwarning("Chú ý", "Cần ít nhất 2 video để ghép.")
            return
        list_file = os.path.join(folder, "list.txt")
        with open(list_file, "w", encoding="utf-8") as f:
            for v in vids:
                safe_v = v.replace("'", "'\\''")
                f.write(f"file '{safe_v}'\n")
        out = os.path.join(folder, f"merged_{int(time.time())}.mp4")
        self.log(f"🎞 Đang ghép {len(vids)} video…")

        def _work():
            try:
                subprocess.run(
                    ["ffmpeg", "-f", "concat", "-safe", "0", "-i", list_file, "-c", "copy", "-y", out],
                    check=True,
                    timeout=300,
                    creationflags=0x08000000,
                )
                self.log(f"✅ Đã ghép: {out}")
                self.after(0, lambda: messagebox.showinfo("Thành công", f"Đã ghép:\n{out}"))
            except Exception as e:
                self.log(f"❌ Ghép lỗi: {e}")

        threading.Thread(target=_work, daemon=True).start()

    def _load_accounts(self):
        self.accounts = muse.discover_profiles()
        if self.accounts:
            names = ", ".join(p.name for p in self.accounts)
            self.lbl_acc_count.configure(text=f"✅ {len(self.accounts)} tài khoản Muse: {names}", text_color=T.OK)
        else:
            self.lbl_acc_count.configure(text="⚠️ Chưa có tài khoản — bấm Quản lý tài khoản Muse.", text_color=T.WARN)

    def _check_accounts(self):
        self._load_accounts()
        if not self.accounts:
            messagebox.showwarning("Thiếu", "Chưa có tài khoản Muse.")
            return

        def _work():
            for p in self.accounts:
                st = muse.check_profile_state(p)
                if st.get("connected") and st.get("hasChat"):
                    self.log(f"✅ [{p.name}] đã đăng nhập Muse sẵn sàng")
                elif st.get("error"):
                    self.log(f"❌ [{p.name}] {st['error']}")
                else:
                    self.log(f"⚠️ [{p.name}] chưa đăng nhập — đang ở trang {st.get('url', '')}. Bấm Đăng nhập để mở chat Muse.")

        threading.Thread(target=_work, daemon=True).start()

    def _login_account(self, path: Path):
        self.log(f"🌐 Mở Chrome cho [{path.name}] — đăng nhập muse.ai rồi đóng cửa sổ.")
        threading.Thread(target=muse.open_login_window, args=(path, self.log), daemon=True).start()

    def _close_login_account(self, path: Path):
        threading.Thread(target=muse.close_login_window, args=(path,), daemon=True).start()
        self.log(f"🚪 Đã đóng cửa sổ đăng nhập [{path.name}]")

    def _delete_account(self, path: Path):
        if messagebox.askyesno("Xoá tài khoản", f"Xoá hẳn profile '{path.name}'?\nPhiên đăng nhập Muse của nó sẽ mất."):
            muse.close_login_window(path)
            shutil.rmtree(path, ignore_errors=True)
            self.log(f"🗑 Đã xoá tài khoản Muse [{path.name}]")
            self._load_accounts()

    def _add_account(self):
        try:
            p = muse.new_profile_path()
            self.log(f"➕ Tạo tài khoản Muse [{p.name}] — đang mở Chrome để đăng nhập…")
            self._load_accounts()
            self._login_account(p)
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không tạo được profile: {e}")

    def _account_manager(self):
        win = dialog(self, "Tài khoản Muse", w=660, h=460, grab=True)
        lbl(win, "TÀI KHOẢN MUSE (CHROME PROFILE)", T.TEXT_STRONG, F.title, anchor="w").pack(fill="x", padx=18, pady=(16, 2))
        lbl(
            win,
            "Mỗi tài khoản là một profile Chrome riêng. Bấm “Đăng nhập” để mở Chrome, đăng nhập muse.ai rồi đóng cửa sổ — tool dùng lại phiên đó.",
            T.MUTED,
            F.tiny,
            anchor="w",
            justify="left",
            wraplength=610,
        ).pack(fill="x", padx=18, pady=(0, 8))

        top = row(win)
        top.pack(fill="x", padx=18, pady=6)

        box = card(win)
        box.pack(fill="both", expand=True, padx=18, pady=4)
        lst = ctk.CTkScrollableFrame(box, fg_color="transparent", corner_radius=0)
        lst.pack(fill="both", expand=True, padx=8, pady=8)

        def refresh():
            for w in lst.winfo_children():
                w.destroy()
            self._load_accounts()
            profiles = self.accounts
            if not profiles:
                lbl(lst, "Chưa có tài khoản — bấm “Thêm tài khoản mới”.", T.MUTED, F.ui).pack(pady=24)
                return
            for p in profiles:
                r = card(lst, fg_color=T.INPUT, corner_radius=T.RADIUS)
                r.pack(fill="x", pady=3, padx=2)
                lbl(r, f"👤  {p.name}", T.TEXT_STRONG, F.ui_sb, anchor="w").pack(side="left", padx=12, pady=8)
                sbtn(
                    r,
                    "✕ Xoá",
                    lambda q=p: (self._delete_account(q), refresh()),
                    width=58,
                    fg_color=T.DANGER_BG,
                    text_color=T.DANGER_TEXT,
                ).pack(side="right", padx=(3, 10), pady=6)
                sbtn(r, "Đóng Chrome", lambda q=p: self._close_login_account(q), width=92).pack(side="right", padx=3, pady=6)
                btn_primary(r, "🌐 Đăng nhập", lambda q=p: self._login_account(q), width=110).pack(side="right", padx=3, pady=6)

        def add():
            self._add_account()
            refresh()

        btn_primary(top, "➕  Thêm tài khoản mới", add, width=190).pack(side="left")
        sbtn(top, "🔄 Làm mới", refresh, width=90).pack(side="left", padx=8)
        btn(win, "Đóng", win.destroy, width=90).pack(anchor="e", padx=18, pady=12)
        refresh()


def build_tab(frame, pipeline=None, *args, **kwargs):
    """Điểm vào chuẩn Film Studio — dựng tab Video Nhân Vật Muse vào `frame`."""
    app = App(master=frame)
    app.pipeline = pipeline
    app.pack(fill="both", expand=True)
    return app
