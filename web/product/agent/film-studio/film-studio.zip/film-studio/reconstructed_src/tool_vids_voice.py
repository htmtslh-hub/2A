"""
tool_vids_voice.py — Tool tạo VOICE bằng Google Vids (23 giọng Espresso thế hệ mới).

Tính năng:
  • Nhập văn bản trực tiếp hoặc NHẬP FILE .TXT (văn bản dài).
  • Tạo voice theo SUB: nhập file .srt → mỗi câu phụ đề = 1 file voice riêng (0001.wav, 0002.wav…).
  • Văn bản dài tự chia đoạn theo giới hạn ký tự và byte UTF-8 của Google Vids.
  • Tự chèn thẻ cảm xúc [happy]/[serious]/[admiration]… (lệnh 326).
  • Cơ chế cứu đoạn bị từ chối 2 tầng: tự bỏ thẻ cảm xúc thử lại → tách đọc từng câu lẻ rồi ghép lại bằng FFmpeg.
"""

import json
import os
import re
import shutil
import subprocess
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk

from ui import (
    T,
    F,
    set_density_early,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    lbl,
    switch,
    TabStrip,
    sbtn,
    track_log_follow,
)
import vids_backend

APP_DIR = os.path.dirname(os.path.abspath(__file__))

VOICES = [
    "Algenib",
    "Achernar",
    "Achird",
    "Aoede",
    "Autonoe",
    "Callirrhoe",
    "Charon",
    "Despina",
    "Enceladus",
    "Fenrir",
    "Gacrux",
    "Iapetus",
    "Kore",
    "Laomedeia",
    "Leda",
    "Orus",
    "Puck",
    "Sadaltager",
    "Schedar",
    "Sulafat",
    "Umbriel",
    "Zephyr",
    "Zubenelgenubi",
]

VIDS_LIMIT = 2500
VIDS_BYTE_LIMIT = 3200
VOICE_MIN_SIZE = 1024
_TIME_RE = re.compile(r"\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}\s*-->")


def clean_text(s: str) -> str:
    """Bỏ ký tự ẩn / lạ hay khiến backend đọc tiếng từ chối; chuẩn hoá dấu câu."""
    s = unicodedata.normalize("NFC", s or "")
    s = re.sub(r"[\u0000-\u0008\u000B\u000C\u000E-\u001F\u200b-\u200f\u202a-\u202e\u2028\u2029\ufeff]", "", s)
    s = "".join(ch for ch in s if ch == "\n" or unicodedata.category(ch)[0] in "LNPZ")
    s = re.sub(r"[ \t]+", " ", s)
    return s.strip()


def _sentences(text: str) -> list[str]:
    """Tách câu (để cứu đoạn bị lọc nội dung: đọc từng câu rồi ghép)."""
    out = []
    for para in re.split(r"\n+", text or ""):
        para = para.strip()
        if not para:
            continue
        for sent in re.split(r"(?<=[\.\!\?…。！？])\s+", para):
            sent = sent.strip()
            if sent:
                out.append(sent)
    return out


def _fits(s: str, limit: int = VIDS_LIMIT, byte_limit: int = VIDS_BYTE_LIMIT) -> bool:
    return len(s) <= limit and len(s.encode("utf-8")) <= byte_limit


def _hard_split(u: str, limit: int, byte_limit: int) -> list[str]:
    """Cắt cứng 1 câu quá dài, mỗi mảnh vừa cả ký tự lẫn byte (tránh cắt giữa từ)."""
    out = []
    cur = ""
    for w in u.split():
        cand = f"{cur} {w}".strip() if cur else w
        if _fits(cand, limit, byte_limit):
            cur = cand
        else:
            if cur:
                out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


def split_text(text: str, limit: int = 800, byte_limit: int = VIDS_BYTE_LIMIT) -> list[str]:
    """Chia văn bản dài thành các đoạn đủ ngắn cho backend đọc tiếng của Vids."""
    cleaned = clean_text(text)
    if not cleaned:
        return []
    units = _sentences(cleaned)
    chunks = []
    cur = ""
    for sent in units:
        if not _fits(sent, limit, byte_limit):
            if cur:
                chunks.append(cur)
                cur = ""
            chunks.extend(_hard_split(sent, limit, byte_limit))
            continue
        cand = f"{cur} {sent}".strip() if cur else sent
        if _fits(cand, limit, byte_limit):
            cur = cand
        else:
            if cur:
                chunks.append(cur)
            cur = sent
    if cur:
        chunks.append(cur)
    return chunks


def parse_srt(text: str) -> list[str]:
    """Trả list câu thoại theo thứ tự phụ đề (bỏ số thứ tự + dòng thời gian)."""
    out = []
    raw = (text or "").replace("\r\n", "\n").strip()
    if not raw:
        return out
    for block in re.split(r"\n\s*\n", raw):
        lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
        if not lines:
            continue
        if lines[0].isdigit():
            lines = lines[1:]
        if lines and _TIME_RE.search(lines[0]):
            lines = lines[1:]
        say = clean_text(" ".join(lines))
        if say:
            out.append(say)
    return out


class App:
    """Tab Tạo Voice Google Vids — nhúng vào `host` (frame của tab hoặc cửa sổ)."""

    def __init__(self, host):
        set_density_early()
        F.init()
        self.host = host
        self.host.configure(fg_color=T.BG)
        self.cfg = vids_backend.load_config()
        self.accounts = {}
        self.running = False
        self.stop_flag = threading.Event()
        self._auth_dead = threading.Event()
        self.save_dir = os.path.join(APP_DIR, "Voice_Vids_Result")
        os.makedirs(self.save_dir, exist_ok=True)

        self.host.grid_columnconfigure(0, weight=0, minsize=345)
        self.host.grid_columnconfigure(1, weight=1)
        self.host.grid_rowconfigure(0, weight=1)

        self._build_left()
        self._build_right()
        self._load_accounts()

    def _build_left(self):
        col = row(self.host)
        col.grid(row=0, column=0, sticky="nsew", padx=(T.PAD, T.GAP), pady=T.PAD)
        col.columnconfigure(0, weight=1)
        col.rowconfigure(0, weight=1)

        c = card(col)
        c.grid(row=0, column=0, sticky="nsew")
        p = row(c)
        p.pack(fill="both", expand=True, padx=T.PADC, pady=T.PADC)

        def sect(title: str):
            lbl(p, title.upper(), T.ACCENT, F.group, anchor="w").pack(fill="x", pady=(8, 3))

        def _combo(parent, values, **kw):
            return ctk.CTkComboBox(
                parent,
                values=values,
                state="readonly",
                height=T.H_CTRL,
                corner_radius=T.RADIUS,
                fg_color=T.INPUT,
                border_color=T.BORDER,
                button_color=T.BTN,
                button_hover_color=T.TAB_ACTIVE,
                text_color=T.TEXT,
                dropdown_fg_color=T.CARD,
                dropdown_hover_color=T.TAB_ACTIVE,
                dropdown_text_color=T.TEXT,
                font=F.ui,
                **kw,
            )

        sect("Tài khoản (Cookie Google Vids)")
        arow = row(p)
        arow.pack(fill="x", pady=2)
        arow.columnconfigure(0, weight=1)
        self.acc_cb = _combo(arow, ["(chưa có)"])
        self.acc_cb.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        btn(arow, "Nạp lại", self._load_accounts, width=64).grid(row=0, column=1, padx=(0, 4))
        btn(arow, "Kiểm tra", self._check_cookie, width=68).grid(row=0, column=2)

        btn(
            p,
            "🍪  Quản lý cookie…",
            self._cookie_manager,
            fg_color="#0f293a",
            hover_color="#163b52",
            border_color=T.ACCENT,
            text_color="#7ce8ff",
        ).pack(fill="x", pady=(6, 4))

        sect("Giọng đọc (23 Giọng Espresso)")
        self.voice_cb = _combo(p, VOICES)
        self.voice_cb.set("Kore")
        self.voice_cb.pack(fill="x", pady=2)

        sect("Chia đoạn (văn bản dài)")
        lrow = row(p)
        lrow.pack(fill="x", pady=2)
        lbl(lrow, "Tối đa", T.LABEL, F.label).pack(side="left", padx=(0, 6))
        self.limit_ent = ctk.CTkEntry(
            lrow,
            width=72,
            height=T.H_CTRL,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER,
            text_color=T.TEXT,
            font=F.ui,
        )
        self.limit_ent.insert(0, "800")
        self.limit_ent.pack(side="left")
        lbl(lrow, "ký tự / đoạn (tối đa 2500)", T.MUTED, F.tiny).pack(side="left", padx=8)

        sect("Tuỳ chọn nâng cao")
        trow = row(p)
        trow.pack(fill="x", pady=4)
        lbl(trow, "Số luồng:", T.LABEL, F.label).pack(side="left", padx=(0, 8))
        self.threads_cb = _combo(trow, ["1", "2", "3", "4", "5"], width=68)
        self.threads_cb.set("2")
        self.threads_cb.pack(side="left")
        lbl(trow, "(nhanh nhưng tốn RAM)", T.MUTED, F.tiny).pack(side="left", padx=8)

        self.autotag = tk.BooleanVar(value=True)
        switch(p, "Tự chèn thẻ cảm xúc ([happy], [serious]…)", variable=self.autotag).pack(fill="x", pady=3)

        self.merge = tk.BooleanVar(value=True)
        switch(p, "Ghép tất cả thành 1 file (ffmpeg)", variable=self.merge).pack(fill="x", pady=3)

        sect("Nơi lưu kết quả")
        srow = row(p)
        srow.pack(fill="x", pady=2)
        srow.columnconfigure(0, weight=1)
        btn(srow, "Chọn thư mục…", self._pick_out, width=120).grid(row=0, column=0, sticky="ew", padx=(0, 6))
        btn(srow, "Mở", self._open_out, width=56).grid(row=0, column=1)

        self.path_lbl = lbl(p, self.save_dir, T.MUTED, F.tiny, anchor="w", wraplength=310, justify="left")
        self.path_lbl.pack(fill="x", pady=(4, 8))

        act = row(p)
        act.pack(fill="x", pady=(6, 4))
        act.columnconfigure(0, weight=1)
        act.columnconfigure(1, weight=1)
        self.run_btn = btn_primary(act, "▶  Tạo voice", self._run)
        self.run_btn.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.stop_btn = btn_danger(act, "■  Dừng", self._stop, state="disabled")
        self.stop_btn.grid(row=0, column=1, sticky="ew", padx=(4, 0))

        self.progress = ctk.CTkProgressBar(p, height=6, corner_radius=3, fg_color=T.INPUT, progress_color=T.ACCENT)
        self.progress.set(0)
        self.progress.pack(fill="x", pady=(6, 4))

        self.status_lbl = lbl(p, "Sẵn sàng", T.TEXT_DIM, F.tiny, anchor="w")
        self.status_lbl.pack(fill="x", pady=2)

    def _build_right(self):
        right = row(self.host)
        right.grid(row=0, column=1, sticky="nsew", padx=(0, T.PAD), pady=T.PAD)
        right.rowconfigure(0, weight=3)
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)

        holder = card(right)
        holder.grid(row=0, column=0, sticky="nsew", pady=(0, T.GAP))
        holder.rowconfigure(1, weight=1)
        holder.columnconfigure(0, weight=1)

        head = row(holder)
        head.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(8, 0))
        lbl(head, "NỘI DUNG ĐỌC VOICE GEMINI 2 (GOOGLE VIDS)", T.TEXT_STRONG, F.ui_sb).pack(side="left")
        self.count_lbl = lbl(head, "0 ký tự · 0 đoạn", T.MUTED, F.tiny)
        self.count_lbl.pack(side="right")

        self.tabs = TabStrip(holder)
        t_text = self.tabs.add("📄 Văn bản")
        t_srt = self.tabs.add("🎬 SRT (theo sub)")
        self.tabs.grid(row=1, column=0)

        self._tab_text(t_text)
        self._tab_srt(t_srt)
        self._log_card(right)

    def _big_box(self, parent, **kw):
        kw.setdefault("fg_color", T.INPUT)
        kw.setdefault("border_color", T.BORDER_SOFT)
        kw.setdefault("border_width", 1)
        kw.setdefault("text_color", "#c8ccd8")
        kw.setdefault("wrap", "word")
        return ctk.CTkTextbox(parent, **kw)

    def _tab_text(self, tab):
        tab.rowconfigure(1, weight=1)
        tab.columnconfigure(0, weight=1)
        bar = row(tab)
        bar.grid(row=0, column=0, sticky="ew", padx=8, pady=(4, 4))
        btn(bar, "📄  Nhập file TXT", self._import_txt, width=130).pack(side="left")
        btn(bar, "🧹 Làm sạch", lambda: self.clear_previous_session(ask_confirm=False), width=95).pack(side="left", padx=(6, 0))
        lbl(bar, "  hoặc gõ / dán văn bản dài vào đây — tool tự chia đoạn.", T.MUTED, F.tiny).pack(side="left")

        self.textbox = self._big_box(tab, font=F.ui)
        self.textbox.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))
        self.textbox.bind("<KeyRelease>", lambda _e: self._update_count())

    def _tab_srt(self, tab):
        tab.rowconfigure(1, weight=1)
        tab.columnconfigure(0, weight=1)
        bar = row(tab)
        bar.grid(row=0, column=0, sticky="ew", padx=8, pady=(4, 4))
        btn(bar, "🎬  Nhập file SRT", self._import_srt, width=130).pack(side="left")
        btn(bar, "🧹 Làm sạch", lambda: self.clear_previous_session(ask_confirm=False), width=95).pack(side="left", padx=(6, 0))
        lbl(bar, "  mỗi câu phụ đề = 1 file voice (0001.wav, 0002.wav…).", T.MUTED, F.tiny).pack(side="left")

        self.srt_box = self._big_box(tab, font=F.mono_sm, wrap="none", text_color="#8fe3c4")
        self.srt_box.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))
        self.srt_box.bind("<KeyRelease>", lambda _e: self._update_count())

    def _log_card(self, right):
        lc = card(right)
        lc.grid(row=1, column=0, sticky="nsew")
        lc.rowconfigure(1, weight=1)
        lc.columnconfigure(0, weight=1)

        lh = row(lc)
        lh.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(8, 4))
        lbl(lh, "NHẬT KÝ", T.TEXT_STRONG, F.ui_sb).pack(side="left")
        sbtn(lh, "Xoá", self._clear_log, width=48, height=24).pack(side="right")

        self.console = ctk.CTkTextbox(
            lc,
            height=115,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER_SOFT,
            border_width=1,
            text_color="#b6bbc8",
            font=F.mono_sm,
            wrap="word",
        )
        self.console.grid(row=1, column=0, sticky="nsew", padx=T.PADC, pady=(0, T.PADC))
        track_log_follow(self, self.console)

    def _clear_log(self):
        self.console.configure(state="normal")
        self.console.delete("1.0", "end")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch văn bản, phụ đề SRT và các file voice cũ từ lần dùng trước."""
        if self.running:
            if ask_confirm:
                messagebox.showwarning("Đang chạy", "Hãy bấm Dừng trước khi làm sạch dữ liệu!")
            return
        if ask_confirm:
            ans = messagebox.askyesnocancel(
                "Làm sạch dữ liệu Voice Gemini 2",
                "Bạn muốn làm sạch toàn bộ Văn bản, SRT & File âm thanh từ lần dùng trước?\n\n"
                "• Chọn YES: Xoá sạch Văn bản/SRT + Xoá các file .wav/.mp3 cũ trong thư mục xuất\n"
                "• Chọn NO: Chỉ xoá trắng Văn bản & SRT trên giao diện (giữ file trong ổ đĩa)\n"
                "• Chọn CANCEL: Huỷ bỏ",
            )
            if ans is None:
                return
            delete_files = bool(ans)
        else:
            delete_files = False

        self.textbox.delete("1.0", "end")
        self.srt_box.delete("1.0", "end")
        self._update_count()
        self.progress.set(0)

        removed = 0
        if delete_files and self.save_dir and os.path.isdir(self.save_dir):
            for fn in os.listdir(self.save_dir):
                if fn.lower().endswith((".wav", ".mp3", ".m4a", ".txt")):
                    try:
                        os.remove(os.path.join(self.save_dir, fn))
                        removed += 1
                    except Exception:
                        pass
        extra = f" (đã xoá {removed} file âm thanh cũ)" if delete_files else ""
        self._status("Đã làm sạch")
        self.log(f"🧹 Đã làm sạch Văn bản & Phụ đề SRT cũ{extra}.")

    def log(self, msg: str):
        def _do():
            try:
                ts = time.strftime("[%H:%M:%S] ")
                self.console.configure(state="normal")
                self.console.insert("end", ts + str(msg) + "\n")
                if getattr(self, "_log_follow", True):
                    self.console.see("end")
            except Exception:
                pass

        self.host.after(0, _do)

    def _status(self, msg: str):
        self.host.after(0, lambda: self.status_lbl.configure(text=msg))

    def _set_progress(self, v: float):
        self.host.after(0, lambda: self.progress.set(max(0.0, min(1.0, float(v)))))

    def _limit(self) -> int:
        try:
            v = int(self.limit_ent.get().strip() or "800")
            return max(200, min(VIDS_LIMIT, v))
        except ValueError:
            return 800

    def _current_jobs(self):
        """Trả (danh_sách_câu, mô_tả) theo tab đang mở."""
        cur = str(self.tabs.get() or "")
        if "SRT" in cur.upper():
            says = parse_srt(self.srt_box.get("1.0", "end"))
            return says, "SRT"
        text = self.textbox.get("1.0", "end")
        return split_text(text, self._limit()), "TEXT"

    def _update_count(self):
        jobs, mode = self._current_jobs()
        if mode == "SRT":
            self.count_lbl.configure(text=f"{len(jobs)} câu phụ đề")
        else:
            raw_len = len(self.textbox.get("1.0", "end").strip())
            self.count_lbl.configure(text=f"{raw_len:,} ký tự · {len(jobs)} đoạn")

    def _import_txt(self):
        f = filedialog.askopenfilename(title="Chọn file văn bản", filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if f:
            try:
                with open(f, "r", encoding="utf-8", errors="ignore") as fp:
                    data = fp.read()
                self.textbox.delete("1.0", "end")
                self.textbox.insert("1.0", data)
                self._update_count()
                self.log(f"📄 Đã nhập {os.path.basename(f)} ({len(data):,} ký tự)")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def _import_srt(self):
        f = filedialog.askopenfilename(title="Chọn file phụ đề", filetypes=[("SubRip", "*.srt"), ("All", "*.*")])
        if f:
            try:
                with open(f, "r", encoding="utf-8", errors="ignore") as fp:
                    data = fp.read()
                self.srt_box.delete("1.0", "end")
                self.srt_box.insert("1.0", data)
                says = parse_srt(data)
                self._update_count()
                self.log(f"🎬 Đã nhập {os.path.basename(f)} — {len(says)} câu phụ đề")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def _pick_out(self):
        d = filedialog.askdirectory(title="Chọn thư mục lưu")
        if d:
            self.save_dir = d
            self.path_lbl.configure(text=d)

    def _open_out(self):
        os.makedirs(self.save_dir, exist_ok=True)
        try:
            os.startfile(self.save_dir)
        except Exception:
            pass

    def _load_accounts(self):
        self.accounts = vids_backend.load_accounts(log=self.log)
        names = list(self.accounts.keys())
        if names:
            self.acc_cb.configure(values=names)
            self.acc_cb.set(names[0])
            self.log(f"✅ {len(names)} tài khoản: {', '.join(names)}")
        else:
            self.acc_cb.configure(values=["(chưa có)"])
            self.acc_cb.set("(chưa có)")
            self.log("⚠️ Chưa có tài khoản — bấm '🍪 Quản lý cookie…' để thêm hoặc mở Chrome đăng nhập Google.")

    def _backend(self):
        name = self.acc_cb.get().strip()
        ck = self.accounts.get(name)
        if not ck:
            return None
        return vids_backend.VidsBackend(ck, config=self.cfg, name=name)

    def _check_cookie(self):
        be = self._backend()
        if not be:
            messagebox.showwarning("Thiếu", "Chưa chọn tài khoản.")
            return
        self.log(f"🔎 Kiểm tra cookie [{be.name}]…")

        def _work():
            try:
                ok, code, text = be.quota_summary()
                if ok:
                    q = vids_backend.parse_quota(text)
                    if q:
                        self.log(f"✅ Cookie SỐNG — còn {q['remaining']}/{q['total']} lượt (làm mới {q['reset']}).")
                    else:
                        self.log("✅ Cookie sống (không đọc được số lượt).")
                elif code == 401:
                    self.log("❌ Cookie CHẾT (401) — xuất lại cookie mới, ghi đè file trong vids_cookies/.")
                else:
                    self.log(f"⚠️ HTTP {code}: {text[:180]}")
            except Exception as e:
                self.log(f"❌ Lỗi mạng: {e}")

        threading.Thread(target=_work, daemon=True).start()

    def _cookie_dir(self) -> str:
        d = os.path.join(APP_DIR, "vids_cookies")
        os.makedirs(d, exist_ok=True)
        return d

    def _account_names(self) -> list[str]:
        out = []
        d = self._cookie_dir()
        for fn in sorted(os.listdir(d)):
            nm, ext = os.path.splitext(fn)
            if ext.lower() in (".json", ".txt") and nm not in out:
                out.append(nm)
        return out

    def _next_name(self) -> str:
        have = set(self._account_names())
        i = 1
        while True:
            cand = f"acc_{i:02d}"
            if cand not in have:
                return cand
            i += 1

    def _delete_account(self, name: str):
        d = self._cookie_dir()
        for ext in (".json", ".txt"):
            p = os.path.join(d, name + ext)
            if os.path.isfile(p):
                try:
                    os.remove(p)
                except Exception:
                    pass
        self.log(f"🗑 Đã xoá tài khoản [{name}]")
        self._load_accounts()

    def _save_account(self, name: str, cookie_text: str, link: str = ""):
        clean_nm = re.sub(r"[^A-Za-z0-9_.-]", "_", (name or "").strip())
        if not clean_nm:
            return False, "Chưa đặt tên tài khoản."
        try:
            ck = vids_backend.parse_cookies(cookie_text)
        except Exception as e:
            return False, f"Cookie không đọc được: {e}"
        if not (ck.get("SAPISID") or ck.get("__Secure-3PAPISID")):
            return False, "Cookie thiếu SAPISID — xuất lại khi ĐÃ đăng nhập Google."

        be = vids_backend.VidsBackend(ck, config=self.cfg, name=clean_nm)
        try:
            ok, code, text = be.quota_summary()
        except Exception as e:
            return False, f"Lỗi kiểm tra: {e}"
        if not ok:
            return False, f"Cookie không dùng được (HTTP {code}) — xuất lại cookie."

        out_path = os.path.join(self._cookie_dir(), f"{clean_nm}.json")
        try:
            raw = cookie_text.strip()
            if raw.startswith("[") or raw.startswith("{"):
                data = json.loads(raw)
                if isinstance(data, dict) and "cookies" in data:
                    blob = data["cookies"]
                else:
                    blob = data
            else:
                blob = [{"name": k, "value": v, "domain": ".google.com"} for k, v in ck.items()]
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(blob, f, ensure_ascii=False, indent=2)
        except Exception as e:
            return False, f"Không ghi được cookie: {e}"

        did = vids_backend.doc_id_of(link)
        if did:
            self.cfg.setdefault("doc_ids", {})[clean_nm] = did
            if not self.cfg.get("doc_id"):
                self.cfg["doc_id"] = did
            cfg_path = os.path.join(APP_DIR, "vids_config.json")
            try:
                with open(cfg_path, "w", encoding="utf-8") as f:
                    json.dump(self.cfg, f, indent=2, ensure_ascii=False)
            except Exception:
                pass

        q = vids_backend.parse_quota(text)
        extra = f" · còn {q['remaining']}/{q['total']} lượt" if q else ""
        self._load_accounts()
        return True, f"Đã lưu [{clean_nm}]{extra}"

    def _cookie_manager(self):
        win = ctk.CTkToplevel(self.host)
        win.title("Quản lý cookie Google Vids")
        win.geometry("620x520")
        win.configure(fg_color=T.BG)
        win.transient(self.host.winfo_toplevel())
        win.grab_set()

        lbl(win, "TÀI KHOẢN GOOGLE VIDS", T.TEXT_STRONG, F.title, anchor="w").pack(fill="x", padx=18, pady=(16, 4))

        top = row(win)
        top.pack(fill="x", padx=18, pady=6)

        box = card(win)
        box.pack(fill="both", expand=True, padx=18, pady=4)
        lst = ctk.CTkScrollableFrame(box, fg_color="transparent", corner_radius=0)
        lst.pack(fill="both", expand=True, padx=8, pady=8)

        def refresh():
            for w in lst.winfo_children():
                w.destroy()
            names = self._account_names()
            if not names:
                lbl(lst, "Chưa có tài khoản — bấm “Thêm tài khoản mới”.", T.MUTED, F.ui).pack(pady=24)
                return
            for nm in names:
                r = card(lst, fg_color=T.INPUT, corner_radius=T.RADIUS)
                r.pack(fill="x", pady=3, padx=2)
                lbl(r, f"👤  {nm}", T.TEXT_STRONG, F.ui_sb, anchor="w").pack(side="left", padx=12, pady=8)
                sbtn(
                    r,
                    "✕ Xoá",
                    lambda n=nm: (self._delete_account(n), refresh()),
                    width=60,
                    fg_color=T.DANGER_BG,
                    text_color=T.DANGER_TEXT,
                ).pack(side="right", padx=10, pady=6)

        btn_primary(top, "➕  Thêm tài khoản mới", lambda: self._add_account_dialog(win, refresh), width=190).pack(side="left")
        btn(win, "Đóng", win.destroy, width=90).pack(anchor="e", padx=18, pady=12)
        refresh()

    def _add_account_dialog(self, parent, on_done):
        d = ctk.CTkToplevel(parent)
        d.title("Thêm tài khoản")
        d.geometry("560x560")
        d.configure(fg_color=T.BG)
        d.transient(parent)
        d.grab_set()

        lbl(d, "Tên tài khoản (không dấu cách)", T.LABEL, F.label, anchor="w").pack(fill="x", padx=18, pady=(14, 2))
        e_name = ctk.CTkEntry(d, height=T.H_CTRL, corner_radius=T.RADIUS, fg_color=T.INPUT, border_color=T.BORDER, text_color=T.TEXT, font=F.ui)
        e_name.insert(0, self._next_name())
        e_name.pack(fill="x", padx=18, pady=(0, 8))

        lbl(d, "Cookie — ở extension bấm 'Copy cookie + link' (hoặc Cookie-Editor JSON) rồi dán vào đây", T.LABEL, F.label, anchor="w").pack(
            fill="x", padx=18, pady=(4, 2)
        )
        t_ck = ctk.CTkTextbox(d, height=220, corner_radius=T.RADIUS, fg_color=T.INPUT, border_color=T.BORDER, border_width=1, text_color=T.TEXT, font=F.mono_sm)
        t_ck.pack(fill="both", expand=True, padx=18, pady=(0, 8))

        lbl(d, "Link file Google Vids (tuỳ chọn — voice không cần)", T.LABEL, F.label, anchor="w").pack(fill="x", padx=18, pady=(4, 2))
        e_doc = ctk.CTkEntry(
            d,
            height=T.H_CTRL,
            corner_radius=T.RADIUS,
            fg_color=T.INPUT,
            border_color=T.BORDER,
            text_color=T.TEXT,
            font=F.ui,
            placeholder_text="https://docs.google.com/videos/d/.../edit",
        )
        e_doc.pack(fill="x", padx=18, pady=(0, 8))

        st = lbl(d, "", T.MUTED, F.tiny, anchor="w")
        st.pack(fill="x", padx=18, pady=2)

        def save():
            st.configure(text="Đang kiểm tra cookie…", text_color=T.WARN)
            d.update_idletasks()
            ok, msg = self._save_account(e_name.get(), t_ck.get("1.0", "end"), e_doc.get())
            if not ok:
                st.configure(text=f"❌ {msg}", text_color=T.DANGER_TEXT)
                return
            self.log(f"➕ {msg}")
            on_done()
            d.destroy()

        bar = row(d)
        bar.pack(fill="x", padx=18, pady=12)
        btn_primary(bar, "Kiểm tra & Lưu", save, width=150).pack(side="right", padx=(6, 0))
        btn(bar, "Huỷ", d.destroy, width=80).pack(side="right")

    def _run(self):
        if self.running:
            return
        be = self._backend()
        if not be:
            messagebox.showwarning("Thiếu", "Chưa chọn tài khoản (cookie).")
            return
        jobs, mode = self._current_jobs()
        if not jobs:
            messagebox.showwarning("Thiếu", "Chưa có nội dung để tạo.")
            return

        try:
            self._nthreads_snap = max(1, int(self.threads_cb.get() or "1"))
        except ValueError:
            self._nthreads_snap = 1
        self._voice_snap = self.voice_cb.get().strip() or "Kore"
        self._autotag_snap = bool(self.autotag.get())
        self._merge_snap = bool(self.merge.get())

        self.running = True
        self.stop_flag.clear()
        self._auth_dead.clear()
        self.run_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self._set_progress(0)

        threading.Thread(target=self._worker, args=(be, jobs, mode), daemon=True).start()

    def _stop(self):
        self.stop_flag.set()
        self.log("⏹ Đang dừng sau đoạn hiện tại…")

    def _worker(self, be, jobs: list[str], mode: str):
        total = len(jobs)
        nthreads = getattr(self, "_nthreads_snap", 1)
        unit = "câu (SRT)" if mode == "SRT" else "đoạn"
        voice = getattr(self, "_voice_snap", "Kore")
        self.log(f"▶ Bắt đầu {total} {unit} · giọng {voice} · {nthreads} luồng")

        made = {}
        done = 0
        dlock = threading.Lock()
        try:
            with ThreadPoolExecutor(max_workers=nthreads) as ex:
                futs = {ex.submit(self._process_one, be, i, total, ch): i for i, ch in enumerate(jobs, 1)}
                for fut in as_completed(futs):
                    idx = futs[fut]
                    try:
                        dst = fut.result()
                        if dst:
                            made[idx] = dst
                    except Exception as e:
                        self.log(f"❌ Đoạn {idx} lỗi: {e}")
                    with dlock:
                        done += 1
                        self._set_progress(done / max(1, total))
                        self._status(f"Xong {done}/{total}…")

            ok_files = [made[i] for i in sorted(made.keys()) if os.path.isfile(made[i])]
            if getattr(self, "_merge_snap", True) and len(ok_files) >= 2 and not self.stop_flag.is_set():
                self._merge(ok_files)

            if self._auth_dead.is_set():
                self._status("Cookie chết (401) — xuất lại cookie rồi chạy lại.")
            else:
                msg = f"Hoàn tất: {len(ok_files)}/{total} file → {self.save_dir}"
                self._status(msg)
                self.log(f"🏁 {msg}")
        except Exception as e:
            self.log(f"❌ Lỗi: {e}")
        finally:
            self.running = False
            self.host.after(0, lambda: (self.run_btn.configure(state="normal"), self.stop_btn.configure(state="disabled")))

    def _process_one(self, be, idx: int, total: int, chunk: str):
        if self.stop_flag.is_set() or self._auth_dead.is_set():
            return None
        name = f"{idx:04d}.wav"
        dst = os.path.join(self.save_dir, name)
        if os.path.isfile(dst) and os.path.getsize(dst) >= VOICE_MIN_SIZE:
            self.log(f"⏭ [{idx:03d}/{total:03d}] {name}: đã có — bỏ qua")
            return dst

        raw = clean_text(chunk)
        tagged = raw
        if getattr(self, "_autotag_snap", True):
            tagged = be.add_emotion_tags(raw)
            if tagged != raw:
                self.log(f"🏷 [{idx:03d}/{total:03d}]: đã chèn thẻ cảm xúc")

        self.log(f"🎙 [{idx:03d}/{total:03d}] ({len(raw)} ký tự) — đang tạo…")
        path, st = self._synth_piece(be, tagged, name, f"[{idx:03d}/{total:03d}]", raw=raw, attempts=2)
        if path:
            self.log(f"✅ [{idx:03d}/{total:03d}]: xong → {name}")
            return path
        if st == "AUTH" or self.stop_flag.is_set():
            return None

        # Cứu đoạn bị lọc nội dung: đọc từng câu rồi ghép lại bằng ffmpeg
        sents = _sentences(raw)
        if len(sents) >= 2 and shutil.which("ffmpeg"):
            self.log(f"✂ [{idx:03d}/{total:03d}]: cả đoạn bị từ chối — thử đọc từng câu ({len(sents)} câu)…")
            parts = []
            refused = 0
            for s_idx, sent in enumerate(sents, 1):
                if self.stop_flag.is_set() or self._auth_dead.is_set():
                    break
                sub_name = f"{idx:04d}_part{s_idx:02d}.wav"
                p2, st2 = self._synth_piece(be, sent, sub_name, f"[{idx:03d}.{s_idx:02d}]", raw=sent, attempts=2)
                if p2:
                    parts.append(p2)
                else:
                    refused += 1
                    self.log(f"   – [{idx:03d}.{s_idx:02d}]: câu bị chặn, bỏ")
            if parts and self._concat(parts, dst):
                for p2 in parts:
                    try:
                        os.remove(p2)
                    except Exception:
                        pass
                self.log(f"✅ [{idx:03d}/{total:03d}]: ghép {len(parts)} câu (bỏ {refused} câu bị chặn) → {name}")
                return dst

        self.log(f"🚫 [{idx:03d}/{total:03d}]: Google từ chối đọc — ghi vào bi_tu_choi.txt.")
        ref_path = os.path.join(self.save_dir, "bi_tu_choi.txt")
        with open(ref_path, "a", encoding="utf-8") as f:
            f.write(f"===== ĐOẠN {idx:04d} ({len(raw)} ký tự) =====\n{raw}\n\n")
        return None

    def _synth_piece(self, be, text: str, name: str, label: str, raw: str = None, attempts: int = 2):
        dst = os.path.join(self.save_dir, name)
        status, url = self._gen_retry(be, text, label, raw=raw, attempts=attempts)
        if status != "OK":
            return None, status
        self.log(f"⬇ {label}: Đang tải trực tiếp bằng Python...")
        ok, msg = be.download(url, dst, min_size=VOICE_MIN_SIZE)
        if ok:
            return dst, "OK"
        self.log(f"⚠️ {label}: Lỗi tải trực tiếp ({msg}) - có thể bị 403 do Google chặn.")
        return None, "NODL"

    def _gen_retry(self, be, chunk: str, label: str, raw: str = None, attempts: int = 2):
        voice = getattr(self, "_voice_snap", "Kore")
        last = ""
        use = chunk
        for att in range(1, attempts + 1):
            if self.stop_flag.is_set() or self._auth_dead.is_set():
                return "STOP", "đã dừng"
            status, url = be.generate_voice(use, voice=voice)
            if status == "OK":
                return "OK", url
            last = url
            if any(k in last for k in ("401", "SESSION_COOKIE_INVALID", "invalid authentication")):
                self._auth_dead.set()
                self.log("⛔ COOKIE CHẾT (401) — dừng. Xuất lại cookie mới rồi chạy lại (đoạn đã có sẽ tự bỏ qua).")
                return "AUTH", last
            if att < attempts:
                if raw and use != raw:
                    use = raw
                    self.log(f"↻ {label}: bị từ chối — bỏ thẻ cảm xúc, thử lại…")
                else:
                    self.log(f"↻ {label}: bị từ chối, thử lại {att}/{attempts}…")
                time.sleep(1.5)
        return "FAIL", last

    def _concat(self, files: list[str], out: str) -> bool:
        listf = out + ".list.txt"
        try:
            with open(listf, "w", encoding="utf-8") as f:
                for p in files:
                    safe_p = p.replace("'", "'\\''")
                    f.write(f"file '{safe_p}'\n")
            r = subprocess.run(
                ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", listf, "-ar", "24000", "-ac", "1", out],
                capture_output=True,
                text=True,
                creationflags=0x08000000,
            )
            return r.returncode == 0 and os.path.isfile(out) and os.path.getsize(out) >= VOICE_MIN_SIZE
        except Exception:
            return False
        finally:
            if os.path.isfile(listf):
                try:
                    os.remove(listf)
                except Exception:
                    pass

    def _merge(self, files: list[str]):
        if not shutil.which("ffmpeg"):
            self.log("⚠️ Không có ffmpeg trong PATH — bỏ qua ghép file.")
            return
        out = os.path.join(self.save_dir, "voice_full.wav")
        if self._concat(files, out):
            self.log(f"🔗 Đã ghép → {out}")
        else:
            self.log("⚠️ Ghép lỗi.")


def build_tab(frame, pipeline=None, *args, **kwargs):
    """Điểm vào chuẩn Film Studio — dựng tab Tạo Voice Google Vids vào `frame`."""
    app = App(frame)
    app.pipeline = pipeline
    return app
