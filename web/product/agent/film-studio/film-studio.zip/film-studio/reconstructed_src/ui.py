"""
ui.py — BẢN CHO ALL-TOOL-YOUTUBE (màu xanh ngọc #00A99D)
─────────────────────────────────────────────────────────────
Giao diện & Bộ công cụ UI dùng chung cho các tab VEO 3 (tool4, tool5, tool7, tt).
"""

import os
import sys
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk


class T:
    """Bảng màu & kích thước chuẩn CineFlow AI Studio (Slate-Cyan High-Contrast Theme)."""
    BG = "#0f1419"
    SIDEBAR = "#131a22"
    CARD = "#17202a"
    INPUT = "#10171f"
    BORDER = "#263445"
    BORDER_SOFT = "#1f2c3a"
    DIVIDER = "#1e2936"

    TEXT = "#e6eef8"
    TEXT_STRONG = "#f8fbff"
    LABEL = "#c9d6e5"
    TEXT_DIM = "#8fa3ba"
    MUTED = "#62768c"

    ACCENT = "#00b4d8"
    ACCENT_HOVER = "#22c5e8"
    ACCENT_SOFT = "#0d2b38"

    TAB_HOVER = "#1b2836"
    TAB_ACTIVE = "#113547"
    TAB_HOVER_TXT = "#7ce8ff"

    BTN = "#1c2633"
    BTN_HOVER = "#263344"
    BTN_BORDER = "#2e3e52"

    OK = "#34d399"
    DANGER = "#f43f5e"
    DANGER_BG = "#2c1620"
    DANGER_BORDER = "#642636"
    DANGER_TEXT = "#fb7185"
    WARN = "#fbbf24"

    RADIUS = 7
    RADIUS_CARD = 10
    H_CTRL = 32
    H_BAR = 44
    H_TAB = 34
    PAD = 10
    PADC = 12
    GAP = 8
    STEP_PAD = 6
    PANE_MIN = 110
    PANE_HEAD = 36


class F:
    """Font — khởi tạo sau khi đã có root window."""
    ui = None
    ui_sb = None
    title = None
    h = None
    label = None
    tiny = None
    group = None
    mono = None
    mono_sm = None

    @classmethod
    def init(cls):
        if cls.ui is not None:
            return
        try:
            cls.ui = ctk.CTkFont(family="Segoe UI", size=13)
            cls.ui_sb = ctk.CTkFont(family="Segoe UI", size=13, weight="bold")
            cls.title = ctk.CTkFont(family="Segoe UI", size=15, weight="bold")
            cls.h = ctk.CTkFont(family="Segoe UI", size=11, weight="bold")
            cls.label = ctk.CTkFont(family="Segoe UI", size=12)
            cls.tiny = ctk.CTkFont(family="Segoe UI", size=11)
            cls.group = ctk.CTkFont(family="Segoe UI", size=10, weight="bold")
            cls.mono = ctk.CTkFont(family="Consolas", size=12)
            cls.mono_sm = ctk.CTkFont(family="Consolas", size=11)
        except Exception:
            cls.ui = ("Segoe UI", 13)
            cls.ui_sb = ("Segoe UI", 13, "bold")
            cls.title = ("Segoe UI", 15, "bold")
            cls.h = ("Segoe UI", 11, "bold")
            cls.label = ("Segoe UI", 12)
            cls.tiny = ("Segoe UI", 11)
            cls.group = ("Segoe UI", 10, "bold")
            cls.mono = ("Consolas", 12)
            cls.mono_sm = ("Consolas", 11)


_density_done = False


def set_density(screen_h=None):
    """Thu nhỏ giao diện cho màn hình thấp."""
    global _density_done
    if _density_done:
        return
    _density_done = True
    if screen_h is None:
        try:
            import ctypes
            screen_h = ctypes.windll.user32.GetSystemMetrics(1)
        except Exception:
            screen_h = 1080
    if screen_h <= 800:
        T.H_CTRL, T.H_BAR, T.H_TAB = 26, 36, 30
        T.PAD, T.PADC, T.GAP = 8, 9, 5
    elif screen_h <= 950:
        T.H_CTRL, T.H_BAR, T.H_TAB = 28, 38, 32
        T.PAD, T.PADC, T.GAP = 9, 10, 6


def set_density_early():
    """Áp mật độ + zoom TRƯỚC khi tạo cửa sổ CustomTkinter đầu tiên."""
    set_density()


def card(parent, **kw):
    kw.setdefault("fg_color", T.CARD)
    kw.setdefault("corner_radius", T.RADIUS_CARD)
    kw.setdefault("border_color", T.BORDER_SOFT)
    kw.setdefault("border_width", 1)
    return ctk.CTkFrame(parent, **kw)


def row(parent, **kw):
    kw.setdefault("fg_color", "transparent")
    return ctk.CTkFrame(parent, **kw)


def lbl(parent, text="", color=None, font=None, **kw):
    F.init()
    kw.setdefault("text", text)
    kw.setdefault("text_color", color or T.TEXT)
    kw.setdefault("font", font or F.ui)
    return ctk.CTkLabel(parent, **kw)


def btn(parent, text="", command=None, width=100, height=None, **kw):
    F.init()
    kw.setdefault("text", text)
    kw.setdefault("command", command)
    kw.setdefault("width", width)
    kw.setdefault("height", height or T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.BTN)
    kw.setdefault("hover_color", T.BTN_HOVER)
    kw.setdefault("border_color", T.BTN_BORDER)
    kw.setdefault("border_width", 1)
    kw.setdefault("text_color", T.TEXT)
    kw.setdefault("font", F.ui)
    return ctk.CTkButton(parent, **kw)


def btn_primary(parent, text="", command=None, width=120, height=None, **kw):
    F.init()
    kw.setdefault("text", text)
    kw.setdefault("command", command)
    kw.setdefault("width", width)
    kw.setdefault("height", height or T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.ACCENT)
    kw.setdefault("hover_color", T.ACCENT_HOVER)
    kw.setdefault("text_color", "#ffffff")
    kw.setdefault("font", F.ui_sb)
    return ctk.CTkButton(parent, **kw)


def btn_danger(parent, text="", command=None, width=100, height=None, **kw):
    F.init()
    kw.setdefault("text", text)
    kw.setdefault("command", command)
    kw.setdefault("width", width)
    kw.setdefault("height", height or T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.DANGER_BG)
    kw.setdefault("hover_color", "#3a2029")
    kw.setdefault("border_color", T.DANGER_BORDER)
    kw.setdefault("border_width", 1)
    kw.setdefault("text_color", T.DANGER_TEXT)
    kw.setdefault("font", F.ui_sb)
    return ctk.CTkButton(parent, **kw)


def sbtn(parent, text="", cmd=None, width=90, **kw):
    return btn(parent, text=text, command=cmd, width=width, **kw)


def btn_quiet(parent, text="", command=None, width=90, height=None, **kw):
    F.init()
    kw.setdefault("text", text)
    kw.setdefault("command", command)
    kw.setdefault("width", width)
    kw.setdefault("height", height or (T.H_CTRL - 2))
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", "transparent")
    kw.setdefault("hover_color", T.BTN_HOVER)
    kw.setdefault("border_color", T.BORDER_SOFT)
    kw.setdefault("border_width", 1)
    kw.setdefault("text_color", T.TEXT_DIM)
    kw.setdefault("font", F.tiny)
    return ctk.CTkButton(parent, **kw)


def switch(parent, text="", variable=None, command=None, **kw):
    F.init()
    kw.setdefault("text", text)
    if variable is not None:
        kw.setdefault("variable", variable)
    if command is not None:
        kw.setdefault("command", command)
    kw.setdefault("progress_color", T.ACCENT)
    kw.setdefault("button_color", "#ffffff")
    kw.setdefault("button_hover_color", T.TAB_HOVER_TXT)
    kw.setdefault("fg_color", T.BORDER)
    kw.setdefault("text_color", T.TEXT)
    kw.setdefault("font", F.ui)
    return ctk.CTkSwitch(parent, **kw)


def combo(parent, values, width=160, command=None, state="readonly", **kw):
    F.init()
    kw.setdefault("values", list(values))
    kw.setdefault("width", width)
    kw.setdefault("height", T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.INPUT)
    kw.setdefault("border_color", T.BORDER)
    kw.setdefault("border_width", 1)
    kw.setdefault("button_color", T.BTN)
    kw.setdefault("button_hover_color", T.TAB_ACTIVE)
    kw.setdefault("text_color", T.TEXT)
    kw.setdefault("dropdown_fg_color", T.CARD)
    kw.setdefault("dropdown_hover_color", T.TAB_ACTIVE)
    kw.setdefault("dropdown_text_color", T.TEXT)
    kw.setdefault("font", F.ui)
    kw.setdefault("dropdown_font", F.ui)
    kw.setdefault("state", state)
    if command is not None:
        kw["command"] = command
    return ctk.CTkComboBox(parent, **kw)


def _sync_combo(cb, var):
    """Đồng bộ biến tk.Variable với CTkOptionMenu / CTkComboBox."""
    try:
        v = var.get()
        if v:
            cb.set(v)
    except Exception:
        pass
    return cb


def wire_hover(btn_widget, active_check=None):
    """Gắn hiệu ứng hover sáng chữ cho nút tab."""
    try:
        def _enter(_e=None):
            if active_check and active_check():
                return
            btn_widget.configure(text_color=T.TEXT_STRONG)

        def _leave(_e=None):
            if active_check and active_check():
                return
            btn_widget.configure(text_color=T.TEXT_DIM)

        btn_widget.bind("<Enter>", _enter, add="+")
        btn_widget.bind("<Leave>", _leave, add="+")
    except Exception:
        pass
    return btn_widget


def opt(parent, values, width=160, command=None, **kw):
    F.init()
    kw.setdefault("values", list(values))
    kw.setdefault("width", width)
    kw.setdefault("height", T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.INPUT)
    kw.setdefault("button_color", T.BTN)
    kw.setdefault("button_hover_color", T.BTN_HOVER)
    kw.setdefault("text_color", T.TEXT)
    kw.setdefault("dropdown_fg_color", T.CARD)
    kw.setdefault("dropdown_hover_color", T.TAB_HOVER)
    kw.setdefault("dropdown_text_color", T.TEXT)
    kw.setdefault("font", F.ui)
    kw.setdefault("dropdown_font", F.ui)
    if command is not None:
        kw["command"] = command
    return ctk.CTkOptionMenu(parent, **kw)


def entry(parent, **kw):
    F.init()
    kw.setdefault("height", T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.INPUT)
    kw.setdefault("border_color", T.BORDER)
    kw.setdefault("border_width", 1)
    kw.setdefault("text_color", T.TEXT)
    kw.setdefault("font", F.ui)
    return ctk.CTkEntry(parent, **kw)


def grid_field(parent, r, text, widget, label_w=92):
    F.init()
    l = lbl(parent, text, T.LABEL, F.label, width=label_w, anchor="w")
    l.grid(row=r, column=0, sticky="w", pady=3, padx=(0, 6))
    widget.grid(row=r, column=1, sticky="ew", pady=3)
    return l


def note(parent, r, text):
    F.init()
    n = lbl(parent, text, T.MUTED, F.tiny, anchor="w", justify="left", wraplength=270)
    n.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(2, 6))
    return n


def group(parent, r, title):
    F.init()
    g = lbl(parent, title.upper(), T.ACCENT, F.group, anchor="w")
    g.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(8, 3))
    return g


def _scroll(parent):
    parent.grid_rowconfigure(0, weight=1)
    parent.grid_columnconfigure(0, weight=1)
    sf = ctk.CTkScrollableFrame(
        parent,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    sf.grid(row=0, column=0, sticky="nsew", padx=T.PAD, pady=4)
    sf.columnconfigure(0, weight=1)
    sf.columnconfigure(1, weight=1)
    return sf


class TabStrip:
    """Hàng tab chữ IN HOA + hover sáng. API giống CTkTabview: add/tab/set/get."""

    def __init__(self, parent, height=28, minw=84):
        F.init()
        self._bar = ctk.CTkFrame(parent, fg_color=T.INPUT, corner_radius=T.RADIUS)
        self._holder = ctk.CTkFrame(parent, fg_color="transparent")
        self._holder.grid_rowconfigure(0, weight=1)
        self._holder.grid_columnconfigure(0, weight=1)
        self._frames = {}
        self._btns = {}
        self._order = []
        self._current = None
        self._h = height
        self._minw = minw

    def add(self, name: str):
        frame = ctk.CTkFrame(self._holder, fg_color="transparent")
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        self._frames[name] = frame
        self._order.append(name)

        b = ctk.CTkButton(
            self._bar,
            text=name.upper(),
            height=self._h,
            width=self._minw,
            corner_radius=T.RADIUS - 1,
            fg_color="transparent",
            hover_color=T.TAB_HOVER,
            text_color=T.TEXT_DIM,
            font=F.h,
            command=lambda n=name: self.set(n),
        )
        b.pack(side="left", fill="x", expand=True, padx=2, pady=2)
        self._btns[name] = b
        if self._current is None:
            self.set(name)
        return frame

    def _resolve(self, name):
        if name in self._frames:
            return name
        for k in self._order:
            if k.upper() == str(name).upper():
                return k
        return self._order[0] if self._order else name

    def set(self, name: str):
        key = self._resolve(name)
        self._current = key
        for k, fr in self._frames.items():
            if k == key:
                fr.grid(row=0, column=0, sticky="nsew")
            else:
                fr.grid_forget()
        for k, b in self._btns.items():
            if k == key:
                b.configure(fg_color=T.TAB_ACTIVE, text_color=T.TAB_HOVER_TXT)
            else:
                b.configure(fg_color="transparent", text_color=T.TEXT_DIM)

    def get(self):
        return self._current

    def tab(self, name: str):
        return self._frames[self._resolve(name)]

    def grid(self, **kw):
        r = kw.pop("row", 0)
        c = kw.pop("column", 0)
        self._bar.grid(row=r, column=c, sticky="ew", padx=T.PAD, pady=(T.PAD, 4))
        self._holder.grid(row=r + 1, column=c, sticky="nsew", padx=4, pady=2)


def dialog(parent, title="Thông báo", w=600, h=420, grab=False):
    """CTkToplevel theo màu chung, đã canh giữa trên cửa sổ cha."""
    F.init()
    win = ctk.CTkToplevel(parent)
    win.title(title)
    win.configure(fg_color=T.BG)
    try:
        win.transient(parent.winfo_toplevel())
        px = parent.winfo_rootx() + max(0, (parent.winfo_width() - w) // 2)
        py = parent.winfo_rooty() + max(0, (parent.winfo_height() - h) // 2)
        win.geometry(f"{w}x{h}+{px}+{py}")
    except Exception:
        win.geometry(f"{w}x{h}")
    if grab:
        try:
            win.grab_set()
        except Exception:
            pass
    return win


def account_row(app_or_parent, parent_or_idx, idx_or_acc=None, acc_or_app=None):
    """Một tài khoản trong bảng quản lý. Hỗ trợ cả (app, parent, idx, acc) và (parent, idx, acc, app)."""
    F.init()
    if isinstance(parent_or_idx, int):
        parent, idx, acc, app = app_or_parent, parent_or_idx, idx_or_acc, acc_or_app
    else:
        app, parent, idx, acc = app_or_parent, parent_or_idx, idx_or_acc, acc_or_app
    r = card(parent, fg_color=T.INPUT, corner_radius=T.RADIUS)
    r.pack(fill="x", pady=3, padx=2)

    lbl(r, f"{idx + 1:02d}", T.MUTED, F.mono_sm, width=28).pack(side="left", padx=(10, 4), pady=8)

    mid = row(r)
    mid.pack(side="left", fill="x", expand=True, padx=4, pady=6)

    tok = str(acc.get("token", ""))
    tok_short = f"{tok[:10]}…{tok[-6:]}" if len(tok) > 20 else tok
    email = str(acc.get("email", ""))
    credits = acc.get("credits", "Unknown")
    pid = str(acc.get("project_id", ""))
    has_sess = bool(str(acc.get("labs_session", "")).strip())

    head_txt = (
        f"{email}  ·  token {tok_short}"
        if email and not email.startswith("captured_")
        else f"token {tok_short}  ·  {credits} credit"
    )
    lbl(mid, head_txt, T.TEXT_STRONG, F.ui_sb, anchor="w").pack(fill="x")

    pid_txt = f"project {pid[:12]}…" if pid else "chưa có project_id"
    sess_txt = "session: có" if has_sess else "session: thiếu — không tải được video"
    sess_col = T.OK if has_sess else "#e0a458"
    sub = row(mid)
    sub.pack(fill="x")
    lbl(sub, pid_txt + "   ·   ", T.MUTED, F.tiny, anchor="w").pack(side="left")
    lbl(sub, sess_txt, sess_col, F.tiny, anchor="w").pack(side="left")

    ctk.CTkButton(
        r,
        text="✕",
        width=28,
        height=26,
        corner_radius=T.RADIUS,
        fg_color=T.DANGER_BG,
        hover_color="#3a2029",
        border_color=T.DANGER_BORDER,
        border_width=1,
        text_color=T.DANGER_TEXT,
        font=F.tiny,
        command=lambda i=idx: app._delete_account(i),
    ).pack(side="right", padx=10)
    return r


def status_color(lbl_or_text, text: str = None) -> str:
    """Đổi màu nhãn trạng thái theo nội dung. Hỗ trợ cả status_color(lbl, text) và status_color(text)."""
    st = str(text if text is not None else lbl_or_text or "")
    if any(k in st for k in ("Hoàn thành", "Đã có", "Xong", "✅")):
        col = T.OK
    elif any(k in st for k in ("❌", "Lỗi", "🛑", "🚫")):
        col = T.DANGER_TEXT
    elif any(k in st for k in ("Waiting", "Chờ", "⏹")):
        col = T.MUTED
    else:
        col = "#e0a458"
    if text is not None and hasattr(lbl_or_text, "configure"):
        try:
            lbl_or_text.configure(text=st, text_color=col)
        except Exception:
            pass
    return col


def _startfile(file_path):
    """Mở file bằng chương trình mặc định. Không có thì im lặng bỏ qua."""
    if file_path and os.path.exists(file_path):
        try:
            os.startfile(file_path)
        except Exception:
            pass


def track_log_follow(owner, box, attr: str = "_log_follow"):
    """Ô nhật ký: đang ở ĐÁY thì log mới tự cuộn theo; người dùng kéo lên đọc thì
    thôi cuộn (không giật xuống). Dùng: gọi 1 lần sau khi tạo ô; lúc ghi log:
    if getattr(owner, attr, True): box.see("end")."""
    setattr(owner, attr, True)
    tb = getattr(box, "_textbox", box)

    def _check():
        try:
            _, bottom = tb.yview()
            setattr(owner, attr, bottom >= 0.98)
        except Exception:
            pass

    def _on_user_scroll(_event=None):
        try:
            box.after(20, _check)
        except Exception:
            pass

    for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>", "<ButtonRelease-1>", "<B1-Motion>", "<KeyRelease>"):
        try:
            tb.bind(seq, _on_user_scroll, add="+")
        except Exception:
            pass
    return box


def result_row(app, item: dict):
    """Một dòng prompt trong danh sách kết quả."""
    F.init()
    row_id = item["id"]
    text = item.get("text", "")
    status = item.get("status", "Waiting...")
    file_path = item.get("file_path")

    r = card(app.list_frame, fg_color=T.INPUT, corner_radius=T.RADIUS)
    r.pack(fill="x", pady=3, padx=2)

    lbl(r, f"{row_id + 1:03d}", T.MUTED, F.mono_sm, width=30).pack(side="left", padx=(10, 6), pady=7)

    preview = text.replace("\n", " ")
    if len(preview) > 70:
        preview = preview[:70] + "…"
    lbl_prev = lbl(r, preview, T.TEXT, F.ui, anchor="w")
    lbl_prev.pack(side="left", fill="x", expand=True, padx=4)

    bf = row(r)
    bf.pack(side="right", padx=8, pady=4)

    lbl_st = lbl(r, status, status_color(status), F.tiny, width=126, anchor="w")
    lbl_st.pack(side="right", padx=6)

    sbtn(bf, "Sửa", lambda rid=row_id: app.on_edit_prompt(rid), width=48).pack(side="left", padx=2)
    sbtn(bf, "Tạo lại", lambda rid=row_id: app.on_regen_prompt(rid), width=62).pack(side="left", padx=2)
    sbtn(bf, "Xoá", lambda rid=row_id: app.on_delete_video(rid), width=46).pack(side="left", padx=2)

    btn_view = sbtn(
        bf,
        "Xem",
        (lambda fp=file_path: _startfile(fp)) if file_path else None,
        width=52,
        state="normal" if file_path else "disabled",
    )
    btn_view.pack(side="left", padx=2)

    app.rows_ui[row_id] = {
        "frame": r,
        "status_lbl": lbl_st,
        "view_btn": btn_view,
        "text_preview": lbl_prev,
    }
    return r
