"""
ui_openspeaker.py — Giao diện tab "HaThanh TTS" (openspeaker_tts.py), tách riêng.
────────────────────────────────────────────────────────────────────────────────
Dùng chung bộ màu / thành phần với ui.py nên liền mạch với giao diện tổng.

Cách dùng trong openspeaker_tts.py:

    import ui_openspeaker as _uio

    class HaThanhVoiceApp(ctk.CTkFrame):
        def _build_ui(self):                 _uio.setup_ui(self)
        def _build_left(self):               _uio.build_left(self)
        def _build_right(self):              _uio.build_right(self)
        def _build_tag_bar(self, p, row, t): _uio.build_tag_bar(self, p, row, t)
        def _build_tab_dialogue(self, tab, *a): _uio.build_tab_dialogue(self, tab)
        def _build_tab_dict(self, tab, *a):     _uio.build_tab_dict(self, tab)
        def _build_tab_clone(self, tab, *a):    _uio.build_tab_clone(self, tab)

Mọi TÊN BIẾN giữ nguyên (ent_key, cb_voice, textbox, tabview, file_list ...) nên
phần xử lý trong openspeaker_tts.py và tt.py không phải sửa gì.
"""

import sys
import tkinter as tk
import customtkinter as ctk
from ui import (
    T,
    F,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    btn_quiet,
    lbl,
    switch,
    wire_hover,
    TabStrip,
    set_density_early,
)


def _mod(app):
    return sys.modules.get(app.__class__.__module__)


def section(parent, title: str):
    """Thẻ có tiêu đề, trả về vùng nội dung bên trong."""
    c = card(parent)
    c.pack(fill="x", padx=2, pady=T.GAP)
    lbl(c, title, T.TEXT_STRONG, F.ui_sb, anchor="w").pack(fill="x", padx=12, pady=(8, 4))
    body = row(c)
    body.pack(fill="x", padx=12, pady=(0, 10))
    body.columnconfigure(1, weight=1)
    return body


def entry(parent, **kw):
    F.init()
    kw.setdefault("height", T.H_CTRL)
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.INPUT)
    kw.setdefault("border_color", T.BORDER)
    kw.setdefault("text_color", T.TEXT)
    kw.setdefault("font", F.ui)
    return ctk.CTkEntry(parent, **kw)


def combo(parent, values, command=None, state="readonly", width=None):
    F.init()
    kw = dict(
        values=list(values),
        command=command,
        state=state,
        height=T.H_CTRL,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER,
        button_color=T.TAB_ACTIVE,
        button_hover_color=T.ACCENT,
        text_color=T.TEXT,
        dropdown_fg_color=T.CARD,
        dropdown_hover_color=T.TAB_ACTIVE,
        dropdown_text_color=T.TEXT,
        font=F.ui,
        dropdown_font=F.ui,
    )
    if width:
        kw["width"] = width
    return ctk.CTkComboBox(parent, **kw)


def sbtn(parent, text: str, command=None, width=84):
    """Nút phụ có nền — màn này nhiều nút, để nền trong suốt sẽ mờ khó thấy."""
    F.init()
    return ctk.CTkButton(
        parent,
        text=text,
        command=command,
        width=width,
        height=T.H_CTRL,
        corner_radius=T.RADIUS,
        fg_color=T.BTN,
        hover_color=T.BTN_HOVER,
        border_color=T.BTN_BORDER,
        border_width=1,
        text_color=T.TEXT_DIM,
        font=F.ui,
    )


def grid_field(parent, r: int, text: str, widget, label_w: int = 86):
    F.init()
    lbl(parent, text, T.LABEL, F.label, width=label_w, anchor="w").grid(
        row=r, column=0, sticky="w", padx=(0, 6), pady=3
    )
    widget.grid(row=r, column=1, sticky="ew", pady=3)


def _scroll(parent):
    """Vùng cuộn lấp đầy 1 tab."""
    sf = ctk.CTkScrollableFrame(
        parent,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    sf.columnconfigure(0, weight=1)
    sf.columnconfigure(1, weight=1)
    return sf


def _group_head(parent, r: int, title: str):
    """Tiêu đề nhóm nhỏ bên trong 1 tab."""
    lbl(parent, title.upper(), T.MUTED, F.group, anchor="w").grid(
        row=r, column=0, columnspan=2, sticky="ew", pady=(8, 2)
    )


def setup_ui(app):
    set_density_early()
    F.init()
    app.configure(fg_color=T.BG)
    try:
        sw = app.winfo_screenwidth()
    except Exception:
        sw = 1920
    left_w = 380 if sw < 1450 else 430
    app._left_w = left_w

    app.grid_columnconfigure(0, weight=0, minsize=left_w)
    app.grid_columnconfigure(1, weight=1)
    app.grid_rowconfigure(0, weight=1)

    build_left(app)
    build_right(app)
    app._update_char()


def build_left(app):
    col = ctk.CTkFrame(app, fg_color=T.SIDEBAR, corner_radius=0)
    col.grid(row=0, column=0, sticky="nsew")
    col.grid_columnconfigure(0, weight=1)
    col.grid_rowconfigure(1, weight=1)

    app._left_tabs = TabStrip(col, height=26, minw=50)
    t_voice = app._left_tabs.add("Giọng")
    t_filter = app._left_tabs.add("Lọc")
    t_files = app._left_tabs.add("File")
    t_cfg = app._left_tabs.add("Cài đặt")
    app._left_tabs.grid(row=0, column=0)

    _voice_tab(app, _scroll(t_voice))
    _filter_tab(app, _scroll(t_filter))
    _files_tab(app, _scroll(t_files))
    _config_tab(app, _scroll(t_cfg))

    for tab in (t_voice, t_filter, t_files, t_cfg):
        for ch in tab.winfo_children():
            ch.grid(row=0, column=0, sticky="nsew", padx=T.PAD, pady=4)
        tab.grid_rowconfigure(0, weight=1)
        tab.grid_columnconfigure(0, weight=1)

    app._left_tabs.set("Giọng")
    _action_bar(app, col)


def _voice_tab(app, box):
    mod = _mod(app)
    all_src = getattr(mod, "ALL_SRC", "(tất cả nguồn)")
    providers = [all_src] + list(getattr(mod, "PROVIDERS", ["edge", "elevenlabs", "minimax", "vbee", "clone"]))
    lang_codes = list(getattr(mod, "LANG_CODES", {"Tự nhận (auto)": "auto"}).keys())

    app.cb_prov = combo(box, providers, command=lambda _=None: app._load_cached_voices())
    app.cb_prov.set(app.cfg.get("provider", "edge"))
    grid_field(box, 0, "Nguồn", app.cb_prov)

    app.cb_lang = combo(box, ["Tất cả"], command=lambda _=None: app.filter_voices())
    app.cb_lang.set("Tất cả")
    grid_field(box, 1, "Nước", app.cb_lang)

    app.cb_voice = combo(
        box,
        [app.cfg.get("voice_label") or app.cfg.get("voice_id") or "—"],
        command=app._on_pick_voice,
        state="normal",
    )
    app.cb_voice.set(app.cfg.get("voice_label") or app.cfg.get("voice_id") or "—")
    grid_field(box, 2, "Giọng", app.cb_voice)

    sr = row(box)
    sr.grid(row=3, column=0, columnspan=2, sticky="ew", pady=4)
    sr.columnconfigure(0, weight=1)
    app.ent_search = entry(sr, placeholder_text="gõ tên giọng hoặc dán mã voice_id…")
    app.ent_search.grid(row=0, column=0, sticky="ew")
    app.ent_search.bind("<KeyRelease>", lambda _e: app.filter_voices())
    app.ent_search.bind("<Return>", lambda _e: app.search_voices())
    sbtn(sr, "Tìm", app.search_voices, width=48).grid(row=0, column=1, padx=(4, 0))
    app.btn_prev = sbtn(sr, "Nghe thử", app.preview_voice, width=72)
    app.btn_prev.grid(row=0, column=2, padx=(4, 0))

    vr = row(box)
    vr.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(0, 6))
    vr.columnconfigure((0, 1), weight=1)
    btn(vr, "Tải danh sách giọng", app.load_voices).grid(row=0, column=0, sticky="ew", padx=(0, 3))
    btn(vr, "Danh mục giọng", app.open_voice_picker).grid(row=0, column=1, sticky="ew", padx=(3, 0))

    _group_head(box, 5, "Cách đọc")

    app.cb_dict = combo(box, ["— Không dùng —"])
    app.cb_dict.set("— Không dùng —")
    grid_field(box, 6, "Từ điển", app.cb_dict)

    app.cb_quality = combo(box, ["Chất lượng cao", "Giá rẻ (-50%)"])
    app.cb_quality.set("Giá rẻ (-50%)" if app.cfg.get("quality_tier") == "cheap" else "Chất lượng cao")
    grid_field(box, 7, "Chất lượng", app.cb_quality)

    app.cb_lang_out = combo(box, lang_codes)
    app.cb_lang_out.set(app.cfg.get("out_lang", "Tự nhận (auto)"))
    grid_field(box, 8, "Đọc bằng", app.cb_lang_out)

    app.sw_transcript = switch(box, text="Kèm transcript / SRT")
    if app.cfg.get("transcript", True):
        app.sw_transcript.select()
    app.sw_transcript.grid(row=9, column=0, columnspan=2, sticky="w", pady=(6, 4))

    pr = row(box)
    pr.grid(row=10, column=0, columnspan=2, sticky="ew", pady=4)
    lbl(pr, "Tốc độ", T.LABEL, F.label).pack(side="left")
    app.ent_speed = entry(pr, width=52)
    app.ent_speed.insert(0, str(app.cfg.get("speed", "1.0")))
    app.ent_speed.pack(side="left", padx=(4, 10))

    lbl(pr, "Giống mẫu", T.LABEL, F.label).pack(side="left")
    app.ent_sim = entry(pr, width=44)
    app.ent_sim.insert(0, str(app.cfg.get("similarity", "0.85")))
    app.ent_sim.pack(side="left", padx=(4, 10))

    lbl(pr, "Luồng", T.LABEL, F.label).pack(side="left")
    app.ent_threads = entry(pr, width=40)
    app.ent_threads.insert(0, str(app.cfg.get("threads", "2")))
    app.ent_threads.pack(side="left", padx=(4, 0))


def _filter_tab(app, box):
    lbl(
        box,
        "Lọc bớt danh sách giọng cho dễ chọn.",
        T.MUTED,
        F.tiny,
        anchor="w",
        justify="left",
        wraplength=300,
    ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))

    specs = [
        ("Tuổi", "cb_age"),
        ("Loại", "cb_cat"),
        ("Giới tính", "cb_sex"),
        ("Thẻ", "cb_tag"),
        ("Nguồn giọng", "cb_src"),
        ("Giọng điệu", "cb_tone"),
    ]
    for idx, (text, attr) in enumerate(specs, start=1):
        cb = combo(box, ["Tất cả"], command=lambda _=None: app.filter_voices())
        cb.set("Tất cả")
        setattr(app, attr, cb)
        grid_field(box, idx, text, cb, label_w=86)

    def _reset_filters():
        for _, attr in specs:
            getattr(app, attr).set("Tất cả")
        app.filter_voices()

    btn(box, "Bỏ hết bộ lọc", _reset_filters).grid(
        row=len(specs) + 1, column=0, columnspan=2, sticky="ew", pady=10
    )


def _files_tab(app, box):
    r1 = row(box)
    r1.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
    r1.columnconfigure((0, 1), weight=1)
    sbtn(r1, "Chọn tất cả", app.select_all).grid(row=0, column=0, sticky="ew", padx=(0, 3))
    sbtn(r1, "Bỏ chọn", app.deselect_all).grid(row=0, column=1, sticky="ew", padx=(3, 0))

    app.file_list = ctk.CTkScrollableFrame(
        box,
        height=210,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        scrollbar_fg_color=T.INPUT,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.file_list.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 6))

    r2 = row(box)
    r2.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 6))
    r2.columnconfigure((0, 1, 2), weight=1)
    app.btn_play = sbtn(r2, "▶ Nghe", app.playback)
    app.btn_play.grid(row=0, column=0, sticky="ew", padx=(0, 2))
    sbtn(r2, "Nối lại", app.merge_selected).grid(row=0, column=1, sticky="ew", padx=2)
    sbtn(r2, "Xoá", app.delete_selected).grid(row=0, column=2, sticky="ew", padx=(2, 0))

    app.btn_retry = btn(box, "Làm lại phần lỗi", app.retry_failed)
    app.btn_retry.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 4))
    btn_quiet(box, "Đặt lại tool", app.reset_app).grid(row=4, column=0, columnspan=2, sticky="ew")


def _config_tab(app, box):
    _group_head(box, 0, "API Key")
    app.ent_key = entry(box, show="•", font=F.mono_sm, placeholder_text="dán key vào đây…")
    if app.cfg.get("api_key"):
        app.ent_key.insert(0, app.cfg.get("api_key", ""))
    app.ent_key.grid(row=1, column=0, columnspan=2, sticky="ew", pady=4)

    kr = row(box)
    kr.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 4))
    kr.columnconfigure((0, 1, 2), weight=1)
    sbtn(kr, "Hiện", app.toggle_key).grid(row=0, column=0, sticky="ew", padx=(0, 2))
    sbtn(kr, "Lưu", app.save_key).grid(row=0, column=1, sticky="ew", padx=2)
    sbtn(kr, "Số dư", app.check_key).grid(row=0, column=2, sticky="ew", padx=(2, 0))

    app.lbl_credit = lbl(box, "Chưa kiểm tra số dư", T.MUTED, F.tiny, anchor="w")
    app.lbl_credit.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 6))

    _group_head(box, 4, "Khi chạy")
    specs = [
        ("sw_resume", "Bỏ qua file đã có", app.cfg.get("resume", True)),
        ("sw_striptag", "Bỏ thẻ nếu nguồn không hỗ trợ", app.cfg.get("strip_tags", True)),
        ("sw_chain", "Nối ngữ cảnh giữa các đoạn", app.cfg.get("context_chaining", False)),
        ("sw_dump", "Lưu JSON thô (debug)", app.cfg.get("dump", False)),
    ]
    for i, (attr, text, on) in enumerate(specs, start=5):
        sw = switch(box, text=text)
        if on:
            sw.select()
        setattr(app, attr, sw)
        sw.grid(row=i, column=0, columnspan=2, sticky="w", pady=3)

    btn(box, "Lưu cấu hình ngay", app.save_config_now).grid(
        row=10, column=0, columnspan=2, sticky="ew", pady=(10, 4)
    )


def _action_bar(app, col):
    """Thanh điều khiển cố định đáy cột trái — luôn thấy, không phải cuộn."""
    ctk.CTkFrame(col, height=1, fg_color=T.DIVIDER).grid(row=2, column=0, sticky="ew")
    bar = ctk.CTkFrame(col, fg_color=T.SIDEBAR)
    bar.grid(row=3, column=0, sticky="ew", padx=T.PAD, pady=T.PAD)
    bar.grid_columnconfigure((0, 1, 2), weight=1)

    app.btn_gen = btn_primary(bar, "🎙️ Đọc thành tiếng", lambda: app.start_generation(False))
    app.btn_gen.grid(row=0, column=0, sticky="ew", padx=(0, 3), pady=(0, 6))

    app.btn_genmerge = btn(bar, "🔗 Đọc & Nối", lambda: app.start_generation(True))
    app.btn_genmerge.grid(row=0, column=1, sticky="ew", padx=3, pady=(0, 6))

    app.btn_stop = btn_danger(bar, "⏹ Dừng", app.stop_generation)
    app.btn_stop.configure(state="disabled")
    app.btn_stop.grid(row=0, column=2, sticky="ew", padx=(3, 0), pady=(0, 6))

    pr = row(bar)
    pr.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(0, 4))
    pr.columnconfigure((0, 1), weight=1)
    sbtn(pr, "📂 Nơi lưu…", app.choose_save).grid(row=0, column=0, sticky="ew", padx=(0, 3))
    sbtn(pr, "📂 Mở thư mục", app.open_folder).grid(row=0, column=1, sticky="ew", padx=(3, 0))

    app.lbl_path = lbl(bar, app.save_location, T.MUTED, F.tiny, anchor="w", wraplength=320, justify="left")
    app.lbl_path.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(0, 4))

    app.progress = ctk.CTkProgressBar(
        bar, height=6, corner_radius=3, fg_color=T.INPUT, progress_color=T.ACCENT
    )
    app.progress.set(0)
    app.progress.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(0, 4))

    app.lbl_status = lbl(bar, "● Sẵn sàng thu âm (Hỗ trợ Edge-TTS miễn phí)", T.OK, F.tiny, anchor="w")
    app.lbl_status.grid(row=4, column=0, columnspan=3, sticky="ew")

    app.lbl_cost = lbl(bar, "", T.OK, F.tiny, anchor="w")
    app.lbl_cost.grid(row=5, column=0, columnspan=3, sticky="ew")


def build_right(app):
    right = ctk.CTkFrame(app, fg_color=T.BG)
    right.grid(row=0, column=1, sticky="nsew", padx=T.PAD, pady=T.PAD)
    right.grid_columnconfigure(0, weight=1)
    right.grid_rowconfigure(1, weight=1)

    head = row(right)
    head.grid(row=0, column=0, sticky="ew", pady=(0, 4))
    lbl(head, "🎙️ BÀN SOẠN LỜI THOẠI, HỘI THOẠI & PHỤ ĐỀ SRT", T.TEXT_STRONG, F.ui_sb).pack(side="left")
    sbtn(head, "🧹 Làm sạch cũ", lambda: app.clear_previous_session(ask_confirm=True), width=106).pack(side="right", padx=(8, 0))
    app.lbl_char = lbl(head, "0 ký tự", T.MUTED, F.mono_sm)
    app.lbl_char.pack(side="right")

    app.tabview = TabStrip(right, height=30, minw=96)
    t_txt = app.tabview.add("Văn bản")
    t_chk = app.tabview.add("Đoạn chia")
    t_srt = app.tabview.add("SRT")
    t_dlg = app.tabview.add("Hội thoại")
    t_dct = app.tabview.add("Từ điển")
    t_cln = app.tabview.add("Clone giọng")
    app.tabview.grid(row=1, column=0)

    _tab_text(app, _pad(t_txt))
    _tab_chunks(app, _pad(t_chk))
    _tab_srt(app, _pad(t_srt))
    app._build_tab_dialogue(_pad(t_dlg))
    app._build_tab_dict(_pad(t_dct))
    app._build_tab_clone(_pad(t_cln))

    _log_card(app, right)


def _pad(tab):
    """Khung đệm trong 1 tab để nội dung không dính viền."""
    inner = ctk.CTkFrame(tab, fg_color="transparent")
    inner.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
    tab.grid_rowconfigure(0, weight=1)
    tab.grid_columnconfigure(0, weight=1)
    inner.grid_columnconfigure(0, weight=1)
    return inner


def _big_box(parent, **kw):
    F.init()
    kw.setdefault("corner_radius", T.RADIUS)
    kw.setdefault("fg_color", T.INPUT)
    kw.setdefault("border_color", T.BORDER_SOFT)
    kw.setdefault("border_width", 1)
    kw.setdefault("text_color", "#c8ccd8")
    kw.setdefault("font", F.ui)
    kw.setdefault("wrap", "word")
    return ctk.CTkTextbox(parent, **kw)


def _tab_text(app, box):
    box.grid_rowconfigure(2, weight=1)
    bar = row(box)
    bar.grid(row=0, column=0, sticky="ew", pady=(0, 4))
    sbtn(bar, "Nhập TXT", app.import_txt, width=84).pack(side="left", padx=(0, 4))
    sbtn(bar, "🧹 Xoá trắng", lambda: (app.textbox.delete("1.0", "end"), app._update_char()), width=88).pack(side="left", padx=(0, 8))
    lbl(bar, "Cắt đoạn:", T.MUTED, F.tiny).pack(side="left", padx=(0, 6))
    sbtn(bar, "Không chia — 1 file", app.do_no_split, width=138).pack(side="left", padx=2)
    sbtn(bar, "Theo dấu phẩy", app.do_split_comma, width=108).pack(side="left", padx=2)
    sbtn(bar, "Theo dấu câu", app.do_split_punct, width=104).pack(side="left", padx=2)
    sbtn(bar, "Theo dòng", app.do_split_lines, width=88).pack(side="left", padx=2)
    app.lbl_split = lbl(bar, "", T.ACCENT, F.tiny)
    app.lbl_split.pack(side="right")

    app._build_tag_bar(box, 1, lambda: app.textbox)
    app.textbox = _big_box(box)
    app.textbox.grid(row=2, column=0, sticky="nsew")
    app.textbox.bind("<KeyRelease>", lambda _e: app._update_char())


def _tab_chunks(app, box):
    box.grid_rowconfigure(1, weight=1)
    bar = row(box)
    bar.grid(row=0, column=0, sticky="ew", pady=(0, 4))
    lbl(
        bar,
        "Sửa thẳng trong đây rồi bấm Áp dụng. Giữ nguyên dòng --- ĐOẠN n ---",
        T.MUTED,
        F.tiny,
    ).pack(side="left")
    btn_primary(bar, "Áp dụng chỉnh sửa", app.apply_chunk_edits, width=140).pack(side="right")

    app.chunks_box = _big_box(box, font=F.mono)
    app.chunks_box.grid(row=1, column=0, sticky="nsew")


def _tab_srt(app, box):
    box.grid_rowconfigure(1, weight=1)
    bar = row(box)
    bar.grid(row=0, column=0, sticky="ew", pady=(0, 4))
    sbtn(bar, "Nhập SRT — mỗi câu 1 file", app.import_srt, width=170).pack(side="left", padx=(0, 6))
    sbtn(bar, "Lưu .srt", lambda: app.save_srt("merged"), width=76).pack(side="left", padx=2)
    sbtn(bar, "Từng clip", lambda: app.save_srt("clip"), width=80).pack(side="left", padx=2)
    sbtn(bar, "Chép", app.copy_srt, width=56).pack(side="left", padx=2)
    sbtn(bar, "Đưa thoại sang tab Văn bản", app.srt_to_text, width=180).pack(side="right")

    app.srt_box = _big_box(box, font=F.mono_sm, wrap="none", text_color="#8fe3c4")
    app.srt_box.grid(row=1, column=0, sticky="nsew")


def _log_card(app, right):
    c = card(right)
    c.grid(row=2, column=0, sticky="ew", pady=(T.GAP, 0))
    c.grid_columnconfigure(0, weight=1)

    head = row(c)
    head.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(6, 2))
    lbl(head, "NHẬT KÝ", T.MUTED, F.h).pack(side="left")
    btn_quiet(head, "Xoá", app.clear_log, width=46).pack(side="right")

    app.console = ctk.CTkTextbox(
        c,
        height=100,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER_SOFT,
        border_width=1,
        text_color="#b6bbc8",
        font=F.mono_sm,
        wrap="word",
    )
    app.console.grid(row=1, column=0, sticky="ew", padx=T.PADC, pady=(0, 8))


def build_tag_bar(app, parent, r: int, target):
    bar = row(parent)
    bar.grid(row=r, column=0, sticky="ew", pady=(0, 4))
    lbl(bar, "Thẻ:", T.MUTED, F.tiny).pack(side="left", padx=(0, 4))

    for group_name, items in (app.tags or {}).items():
        vals = [group_name] + [f"{label}  {tag}" for label, tag in items]
        cb = combo(
            bar,
            vals,
            width=124,
            command=lambda choice, g=group_name, tgt=target: (
                app.insert_tag(choice, tgt()) if choice != g else None
            ),
        )
        cb.set(group_name)
        cb.pack(side="left", padx=2)
        app._tag_combos.append((cb, group_name))

    btn_quiet(bar, "Sửa thẻ", app.edit_tags, width=64).pack(side="left", padx=(6, 0))


def build_tab_dialogue(app, box):
    box.grid_rowconfigure(2, weight=1)
    bar = row(box)
    bar.grid(row=0, column=0, sticky="ew", pady=(0, 4))
    lbl(bar, "Nghỉ giữa lượt (giây)", T.LABEL, F.label).pack(side="left")
    app.ent_gap = entry(bar, width=52)
    app.ent_gap.insert(0, "0.4")
    app.ent_gap.pack(side="left", padx=(6, 12))

    sbtn(bar, "Quét nhân vật", app.scan_speakers, width=108).pack(side="left", padx=2)
    sbtn(bar, "Nhập TXT", app.import_dialogue_txt, width=84).pack(side="left", padx=2)
    btn_primary(bar, "Tạo hội thoại", app.start_dialogue, width=128).pack(side="right")

    app._build_tag_bar(box, 1, lambda: app.dlg_box)

    app.dlg_box = _big_box(box)
    app.dlg_box.grid(row=2, column=0, sticky="nsew", pady=(0, 6))
    app.dlg_box.insert("1.0", "A> Chào cậu, lâu rồi không gặp.\nB> Ừ, dạo này tớ bận quá.\n")

    app.dlg_voices_frame = ctk.CTkScrollableFrame(
        box,
        height=104,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        label_text="Gán giọng cho nhân vật",
        label_font=F.label,
        label_fg_color=T.CARD,
        label_text_color=T.TEXT_DIM,
        scrollbar_fg_color=T.INPUT,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.dlg_voices_frame.grid(row=3, column=0, sticky="ew")
    app.dlg_speaker_combos = {}


def build_tab_dict(app, box):
    box.grid_rowconfigure(2, weight=1)
    bar = row(box)
    bar.grid(row=0, column=0, sticky="ew", pady=(0, 4))
    lbl(bar, "Tên từ điển", T.LABEL, F.label).pack(side="left", padx=(0, 6))
    app.ent_dictname = entry(bar, width=180, placeholder_text="vd: Tên riêng kênh")
    app.ent_dictname.pack(side="left", padx=(0, 12))

    app.sw_whole = switch(bar, text="Nguyên từ")
    app.sw_whole.select()
    app.sw_whole.pack(side="left", padx=(0, 10))

    app.sw_case = switch(bar, text="Phân biệt hoa thường")
    app.sw_case.pack(side="left", padx=(0, 10))

    btn_primary(bar, "Tạo từ điển", app.create_dict, width=110).pack(side="right", padx=(4, 0))
    sbtn(bar, "Xem thử", app.preview_dict, width=78).pack(side="right", padx=2)
    sbtn(bar, "Tải từ điển đã có", app.load_dicts, width=128).pack(side="right", padx=2)

    lbl(
        box,
        "Mỗi dòng một luật:   từ cần sửa = cách đọc đúng   (tối đa 500 luật)",
        T.MUTED,
        F.tiny,
        anchor="w",
    ).grid(row=1, column=0, sticky="ew", pady=(0, 4))

    app.dict_box = _big_box(box, font=F.mono)
    app.dict_box.grid(row=2, column=0, sticky="nsew", pady=(0, 6))
    app.dict_box.insert("1.0", "HaThanhAuto = Hà Thành Ao Tô\nAI = ây ai\nSSW = ét ét đắp bờ liu\n")

    app.dict_preview = _big_box(box, height=68, font=F.mono_sm, state="disabled")
    app.dict_preview.grid(row=3, column=0, sticky="ew")


def build_tab_clone(app, box):
    box.grid_rowconfigure(4, weight=1)
    lbl(
        box,
        "Mẫu 3–30 giây, tối đa 10 MB. Chấp nhận MP3, WAV, M4A, AAC, OGG, WebM, FLAC, Opus.\nChỉ clone giọng của chính bạn hoặc giọng đã được cho phép.",
        T.MUTED,
        F.tiny,
        anchor="w",
        justify="left",
    ).grid(row=0, column=0, sticky="ew", pady=(0, 6))

    r1 = row(box)
    r1.grid(row=1, column=0, sticky="ew", pady=(0, 4))
    lbl(r1, "Tên giọng", T.LABEL, F.label).pack(side="left", padx=(0, 6))
    app.ent_clonename = entry(r1, width=210, placeholder_text="vd: Giọng dẫn kênh 1")
    app.ent_clonename.pack(side="left", padx=(0, 12))

    app.sw_denoise = switch(r1, text="Khử ồn trước khi clone")
    app.sw_denoise.pack(side="left", padx=(0, 12))

    sbtn(r1, "Chọn file mẫu", app.pick_clone_file, width=110).pack(side="left", padx=4)
    app.lbl_clonefile = lbl(r1, "Chưa chọn file mẫu", T.MUTED, F.tiny)
    app.lbl_clonefile.pack(side="left", padx=6)
    btn_primary(r1, "Bắt đầu clone", app.start_clone, width=130).pack(side="right")

    r2 = row(box)
    r2.grid(row=2, column=0, sticky="ew", pady=4)
    sbtn(r2, "Tải danh sách", app.list_clones, width=110).pack(side="left", padx=(0, 4))
    sbtn(r2, "Dùng giọng này", app.use_selected_clone, width=120).pack(side="left", padx=4)
    btn_danger(r2, "Xoá giọng đã chọn", app.delete_clones, width=140).pack(side="right")

    lf = tk.Frame(box, bg=T.INPUT, highlightthickness=1, highlightbackground=T.BORDER_SOFT)
    lf.grid(row=3, column=0, sticky="ew", pady=4)
    sb = tk.Scrollbar(lf)
    sb.pack(side="right", fill="y")
    app.clone_list = tk.Listbox(
        lf,
        height=6,
        bg=T.INPUT,
        fg=T.TEXT,
        selectmode="extended",
        selectbackground=T.ACCENT_SOFT,
        selectforeground="#ffffff",
        highlightthickness=0,
        borderwidth=0,
        activestyle="none",
        font=("Consolas", 10),
        yscrollcommand=sb.set,
    )
    app.clone_list.pack(side="left", fill="both", expand=True)
    sb.config(command=app.clone_list.yview)
    app.clone_list.bind("<Double-Button-1>", lambda _e: app.use_selected_clone())
    app.clone_list.bind("<Delete>", lambda _e: app.delete_clones())

    app.clone_box = _big_box(box, font=F.mono_sm)
    app.clone_box.grid(row=4, column=0, sticky="nsew", pady=(4, 0))
    app.clone_file = None
    app.clone_rows = []


def build_picker(app, H: dict):
    """Dựng lớp phủ chọn giọng. Trả về (khung phủ, nhãn đếm, ô lọc, listbox)."""
    ov = ctk.CTkFrame(
        app,
        fg_color=T.CARD,
        border_width=2,
        border_color=T.ACCENT,
        corner_radius=T.RADIUS_CARD,
    )
    ov.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.82, relheight=0.82)
    ov.lift()

    head = row(ov)
    head.pack(fill="x", padx=14, pady=(12, 6))
    lbl(head, "CHỌN GIỌNG", T.TEXT_STRONG, F.title).pack(side="left")
    lbl_cnt = lbl(head, "0 giọng", T.MUTED, F.label)
    lbl_cnt.pack(side="left", padx=10)
    btn_danger(head, "✕", lambda: H.get("close", lambda: None)(), width=32, height=26).pack(side="right")

    ent = entry(ov, placeholder_text="lọc nhanh theo tên hoặc mã…")
    ent.pack(fill="x", padx=14, pady=(0, 8))

    lf = tk.Frame(ov, bg=T.INPUT, highlightthickness=1, highlightbackground=T.BORDER)
    lf.pack(fill="both", expand=True, padx=14, pady=4)
    sb = tk.Scrollbar(lf)
    sb.pack(side="right", fill="y")
    lst = tk.Listbox(
        lf,
        bg=T.INPUT,
        fg="#c8ccd8",
        selectbackground=T.TAB_ACTIVE,
        selectforeground="#ffffff",
        highlightthickness=0,
        borderwidth=0,
        font=("Consolas", 10),
        activestyle="none",
        yscrollcommand=sb.set,
    )
    lst.pack(side="left", fill="both", expand=True)
    sb.config(command=lst.yview)

    foot = row(ov)
    foot.pack(fill="x", padx=14, pady=12)
    app._picker_prev_btn = sbtn(foot, "▶ Nghe thử", lambda: H.get("play", lambda: None)(), width=96)
    app._picker_prev_btn.pack(side="left", padx=(0, 6))
    sbtn(foot, "Tìm trên kho", lambda: H.get("search", lambda: None)(), width=110).pack(side="left")
    sbtn(foot, "Đóng", lambda: H.get("close", lambda: None)(), width=80).pack(side="right", padx=(6, 0))
    btn_primary(foot, "Chọn giọng này", lambda: H.get("choose", lambda: None)(), width=140).pack(side="right")

    return ov, lbl_cnt, ent, lst
