"""
ui_review.py — Giao diện tab "Rà Soát Prompt" (prompt_review.py), tách riêng.
──────────────────────────────────────────────────────────────────────────────
Mọi hàm nhận `app` (instance của ReviewTab) để gắn widget và sự kiện trực tiếp.
"""

import tkinter as tk
import customtkinter as ctk
from ui import (
    T,
    F,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    btn_quiet,
    lbl,
    entry,
    combo,
    grid_field,
    note,
    TabStrip,
    _scroll,
    dialog,
    set_density_early,
)

STATUS = {
    "cho": ("chờ rà soát", T.MUTED),
    "dang": ("đang rà soát…", "#e0a458"),
    "xong": ("đã sửa xong", T.OK),
    "loi": ("rà soát hỏng", T.DANGER_TEXT),
    "daguilai": ("đã trả về tab tạo", T.ACCENT),
}


def setup_ui(app):
    """Dựng bố cục 2 cột cho ReviewTab."""
    set_density_early()
    F.init()
    app.configure(fg_color=T.BG)

    try:
        sw = app.winfo_screenwidth()
    except Exception:
        sw = 1920
    left_w = 360 if sw < 1400 else 410

    app.grid_columnconfigure(0, weight=0, minsize=left_w)
    app.grid_columnconfigure(1, weight=1)
    app.grid_rowconfigure(0, weight=1)

    _build_left(app)
    _build_right(app)


def _build_left(app):
    col = ctk.CTkFrame(app, fg_color=T.SIDEBAR, corner_radius=0)
    col.grid(row=0, column=0, sticky="nsew")
    col.grid_columnconfigure(0, weight=1)
    col.grid_rowconfigure(1, weight=1)

    app._left_tabs = TabStrip(col, height=28, minw=110)
    t_list = app._left_tabs.add("📋 Hàng đợi cứu hộ")
    t_cfg = app._left_tabs.add("⚙️ Cấu hình AI")
    app._left_tabs.grid(row=0, column=0)

    _list_tab(app, t_list)
    _cfg_tab(app, t_cfg)
    _action_bar(app, col)


def _list_tab(app, box):
    box.grid_columnconfigure(0, weight=1)
    box.grid_rowconfigure(1, weight=1)

    top = row(box)
    top.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(4, 4))

    app.lbl_count = lbl(top, "0 prompt", T.TEXT_STRONG, F.ui_sb)
    app.lbl_count.pack(side="left")

    btn_quiet(top, "Xoá tất cả", app.clear_all, width=76).pack(side="right", padx=(4, 0))
    btn_quiet(top, "Xoá đã gửi", app.clear_done, width=80).pack(side="right", padx=(4, 0))
    btn(top, "+ Dán thêm", lambda: paste_dialog(app), width=88).pack(side="right")

    app.list_scroll = ctk.CTkScrollableFrame(
        box,
        fg_color=T.CARD,
        corner_radius=T.RADIUS_CARD,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.list_scroll.grid(row=1, column=0, sticky="nsew", padx=T.PAD, pady=(2, 6))
    app.list_scroll.grid_columnconfigure(0, weight=1)


def _cfg_tab(app, box):
    sf = _scroll(box)
    sf.grid(row=0, column=0, sticky="nsew", padx=T.PAD, pady=4)
    box.grid_rowconfigure(0, weight=1)
    box.grid_columnconfigure(0, weight=1)

    note(
        sf,
        0,
        "Dùng chung 9Router với tab Tạo Kịch Bản. Đã dán key bên đó thì bên này tự nhận.",
    )

    app.ent_url = entry(sf)
    app.ent_url.insert(0, app.cfg.get("url", ""))
    grid_field(sf, 1, "Địa chỉ", app.ent_url, label_w=78)

    kr = row(sf)
    app.ent_key = entry(kr, placeholder_text="r9_… (để trống = lấy từ Kịch Bản)", show="•", font=F.mono_sm)
    if app.cfg.get("key"):
        app.ent_key.insert(0, app.cfg.get("key", ""))
    app.ent_key.pack(side="left", fill="x", expand=True)
    btn_quiet(kr, "Lấy lại", app.refresh_key, width=62).pack(side="left", padx=(4, 0))
    grid_field(sf, 2, "Key riêng", kr, label_w=78)

    app.lbl_key_src = lbl(sf, "", T.MUTED, F.tiny, anchor="w")
    app.lbl_key_src.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 4))

    mr = row(sf)
    cur_model = app.cfg.get("model", "gemini-3.8-flash-high")
    models = app.cfg.get("models") or [cur_model]
    if cur_model not in models:
        models = [cur_model] + list(models)
    app.cb_model = combo(mr, values=models, state="normal")
    app.cb_model.set(cur_model)
    app.cb_model.pack(side="left", fill="x", expand=True)
    btn_quiet(mr, "Tải", app.load_models, width=50).pack(side="left", padx=(4, 0))
    grid_field(sf, 4, "Model", mr, label_w=78)

    app.sw_auto_review = ctk.CTkSwitch(
        sf,
        text="Tự rà soát ngay khi có prompt mới",
        progress_color=T.ACCENT,
        button_color="#ffffff",
        fg_color=T.BORDER,
        text_color=T.TEXT,
        font=F.ui,
        command=app.save_cfg,
    )
    if app.cfg.get("auto_review", True):
        app.sw_auto_review.select()
    app.sw_auto_review.grid(row=5, column=0, columnspan=2, sticky="w", pady=(8, 4))

    app.sw_auto_back = ctk.CTkSwitch(
        sf,
        text="Sửa xong tự trả về tab tạo & chạy lại",
        progress_color=T.ACCENT,
        button_color="#ffffff",
        fg_color=T.BORDER,
        text_color=T.TEXT,
        font=F.ui,
        command=app.save_cfg,
    )
    if app.cfg.get("auto_send_back", True):
        app.sw_auto_back.select()
    app.sw_auto_back.grid(row=6, column=0, columnspan=2, sticky="w", pady=(2, 8))

    btn(sf, "Lưu cài đặt", app.save_cfg, width=120).grid(
        row=7, column=0, columnspan=2, sticky="ew", pady=(6, 4)
    )


def _action_bar(app, col):
    ctk.CTkFrame(col, height=1, fg_color=T.DIVIDER).grid(row=2, column=0, sticky="ew")
    bar = ctk.CTkFrame(col, fg_color=T.SIDEBAR)
    bar.grid(row=3, column=0, sticky="ew", padx=T.PAD, pady=T.PAD)
    bar.grid_columnconfigure((0, 1), weight=1)

    btn_primary(bar, "🛡️ Làm sạch & sửa dòng đang chọn", app.review_selected).grid(
        row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6)
    )
    btn(bar, "✨ Sửa toàn bộ danh sách", app.review_all).grid(
        row=1, column=0, sticky="ew", padx=(0, 3), pady=(0, 6)
    )
    btn(bar, "📤 Trả hết mục đã sửa", app.send_back_all).grid(
        row=1, column=1, sticky="ew", padx=(3, 0), pady=(0, 6)
    )

    app.lbl_status = lbl(bar, "● Sẵn sàng cứu hộ câu lệnh", T.OK, F.tiny, anchor="w")
    app.lbl_status.grid(row=2, column=0, columnspan=2, sticky="ew")


def _build_right(app):
    right = ctk.CTkFrame(app, fg_color=T.BG)
    right.grid(row=0, column=1, sticky="nsew", padx=T.PAD, pady=T.PAD)
    right.grid_columnconfigure(0, weight=1)
    right.grid_rowconfigure(1, weight=1)
    right.grid_rowconfigure(2, weight=2)

    # Hộp 1: Prompt gốc
    c_orig = card(right)
    c_orig.grid(row=0, column=0, sticky="ew", pady=(0, T.GAP))
    c_orig.grid_columnconfigure(0, weight=1)

    h1 = row(c_orig)
    h1.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(8, 4))
    lbl(h1, "⚠️ CÂU LỆNH GỐC BỊ CHẶN HOẶC LỖI", T.MUTED, F.h).pack(side="left")
    app.lbl_src = lbl(h1, "", T.TEXT_DIM, F.tiny)
    app.lbl_src.pack(side="right")

    app.txt_orig = _box(c_orig, h=95)
    app.txt_orig.grid(row=1, column=0, sticky="ew", padx=T.PADC, pady=(0, 4))

    app.lbl_reason = lbl(c_orig, "", T.DANGER_TEXT, F.tiny, anchor="w", justify="left", wraplength=680)
    app.lbl_reason.grid(row=2, column=0, sticky="ew", padx=T.PADC, pady=(0, 8))

    # Hộp 2: Chuẩn đoán của AI
    c_diag = card(right)
    c_diag.grid(row=1, column=0, sticky="nsew", pady=(0, T.GAP))
    c_diag.grid_columnconfigure(0, weight=1)
    c_diag.grid_rowconfigure(1, weight=1)

    h2 = row(c_diag)
    h2.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(8, 4))
    lbl(h2, "🔍 CHẨN ĐOÁN NGUYÊN NHÂN VI PHẠM CHÍNH SÁCH", T.MUTED, F.h).pack(side="left")
    app.lbl_codes = lbl(h2, "", "#fbbf24", F.ui_sb)
    app.lbl_codes.pack(side="right")

    app.txt_diag = _box(c_diag, h=90)
    app.txt_diag.grid(row=1, column=0, sticky="nsew", padx=T.PADC, pady=(0, 8))

    # Hộp 3: Prompt đã sửa
    c_fix = card(right)
    c_fix.grid(row=2, column=0, sticky="nsew", pady=(0, T.GAP))
    c_fix.grid_columnconfigure(0, weight=1)
    c_fix.grid_rowconfigure(1, weight=1)

    h3 = row(c_fix)
    h3.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(8, 4))
    lbl(h3, "✅ CÂU LỆNH ĐÃ LÀM SẠCH AN TOÀN (Có thể chỉnh thêm trước khi gửi lại)", T.OK, F.h).pack(side="left")

    b_row = row(h3)
    b_row.pack(side="right")
    btn_quiet(b_row, "📋 Sao chép", lambda: _copy(app), width=82).pack(side="left", padx=(0, 4))
    app.btn_back = btn_primary(b_row, "📤 Trả về Xưởng Quay & Chạy lại", app.send_back, width=210)
    app.btn_back.pack(side="left")

    app.txt_fixed = _box(c_fix, h=130)
    app.txt_fixed.configure(text_color="#d6f5e3")
    app.txt_fixed.grid(row=1, column=0, sticky="nsew", padx=T.PADC, pady=(0, 8))

    _log_card(app, right)


def _box(parent, h=110):
    return ctk.CTkTextbox(
        parent,
        height=h,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER_SOFT,
        border_width=1,
        text_color=T.TEXT,
        font=F.ui,
        wrap="word",
    )


def _copy(app):
    txt = app.txt_fixed.get("1.0", "end").strip()
    if not txt:
        return
    try:
        app.clipboard_clear()
        app.clipboard_append(txt)
        app.lbl_status.configure(text="Đã chép prompt đã sửa", text_color=T.OK)
    except Exception:
        pass


def _log_card(app, right):
    c_log = card(right)
    c_log.grid(row=3, column=0, sticky="ew")
    c_log.grid_columnconfigure(0, weight=1)

    hl = row(c_log)
    hl.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(6, 2))
    lbl(hl, "NHẬT KÝ", T.MUTED, F.h).pack(side="left")

    app.txt_log = ctk.CTkTextbox(
        c_log,
        height=90,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER_SOFT,
        border_width=1,
        text_color="#b6bbc8",
        font=F.mono_sm,
        wrap="word",
        state="disabled",
    )
    app.txt_log.grid(row=1, column=0, sticky="ew", padx=T.PADC, pady=(0, 8))


def paste_dialog(app):
    """Hộp thoại dán prompt thủ công để rà soát."""
    win = dialog(app, "Dán prompt cần rà soát", w=600, h=420, grab=True)
    lbl(
        win,
        "Mỗi dòng 1 prompt (hoặc dán cả đoạn). Bấm Thêm là AI rà soát ngay.",
        T.TEXT_DIM,
        F.label,
    ).pack(anchor="w", padx=14, pady=(12, 4))

    box = ctk.CTkTextbox(
        win,
        fg_color=T.INPUT,
        border_color=T.BORDER,
        border_width=1,
        text_color=T.TEXT,
        font=F.ui,
        wrap="word",
    )
    box.pack(fill="both", expand=True, padx=14, pady=6)
    box.focus_set()

    rr = row(win)
    rr.pack(fill="x", padx=14, pady=4)
    lbl(rr, "Lý do lỗi (nếu biết):", T.LABEL, F.label).pack(side="left", padx=(0, 6))
    ent_reason = entry(rr, placeholder_text="vd: PUBLIC_ERROR_MINOR, 58061214, làm mờ mặt…")
    ent_reason.pack(side="left", fill="x", expand=True)

    br = row(win)
    br.pack(fill="x", padx=14, pady=(6, 12))

    def _ok():
        raw = box.get("1.0", "end").strip()
        rs = ent_reason.get().strip()
        win.destroy()
        if raw:
            app.add_manual(raw, rs)

    btn(br, "Huỷ", win.destroy, width=80).pack(side="right", padx=(6, 0))
    btn_primary(br, "Thêm & Rà soát", _ok, width=140).pack(side="right")


def render_list(app):
    """Vẽ lại danh sách prompt bên cột trái và chi tiết bên phải."""
    for w in app.list_scroll.winfo_children():
        try:
            w.destroy()
        except Exception:
            pass

    app.lbl_count.configure(text=f"{len(app.items)} prompt")
    if not app.items:
        lbl(
            app.list_scroll,
            "Chưa có prompt nào.\n\n• Khi VEO 3 hoặc Imagen lỗi chính sách / quá 5 lần, prompt sẽ tự chảy sang đây.\n• Hoặc bấm '+ Dán thêm' để rà soát tay.",
            T.MUTED,
            F.label,
            justify="left",
            wraplength=280,
        ).pack(padx=12, pady=20)
        _show(app, None)
        return

    for idx, it in enumerate(app.items):
        is_sel = it["uid"] == app.selected_uid
        c = card(
            app.list_scroll,
            fg_color=T.TAB_ACTIVE if is_sel else T.INPUT,
            border_color=T.ACCENT if is_sel else T.BORDER_SOFT,
            corner_radius=T.RADIUS,
        )
        c.pack(fill="x", pady=3, padx=2)

        top = row(c)
        top.pack(fill="x", padx=8, pady=(6, 2))
        src_name = app._src_label.get(it["src"], it["src"])
        rid_str = f" · #{it['row_id'] + 1}" if it.get("row_id") is not None else ""
        rnd_str = f" · vòng {it['round']}" if it.get("round", 1) > 1 else ""
        lbl(top, f"#{idx + 1:02d}  [{src_name}{rid_str}{rnd_str}]", T.TEXT_STRONG, F.ui_sb).pack(side="left")

        st_txt, st_col = STATUS.get(it.get("status", "cho"), (it.get("status", ""), T.MUTED))
        lbl(top, st_txt, st_col, F.tiny).pack(side="right")

        prev = (it.get("fixed") or it.get("orig") or "").replace("\n", " ")
        if len(prev) > 85:
            prev = prev[:85] + "…"
        l_prev = lbl(c, prev, T.TEXT_DIM, F.tiny, anchor="w", justify="left")
        l_prev.pack(fill="x", padx=8, pady=(0, 4))

        if it.get("codes"):
            lbl(c, "Vi phạm: " + ", ".join(it["codes"]), "#e0a458", F.tiny, anchor="w").pack(
                fill="x", padx=8, pady=(0, 6)
            )

        uid = it["uid"]
        for w in (c, top, l_prev):
            try:
                w.bind("<Button-1>", lambda _e, u=uid: app.select(u))
            except Exception:
                pass

    _show(app, app._current())


def _show(app, it):
    app.txt_orig.delete("1.0", "end")
    app.txt_diag.delete("1.0", "end")
    app.txt_fixed.delete("1.0", "end")

    if not it:
        app.lbl_src.configure(text="")
        app.lbl_reason.configure(text="")
        app.lbl_codes.configure(text="")
        app.btn_back.configure(state="disabled")
        return

    src_name = app._src_label.get(it["src"], it["src"])
    rid_str = f" · dòng #{it['row_id'] + 1}" if it.get("row_id") is not None else ""
    rnd_str = f" · vòng {it['round']}/4" if it.get("round", 1) > 1 else ""
    app.lbl_src.configure(text=f"Nguồn: {src_name}{rid_str}{rnd_str}")
    app.txt_orig.insert("1.0", it.get("orig", ""))
    app.lbl_reason.configure(text=f"Lý do lỗi: {it['reason']}" if it.get("reason") else "")

    app.lbl_codes.configure(
        text=("Mã vi phạm: " + ", ".join(it["codes"])) if it.get("codes") else ""
    )

    diag_parts = []
    if it.get("diagnosis"):
        diag_parts.append(it["diagnosis"])
    if it.get("changes"):
        diag_parts.append("\nCác chỗ đã sửa:\n" + "\n".join(f"  • {c}" for c in it["changes"]))
    app.txt_diag.insert("1.0", "\n".join(diag_parts))

    app.txt_fixed.insert("1.0", it.get("fixed", ""))
    can_back = bool(
        it.get("src") in ("veo", "veo7", "veo4", "imagen", "imagen_consist")
        and it.get("row_id") is not None
    )
    app.btn_back.configure(state="normal" if can_back else "disabled")
