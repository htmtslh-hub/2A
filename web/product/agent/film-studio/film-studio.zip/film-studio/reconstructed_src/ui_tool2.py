"""
ui_tool2.py — Giao diện tab "Ghép Video" (tool2.py), tách riêng.
────────────────────────────────────────────────────────────────
Dùng chung bộ màu / thành phần với ui.py nên nhìn liền mạch với giao diện tổng.

Cách dùng trong tool2.py:

    import ui_tool2 as _ui2

    class AutoVideoUltimateApp(ctk.CTkFrame):
        def _setup_ui(self):                     _ui2.setup_ui(self)
        def _make_scroll_body(self, tab, *a, **k): return _ui2.make_scroll_body(self, tab)
        def _setup_tab2(self, parent):           _ui2.setup_tab2(self, parent)
        def _setup_tab3(self, parent):           _ui2.setup_tab3(self, parent)
        def _build_transition_ui(self, parent, prefix, accent=None):
            return _ui2.build_transition_ui(self, parent, prefix)
        def _create_input(self, parent, label, var, cmd, is_save=False):
            return _ui2.create_input(self, parent, label, var, cmd, is_save)

Mọi TÊN BIẾN giữ nguyên (t2_audio_dir, t3_effect, tabview, _result_scroll ...)
nên phần xử lý trong tool2.py và tt.py không phải sửa gì.
"""

import sys
import tkinter as tk
import customtkinter as ctk
from ui import (
    T,
    F,
    card,
    row,
    btn,
    btn_primary,
    btn_quiet,
    lbl,
    switch,
    _sync_combo,
    wire_hover,
    set_density,
)

EFFECTS = [
    ("random", "Ngẫu nhiên mỗi ảnh"),
    ("zoom_in", "Zoom in — phóng to dần"),
    ("zoom_out", "Zoom out — thu nhỏ dần"),
    ("combo", "Combo — zoom kèm pan"),
    ("pan_left", "Pan sang trái"),
    ("pan_right", "Pan sang phải"),
    ("pan_up", "Pan lên trên"),
    ("pan_down", "Pan xuống dưới"),
    ("shake", "Rung lắc"),
    ("classic", "Ken Burns cổ điển"),
    ("none", "Không hiệu ứng"),
]
_EFF_LABEL = {k: v for k, v in EFFECTS}
_EFF_VALUE = {v: k for k, v in EFFECTS}


def _mod(app):
    """Module chứa lớp app (tool2) — để lấy VOCAL_MODES, TransitionFX."""
    return sys.modules.get(app.__class__.__module__)


def section(parent, title: str, subtitle: str = ""):
    """Thẻ có tiêu đề. Trả về (thẻ, vùng nội dung)."""
    c = card(parent)
    c.pack(fill="x", padx=T.PADC, pady=T.GAP)
    head = row(c)
    head.pack(fill="x", padx=T.PADC, pady=(8, 4))
    lbl(head, title, T.TEXT_STRONG, F.ui_sb).pack(side="left")
    if subtitle:
        lbl(head, f"  ·  {subtitle}", T.MUTED, F.label).pack(side="left", padx=(4, 0))
    body = row(c)
    body.pack(fill="x", padx=T.PADC, pady=(0, 10))
    return c, body


def radio(parent, text: str, variable, value: str):
    F.init()
    return ctk.CTkRadioButton(
        parent,
        text=text,
        variable=variable,
        value=value,
        radiobutton_width=16,
        radiobutton_height=16,
        border_width_checked=5,
        border_width_unchecked=2,
        fg_color=T.ACCENT,
        hover_color=T.ACCENT_HOVER,
        border_color="#3a3d4d",
        text_color=T.TEXT_DIM,
        font=F.ui,
    )


def _make_combo(parent, values, variable=None, width=110, command=None):
    F.init()
    cb = ctk.CTkOptionMenu(
        parent,
        values=list(values),
        variable=variable,
        command=command,
        width=width,
        height=T.H_CTRL,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        button_color=T.TAB_ACTIVE,
        button_hover_color=T.ACCENT,
        text_color=T.TEXT,
        dropdown_fg_color=T.CARD,
        dropdown_hover_color=T.TAB_ACTIVE,
        dropdown_text_color=T.TEXT,
        font=F.ui,
        dropdown_font=F.ui,
    )
    if variable is not None:
        _sync_combo(cb, variable)
    return cb


def labeled_combo(parent, text: str, values, variable=None, width=96, command=None):
    r = row(parent)
    lbl(r, text, T.LABEL, F.label).pack(side="left", padx=(0, 6))
    cb = _make_combo(r, values, variable=variable, width=width, command=command)
    cb.pack(side="left")
    return r


class SubTabs:
    """2 tab con của tool ghép video. Tương thích lệnh .set() tên cũ từ tt.py."""

    ALIAS = {
        "Mode 2: Folder Sync": "Audio + Video",
        "Mode 3: Ảnh + Hiệu ứng": "Ảnh + Hiệu ứng",
    }

    def __init__(self, barparent, content):
        F.init()
        self._bar = barparent
        self._content = content
        self._btns = {}
        self._frames = {}
        self._current = None
        self._content.rowconfigure(0, weight=1)
        self._content.columnconfigure(0, weight=1)

    def add(self, name: str):
        b = ctk.CTkButton(
            self._bar,
            text=name.upper(),
            height=28,
            corner_radius=T.RADIUS,
            fg_color="transparent",
            hover_color=T.TAB_HOVER,
            text_color=T.TEXT_DIM,
            font=F.ui_sb,
            width=max(130, len(name) * 9),
            command=lambda n=name: self.set(n),
        )
        b.pack(side="left", padx=(0, 4))
        wire_hover(b, lambda n=name: self._current == n)

        fr = ctk.CTkFrame(self._content, fg_color="transparent", corner_radius=0)
        self._btns[name] = b
        self._frames[name] = fr
        if self._current is None:
            self.set(name)
        return fr

    def _resolve(self, name: str) -> str:
        if name in self._frames:
            return name
        if name in self.ALIAS and self.ALIAS[name] in self._frames:
            return self.ALIAS[name]
        low = str(name or "").lower()
        if any(w in low for w in ("3", "ảnh", "anh", "effect", "hiệu ứng")):
            return "Ảnh + Hiệu ứng"
        if any(w in low for w in ("2", "video", "sync", "audio")):
            return "Audio + Video"
        return next((k for k in self._frames if k.lower() == low), next(iter(self._frames), name))

    def set(self, name: str):
        want = self._resolve(name)
        self._current = want
        for k, fr in self._frames.items():
            if k == want:
                fr.grid(row=0, column=0, sticky="nsew")
            else:
                fr.grid_forget()
        for k, b in self._btns.items():
            if k == want:
                b.configure(fg_color=T.ACCENT_SOFT, text_color=T.TAB_HOVER_TXT)
            else:
                b.configure(fg_color="transparent", text_color=T.TEXT_DIM)

    def get(self) -> str:
        return self._current or ""

    def tab(self, name: str):
        return self._frames[self._resolve(name)]


def setup_ui(app):
    try:
        set_density(app.winfo_screenheight())
    except Exception:
        set_density()
    F.init()

    app._colors = {
        "bg": T.BG,
        "card": T.CARD,
        "border": T.BORDER_SOFT,
        "accent": T.ACCENT,
        "text": T.TEXT,
        "dim": T.TEXT_DIM,
        "green": T.OK,
        "red": T.DANGER,
        "cyan": T.ACCENT,
    }

    c = app.container
    c.configure(fg_color=T.BG)
    c.grid_columnconfigure(0, weight=3)
    c.grid_columnconfigure(1, weight=2)
    c.grid_rowconfigure(2, weight=1)

    # Top bar
    top = row(c)
    top.grid(row=0, column=0, columnspan=2, sticky="ew", padx=T.PAD, pady=(T.PAD, 6))

    tab_bar = row(top)
    tab_bar.pack(side="left")

    sw_gpu = switch(top, text="Tăng tốc GPU", variable=app.chk_gpu_var)
    sw_gpu.pack(side="left", padx=(16, 6))

    btn_quiet(top, "Kiểm tra GPU", app._show_gpu_log, width=94).pack(side="left", padx=(0, 12))

    ctk.CTkFrame(top, width=1, height=18, fg_color=T.BORDER).pack(side="left", padx=8)

    labeled_combo(top, "Luồng", ["1", "2", "3", "4", "5", "6"], variable=app.thread_count, width=66).pack(
        side="left", padx=(4, 10)
    )
    labeled_combo(top, "Tỉ lệ", ["16:9", "9:16"], variable=app.out_ratio, width=82).pack(
        side="left", padx=(0, 10)
    )
    labeled_combo(
        top, "Chất lượng", ["720p", "1080p", "2K", "4K"], variable=app.out_resolution, width=86
    ).pack(side="left")

    app._lbl_status = ctk.CTkLabel(
        top, textvariable=app.status_var, text_color=T.TEXT_DIM, font=F.label
    )
    app._lbl_status.pack(side="right", padx=6)

    ctk.CTkFrame(c, height=1, fg_color=T.BORDER).grid(
        row=1, column=0, columnspan=2, sticky="ew", pady=(0, 4)
    )

    left_area = ctk.CTkFrame(c, fg_color="transparent")
    left_area.grid(row=2, column=0, sticky="nsew", padx=(T.PAD, 4), pady=(0, T.PAD))

    app.tabview = SubTabs(tab_bar, left_area)
    app.tab2 = app.tabview.add("Audio + Video")
    app.tab3 = app.tabview.add("Ảnh + Hiệu ứng")

    app._tab2_body = make_scroll_body(app, app.tab2)
    app._tab3_body = make_scroll_body(app, app.tab3)
    app._setup_tab2(app._tab2_body)
    app._setup_tab3(app._tab3_body)

    _build_result_panel(app, c)


def make_scroll_body(app, tab):
    """Vùng cuộn + thanh hành động CỐ ĐỊNH ở đáy.

    Màn 768p không đủ cao để hiện hết form; nếu nút Chạy nằm trong vùng cuộn
    thì phải cuộn xuống mới bấm được. Tách nút ra thanh đáy nên luôn thấy.
    """
    tab.grid_rowconfigure(0, weight=1)
    tab.grid_columnconfigure(0, weight=1)

    sf = ctk.CTkScrollableFrame(
        tab,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    sf.grid(row=0, column=0, sticky="nsew")

    ctk.CTkFrame(tab, height=1, fg_color=T.BORDER).grid(row=1, column=0, sticky="ew")

    foot = row(tab)
    foot.grid(row=2, column=0, sticky="ew", padx=T.PADC, pady=8)
    sf._footer = foot
    return sf


def _footer_of(body):
    return getattr(body, "_footer", body)


def _build_result_panel(app, container):
    right = card(container)
    right.grid(row=2, column=1, sticky="nsew", padx=(4, T.PAD), pady=(0, T.PAD))
    right.grid_rowconfigure(1, weight=1)
    right.grid_columnconfigure(0, weight=1)

    head = ctk.CTkFrame(right, height=T.PANE_HEAD, fg_color="transparent")
    head.grid(row=0, column=0, sticky="ew", padx=T.PADC, pady=(6, 2))

    lbl(head, "Video đã tạo", T.TEXT_STRONG, F.ui_sb).pack(side="left", pady=4)
    app._result_count = lbl(head, "0", T.MUTED, F.mono_sm)
    app._result_count.pack(side="left", padx=6, pady=4)

    btn_quiet(head, "🧹 Làm sạch cũ", lambda: app.clear_previous_session(ask_confirm=True), width=102).pack(side="right", padx=(6, 0))
    btn_quiet(head, "Xoá", app._clear_results, width=44).pack(side="right", padx=(6, 0))
    btn_quiet(head, "Mở thư mục", app._open_output, width=82).pack(side="right")

    app._result_scroll = ctk.CTkScrollableFrame(
        right,
        fg_color=T.INPUT,
        corner_radius=T.RADIUS,
        scrollbar_fg_color=T.INPUT,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app._result_scroll.grid(row=1, column=0, sticky="nsew", padx=T.PADC, pady=(4, 6))

    app._prog_var = tk.DoubleVar(value=0.0)
    prog = ctk.CTkProgressBar(
        right,
        variable=app._prog_var,
        height=6,
        corner_radius=3,
        fg_color=T.INPUT,
        progress_color=T.ACCENT,
    )
    prog.grid(row=2, column=0, sticky="ew", padx=T.PADC, pady=(0, 10))


def create_input(app, parent, label: str, var, cmd, is_save: bool = False):
    r = row(parent)
    r.pack(fill="x", pady=4)
    lbl(r, label.rstrip(":") + ":", T.LABEL, F.label, width=96, anchor="w").pack(side="left")
    ent = ctk.CTkEntry(
        r,
        textvariable=var,
        height=T.H_CTRL,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER,
        text_color=T.TEXT,
        font=F.ui,
    )
    ent.pack(side="left", fill="x", expand=True, padx=6)
    btn(r, "Lưu thành…" if is_save else "Chọn…", cmd, width=88).pack(side="left")
    return r


def setup_tab2(app, parent):
    mod = _mod(app)
    vocal_off = getattr(mod, "VOCAL_OFF", "Giữ nguyên giọng")
    vocal_modes = getattr(mod, "VOCAL_MODES", [vocal_off])

    app.t2_audio_dir = tk.StringVar()
    app.t2_video_dir = tk.StringVar()
    app.t2_output = tk.StringVar()
    app.t2_sync_mode = tk.StringVar(value="speed")
    app.t2_max_speed = tk.StringVar(value="2.0")
    app.t2_min_speed = tk.StringVar(value="0.5")
    app.t2_video_vol = tk.StringVar(value="0.0")
    app.t2_export_individual = tk.BooleanVar(value=True)
    app.t2_vocal_mode = tk.StringVar(value=vocal_off)

    _, b_src = section(
        parent,
        "🎞️ Lồng Giọng Đọc Vào Video Cảnh Quay",
        "Giọng đọc giữ nguyên 100%, thời lượng video tự động co giãn khớp từng câu",
    )
    create_input(app, b_src, "Thư mục Audio", app.t2_audio_dir, lambda: app._browse_dir(app.t2_audio_dir))
    create_input(app, b_src, "Thư mục Video", app.t2_video_dir, lambda: app._browse_dir(app.t2_video_dir))
    create_input(app, b_src, "File xuất ra", app.t2_output, lambda: app._browse_save(app.t2_output), is_save=True)

    _, b_sync = section(parent, "Cách đồng bộ", "audio giữ nguyên, video điều chỉnh theo")
    r_modes = row(b_sync)
    r_modes.pack(fill="x", pady=(0, 8))
    radio(r_modes, "Chỉnh tốc độ video", app.t2_sync_mode, "speed").pack(side="left", padx=(0, 20))
    radio(r_modes, "Lặp lại video", app.t2_sync_mode, "loop").pack(side="left", padx=(0, 20))
    radio(r_modes, "Cắt / đóng băng", app.t2_sync_mode, "cut").pack(side="left")

    r_spd = row(b_sync)
    r_spd.pack(fill="x", pady=4)
    labeled_combo(r_spd, "Tốc độ tối thiểu", ["0.25", "0.5", "0.75", "1.0"], variable=app.t2_min_speed, width=74).pack(
        side="left", padx=(0, 18)
    )
    labeled_combo(r_spd, "Tối đa", ["1.5", "2.0", "3.0", "4.0"], variable=app.t2_max_speed, width=74).pack(
        side="left", padx=(0, 18)
    )
    labeled_combo(
        r_spd,
        "Âm lượng video gốc",
        ["0.0", "0.1", "0.2", "0.3", "0.5", "0.7", "1.0"],
        variable=app.t2_video_vol,
        width=74,
    ).pack(side="left")
    lbl(r_spd, "0.0 = chỉ nghe giọng đọc", T.MUTED, F.tiny).pack(side="left", padx=8)

    _, b_voc = section(
        parent,
        "Giọng nói trong video gốc",
        "chỉ có tác dụng khi âm lượng video gốc lớn hơn 0",
    )
    r_v1 = row(b_voc)
    r_v1.pack(fill="x", pady=(0, 6))
    labeled_combo(r_v1, "Chế độ", vocal_modes, variable=app.t2_vocal_mode, width=230).pack(side="left")

    btn_quiet(r_v1, "Cài Demucs", app._t2_install_demucs, width=84).pack(side="right", padx=(4, 0))
    btn_quiet(r_v1, "Kiểm tra lại", app._t2_recheck_demucs, width=84).pack(side="right", padx=(4, 0))
    btn_quiet(r_v1, "Chọn file", app._t2_pick_demucs, width=72).pack(side="right", padx=(4, 0))
    btn_quiet(r_v1, "Kiểm tra nguồn", app._t2_scan_audio, width=104).pack(side="right")

    app._t2_vocal_status = lbl(
        b_voc,
        "Demucs tách sạch nhưng chậm; karaoke tức thì nhưng chỉ hợp với stereo thật.",
        T.MUTED,
        F.tiny,
        anchor="w",
    )
    app._t2_vocal_status.pack(fill="x", pady=(2, 0))
    try:
        app._t2_refresh_vocal_status()
    except Exception:
        pass

    build_transition_ui(app, parent, "t2")

    foot = _footer_of(parent)
    switch(foot, text="Xuất từng cảnh lẻ (không nối thành 1 video tổng)", variable=app.t2_export_individual).pack(
        side="left"
    )
    btn_primary(foot, "🎞️ BẮT ĐẦU DỰNG & LỒNG TIẾNG", app.run_tab2_logic, width=210).pack(side="right")


def setup_tab3(app, parent):
    app.t3_audio_dir = tk.StringVar()
    app.t3_img_dir = tk.StringVar()
    app.t3_output = tk.StringVar()
    app.t3_effect = tk.StringVar(value="random")
    app.t3_intensity = tk.StringVar(value="1.3")
    app.t3_fps = tk.StringVar(value="30")
    app.t3_export_individual = tk.BooleanVar(value=True)

    _, b_src = section(
        parent,
        "🖼️ Tạo Video Chuyển Động Từ Ảnh Tĩnh + Giọng Đọc",
        "Tự động thêm hiệu ứng phóng to / lia máy (Ken Burns) khớp độ dài giọng đọc",
    )
    create_input(app, b_src, "Thư mục Audio", app.t3_audio_dir, lambda: app._browse_dir(app.t3_audio_dir))
    create_input(app, b_src, "Thư mục Ảnh", app.t3_img_dir, lambda: app._browse_dir(app.t3_img_dir))
    create_input(app, b_src, "File xuất ra", app.t3_output, lambda: app._browse_save(app.t3_output), is_save=True)

    _, b_eff = section(parent, "✨ Hiệu ứng chuyển động ống kính (Ken Burns)")
    app._t3_effect_display = tk.StringVar(value=_EFF_LABEL.get(app.t3_effect.get(), "Ngẫu nhiên mỗi ảnh"))

    def _pick(disp):
        app.t3_effect.set(_EFF_VALUE.get(disp, "random"))

    def _sync(*_a):
        want = _EFF_LABEL.get(app.t3_effect.get(), "Ngẫu nhiên mỗi ảnh")
        if app._t3_effect_display.get() != want:
            app._t3_effect_display.set(want)

    try:
        app.t3_effect.trace_add("write", _sync)
    except Exception:
        pass

    r_eff = row(b_eff)
    r_eff.pack(fill="x", pady=4)
    labeled_combo(
        r_eff,
        "Kiểu",
        [v for _, v in EFFECTS],
        variable=app._t3_effect_display,
        width=210,
        command=_pick,
    ).pack(side="left", padx=(0, 16))
    labeled_combo(
        r_eff,
        "Cường độ zoom",
        ["1.1", "1.2", "1.3", "1.5", "1.8", "2.0"],
        variable=app.t3_intensity,
        width=78,
    ).pack(side="left", padx=(0, 16))
    labeled_combo(r_eff, "FPS", ["24", "25", "30", "60"], variable=app.t3_fps, width=72).pack(side="left")

    build_transition_ui(app, parent, "t3")

    foot = _footer_of(parent)
    switch(foot, text="Xuất từng cảnh lẻ (không nối thành 1 video tổng)", variable=app.t3_export_individual).pack(
        side="left"
    )
    btn_primary(foot, "🖼️ TẠO VIDEO TỪ ẢNH & GIỌNG ĐỌC", app.run_tab3_logic, width=220).pack(side="right")


def build_transition_ui(app, parent, prefix: str, accent=None):
    mod = _mod(app)
    FX = getattr(mod, "TransitionFX", None)
    if FX is None:
        return None

    group_var = tk.StringVar(value=FX.GROUP_OFF)
    item_var = tk.StringVar(value="—")
    dur_var = tk.StringVar(value="0.5")

    setattr(app, f"{prefix}_trans_group", group_var)
    setattr(app, f"{prefix}_transition", item_var)
    setattr(app, f"{prefix}_trans_dur", dur_var)

    frame, body = section(
        parent,
        "Chuyển cảnh",
        "không làm đổi thời lượng nên audio vẫn khớp tuyệt đối",
    )

    holder = {"item": None}

    def _on_group(_choice=None):
        items = FX.items_for(group_var.get())
        cb = holder.get("item")
        if not cb:
            return
        if items:
            cb.configure(values=items, state="normal")
            item_var.set(items[0])
            cb.set(items[0])
        else:
            cb.configure(values=["—"], state="disabled")
            item_var.set("—")
            cb.set("—")

    r = row(body)
    r.pack(fill="x", pady=4)
    labeled_combo(
        r,
        "Nhóm",
        FX.group_names(),
        variable=group_var,
        width=190,
        command=_on_group,
    ).pack(side="left", padx=(0, 14))

    icb = _make_combo(r, ["—"], variable=item_var, width=180)
    icb.configure(state="disabled")
    icb.pack(side="left", padx=(0, 14))
    holder["item"] = icb

    labeled_combo(
        r,
        "Dài",
        ["0.3", "0.4", "0.5", "0.8", "1.0", "1.5"],
        variable=dur_var,
        width=74,
    ).pack(side="left")
    lbl(r, "giây", T.MUTED, F.label).pack(side="left", padx=6)

    return frame
