"""
ui_tool4.py — Giao diện "VEO 3 từ ảnh (I2V)" (tool4.py), tách riêng.
──────────────────────────────────────────────────────────────────────
Dùng chung bộ màu / thành phần với ui.py và mấy hàm nhỏ của ui_tool5.py.

Cách dùng trong tool4.py:

    import ui_tool4 as _ui4

    class VeoApp(ctk.CTkFrame):
        def __init__(self, master):
            super().__init__(master)
            ...            # biến trạng thái
            _ui4.setup_ui(self)

Mọi TÊN BIẾN giữ nguyên (cbo_model_ver, cbo_ratio, entry_thread, btn_img1,
lbl_img2, txt_prompt_input, entry_out_dir, list_frame, log_box ...) nên phần
xử lý không phải sửa gì.
"""

import os
import tkinter as tk
import customtkinter as ctk
import ui as _ui
from ui import (
    T,
    F,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    lbl,
    TabStrip,
    sbtn,
    opt,
    combo,
    entry,
    grid_field,
    note,
    group,
    _scroll,
    dialog,
    account_row,
    status_color,
)
import flowkit_engine

MODELS = [
    "Veo 3.1 - Lite",
    "Veo 3.1 - Fast",
    "Veo 3.1 - Quality",
    "Veo 3.1 - Lite [Lower Priority]",
]


def setup_ui(app):
    _ui.set_density_early()
    F.init()
    app.configure(fg_color=T.BG)
    try:
        sw = app.winfo_screenwidth()
    except Exception:
        sw = 1920
    _left_w = 340 if sw <= 1400 else 380

    app.grid_columnconfigure(0, weight=0, minsize=_left_w)
    app.grid_columnconfigure(1, weight=1)
    app.grid_rowconfigure(0, weight=1)

    _build_left(app)
    _build_right(app)
    app._current_acc_list_frame = None
    app._update_acc_count_label()


def _build_left(app):
    col = card(app)
    col.grid(row=0, column=0, sticky="nsew", padx=(T.PAD, T.GAP), pady=T.PAD)
    col.grid_rowconfigure(1, weight=1)
    col.grid_columnconfigure(0, weight=1)

    app.sidebar = TabStrip(col, height=28, minw=62)
    t_acc = app.sidebar.add("🔑 Tài khoản")
    t_img = app.sidebar.add("🖼️ Chọn Ảnh")
    t_cfg = app.sidebar.add("⚙️ Thiết lập & Câu lệnh")
    app.sidebar.grid(row=0, column=0)

    _acc_tab(app, _scroll(t_acc))
    _img_tab(app, _scroll(t_img))
    _cfg_data_tab(app, _scroll(t_cfg))
    app.sidebar.set("⚙️ Thiết lập & Câu lệnh")
    _action_bar(app, col)


def _acc_tab(app, box):
    app.btn_acc_mgr = btn(box, "Quản lý tài khoản", app.open_account_manager)
    app.btn_acc_mgr.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(4, 2))

    app.lbl_acc_count = lbl(box, "đang đọc…", T.MUTED, F.label, anchor="w")
    app.lbl_acc_count.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 8))

    group(box, 2, "Loại tài khoản")
    app.cbo_account_type = opt(box, ["Ultra", "Pro"], command=app._on_account_type_change)
    app.cbo_account_type.set("Ultra")
    grid_field(box, 3, "Gói đang dùng", app.cbo_account_type)
    note(box, 4, "Ultra — chạy model bản _ultra.\nPro — model bản thường, chỉ có Fast và Quality.")


def _img_tab(app, box):
    note(
        box,
        0,
        "Ảnh đầu và ảnh cuối ghép theo thứ tự với danh sách prompt: ảnh 1 đi với prompt 1, ảnh 2 với prompt 2…",
    )
    group(box, 1, "Ảnh bắt đầu")
    app.btn_img1 = sbtn(box, "Chọn ảnh bắt đầu", app.choose_start_images, width=200)
    app.btn_img1.grid(row=2, column=0, columnspan=2, sticky="ew", pady=2)
    app.lbl_img1 = lbl(box, "chưa chọn ảnh nào", T.MUTED, F.tiny, anchor="w")
    app.lbl_img1.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 6))

    group(box, 4, "Ảnh kết thúc")
    app.btn_img2 = sbtn(box, "Chọn ảnh kết thúc", app.choose_end_images, width=200)
    app.btn_img2.grid(row=5, column=0, columnspan=2, sticky="ew", pady=2)
    app.lbl_img2 = lbl(box, "chưa chọn ảnh nào", T.MUTED, F.tiny, anchor="w")
    app.lbl_img2.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(0, 6))
    sbtn(box, "🧹 Xoá toàn bộ ảnh đã chọn", app.clear_selected_images, width=200).grid(
        row=7, column=0, columnspan=2, sticky="ew", pady=(2, 6)
    )
    note(
        box,
        8,
        "Chỉ có ảnh bắt đầu thì video chạy từ ảnh đó. Có cả ảnh kết thúc thì video chuyển từ ảnh đầu sang ảnh cuối.",
    )


def _cfg_data_tab(app, box):
    """Gộp Cấu hình + Prompt vào 1 tab."""
    top = row(box)
    top.grid(row=0, column=0, sticky="ew")
    top.columnconfigure(1, weight=1)
    _cfg_tab(app, top)

    ctk.CTkFrame(box, height=1, fg_color=T.DIVIDER).grid(row=1, column=0, sticky="ew", pady=8)

    bot = row(box)
    bot.grid(row=2, column=0, sticky="ew")
    bot.columnconfigure(1, weight=1)
    _data_tab(app, bot)


def _cfg_tab(app, box):
    app.cbo_model_ver = opt(box, MODELS)
    app.cbo_model_ver.set("Veo 3.1 - Lite [Lower Priority]")
    grid_field(box, 0, "Model", app.cbo_model_ver)

    app.cbo_ratio = opt(box, ["16:9", "9:16"])
    app.cbo_ratio.set("16:9")
    grid_field(box, 1, "Khung hình", app.cbo_ratio)

    app.cbo_style = combo(box, flowkit_engine.DEFAULT_STYLE_PRESETS, state="normal")
    app.cbo_style.set(flowkit_engine.AUTO_STYLE_LABEL)
    grid_field(box, 2, "Phong cách", app.cbo_style)

    app.cbo_upscale = opt(box, ["1080p", "4K", "Không"])
    app.cbo_upscale.set("1080p")
    grid_field(box, 3, "Tự động nâng nét", app.cbo_upscale)

    app.entry_thread = entry(box)
    app.entry_thread.insert(0, "1")
    grid_field(box, 4, "Số luồng", app.entry_thread)
    note(
        box,
        5,
        "Nâng nét chạy sau khi render xong, chỉ giữ bản đã nâng và xoá bản gốc. Nhiều luồng nhanh hơn nhưng dễ bị Google chặn.",
    )


def _data_tab(app, box):
    sbtn(box, "📂 Chọn file kịch bản (TXT / JSON)", app.choose_file, width=220).grid(
        row=0, column=0, columnspan=2, sticky="ew", pady=(2, 2)
    )
    app.lbl_file = lbl(box, "chưa chọn file", T.MUTED, F.tiny, anchor="w", justify="left", wraplength=260)
    app.lbl_file.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 6))

    hdr_p = row(box)
    hdr_p.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(2, 2))
    lbl(hdr_p, "Mô tả chuyển động (mỗi dòng 1 ảnh)", T.LABEL, F.label, anchor="w").pack(side="left")
    sbtn(hdr_p, "🧹 Xoá", app.clear_prompts_only, width=56).pack(side="right", padx=(3, 0))
    sbtn(hdr_p, "📥 Nạp", app.scan_prompts_and_files, width=68).pack(side="right")

    app.txt_prompt_input = ctk.CTkTextbox(
        box,
        height=120,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER,
        border_width=1,
        text_color=T.TEXT,
        font=F.ui,
        wrap="word",
    )
    app.txt_prompt_input.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 8))
    app.txt_prompt_input.bind("<FocusOut>", lambda e: app.scan_prompts_and_files())

    lbl(box, "📂 Thư mục lưu video đầu ra", T.LABEL, F.label, anchor="w").grid(
        row=4, column=0, columnspan=2, sticky="w", pady=(2, 2)
    )
    app.frm_out_dir = row(box)
    app.frm_out_dir.grid(row=5, column=0, columnspan=2, sticky="ew")
    app.frm_out_dir.columnconfigure(0, weight=1)

    app.entry_out_dir = entry(app.frm_out_dir)
    app.entry_out_dir.insert(0, "Video_Result")
    app.entry_out_dir.grid(row=0, column=0, sticky="ew", padx=(0, 6))
    app.entry_out_dir.bind("<FocusOut>", lambda e: app.scan_prompts_and_files())

    app.btn_browse_out = sbtn(app.frm_out_dir, "Chọn…", app.choose_output_folder, width=64)
    app.btn_browse_out.grid(row=0, column=1)


def _action_bar(app, col):
    bar = row(col)
    bar.grid(row=2, column=0, sticky="ew", padx=T.PAD, pady=(4, T.PAD))
    bar.columnconfigure(0, weight=1)
    bar.columnconfigure(1, weight=1)

    app.btn_start = btn_primary(bar, "Tạo video", app.start_process)
    app.btn_start.grid(row=0, column=0, sticky="ew", padx=(0, 4), pady=(0, 4))

    app.btn_stop = btn_danger(bar, "Dừng tạo", app.stop_process)
    app.btn_stop.configure(state="disabled")
    app.btn_stop.grid(row=0, column=1, sticky="ew", padx=(4, 0), pady=(0, 4))

    app.btn_reset = sbtn(bar, "🌐 Đổi IP Mạng (WARP)", app.reset_system)
    app.btn_reset.grid(row=1, column=0, columnspan=2, sticky="ew")


def _build_right(app):
    right = row(app)
    app.right_panel = right
    right.grid(row=0, column=1, sticky="nsew", padx=(T.GAP, T.PAD), pady=T.PAD)
    right.grid_rowconfigure(0, weight=3)
    right.grid_rowconfigure(1, weight=1)
    right.grid_columnconfigure(0, weight=1)

    top_card = card(right)
    top_card.grid(row=0, column=0, sticky="nsew", pady=(0, T.GAP))
    top_card.grid_rowconfigure(1, weight=1)
    top_card.grid_columnconfigure(0, weight=1)

    head = row(top_card)
    head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(T.PAD, 4))

    lbl(head, "🖼️ HÀNG ĐỢI CHUYỂN ẢNH TĨNH THÀNH VIDEO", T.TEXT_STRONG, F.ui_sb).pack(side="left", padx=(4, 14))

    app.btn_prev_page = sbtn(head, "‹", app.prev_page, width=30)
    app.btn_prev_page.pack(side="left")

    app.lbl_page_info = lbl(head, "Trang 0/0", T.TEXT_DIM, F.label)
    app.lbl_page_info.pack(side="left", padx=8)

    app.btn_next_page = sbtn(head, "›", app.next_page, width=30)
    app.btn_next_page.pack(side="left")

    def _open_out():
        d = app.entry_out_dir.get().strip() or "Video_Result"
        os.makedirs(d, exist_ok=True)
        try:
            os.startfile(os.path.abspath(d))
        except Exception:
            pass

    sbtn(head, "📂 Mở thư mục", _open_out, width=98).pack(side="right", padx=(4, 0))
    sbtn(head, "🧹 Làm sạch cũ", lambda: app.clear_previous_session(ask_confirm=True), width=104).pack(side="right", padx=4)
    sbtn(head, "🔗 Nối thành phim dài", app.merge_video, width=132).pack(side="right", padx=4)

    app.list_frame = ctk.CTkScrollableFrame(
        top_card,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.list_frame.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

    _log_card(app, right)


def _log_card(app, right):
    lc = card(right)
    lc.grid(row=1, column=0, sticky="nsew")
    lc.grid_rowconfigure(1, weight=1)
    lc.grid_columnconfigure(0, weight=1)

    head = row(lc)
    head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(6, 2))
    lbl(head, "NHẬT KÝ", T.TEXT_STRONG, F.ui_sb).pack(side="left", padx=4)

    app.log_box = tk.Text(
        lc,
        height=7,
        font=("Consolas", 10),
        bg=T.INPUT,
        fg="#b6bbc8",
        insertbackground=T.TEXT,
        relief="flat",
        bd=0,
        highlightthickness=1,
        highlightbackground=T.BORDER_SOFT,
        highlightcolor=T.BORDER_SOFT,
        padx=8,
        pady=6,
        state="disabled",
    )
    app.log_box.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))

    def clear_log():
        try:
            app.log_box.configure(state="normal")
            app.log_box.delete("1.0", "end")
            app.log_box.configure(state="disabled")
        except Exception:
            pass

    sbtn(head, "Xoá", clear_log, width=46).pack(side="right")


def result_row(app, item: dict, open_cmd=None):
    F.init()
    row_id = item["id"]
    text = item.get("text", "")
    status = item.get("status", "Waiting...")
    file_path = item.get("file_path")

    r = ctk.CTkFrame(
        app.list_frame,
        fg_color=T.INPUT,
        corner_radius=T.RADIUS,
        border_color=T.BORDER_SOFT,
        border_width=1,
    )
    r.pack(fill="x", pady=3)

    lbl(r, f"{row_id + 1:03d}", T.MUTED, F.mono_sm, width=34).pack(side="left", padx=(10, 6), pady=7)

    preview = text.replace("\n", " ")
    if len(preview) > 70:
        preview = preview[:70] + "…"
    lbl_prev = lbl(r, preview, T.TEXT, F.ui, anchor="w")
    lbl_prev.pack(side="left", fill="x", expand=True, padx=4)

    bf = row(r)
    bf.pack(side="right", padx=8)

    lbl_status = lbl(r, status, status_color(status), F.tiny, width=126, anchor="w")
    lbl_status.pack(side="right", padx=6)

    sbtn(bf, "Sửa", lambda rid=row_id: app.on_edit_prompt(rid), width=48).pack(side="left", padx=2)
    sbtn(bf, "Tạo lại", lambda rid=row_id: app.on_regen_prompt(rid), width=62).pack(side="left", padx=2)
    sbtn(bf, "Xoá", lambda rid=row_id: app.on_delete_video(rid), width=46).pack(side="left", padx=2)

    def _open(fp=file_path):
        if fp and os.path.exists(fp):
            if open_cmd:
                open_cmd(fp)
            else:
                try:
                    os.startfile(fp)
                except Exception:
                    pass

    btn_view = sbtn(
        bf,
        "Xem",
        _open if file_path else None,
        width=52,
        state="normal" if file_path else "disabled",
    )
    btn_view.pack(side="left", padx=2)

    app.rows_ui[row_id] = {
        "frame": r,
        "status_lbl": lbl_status,
        "view_btn": btn_view,
        "text_preview": lbl_prev,
    }
    return r
