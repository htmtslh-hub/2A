"""
ui_tool6.py — Giao diện tab "Image đồng nhất" (tool6_image_consist.py)
──────────────────────────────────────────────────────────────────────
Thiết kế chuẩn Luồng 2 Bước (2-Stage Reference-First Flow):
  • Bước 1: Tạo loạt ảnh Tham Chiếu Đồng Nhất — Nhân vật (theo các góc: chính diện, 3/4, nghiêng, toàn thân) & Bối cảnh gốc.
  • Bước 2: Sau khi có loạt ảnh tham chiếu (media_id trên Google Flow), tạo ảnh cho từng phân cảnh bám sát các ảnh tham chiếu đó.
"""

import customtkinter as ctk
import ui as _ui
from ui import (
    T,
    F,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    lbl,
    TabStrip,
    sbtn,
    opt,
    combo,
    entry,
    grid_field,
    note,
    group,
    _scroll,
)
import flowkit_engine

IMAGE_MODELS = [
    "🍌 Nano Banana Pro (GEM_PIX_2 / Imagen 4)",
    "🍌 Nano Banana 2.1 (NARWHAL)",
    "🍌 Nano Banana 2 Lite (HARBOR_SEAL)",
]

IMAGE_QUALITIES = ["Gốc (1K)", "2K", "4K"]
IMAGE_RATIOS = ["16:9 (Ngang)", "9:16 (Dọc)", "1:1 (Vuông)", "4:3 (Ngang)", "3:4 (Dọc)"]
THREAD_PRESETS = ["1", "2", "3", "4 (Tối đa/1 TK)", "6 (Đa TK)", "8 (Đa TK)"]
ACCOUNT_MODE_PRESETS = [
    "⚡ Xoay vòng tất cả TK (Đa luồng)",
    "➕ Mở thêm TK Ultra #1",
    "➕ Mở thêm TK Ultra #2",
    "➕ Mở thêm TK Ultra #3",
    "➕ Mở thêm TK Ultra #4",
]

PUSH_TO_VIDEO_OPTIONS = [
    "🎬 Đẩy sang TẤT CẢ tab Tạo Video (I2V + Muse + Đồng nhất + T2V)",
    "📷 Đẩy sang Image to video (Ghép Ảnh + Prompt từng cảnh)",
    "🎞 Đẩy sang Video Muse (Ghép Ảnh NV + Prompt từng cảnh)",
    "🎭 Đẩy sang Video đồng nhất (Ghép Ảnh NV + Prompt từng cảnh)",
    "🎬 Đẩy sang Text to video (Đẩy toàn bộ Prompt cảnh)",
    "✨ Đẩy sang Chuẩn hóa prompt (Rà soát & Làm sạch Prompt)",
]

CARD_IDLE = T.INPUT
CARD_DONE = "#1d2a24"


def setup_ui(app):
    _ui.set_density_early()
    F.init()
    app.configure(fg_color=T.BG)
    try:
        sw = app.winfo_screenwidth()
    except Exception:
        sw = 1920
    _left_w = 385 if sw <= 1400 else 420

    app.grid_columnconfigure(0, weight=0, minsize=_left_w)
    app.grid_columnconfigure(1, weight=1)
    app.grid_rowconfigure(0, weight=1)

    _build_left(app)
    _build_right(app)
    app._current_acc_list_frame = None
    app._update_acc_count_label()


def _build_left(app):
    col = card(app)
    col.grid(row=0, column=0, sticky="nsew", padx=(T.PAD, T.GAP), pady=T.PAD)
    col.grid_rowconfigure(0, weight=1)
    col.grid_columnconfigure(0, weight=1)

    sc = _scroll(col)
    sc.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
    sc.grid_columnconfigure(0, weight=1)

    # ── 1. CẤU HÌNH MODEL & TÀI KHOẢN GOOGLE FLOW (ĐA TÀI KHOẢN & ĐA LUỒNG) ──
    cfg_box = row(sc)
    cfg_box.grid(row=0, column=0, sticky="ew", padx=4, pady=(2, 4))
    cfg_box.columnconfigure(1, weight=1)

    acc_top_row = row(cfg_box)
    acc_top_row.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))
    acc_top_row.columnconfigure(0, weight=1)
    app.lbl_acc_count = lbl(acc_top_row, "🟢 Đang kiểm tra kết nối Google Ultra...", T.OK, F.label, anchor="w")
    app.lbl_acc_count.grid(row=0, column=0, sticky="ew")
    sbtn(acc_top_row, "👥 Quản lý / Thêm TK", app.open_multi_account_manager, width=128).grid(
        row=0, column=1, padx=(4, 0)
    )

    app.cbo_account_mode = opt(cfg_box, ACCOUNT_MODE_PRESETS, command=app._on_account_mode_selected)
    app.cbo_account_mode.set(ACCOUNT_MODE_PRESETS[0])
    grid_field(cfg_box, 1, "Tài khoản chạy", app.cbo_account_mode)

    app.cbo_model = opt(cfg_box, IMAGE_MODELS)
    app.cbo_model.set(IMAGE_MODELS[0])
    grid_field(cfg_box, 2, "Model AI", app.cbo_model)

    app.cbo_quality = opt(cfg_box, IMAGE_QUALITIES)
    app.cbo_quality.set(IMAGE_QUALITIES[0])
    grid_field(cfg_box, 3, "Chất lượng ảnh", app.cbo_quality)

    app.cbo_ratio = opt(cfg_box, IMAGE_RATIOS)
    app.cbo_ratio.set(IMAGE_RATIOS[0])
    grid_field(cfg_box, 4, "Khung hình", app.cbo_ratio)

    app.cbo_style = combo(
        cfg_box,
        flowkit_engine.DEFAULT_STYLE_PRESETS,
        state="normal",
    )
    app.cbo_style.set(flowkit_engine.AUTO_STYLE_LABEL)
    grid_field(cfg_box, 5, "Phong cách", app.cbo_style)

    app.entry_thread = combo(cfg_box, THREAD_PRESETS, state="normal")
    app.entry_thread.set("3")
    grid_field(cfg_box, 6, "Số luồng song song", app.entry_thread)

    out_row = row(cfg_box)
    out_row.grid(row=7, column=0, columnspan=2, sticky="ew", pady=(2, 2))
    out_row.columnconfigure(0, weight=1)
    app.entry_out = entry(out_row, placeholder_text="Thư mục lưu ảnh")
    app.entry_out.insert(0, "Scene_Images")
    app.entry_out.grid(row=0, column=0, sticky="ew", padx=(0, 6))
    sbtn(out_row, "Thư mục…", app.choose_output_folder, width=76).grid(row=0, column=1)

    ctk.CTkFrame(sc, height=1, fg_color=T.DIVIDER).grid(row=1, column=0, sticky="ew", pady=6)

    # ── 2. BƯỚC 1: NHẬP PROMPT NHÂN VẬT (ĐA GÓC) & BỐI CẢNH ĐỒNG NHẤT ──
    ref_sec = row(sc)
    ref_sec.grid(row=2, column=0, sticky="ew", padx=4)
    ref_sec.columnconfigure(0, weight=1)

    lbl(
        ref_sec,
        "① PROMPT THAM CHIẾU GỐC (NHÂN VẬT 1 KHUNG CHUẨN & BỐI CẢNH)",
        "#38bdf8",
        F.ui_sb,
        anchor="w",
    ).grid(row=0, column=0, sticky="ew", pady=(0, 2))
    lbl(
        ref_sec,
        "Định dạng:  CHAR_01 | mô tả nhân vật   hoặc   LOC_01 | mô tả bối cảnh",
        T.MUTED,
        F.tiny,
        anchor="w",
    ).grid(row=1, column=0, sticky="ew", pady=(0, 3))

    app.txt_ref_prompts = ctk.CTkTextbox(
        ref_sec,
        height=110,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color="#1f6feb",
        border_width=1,
        text_color=T.TEXT,
        font=F.label,
        wrap="word",
    )
    app.txt_ref_prompts.grid(row=2, column=0, sticky="ew", pady=(0, 4))
    app.txt_ref_prompts.insert(
        "1.0",
        "CHAR_01 | A 22-year-old young male sky-mechanic with messy silver-white hair, warm amber eyes, brass aviator goggles on forehead, brown leather bomber jacket over teal tunic, glowing blue gauntlet on right arm, small bronze clockwork dragon on shoulder\n"
        "LOC_01 | Floating steampunk sky-city with giant brass airships, marble towers, glowing cyan energy bridges above a sea of golden sunrise clouds",
    )

    ref_btn_bar = row(ref_sec)
    ref_btn_bar.grid(row=3, column=0, sticky="ew", pady=(0, 4))
    ref_btn_bar.columnconfigure((0, 1, 2), weight=1)
    sbtn(ref_btn_bar, "📥 Nạp Ref", app._apply_ref_prompts).grid(
        row=0, column=0, sticky="ew", padx=(0, 2)
    )
    sbtn(ref_btn_bar, "📂 Ảnh mẫu máy", app.add_images).grid(
        row=0, column=1, sticky="ew", padx=2
    )
    sbtn(ref_btn_bar, "🧹 Xoá Ref", app.clear_refs_only).grid(
        row=0, column=2, sticky="ew", padx=(2, 0)
    )

    ctk.CTkFrame(sc, height=1, fg_color=T.DIVIDER).grid(row=3, column=0, sticky="ew", pady=6)

    # ── 3. BƯỚC 2: NHẬP PROMPT TỪNG PHÂN CẢNH (GẮN MÃ CHAR_ / LOC_) ──
    scn_sec = row(sc)
    scn_sec.grid(row=4, column=0, sticky="ew", padx=4)
    scn_sec.columnconfigure(0, weight=1)

    lbl(
        scn_sec,
        "② PROMPT TỪNG PHÂN CẢNH ẢNH ĐƠN (1 KHUNG HÌNH / BẤM ✏️ SỬA)",
        "#34d399",
        F.ui_sb,
        anchor="w",
    ).grid(row=0, column=0, sticky="ew", pady=(0, 2))
    lbl(
        scn_sec,
        "Mỗi dòng 1 cảnh:  CHAR_01, LOC_01 | Scene 1: mô tả hành động & góc máy",
        T.MUTED,
        F.tiny,
        anchor="w",
    ).grid(row=1, column=0, sticky="ew", pady=(0, 3))

    app.txt_prompt = ctk.CTkTextbox(
        scn_sec,
        height=155,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER,
        border_width=1,
        text_color=T.TEXT,
        font=F.label,
        wrap="word",
    )
    app.txt_prompt.grid(row=2, column=0, sticky="ew", pady=(0, 4))
    app.txt_prompt.insert(
        "1.0",
        "CHAR_01, LOC_01 | Scene 1: Extreme wide establishing shot standing on the edge of the floating steampunk sky-dock at sunrise, giant brass airships drifting through clouds\n"
        "CHAR_01, LOC_01 | Scene 2: Medium shot tightening a glowing blue crystal core inside the small bronze dragon's chest with a brass wrench, warm lantern light\n"
        "CHAR_01, LOC_01 | Scene 3: Close-up reaction shot as the small bronze dragon's eyes ignite with bright cyan light and its mechanical wings unfold, joyful expression\n"
        "CHAR_01, LOC_01 | Scene 4: Dynamic low-angle tracking shot sprinting across the wooden sky-bridge as storm clouds gather, holding an ancient glowing compass\n"
        "CHAR_01, LOC_01 | Scene 5: Wide cinematic shot piloting a sleek brass sky-glider through a canyon of floating rock islands, waterfalls cascading below",
    )

    p_bar = row(scn_sec)
    p_bar.grid(row=3, column=0, sticky="ew", pady=(0, 4))
    p_bar.columnconfigure((0, 1, 2), weight=1)
    sbtn(p_bar, "📥 Nạp Phân Cảnh", app._apply_manual_prompts).grid(row=0, column=0, sticky="ew", padx=(0, 2))
    sbtn(p_bar, "📂 Mở File TXT", app.choose_file).grid(row=0, column=1, sticky="ew", padx=2)
    sbtn(p_bar, "🧹 Xoá Cảnh", app.clear_scenes_only).grid(
        row=0, column=2, sticky="ew", padx=(2, 0)
    )

    ctk.CTkButton(
        scn_sec,
        text="🧠 AI Đọc Prompt ➔ Tự Tách Nhân Vật (①) & Phân Cảnh (②)",
        height=30,
        corner_radius=T.RADIUS,
        fg_color="#6d28d9",
        hover_color="#7c3aed",
        text_color="#ffffff",
        font=F.ui_sb,
        command=app.smart_analyze_and_split_prompts,
    ).grid(row=4, column=0, sticky="ew", pady=(2, 4))

    _action_bar(app, col)


def _action_bar(app, col):
    bar = ctk.CTkFrame(col, fg_color="transparent")
    bar.grid(row=1, column=0, sticky="ew", padx=T.PAD, pady=(4, T.PAD))
    bar.grid_columnconfigure((0, 1), weight=1)

    app.btn_gen_refs = ctk.CTkButton(
        bar,
        text="① Tạo Ảnh Tham Chiếu (Nhân vật/Bối cảnh)",
        height=34,
        corner_radius=7,
        fg_color="#1f6feb",
        hover_color="#388bfd",
        text_color="#ffffff",
        font=F.h,
        command=app.start_generate_refs,
    )
    app.btn_gen_refs.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 5))

    app.btn_start = btn_primary(bar, "② Tạo Ảnh Từng Phân Cảnh (Theo Ref)", app.start_process)
    app.btn_start.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 5))

    app.btn_full_flow = ctk.CTkButton(
        bar,
        text="⚡ Chạy Trọn Bộ (① ➔ ②)",
        height=32,
        corner_radius=7,
        fg_color="#10b981",
        hover_color="#34d399",
        text_color="#041b11",
        font=F.h,
        command=app.start_full_flow,
    )
    app.btn_full_flow.grid(row=2, column=0, sticky="ew", padx=(0, 3))

    app.btn_stop = btn_danger(bar, "⏹ Dừng", app.stop_process)
    app.btn_stop.configure(state="disabled")
    app.btn_stop.grid(row=2, column=1, sticky="ew", padx=(3, 0))


def _build_right(app):
    right = row(app)
    app.main = right
    right.grid(row=0, column=1, sticky="nsew", padx=(T.GAP, T.PAD), pady=T.PAD)
    right.grid_rowconfigure(0, weight=2)
    right.grid_rowconfigure(1, weight=3)
    right.grid_rowconfigure(2, weight=1)
    right.grid_columnconfigure(0, weight=1)

    # ── BẢNG 1 (TRÊN): LOẠT ẢNH THAM CHIẾU ĐỒNG NHẤT (NHÂN VẬT ĐA GÓC & BỐI CẢNH) ──
    ref_card = card(right)
    ref_card.grid(row=0, column=0, sticky="nsew", pady=(0, T.GAP))
    ref_card.grid_rowconfigure(1, weight=1)
    ref_card.grid_columnconfigure(0, weight=1)

    r_head = row(ref_card)
    r_head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(8, 4))
    lbl(
        r_head,
        "👤 ① ẢNH THAM CHIẾU ĐỒNG NHẤT (NHÂN VẬT & BỐI CẢNH)",
        "#38bdf8",
        F.ui_sb,
    ).pack(side="left", padx=(4, 8))
    sbtn(
        r_head,
        "🧹 Làm sạch",
        lambda: app.clear_previous_session(ask_confirm=True),
        width=96,
    ).pack(side="right", padx=(4, 0))
    sbtn(
        r_head,
        "✨ Chuẩn hóa Prompt Ref",
        app.push_refs_to_review,
        width=165,
    ).pack(side="right", padx=(4, 0))
    app.lbl_ref_summary = lbl(r_head, "0 ảnh tham chiếu", T.MUTED, F.label)
    app.lbl_ref_summary.pack(side="right", padx=6)

    app.ref_frame = ctk.CTkScrollableFrame(
        ref_card,
        height=150,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.ref_frame.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 6))
    app.ref_frame.grid_columnconfigure(0, weight=1)

    # ── BẢNG 2 (GIỮA): DANH SÁCH ẢNH TỪNG PHÂN CẢNH (GẮN REF TỪ ①) ──
    top_card = card(right)
    top_card.grid(row=1, column=0, sticky="nsew", pady=(0, T.GAP))
    top_card.grid_rowconfigure(1, weight=1)
    top_card.grid_columnconfigure(0, weight=1)

    head = row(top_card)
    head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(8, 4))

    lbl(head, "🎨 ② ẢNH TỪNG PHÂN CẢNH (TẠO TỪ ẢNH THAM CHIẾU ①)", "#34d399", F.ui_sb).pack(
        side="left", padx=(4, 8)
    )

    sbtn(head, "📂 Mở thư mục", app.open_output_folder, width=96).pack(side="right", padx=(4, 0))
    sbtn(
        head,
        "🧹 Làm sạch cũ",
        lambda: app.clear_previous_session(ask_confirm=True),
        width=102,
    ).pack(side="right", padx=(4, 0))
    btn_primary(
        head,
        "📤 Đẩy sang Video ➔",
        app.execute_push_to_video,
        width=142,
    ).pack(side="right", padx=(4, 0))
    app.cbo_push_video = opt(head, PUSH_TO_VIDEO_OPTIONS, width=285)
    app.cbo_push_video.set(PUSH_TO_VIDEO_OPTIONS[0])
    app.cbo_push_video.pack(side="right", padx=(4, 0))

    app.task_frame = ctk.CTkScrollableFrame(
        top_card,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.task_frame.grid(row=1, column=0, sticky="nsew", padx=8, pady=(2, 8))
    app.task_frame.grid_columnconfigure(0, weight=1)

    # ── BẢNG 3 (DƯỚI): NHẬT KÝ TIẾN TRÌNH ──
    bot_card = card(right)
    bot_card.grid(row=2, column=0, sticky="nsew")
    bot_card.grid_rowconfigure(1, weight=1)
    bot_card.grid_columnconfigure(0, weight=1)

    log_head = row(bot_card)
    log_head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(6, 2))
    lbl(log_head, "📋 NHẬT KÝ FLOW TẠO ẢNH ĐỒNG NHẤT", T.MUTED, F.label).pack(side="left")
    app.lbl_summary = lbl(log_head, "Sẵn sàng", T.OK, F.label)
    app.lbl_summary.pack(side="right")

    app.log_box = ctk.CTkTextbox(
        bot_card,
        height=85,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        text_color=T.TEXT_DIM,
        font=F.mono_sm,
        wrap="word",
    )
    app.log_box.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 6))
    _ui.track_log_follow(app, app.log_box)
