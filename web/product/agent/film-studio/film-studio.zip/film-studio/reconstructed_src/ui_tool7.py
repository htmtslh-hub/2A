"""
ui_tool7.py — Giao diện tab "VEO 3 Đồng Nhất" (tool7.py), tách riêng.
──────────────────────────────────────────────────────────────────────
Dùng chung bộ màu / thành phần với ui.py, và dùng lại mấy hàm nhỏ của
ui_tool5.py cho hai tab VEO nhìn như một.

Cách dùng trong tool7.py:

    import ui_tool7 as _ui7

    class IngredientsAppPro(ctk.CTkFrame):
        def __init__(self, master):
            super().__init__(master)
            ...  # biến trạng thái
            _ui7.setup_ui(self)

Mọi TÊN BIẾN giữ nguyên (cbo_model, cbo_voice, chk_fixed_seed_var, img_scroll,
txt_prompt, entry_out, btn_start, task_frame, log_box ...) nên phần xử lý
không phải sửa gì.
"""

import os
import customtkinter as ctk
import ui as _ui
from ui import (
    T,
    F,
    card,
    row,
    btn,
    btn_primary,
    btn_danger,
    lbl,
    TabStrip,
    sbtn,
    opt,
    combo,
    entry,
    grid_field,
    note,
    group,
    _scroll,
    dialog,
    account_row,
    status_color,
)
import flowkit_engine

VOICE_LIST = [
    "(Không dùng voice)",
    "⭐ Achernar — Female, soft, high pitch  [stable]",
    "Achird — Male, friendly, mid pitch",
    "Algenib — Male, gravelly, low pitch",
    "Algieba — Male, easy-going, mid-low pitch",
    "Alnilam — Male, firm, mid-low pitch",
    "Aoede — Female, breezy, mid pitch",
    "Autonoe — Female, bright, mid pitch",
    "Callirrhoe — Female, easy-going, mid pitch",
    "Charon — Male, informative, lower pitch",
    "Despina — Female, smooth, mid pitch",
    "Enceladus — Male, breathy, lower pitch",
    "Erinome — Female, clear, mid pitch",
    "Fenrir — Male, excitable, younger pitch",
    "Gacrux — Female, mature, mid pitch",
    "Iapetus — Male, clear, mid-low pitch",
    "Kore — Female, firm, mid pitch",
    "Laomedeia — Female, upbeat, mid-high pitch",
    "Leda — Female, youthful, mid-high pitch",
    "Orus — Male, firm, mid-low pitch",
    "Puck — Male, upbeat, mid pitch",
    "Pulcherrima — Ungendered, forward, mid-high pitch",
    "Rasalgethi — Male, informative, mid pitch",
    "Sadachbia — Male, lively, low pitch",
    "Sadaltager — Male, knowledgeable, mid pitch",
    "Schedar — Male, even, mid-low pitch",
    "Sulafat — Female, warm, mid pitch",
    "Umbriel — Male, smooth, lower pitch",
    "Vindemiatrix — Female, gentle, mid pitch",
    "Zephyr — Female, bright, mid-high pitch",
]

MODELS = [
    "Veo 3.1 - Lite",
    "Veo 3.1 - Fast",
    "Omni 1.1 Flash",
    "Veo 3.1 - Lite [Lower Priority]",
    "Veo 3.1 - Quality",
    "Veo 4",
]

CARD_IDLE = T.INPUT
CARD_DONE = "#1d2a24"


def setup_ui(app):
    _ui.set_density_early()
    F.init()
    app.configure(fg_color=T.BG)
    try:
        sw = app.winfo_screenwidth()
    except Exception:
        sw = 1920
    _left_w = 350 if sw <= 1400 else 390

    app.grid_columnconfigure(0, weight=0, minsize=_left_w)
    app.grid_columnconfigure(1, weight=1)
    app.grid_rowconfigure(0, weight=1)

    _build_left(app)
    _build_right(app)
    app._current_acc_list_frame = None
    app._update_acc_count_label()


def _build_left(app):
    col = card(app)
    col.grid(row=0, column=0, sticky="nsew", padx=(T.PAD, T.GAP), pady=T.PAD)
    col.grid_rowconfigure(1, weight=1)
    col.grid_columnconfigure(0, weight=1)

    app.sidebar = TabStrip(col, height=28, minw=80)
    t_acc_img = app.sidebar.add("👤 Ảnh Mẫu & Tài Khoản")
    t_cfg_prompt = app.sidebar.add("⚙️ Thiết Lập & Câu Lệnh")
    app.sidebar.grid(row=0, column=0)

    _acc_img_tab(app, _scroll(t_acc_img))
    _cfg_prompt_tab(app, _scroll(t_cfg_prompt))
    app.sidebar.set("⚙️ Thiết Lập & Câu Lệnh")
    _action_bar(app, col)


def _acc_img_tab(app, box):
    """Gộp Tài khoản + Ảnh nhân vật vào 1 tab."""
    top = row(box)
    top.grid(row=0, column=0, sticky="ew")
    top.columnconfigure(1, weight=1)
    _acc_tab(app, top)

    ctk.CTkFrame(box, height=1, fg_color=T.DIVIDER).grid(row=1, column=0, sticky="ew", pady=8)

    bot = row(box)
    bot.grid(row=2, column=0, sticky="ew")
    bot.columnconfigure(1, weight=1)
    _img_tab(app, bot)


def _cfg_prompt_tab(app, box):
    """Gộp Cấu hình + Prompt vào 1 tab."""
    top = row(box)
    top.grid(row=0, column=0, sticky="ew")
    top.columnconfigure(1, weight=1)
    _cfg_tab(app, top)

    ctk.CTkFrame(box, height=1, fg_color=T.DIVIDER).grid(row=1, column=0, sticky="ew", pady=8)

    bot = row(box)
    bot.grid(row=2, column=0, sticky="ew")
    bot.columnconfigure(1, weight=1)
    _prompt_tab(app, bot)


def _acc_tab(app, box):
    app.btn_acc_mgr = btn(box, "Quản lý tài khoản", app.open_account_manager)
    app.btn_acc_mgr.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(4, 2))

    app.lbl_acc_count = lbl(box, "đang đọc…", T.MUTED, F.label, anchor="w")
    app.lbl_acc_count.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 8))

    group(box, 2, "Loại tài khoản")
    app.cbo_account_type = opt(box, ["Ultra", "Pro"])
    app.cbo_account_type.set("Ultra")
    grid_field(box, 3, "Gói đang dùng", app.cbo_account_type)
    note(box, 4, "Ultra — chạy model bản _ultra.\nPro — model bản thường, vẫn đủ 5 model.")
    note(
        box,
        5,
        "Mỗi tài khoản cần đủ token, project_id và labs_session; thiếu labs_session thì tạo xong không tải video về được.",
    )


def _cfg_tab(app, box):
    app.cbo_model = opt(box, MODELS)
    app.cbo_model.set("Veo 3.1 - Lite [Lower Priority]")
    grid_field(box, 0, "Model", app.cbo_model)

    app.cbo_duration = opt(box, ["4s", "6s", "8s", "10s"])
    app.cbo_duration.set("8s")
    grid_field(box, 1, "Thời lượng", app.cbo_duration)
    note(box, 2, "Veo 3.1 (Lite/Fast) có ảnh nhân vật tạo được 8 giây. Omni 1.1 Flash chọn được 4/6/8/10 giây.")

    group(box, 3, "Giọng nói")
    app.cbo_voice = opt(box, VOICE_LIST)
    app.cbo_voice.set("(Không dùng voice)")
    grid_field(box, 4, "Giọng", app.cbo_voice)
    note(
        box,
        5,
        'Gắn chip giọng nói của Flow vào prompt. Prompt nên có lời thoại dạng  says: "…"  thì mới ăn giọng.',
    )

    app.chk_fixed_seed_var = ctk.BooleanVar(value=True)
    chk = ctk.CTkCheckBox(
        box,
        text="Khoá seed — giọng và phong cách đồng nhất giữa các prompt",
        variable=app.chk_fixed_seed_var,
        checkbox_height=16,
        checkbox_width=16,
        corner_radius=4,
        fg_color=T.ACCENT,
        hover_color=T.ACCENT_HOVER,
        border_color="#3a3d4d",
        text_color=T.TEXT_DIM,
        font=F.tiny,
    )
    chk.grid(row=6, column=0, columnspan=2, sticky="w", pady=(2, 6))

    group(box, 7, "Đầu ra")
    app.cbo_ratio = opt(box, ["16:9", "9:16"])
    app.cbo_ratio.set("16:9")
    grid_field(box, 8, "Khung hình", app.cbo_ratio)

    app.cbo_style = combo(box, flowkit_engine.DEFAULT_STYLE_PRESETS, state="normal")
    app.cbo_style.set(flowkit_engine.AUTO_STYLE_LABEL)
    grid_field(box, 9, "Phong cách", app.cbo_style)

    app.cbo_upscale = opt(box, ["1080p", "4K", "Không"])
    app.cbo_upscale.set("1080p")
    grid_field(box, 10, "Tự động nâng nét", app.cbo_upscale)

    app.cbo_extend = opt(box, ["Không", "1 lần (+8s)", "2 lần (+16s)", "3 lần (+24s)"])
    app.cbo_extend.set("Không")
    grid_field(box, 11, "Kéo dài", app.cbo_extend)

    app.entry_thread = entry(box)
    app.entry_thread.insert(0, "1")
    grid_field(box, 12, "Số luồng", app.entry_thread)
    note(
        box,
        13,
        "Nâng nét xong sẽ xoá bản gốc. Kéo dài là nối thêm video vào đuôi. Nhiều luồng nhanh hơn nhưng dễ bị Google chặn.",
    )


def _img_tab(app, box):
    f_row = row(box)
    f_row.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(2, 4))
    f_row.columnconfigure(0, weight=1)

    app.entry_img_folder = entry(f_row, placeholder_text="Thư mục ảnh (vd: characters)")
    app.entry_img_folder.insert(0, "characters")
    app.entry_img_folder.grid(row=0, column=0, sticky="ew", padx=(0, 6))
    sbtn(f_row, "Nạp", app.load_image_folder, width=54).grid(row=0, column=1)

    b_row = row(box)
    b_row.grid(row=1, column=0, columnspan=2, sticky="ew", pady=2)
    b_row.columnconfigure((0, 1, 2), weight=1)
    sbtn(b_row, "Thêm ảnh", app.add_images).grid(row=0, column=0, sticky="ew", padx=(0, 3))
    sbtn(b_row, "Tải lên hết", app.batch_upload_thread).grid(row=0, column=1, sticky="ew", padx=3)
    sbtn(b_row, "Xoá hết", app.clear_images).grid(row=0, column=2, sticky="ew", padx=(3, 0))

    c_row = row(box)
    c_row.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(4, 2))
    app.lbl_cache_hint = lbl(c_row, "Chưa nhớ ảnh nào", T.MUTED, F.tiny, anchor="w")
    app.lbl_cache_hint.pack(side="left")
    sbtn(c_row, "Nhập cache", app.import_cache_dialog, width=86).pack(side="right")

    app.img_scroll = ctk.CTkScrollableFrame(
        box,
        height=230,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.img_scroll.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(2, 4))
    note(
        box,
        4,
        "Đặt ID cho từng ảnh (vd nv1), rồi gọi ID đó trong prompt — tool sẽ tự gắn đúng ảnh nhân vật vào video.",
    )


def _prompt_tab(app, box):
    lbl(
        box,
        "Mỗi dòng là một prompt · viết  uid | prompt  để gắn ảnh",
        T.LABEL,
        F.label,
        anchor="w",
        justify="left",
        wraplength=280,
    ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(2, 2))

    app.txt_prompt = ctk.CTkTextbox(
        box,
        height=130,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER,
        border_width=1,
        text_color=T.TEXT,
        font=F.ui,
        wrap="word",
    )
    app.txt_prompt.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 4))
    app.txt_prompt.insert("1.0", "nv1 | A girl walks slowly in the rain\nnv1 | She smiles at the camera")

    p_bar = row(box)
    p_bar.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 6))
    p_bar.columnconfigure(0, weight=1)
    p_bar.columnconfigure(1, weight=1)
    sbtn(p_bar, "📥 Nạp vào danh sách", app._apply_manual_prompts).grid(row=0, column=0, sticky="ew", padx=(0, 3))
    sbtn(p_bar, "🧹 Xoá trắng", app.clear_prompts_only).grid(row=0, column=1, sticky="ew", padx=(3, 0))

    group(box, 3, "Nguồn khác")
    sbtn(box, "📂 Chọn file kịch bản (TXT / JSON)", app.choose_file).grid(row=4, column=0, columnspan=2, sticky="ew", pady=2)

    group(box, 5, "📂 Thư mục lưu video")
    out_row = row(box)
    out_row.grid(row=6, column=0, columnspan=2, sticky="ew")
    out_row.columnconfigure(0, weight=1)

    app.entry_out = entry(out_row, placeholder_text="Thư mục lưu video")
    app.entry_out.insert(0, "Video_Result")
    app.entry_out.grid(row=0, column=0, sticky="ew", padx=(0, 6))
    sbtn(out_row, "Chọn…", app.choose_output_folder, width=64).grid(row=0, column=1)


def _action_bar(app, col):
    bar = row(col)
    bar.grid(row=2, column=0, sticky="ew", padx=T.PAD, pady=(4, T.PAD))
    bar.columnconfigure(0, weight=1)
    bar.columnconfigure(1, weight=1)

    app.btn_start = btn_primary(bar, "Tạo video", app.start_process)
    app.btn_start.grid(row=0, column=0, sticky="ew", padx=(0, 4))

    app.btn_stop = btn_danger(bar, "Dừng tạo", app.stop_process)
    app.btn_stop.configure(state="disabled")
    app.btn_stop.grid(row=0, column=1, sticky="ew", padx=(4, 0))


def _build_right(app):
    right = row(app)
    app.main = right
    right.grid(row=0, column=1, sticky="nsew", padx=(T.GAP, T.PAD), pady=T.PAD)
    right.grid_rowconfigure(0, weight=3)
    right.grid_rowconfigure(1, weight=1)
    right.grid_columnconfigure(0, weight=1)

    top_card = card(right)
    top_card.grid(row=0, column=0, sticky="nsew", pady=(0, T.GAP))
    top_card.grid_rowconfigure(1, weight=1)
    top_card.grid_columnconfigure(0, weight=1)

    head = row(top_card)
    head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(T.PAD, 4))

    lbl(head, "🎭 HÀNG ĐỢI CẢNH QUAY ĐỒNG NHẤT NHÂN VẬT", T.TEXT_STRONG, F.ui_sb).pack(side="left", padx=(4, 14))

    sbtn(head, "‹", app.prev_page, width=30).pack(side="left")
    app.lbl_page = lbl(head, "Trang 1/1", T.TEXT_DIM, F.label)
    app.lbl_page.pack(side="left", padx=8)
    sbtn(head, "›", app.next_page, width=30).pack(side="left")

    def _open_out():
        d = app.entry_out.get().strip() or "Video_Result"
        os.makedirs(d, exist_ok=True)
        try:
            os.startfile(os.path.abspath(d))
        except Exception:
            pass

    sbtn(head, "📂 Mở thư mục", _open_out, width=96).pack(side="right", padx=(4, 0))
    sbtn(head, "🧹 Làm sạch cũ", lambda: app.clear_previous_session(ask_confirm=True), width=104).pack(side="right", padx=4)
    sbtn(head, "🔗 Nối thành phim dài", app.merge_video, width=130).pack(side="right", padx=4)
    sbtn(head, "🖼️ Kho ảnh nhớ", app.show_cache_viewer, width=92).pack(side="right", padx=4)

    app.task_frame = ctk.CTkScrollableFrame(
        top_card,
        fg_color="transparent",
        corner_radius=0,
        scrollbar_fg_color=T.CARD,
        scrollbar_button_color="#3a3d4d",
        scrollbar_button_hover_color=T.ACCENT,
    )
    app.task_frame.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

    _log_card(app, right)


def _log_card(app, right):
    lc = card(right)
    lc.grid(row=1, column=0, sticky="nsew")
    lc.grid_rowconfigure(1, weight=1)
    lc.grid_columnconfigure(0, weight=1)

    head = row(lc)
    head.grid(row=0, column=0, sticky="ew", padx=T.PAD, pady=(6, 2))
    lbl(head, "NHẬT KÝ", T.TEXT_STRONG, F.ui_sb).pack(side="left", padx=4)

    app.log_box = ctk.CTkTextbox(
        lc,
        height=110,
        corner_radius=T.RADIUS,
        fg_color=T.INPUT,
        border_color=T.BORDER_SOFT,
        border_width=1,
        text_color="#b6bbc8",
        font=F.mono_sm,
        wrap="word",
        state="disabled",
    )
    app.log_box.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))

    def clear_log():
        try:
            app.log_box.configure(state="normal")
            app.log_box.delete("1.0", "end")
            app.log_box.configure(state="disabled")
        except Exception:
            pass

    sbtn(head, "Xoá", clear_log, width=46).pack(side="right")


def build_image_card(cardw, image_path: str, image_id: str, delete_command, img=None):
    """Dựng nội dung một thẻ ảnh (ModernImageCard gọi vào đây)."""
    F.init()
    cardw.configure(
        fg_color=CARD_IDLE,
        corner_radius=T.RADIUS,
        border_color=T.BORDER_SOFT,
        border_width=1,
    )
    cardw.pack(fill="x", pady=3, padx=2)

    if img is not None:
        ctk.CTkLabel(cardw, image=img, text="").pack(side="left", padx=(7, 4), pady=6)
    else:
        lbl(cardw, "ảnh", T.MUTED, F.tiny, width=50).pack(side="left", padx=(7, 4), pady=6)

    center = row(cardw)
    center.pack(side="left", fill="x", expand=True, padx=3, pady=5)

    lbl(center, "ID dùng trong prompt", T.MUTED, F.tiny, anchor="w").pack(fill="x")
    entry_id = ctk.CTkEntry(
        center,
        height=T.H_CTRL,
        corner_radius=T.RADIUS,
        fg_color=T.CARD,
        border_color=T.BORDER,
        text_color=T.TEXT,
        font=F.ui_sb,
        placeholder_text="vd: nv1",
    )
    entry_id.insert(0, image_id)
    entry_id.pack(fill="x", pady=(2, 0))

    name = os.path.basename(image_path)
    if len(name) > 24:
        name = name[:24] + "…"
    lbl(center, name, T.TEXT_DIM, F.tiny, anchor="w").pack(fill="x")

    right = row(cardw)
    right.pack(side="right", padx=(4, 8), pady=6)

    lbl_status = lbl(right, "chưa lên", T.MUTED, F.tiny)
    lbl_status.pack(pady=(0, 4))

    btn_del = ctk.CTkButton(
        right,
        text="✕",
        width=26,
        height=24,
        corner_radius=T.RADIUS,
        fg_color=T.DANGER_BG,
        hover_color="#3a2029",
        border_color=T.DANGER_BORDER,
        border_width=1,
        text_color=T.DANGER_TEXT,
        font=F.tiny,
        command=lambda: delete_command(cardw),
    )
    btn_del.pack()
    return entry_id, lbl_status, btn_del


def card_idle(cardw, lbl_status):
    cardw.configure(fg_color=CARD_IDLE)
    lbl_status.configure(text="chưa lên", text_color=T.MUTED)


def card_done(cardw, lbl_status):
    cardw.configure(fg_color=CARD_DONE)
    lbl_status.configure(text="đã lên", text_color=T.OK)


def task_status_color(status_text: str) -> str:
    st = str(status_text or "")
    if any(k in st for k in ("Hoàn thành", "Đã có", "Xong", "Có video", "✅")):
        return T.OK
    if any(k in st for k in ("❌", "Lỗi", "🛑", "🚫")):
        return T.DANGER_TEXT
    if any(k in st for k in ("Waiting", "Chờ", "dừng", "⏹")):
        return T.MUTED
    return "#e0a458"


def build_task_row(row_frame, item: dict, f_edit, f_regen, f_del, f_view):
    """Dựng nội dung một dòng prompt (TaskRow gọi vào đây).
    Trả về dict các widget con để TaskRow giữ lại.
    """
    F.init()
    row_frame.configure(
        fg_color=T.INPUT,
        corner_radius=T.RADIUS,
        border_color=T.BORDER_SOFT,
        border_width=1,
    )

    rid = item.get("id", 0)
    lbl_idx = lbl(row_frame, f"{rid + 1:03d}", T.MUTED, F.mono_sm, width=34)
    lbl_idx.pack(side="left", padx=(10, 6), pady=7)

    p_text = item.get("text", "").replace("\n", " ")
    if len(p_text) > 66:
        p_text = p_text[:66] + "…"
    lbl_preview = lbl(row_frame, p_text, T.TEXT, F.ui, anchor="w")
    lbl_preview.pack(side="left", fill="x", expand=True, padx=4)

    bf = row(row_frame)
    bf.pack(side="right", padx=8)

    st = item.get("status", "Waiting...")
    lbl_status = lbl(row_frame, st, task_status_color(st), F.tiny, width=126, anchor="w")
    lbl_status.pack(side="right", padx=6)

    btn_edit = sbtn(bf, "Sửa", lambda: f_edit(rid), width=48)
    btn_edit.pack(side="left", padx=2)

    btn_regen = sbtn(bf, "Tạo lại", lambda: f_regen(rid), width=62)
    btn_regen.pack(side="left", padx=2)

    btn_del = sbtn(bf, "Xoá", lambda: f_del(rid), width=46)
    btn_del.pack(side="left", padx=2)

    fp = item.get("file_path")
    btn_view = sbtn(
        bf,
        "Xem",
        (lambda: f_view(fp)) if fp else None,
        width=52,
        state="normal" if fp else "disabled",
    )
    btn_view.pack(side="left", padx=2)

    return {
        "lbl_idx": lbl_idx,
        "lbl_preview": lbl_preview,
        "lbl_status": lbl_status,
        "btn_edit": btn_edit,
        "btn_regen": btn_regen,
        "btn_del": btn_del,
        "btn_view": btn_view,
    }
