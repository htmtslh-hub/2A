"""
Auto-Updater - UI dep voi CustomTkinter
"""
import os, sys, json, threading, time, tempfile, subprocess
import tkinter as tk

try:
    import customtkinter as ctk
    HAS_CTK = True
except ImportError:
    HAS_CTK = False
    from tkinter import messagebox

try:
    import requests
except ImportError:
    requests = None

CONFIG_FILE = "update_config.json"
LOCAL_VERSION_FILE = "version.json"
APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0] if not getattr(sys, 'frozen', False) else sys.executable))

# Log file cho update — hữu ích khi build .exe disable console
UPDATE_LOG_FILE = os.path.join(APP_DIR, "update_log.txt")

def _get_exe_name():
    """Tên file .exe của app (để chờ app đóng và mở lại).
    PyInstaller đặt sys.frozen; Nuitka KHÔNG đặt sys.frozen mà đặt __compiled__.
    Dùng argv[0] (đáng tin với Nuitka standalone)."""
    if getattr(sys, 'frozen', False) or ('__compiled__' in globals()):
        cand = sys.argv[0] or sys.executable
        if cand and cand.lower().endswith('.exe'):
            return os.path.basename(cand)
    # Chạy bằng python (dev) hoặc không xác định → tên mặc định của project
    return "AllToolYoutube.exe"

def _log(msg):
    """Ghi log ra cả stdout và file update_log.txt"""
    try:
        line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
        print(line)
        with open(UPDATE_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(line + "\n")
    except:
        pass

def _set_icon(win):
    """Set icon.ico cho window."""
    try:
        icon_path = os.path.join(APP_DIR, "icon.ico")
        if os.path.exists(icon_path):
            win.after(200, lambda: win.iconbitmap(icon_path))
    except: pass

# Colors - match app theme
C_BG = "#0d0d24"
C_CARD = "#12122e"
C_ACCENT = "#a855f7"
C_ACCENT2 = "#c084fc"
C_GREEN = "#00ff88"
C_RED = "#ff2266"
C_TEXT = "#e0e0ff"
C_MUTED = "#7878aa"
C_BORDER = "#2a1a4a"

def _load_config(config_file=None):
    cfg_path = os.path.join(APP_DIR, config_file or CONFIG_FILE)
    default = {"update_url": "", "enabled": True}
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                return {**default, **json.load(f)}
        except: pass
    return default

def get_local_version(version_file=None):
    vf = os.path.join(APP_DIR, version_file or LOCAL_VERSION_FILE)
    try:
        if os.path.exists(vf):
            with open(vf, 'r', encoding='utf-8') as f:
                return json.load(f).get('version', '0.0.0')
    except: pass
    return '0.0.0'

def compare_versions(local, remote):
    try:
        lp = [int(x) for x in str(local).split('.')]
        rp = [int(x) for x in str(remote).split('.')]
        while len(lp) < len(rp): lp.append(0)
        while len(rp) < len(lp): rp.append(0)
        return rp > lp
    except: return False

def fetch_remote_version(base_url):
    if not requests: return None
    try:
        url = base_url.rstrip('/') + '/version.json'
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            r.encoding = 'utf-8'  # Force UTF-8 cho tieng Viet
            return r.json()
    except: pass
    return None

def _download_with_progress(url, dest, progress_cb=None):
    if not requests:
        _log("ERROR: requests module not installed")
        return False
    try:
        _log(f"Start download: {url}")
        _log(f"Save to: {dest}")
        # timeout=(connect_timeout, read_timeout) — file to cần read_timeout dài (30 phút)
        r = requests.get(url, stream=True, timeout=(30, 1800))
        if r.status_code != 200:
            _log(f"ERROR: HTTP {r.status_code}")
            return False
        total = int(r.headers.get('content-length', 0))
        _log(f"Content-Length: {total} bytes ({total/1024/1024:.1f} MB)")
        downloaded = 0
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1048576):  # 1 MB chunks cho file to
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_cb and total > 0:
                        pct = downloaded * 100 / total
                        mb_d = downloaded / 1024 / 1024
                        mb_t = total / 1024 / 1024
                        progress_cb(pct, mb_d, mb_t)
        _log(f"Download complete: {downloaded} bytes")
        if total > 0 and downloaded != total:
            _log(f"WARNING: Downloaded {downloaded} but expected {total}")
        return True
    except Exception as e:
        _log(f"ERROR during download: {type(e).__name__}: {e}")
        return False

def _create_update_bat(zip_path, app_dir, exe_name):
    bat_path = os.path.join(tempfile.gettempdir(), "do_update.bat")
    bat_content = f'''@echo off
chcp 65001 >nul
color 0D
title Dang cap nhat...
echo.
echo  ================================================
echo     DANG CAP NHAT PHIEN BAN MOI
echo  ================================================
echo.
echo  Dang cho app dong lai...
timeout /t 3 /nobreak >nul

:wait_loop
tasklist /FI "IMAGENAME eq {exe_name}" 2>nul | find /I "{exe_name}" >nul
if not errorlevel 1 (
    timeout /t 2 /nobreak >nul
    goto wait_loop
)

echo  App da dong. Bat dau cap nhat...
echo.

if not exist "{app_dir}\\_backup" mkdir "{app_dir}\\_backup"
xcopy "{app_dir}\\*.exe" "{app_dir}\\_backup\\" /Y /Q 2>nul

echo  Dang giai nen ban moi...
powershell -Command "Expand-Archive -Path '{zip_path}' -DestinationPath '{app_dir}' -Force"

del /F /Q "{zip_path}" 2>nul

echo.
echo  ================================================
echo     CAP NHAT XONG - KHOI DONG LAI...
echo  ================================================

start "" /D "{app_dir}" "{os.path.join(app_dir, exe_name)}"
timeout /t 1 >nul
del "%~f0"
'''
    with open(bat_path, 'w', encoding='utf-8') as f:
        f.write(bat_content)
    return bat_path

# ═══════════════════════════════════════════════════════════
# UI - NICE DIALOGS
# ═══════════════════════════════════════════════════════════

def _show_update_dialog(parent, current, remote_ver, changelog, size_mb, on_yes, on_no):
    """Hien dialog dep hoi update."""
    if not HAS_CTK:
        # Fallback messagebox
        msg = f"Co ban cap nhat!\n\nHien tai: v{current}\nMoi: v{remote_ver}\n"
        if changelog: msg += f"\n{changelog}\n"
        msg += f"\nTai ve (~{size_mb} MB)?"
        if messagebox.askyesno("Update", msg, parent=parent):
            on_yes()
        else:
            on_no()
        return
    
    win = ctk.CTkToplevel(parent) if parent else ctk.CTk()
    win.title("🔄 Cập nhật")
    win.geometry("500x500")
    win.resizable(False, False)
    win.configure(fg_color=C_BG)
    try: win.attributes("-topmost", True)
    except: pass
    _set_icon(win)
    
    # Center
    win.update_idletasks()
    if parent:
        x = parent.winfo_x() + (parent.winfo_width() - 500) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 500) // 2
        win.geometry(f"+{x}+{y}")
    
    # Header
    header = ctk.CTkFrame(win, fg_color=C_CARD, corner_radius=0, height=70)
    header.pack(fill="x"); header.pack_propagate(False)
    ctk.CTkLabel(header, text="🆕  CÓ BẢN CẬP NHẬT MỚI",
                 font=("Segoe UI", 18, "bold"),
                 text_color=C_ACCENT2).pack(pady=20)
    
    # Body
    body = ctk.CTkFrame(win, fg_color=C_BG)
    body.pack(fill="both", expand=True, padx=24, pady=16)
    
    # Version box
    ver_frame = ctk.CTkFrame(body, fg_color=C_CARD, corner_radius=12, border_width=1, border_color=C_BORDER)
    ver_frame.pack(fill="x", pady=(0, 12))
    
    inner = ctk.CTkFrame(ver_frame, fg_color="transparent")
    inner.pack(padx=20, pady=14)
    
    # Current version
    row1 = ctk.CTkFrame(inner, fg_color="transparent")
    row1.pack(fill="x", pady=2)
    ctk.CTkLabel(row1, text="Hiện tại:", font=("Segoe UI", 12),
                 text_color=C_MUTED, width=80, anchor="w").pack(side="left")
    ctk.CTkLabel(row1, text=f"v{current}", font=("Consolas", 14, "bold"),
                 text_color=C_TEXT).pack(side="left")
    
    # Arrow
    ctk.CTkLabel(inner, text="↓", font=("Segoe UI", 16, "bold"),
                 text_color=C_ACCENT).pack(pady=2)
    
    # New version
    row2 = ctk.CTkFrame(inner, fg_color="transparent")
    row2.pack(fill="x", pady=2)
    ctk.CTkLabel(row2, text="Mới:", font=("Segoe UI", 12),
                 text_color=C_MUTED, width=80, anchor="w").pack(side="left")
    ctk.CTkLabel(row2, text=f"v{remote_ver}", font=("Consolas", 14, "bold"),
                 text_color=C_GREEN).pack(side="left")
    
    # Changelog
    if changelog:
        chg_frame = ctk.CTkFrame(body, fg_color=C_CARD, corner_radius=12, border_width=1, border_color=C_BORDER)
        chg_frame.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(chg_frame, text="📝 Thay đổi",
                     font=("Segoe UI", 11, "bold"),
                     text_color=C_ACCENT2).pack(anchor="w", padx=16, pady=(10, 4))
        ctk.CTkLabel(chg_frame, text=changelog[:200],
                     font=("Segoe UI", 11),
                     text_color=C_TEXT, wraplength=400, justify="left").pack(anchor="w", padx=16, pady=(0, 10))
    
    # Size
    size_lbl = ctk.CTkLabel(body, text=f"💾 Dung lượng tải: ~{size_mb} MB",
                 font=("Segoe UI", 11),
                 text_color=C_MUTED)
    size_lbl.pack(pady=(0, 14))
    
    # Buttons
    btn_frame = ctk.CTkFrame(body, fg_color="transparent")
    btn_frame.pack(fill="x")
    
    def _yes():
        try: win.destroy()
        except: pass
        on_yes()
    
    def _no():
        try: win.destroy()
        except: pass
        on_no()
    
    ctk.CTkButton(btn_frame, text="Để sau", width=120, height=38,
                  fg_color=C_CARD, hover_color=C_BORDER,
                  text_color=C_MUTED, border_width=1, border_color=C_BORDER,
                  font=("Segoe UI", 12), command=_no).pack(side="left", padx=(0, 8))
    
    ctk.CTkButton(btn_frame, text="⬇  CẬP NHẬT NGAY", height=38,
                  fg_color=C_ACCENT, hover_color=C_ACCENT2,
                  text_color="white", font=("Segoe UI", 12, "bold"),
                  command=_yes).pack(side="right", fill="x", expand=True)
    
    win.protocol("WM_DELETE_WINDOW", _no)

def _show_progress_dialog(parent):
    """Dialog progress dep khi dang tai."""
    if not HAS_CTK:
        win = tk.Toplevel(parent) if parent else tk.Tk()
        win.title("Cap nhat"); win.geometry("400x100")
        lbl = tk.Label(win, text="Chuan bi...", font=("Arial", 11))
        lbl.pack(pady=30)
        return win, lambda pct, md, mt: lbl.configure(text=f"{md:.1f}/{mt:.1f} MB ({pct:.0f}%)")
    
    win = ctk.CTkToplevel(parent) if parent else ctk.CTk()
    win.title("🔄 Đang cập nhật")
    win.geometry("480x220")
    win.resizable(False, False)
    win.configure(fg_color=C_BG)
    try: win.attributes("-topmost", True)
    except: pass
    _set_icon(win)
    
    if parent:
        win.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 480) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 220) // 2
        win.geometry(f"+{x}+{y}")
    
    # Header
    hdr = ctk.CTkFrame(win, fg_color=C_CARD, corner_radius=0, height=60)
    hdr.pack(fill="x"); hdr.pack_propagate(False)
    ctk.CTkLabel(hdr, text="⬇  ĐANG TẢI BẢN MỚI",
                 font=("Segoe UI", 16, "bold"),
                 text_color=C_ACCENT2).pack(pady=16)
    
    body = ctk.CTkFrame(win, fg_color=C_BG)
    body.pack(fill="both", expand=True, padx=30, pady=20)
    
    # Progress bar
    pbar = ctk.CTkProgressBar(body, height=14, progress_color=C_ACCENT,
                              fg_color=C_CARD, border_width=1, border_color=C_BORDER)
    pbar.pack(fill="x", pady=(10, 8))
    pbar.set(0)
    
    # Progress labels
    lbl_row = ctk.CTkFrame(body, fg_color="transparent")
    lbl_row.pack(fill="x")
    
    pct_lbl = ctk.CTkLabel(lbl_row, text="0%", font=("Consolas", 14, "bold"),
                           text_color=C_GREEN)
    pct_lbl.pack(side="left")
    
    size_lbl = ctk.CTkLabel(lbl_row, text="0 / 0 MB", font=("Consolas", 12),
                            text_color=C_MUTED)
    size_lbl.pack(side="right")
    
    # Status
    status_lbl = ctk.CTkLabel(body, text="⏳ Đang kết nối server...",
                              font=("Segoe UI", 11),
                              text_color=C_TEXT)
    status_lbl.pack(pady=(16, 0))
    
    def update_progress(pct, mb_d, mb_t):
        try:
            pbar.set(pct / 100)
            pct_lbl.configure(text=f"{pct:.0f}%")
            size_lbl.configure(text=f"{mb_d:.1f} / {mb_t:.1f} MB")
            if pct < 30: status_lbl.configure(text="⏳ Đang tải...")
            elif pct < 70: status_lbl.configure(text="⚡ Tốc độ cao...")
            elif pct < 95: status_lbl.configure(text="🎯 Gần xong...")
            else: status_lbl.configure(text="✅ Hoàn tất!")
            win.update()
        except: pass
    
    return win, update_progress

def _show_info_dialog(parent, title, message, icon="✅"):
    if not HAS_CTK:
        messagebox.showinfo(title, message, parent=parent)
        return
    
    win = ctk.CTkToplevel(parent) if parent else ctk.CTk()
    win.title(title); win.geometry("420x200"); win.resizable(False, False)
    win.configure(fg_color=C_BG)
    try: win.attributes("-topmost", True)
    except: pass
    _set_icon(win)
    
    if parent:
        win.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 420) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 200) // 2
        win.geometry(f"+{x}+{y}")
    
    ctk.CTkLabel(win, text=icon, font=("Segoe UI", 36)).pack(pady=(20, 8))
    ctk.CTkLabel(win, text=message, font=("Segoe UI", 12),
                 text_color=C_TEXT, wraplength=360, justify="center").pack(padx=20)
    ctk.CTkButton(win, text="OK", width=100, height=36,
                  fg_color=C_ACCENT, hover_color=C_ACCENT2,
                  command=win.destroy).pack(pady=20)
    win.wait_window()

# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def check_and_update(current_version=None, parent_window=None, silent=True, on_complete=None,
                     config_file=None, version_file=None):
    if not requests: return
    cfg = _load_config(config_file)
    if not cfg.get('enabled', True): return
    base_url = cfg.get('update_url', '').strip()
    if not base_url: return
    if current_version is None:
        current_version = get_local_version(version_file)
    
    def _worker():
        try:
            remote = fetch_remote_version(base_url)
            if not remote: return
            rv = remote.get('version', '0.0.0')
            if not compare_versions(current_version, rv): return
            
            changelog = remote.get('changelog', '')
            size_mb = remote.get('size_mb', '?')
            
            def _on_yes():
                _run_update(remote, base_url, parent_window, version_file)
            
            def _on_no():
                if on_complete: on_complete()
            
            def _show():
                _show_update_dialog(parent_window, current_version, rv, changelog, size_mb, _on_yes, _on_no)
            
            if parent_window:
                parent_window.after(100, _show)
            else:
                _show()
        except: pass
    threading.Thread(target=_worker, daemon=True).start()

def _run_update(remote_data, base_url, parent_window=None, version_file=None):
    win, update_progress = _show_progress_dialog(parent_window)
    
    def _do():
        try:
            download_url = remote_data.get('download_url', '')
            if not download_url:
                download_url = base_url.rstrip('/') + '/update.zip'
            
            zip_path = os.path.join(tempfile.gettempdir(), "app_update.zip")
            ok = _download_with_progress(download_url, zip_path, progress_cb=update_progress)
            if not ok:
                try: win.destroy()
                except: pass
                _show_info_dialog(parent_window, "Lỗi", "Tải file update thất bại!", icon="❌")
                return
            
            vf = os.path.join(APP_DIR, version_file or LOCAL_VERSION_FILE)
            try:
                with open(vf, 'w', encoding='utf-8') as f:
                    json.dump(remote_data, f, indent=2, ensure_ascii=False)
            except: pass
            
            exe_name = _get_exe_name()
            bat_path = _create_update_bat(zip_path, APP_DIR, exe_name)
            
            try: win.destroy()
            except: pass
            
            _show_info_dialog(parent_window,
                "Cập nhật",
                "App sẽ TẮT và tự cập nhật.\nSau khi xong sẽ tự mở lại.\n\nKHÔNG tắt cửa sổ CMD!",
                icon="🔄")
            
            subprocess.Popen(f'start "Updater" cmd /c "{bat_path}"', shell=True)
            time.sleep(1)
            os._exit(0)
        except Exception as e:
            try: win.destroy()
            except: pass
            _show_info_dialog(parent_window, "Lỗi", f"Update lỗi: {e}", icon="❌")
    
    threading.Thread(target=_do, daemon=True).start()


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--set-url"); p.add_argument("--check", action="store_true")
    p.add_argument("--version", "-v", action="store_true")
    p.add_argument("--config", default=None, help="Tên file config (vd: update_config_main.json)")
    p.add_argument("--version-file", default=None, help="Tên file version (vd: version_main.json)")
    args = p.parse_args()
    _cfg_name = args.config or CONFIG_FILE
    _ver_name = args.version_file or LOCAL_VERSION_FILE
    if args.set_url:
        cfg = _load_config(args.config); cfg['update_url'] = args.set_url
        with open(os.path.join(APP_DIR, _cfg_name), 'w', encoding='utf-8') as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
        print(f"[{_cfg_name}] URL: {args.set_url}")
    elif args.check:
        cfg = _load_config(args.config); url = cfg.get('update_url', '')
        print(f"Config: {_cfg_name}\nURL: {url}\nLocal: v{get_local_version(args.version_file)}")
        if url:
            r = fetch_remote_version(url)
            if r: print(f"Remote: v{r['version']}\nNew: {'YES' if compare_versions(get_local_version(args.version_file), r['version']) else 'NO'}")
    elif args.version: print(f"v{get_local_version(args.version_file)}")
    else: p.print_help()