"""
veo3_prompt_tool2.py — VEO3 PROMPT 2 (Tab #3 trong All-Tool-Youtube)
─────────────────────────────────────────────────────────────────────
Công cụ tạo kịch bản phân cảnh Veo 3 (8s/clip) + Character Sheet đồng nhất
hỗ trợ cả Gemini API (xoay vòng key từ gemini.txt) lẫn 9Router (OpenAI-compatible).
Xuất kết quả ra .txt hoặc .xlsx (2 sheet: Video Prompts + Anh Nhan Vat Mau).
"""

import os
import re
import json
import time
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
import requests

try:
    import google.generativeai as genai
except Exception:
    genai = None

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except Exception:
    openpyxl = None


_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
NINEROUTER_URL = "http://localhost:20128/v1"
ROUTER9_CONFIG_FILE = os.path.join(_BASE_DIR, "veo3_router9_config.json")
DEFAULT_GEMINI_FILE = os.path.join(_BASE_DIR, "gemini.txt")

STYLE_OPTIONS = [
    "⚡ Tự nhận diện từ Prompt",
    "3D Cocomelon (Thiếu nhi tươi sáng, nhân vật đầu to dễ thương)",
    "3D Pixar / Disney (Hoạt hình 3D điện ảnh, ánh sáng mềm mại, biểu cảm sống động)",
    "Anime Nhật Bản (Makoto Shinkai / Ghibli — bầu trời rực rỡ, chi tiết tinh tế)",
    "Điện ảnh thực tế (Cinematic Photorealistic — ARRI Alexa, 8K, shallow DOF)",
    "Hoạt hình 2D Cartoon (Màu sắc phẳng, đường viền rõ nét, vui nhộn)",
    "Claymation / Stop-Motion (Đất sét nặn thủ công, ánh sáng studio ấm áp)",
    "Cyberpunk / Sci-Fi Neon (Tương lai, đèn neon phản chiếu, khí quyển u tối)",
    "Cổ trang / Tiên hiệp 3D (Trang phục cổ đại bay bổng, kỹ xảo huyền ảo)",
    "Tài liệu thiên nhiên BBC / National Geographic (Ống kính tele, 4K sắc nét)",
]

GENRE_OPTIONS = [
    "Hoạt hình thiếu nhi / Giáo dục",
    "Phiêu lưu / Hành động",
    "Kể chuyện cảm động / Gia đình",
    "Hài hước / Giải trí ngắn",
    "Khoa học viễn tưởng / Tương lai",
    "Kinh dị / Bí ẩn",
    "Cổ tích / Thần thoại",
    "Quảng cáo sản phẩm / Thương mại",
    "Lịch sử / Tài liệu",
]

DIALOGUE_LANGUAGE_OPTIONS = [
    "Không có thoại (Chỉ âm thanh môi trường & nhạc nền)",
    "Tiếng Việt",
    "Tiếng Anh (English)",
    "Tiếng Nhật (Japanese)",
    "Tiếng Hàn (Korean)",
    "Tiếng Trung (Mandarin)",
    "Tiếng Tây Ban Nha (Spanish)",
]

VOICE_LANGUAGE_OPTIONS = [
    "Không có giọng thuyết minh (Voiceover)",
    "Tiếng Việt",
    "Tiếng Anh (English)",
    "Tiếng Nhật (Japanese)",
    "Tiếng Hàn (Korean)",
    "Tiếng Trung (Mandarin)",
]


class GeminiAPIManager:
    """Quản lý danh sách Gemini API keys trong gemini.txt, gọi REST API trực tiếp và tự động xoay vòng."""

    REST_MODELS = ("gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash")

    def __init__(self, key_file: str = DEFAULT_GEMINI_FILE, model_name: str = "models/gemini-2.5-flash", preferred_provider: str = None, **kwargs):
        if "filepath" in kwargs and kwargs["filepath"]:
            key_file = kwargs["filepath"]
        if key_file == "gemini.txt" or not os.path.isabs(key_file):
             candidate = os.path.join(_BASE_DIR, key_file)
             self.key_file = candidate if os.path.exists(candidate) else key_file
        else:
            self.key_file = key_file
        self.model_name = model_name
        self.preferred_provider = preferred_provider
        self.keys = []
        self.index = 0
        self.model = None
        self._load_keys()
        if self.keys:
            self._configure_current()

    def _load_keys(self):
        self.keys = []
        for path_try in (self.key_file, DEFAULT_GEMINI_FILE, "gemini.txt"):
            if path_try and os.path.exists(path_try):
                try:
                    with open(path_try, "r", encoding="utf-8") as f:
                        for line in f:
                            k = line.strip()
                            if k and not k.startswith("#") and k not in self.keys:
                                self.keys.append(k)
                except Exception as e:
                    print(f"[Gemini API] Lỗi đọc file key {path_try}: {e}")
                if self.keys:
                    break

    def _configure_current(self):
        if not self.keys:
            return
        current_key = self.keys[self.index % len(self.keys)]
        if genai is not None:
            try:
                genai.configure(api_key=current_key)
                self.model = genai.GenerativeModel(self.model_name)
            except Exception:
                self.model = None

    @staticmethod
    def _should_rotate(err: Exception) -> bool:
        msg = str(err).lower()
        keywords = (
            "quota", "rate", "429", "resource_exhausted", "permission_denied",
            "api_key_invalid", "invalid api key", "403", "401", "exceeded", "limit", "404"
        )
        return any(k in msg for k in keywords)

    def _rotate(self):
        if len(self.keys) <= 1:
            return
        self.index = (self.index + 1) % len(self.keys)
        self._configure_current()

    def _call_rest_api(self, api_key: str, prompt: str) -> str:
        primary = self.model_name.replace("models/", "").strip()
        candidates = []
        for m in (primary, *self.REST_MODELS):
            if m and m not in candidates and "3.1" not in m:
                candidates.append(m)
        if not candidates:
            candidates = list(self.REST_MODELS)

        last_err = None
        for m in candidates:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={api_key}"
            payload = {
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"temperature": 0.7},
            }
            try:
                r = requests.post(url, json=payload, timeout=120)
                if r.status_code == 200:
                    data = r.json()
                    cands = data.get("candidates") or []
                    if cands:
                        parts = (cands[0].get("content") or {}).get("parts") or []
                        txt = "".join(p.get("text", "") for p in parts).strip()
                        if txt:
                            return txt
                last_err = RuntimeError(f"HTTP {r.status_code}: {r.text[:240]}")
                if r.status_code in (400, 401, 403, 429):
                    if r.status_code in (401, 403, 429):
                        break
            except Exception as e:
                last_err = e
        raise last_err or RuntimeError("Không gọi được Gemini REST API.")

    def generate(self, prompt: str) -> str:
        if "__offline_mode__" in str(self.key_file):
            return _local_storyboard_fallback(prompt)

        try:
            import multi_llm_bridge as _mlb

            ok_m, txt_m, _ = _mlb.generate_text(prompt, preferred_provider=self.preferred_provider)
            if ok_m and txt_m.strip():
                return txt_m.strip()
        except Exception:
            pass

        if not self.keys:
            self._load_keys()
        if not self.keys:
            return _local_storyboard_fallback(prompt)

        attempts = max(1, len(self.keys))
        last_err = None
        for _ in range(attempts):
            current_key = self.keys[self.index % len(self.keys)]
            try:
                if self.model is not None:
                    resp = self.model.generate_content(prompt)
                    text = getattr(resp, "text", "") or ""
                    if text.strip():
                        return text
                return self._call_rest_api(current_key, prompt)
            except Exception as e:
                last_err = e
                if self._should_rotate(e) and len(self.keys) > 1:
                    self._rotate()
                    time.sleep(0.4)
                else:
                    break
        # Nếu toàn bộ key lỗi hoặc hết hạn mức, tự động dùng bộ sinh kịch bản nội bộ để không gián đoạn
        print(f"[Gemini API Fallback] Dùng trình biên kịch nội bộ do API lỗi: {last_err}")
        return _local_storyboard_fallback(prompt)


def _local_storyboard_fallback(master_prompt: str) -> str:
    """Bộ sinh kịch bản & phân cảnh chuẩn FlowKit 3-Beat 8s (0-3s / 3-6s / 6-8s) nội bộ."""
    import flowkit_engine

    idea_m = re.search(r"-\s*Ý tưởng cốt truyện:\s*(.+)", master_prompt)
    style_m = re.search(r"-\s*Phong cách hình ảnh \(Visual Style\):\s*(.+)", master_prompt)
    num_m = re.search(r"gồm đúng\s+(\d+)\s+cảnh", master_prompt)
    idea = (idea_m.group(1).strip() if idea_m else "A heroic adventure across a glowing world")
    style = (style_m.group(1).strip() if style_m else "3D Pixar / Disney")
    num_prompts = int(num_m.group(1)) if num_m else 5

    char_bible = (
        "25-year-old charismatic protagonist with expressive eyes, neat dark hair, wearing a detailed "
        "adventure jacket with glowing cyan trim, utility belt, and dark trousers"
    )
    lighting_moods = [
        "warm golden hour sunlight with volumetric rays and soft atmospheric particles",
        "dramatic cinematic rim lighting with rich teal and amber color grading",
        "soft studio-grade diffused illumination highlighting fine surface textures",
        "vibrant bioluminescent ambient glow reflecting softly on the character",
    ]
    out_lines = [
        "PHẦN 1 — HỒ SƠ NHÂN VẬT & BỐI CẢNH (BIOMETRIC VISUAL ANCHOR SHEET):",
        "- TÊN NHÂN VẬT: Nhân Vật Chính (Protagonist)",
        "  + Mã nhận diện: CHAR_01",
        f"  + Chủng loài/Giới tính/Độ tuổi: {char_bible}",
        "  + Khuôn mặt & Kiểu tóc: Expressive warm eyes, well-defined features, neat stylized hair",
        "  + Trang phục cố định (STATE_01): Detailed adventure jacket with cyan accents, dark pants, sturdy boots",
        f"- BỐI CẢNH CHÍNH (SETTING): Cinematic environment inspired by '{idea}', rich depth of field, 8K clarity.",
        "",
        f"PHẦN 2 — DANH SÁCH {num_prompts} VIDEO PROMPTS (CHUẨN FLOWKIT 3-BEAT 0-3s / 3-6s / 6-8s):",
    ]
    for i in range(1, num_prompts + 1):
        light = lighting_moods[(i - 1) % len(lighting_moods)]
        out_lines.append(
            flowkit_engine.format_flowkit_3beat_prompt(
                scene_idx=i,
                core_action=f"Scene {i} of {num_prompts} — {idea}",
                style=style,
                char_ref=f"CHAR_01: {char_bible}",
                lighting=light,
                audio_cue="rich ambient soundscape, crisp foley, cinematic orchestral score",
            )
        )
    return "\n".join(out_lines)


class Router9Manager:
    """Gọi LLM qua 9Router (OpenAI-compatible endpoint tại localhost:20128/v1)."""

    def __init__(self, api_key: str, model_id: str = "ag/gemini-3.8-flash-high", base_url: str = NINEROUTER_URL):
        self.api_key = (api_key or "").strip()
        self.model_id = (model_id or "ag/gemini-3.8-flash-high").strip()
        self.base_url = (base_url or NINEROUTER_URL).rstrip("/")

    def generate(self, prompt: str) -> str:
        url = f"{self.base_url}/chat/completions"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = {
            "model": self.model_id,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
        }
        resp = requests.post(url, headers=headers, json=payload, timeout=180)
        if resp.status_code != 200:
            raise RuntimeError(f"9Router lỗi ({resp.status_code}): {resp.text[:300]}")
        data = resp.json()
        choices = data.get("choices") or []
        if not choices:
            raise RuntimeError(f"9Router không trả về choices: {data}")
        msg = choices[0].get("message") or {}
        return msg.get("content", "")


def create_gemini_prompt(
    idea: str,
    style: str,
    num_prompts: int,
    genre: str,
    Character_Appearance: str = "",
    dialogue_lang: str = "Không có thoại (Chỉ âm thanh môi trường & nhạc nền)",
    voice_lang: str = "Không có giọng thuyết minh (Voiceover)",
) -> str:
    """Tạo master prompt yêu cầu AI sinh Hồ sơ nhân vật + Bối cảnh + chuỗi Video Prompts 8s chuẩn Veo 3."""
    char_hint = (
        f"Thông tin ngoại hình nhân vật cố định do người dùng cung cấp:\n{Character_Appearance}\n"
        if Character_Appearance.strip()
        else "Hãy tự thiết kế hồ sơ ngoại hình nhân vật chi tiết, nhất quán xuyên suốt các cảnh."
    )
    return f"""Bạn là Đạo diễn Điện ảnh AI & Chuyên gia Prompt Veo 3 hàng đầu.
Hãy chuyển hóa ý tưởng sau thành bộ kịch bản phân cảnh gồm đúng {num_prompts} cảnh (mỗi cảnh 8 giây):

- Ý tưởng cốt truyện: {idea}
- Thể loại: {genre}
- Phong cách hình ảnh (Visual Style): {style}
- Ngôn ngữ hội thoại nhân vật (Dialogue): {dialogue_lang}
- Ngôn ngữ thuyết minh (Voiceover): {voice_lang}
- {char_hint}

YÊU CẦU ĐỊNH DẠNG ĐẦU RA BẮT BUỘC (TUÂN THỦ CHÍNH XÁC):

PHẦN 1 — HỒ SƠ NHÂN VẬT & BỐI CẢNH:
Phân tích kỹ cốt truyện để xác định TẤT CẢ các nhân vật quan trọng xuất hiện (CHAR_01, CHAR_02, CHAR_03...). Với mỗi nhân vật duy nhất, viết theo đúng mẫu:
- TÊN NHÂN VẬT: [Tên nhân vật]
  + Mã nhận diện: [CHAR_01, CHAR_02, CHAR_03... — mỗi nhân vật 1 mã riêng biệt, tuyệt đối không trùng mã]
  + Chủng loài/Giới tính/Độ tuổi: [Mô tả chi tiết bằng tiếng Anh. LƯU Ý AN TOÀN: Không dùng số tuổi trẻ em như '7-year-old girl' hay 'little child' dễ bị bộ lọc Google chặn; hãy dùng 'petite youthful storybook heroine' hoặc 'stylized young adventurer']
  + Khuôn mặt & Kiểu tóc: [Mô tả chi tiết bằng tiếng Anh]
  + Trang phục cố định: [Mô tả chi tiết bằng tiếng Anh]
  + Đặc điểm nhận dạng nổi bật: [Mô tả chi tiết bằng tiếng Anh]

- BỐI CẢNH CHÍNH (SETTING): [Mô tả chi tiết không gian, ánh sáng, màu sắc bằng tiếng Anh]

PHẦN 2 — DANH SÁCH {num_prompts} SCENE PROMPTS (TIẾNG ANH 100%, ĐỒNG NHẤT CHO CẢ TẠO ẢNH KEYFRAME & TẠO VIDEO 8 GIÂY):
Mỗi cảnh viết trên MỘT DÒNG DUY NHẤT theo cấu trúc 1 cú máy liền mạch (One-Shot Continuous Scene — tuyệt đối không cắt cảnh jump-cut hoặc chia khung trong cùng 1 cảnh), gắn đúng mã `(CHAR_XX: mô tả ngoại hình ngắn gọn)` của nhân vật thực sự xuất hiện trong cảnh đó:
Prompt 1: [{style}] (CHAR_01: mô tả ngoại hình khóa đồng nhất) 0-3s: [Góc máy + Khung hình tổng thể chứa các nhân vật của cảnh trong 1 khung hình duy nhất + Hành động mở đầu]. 3-6s: [Diễn biến chuyển động mượt mà ngay trong cùng khung hình đó]. 6-8s: [Biểu cảm & tư thế kết thúc cảnh]. Lighting: [Ánh sáng & màu sắc]. Audio: [Âm thanh môi trường, foley, lời thoại ({dialogue_lang})]. Negative: subtitles, captions, watermark, text overlay, split screen, 4-panel grid, extra limbs.
Prompt 2: ...
...
Prompt {num_prompts}: ...

QUY TẮC SỐNG CÒN:
1. Mỗi dòng `Prompt X:` phải là 1 cú máy đơn liền mạch trên 1 dòng (không xuống dòng bên trong Prompt X), trong đó phần `0-3s:` mô tả trọn vẹn bố cục khung hình chính (Keyframe) để dùng trực tiếp cho Tạo Ảnh Đồng Nhất (1 khung hình duy nhất, không vẽ 4 khung truyện tranh), còn toàn bộ `0-3s / 3-6s / 6-8s` diễn tả chuyển động mượt cho Tạo Video 8 giây. Cảnh nào có nhân vật nào (`CHAR_01`, `CHAR_02`, `CHAR_03`...) thì ghi đúng `(CHAR_XX: ...)` của nhân vật đó.
2. Xuất đủ từ Prompt 1 đến Prompt {num_prompts}."""


def parse_character_info(character_info_text: str) -> list:
    """Trích xuất danh sách nhân vật từ khối HỒ SƠ NHÂN VẬT do AI trả về."""
    characters = []
    if not character_info_text:
        return characters

    blocks = re.split(r"(?=-\s*TÊN NHÂN VẬT\s*:|Character\s*\d+\s*:)", character_info_text, flags=re.IGNORECASE)
    idx = 1
    for blk in blocks:
        blk = blk.strip()
        if not blk:
            continue
        name_match = re.search(r"(?:TÊN NHÂN VẬT|Character(?:\s*Name)?)\s*:\s*([^\n\r]+)", blk, flags=re.IGNORECASE)
        if not name_match:
            continue
        name = name_match.group(1).strip(" -*[]")
        code_match = re.search(r"(?:Mã nhận diện|ID|Code)\s*:\s*([A-Za-z0-9_]+)", blk, flags=re.IGNORECASE)
        code = code_match.group(1).strip() if code_match else f"CHAR_{idx:02d}"
        desc_lines = []
        for line in blk.splitlines()[1:]:
            clean = line.strip().lstrip("+-*• ")
            if clean:
                desc_lines.append(clean)
        appearance = "; ".join(desc_lines) if desc_lines else blk
        characters.append({
            "id": code,
            "name": name,
            "appearance": appearance,
        })
        idx += 1
    return characters


def create_character_sheet_prompt(character: dict, style: str) -> str:
    """Tạo prompt ảnh tham chiếu nhân vật chuẩn 1 nhân vật toàn thân duy nhất (không chia 4 góc)."""
    name = character.get("name", "Character")
    app = character.get("appearance", "")
    return (
        f"Single full-body standing character reference portrait of {name}, {style}, clear 3/4 front-facing view "
        f"showing exact facial features, hairstyle, and complete outfit from head to toe: {app}. "
        f"Clean neutral studio background, ONE single character only, single unified frame, "
        f"no split screen, no multiple angles, no turnaround grid, ultra-detailed, 8k resolution, no text, no watermark."
    )


def generate_prompts_from_gemini(
    idea: str,
    style: str,
    num_prompts: int,
    genre: str,
    Character_Appearance: str,
    dialogue_lang: str,
    voice_lang: str,
    q: queue.Queue,
    llm_manager=None,
):
    """Hàm worker chạy trên luồng phụ để sinh kịch bản + tách Video Prompts + tạo Character Sheet prompts."""
    try:
        q.put(("status", "Đang khởi tạo kết nối AI..."))
        if llm_manager is None:
            llm_manager = GeminiAPIManager()

        master_prompt = create_gemini_prompt(
            idea=idea,
            style=style,
            num_prompts=num_prompts,
            genre=genre,
            Character_Appearance=Character_Appearance,
            dialogue_lang=dialogue_lang,
            voice_lang=voice_lang,
        )
        q.put(("status", f"Đang yêu cầu AI sinh {num_prompts} phân cảnh Veo 3..."))
        raw_response = llm_manager.generate(master_prompt)

        # Tách phần Hồ sơ nhân vật và phần danh sách Prompt
        prompt_lines = []
        info_lines = []
        in_prompts = False
        prompt_head_re = re.compile(
            r"^(?:[\-\*•#]+\s*)?(?:\d+[\.\)]\s*)?(?:\*\*)?(?:Prompt|Scene|Cảnh)\s*(\d+)\s*(?:\*\*)?\s*[:\-–]\s*(?:\*\*)?\s*(.*)$",
            flags=re.IGNORECASE,
        )

        for line in raw_response.splitlines():
            stripped = line.strip()
            m_head = prompt_head_re.match(stripped)
            if m_head:
                in_prompts = True
                p_idx = m_head.group(1)
                p_body = re.sub(r"^\*\*|\*\*$", "", m_head.group(2)).strip()
                prompt_lines.append(f"Prompt {p_idx}: {p_body}")
            elif not in_prompts:
                info_lines.append(line)
            else:
                if stripped and prompt_lines and not stripped.startswith(("PHẦN", "---", "===")):
                    prompt_lines[-1] += " " + stripped

        char_info_text = "\n".join(info_lines).strip()
        characters = parse_character_info(char_info_text)
        char_sheets = []
        for ch in characters:
            sheet_p = create_character_sheet_prompt(ch, style)
            char_sheets.append({
                "id": ch["id"],
                "name": ch["name"],
                "appearance": ch["appearance"],
                "image_prompt": sheet_p,
            })

        result_payload = {
            "raw_response": raw_response,
            "character_info": char_info_text or raw_response,
            "prompts": prompt_lines if prompt_lines else [raw_response],
            "character_sheets": char_sheets,
            "style": style,
            "genre": genre,
        }
        q.put(("done", result_payload))
    except Exception as e:
        q.put(("error", str(e)))


def _write_xlsx_native(file_path: str, sheet1_rows: list, sheet2_rows: list):
    """Xuất file Excel .xlsx 2 sheet chuẩn OpenXML thuần Python (không cần cài openpyxl)."""
    import zipfile
    from xml.sax.saxutils import escape

    def _sheet_xml(rows: list) -> str:
        lines = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>',
        ]
        for r_idx, row_vals in enumerate(rows, start=1):
            lines.append(f'<row r="{r_idx}">')
            for c_idx, val in enumerate(row_vals):
                col_letter = chr(65 + c_idx)
                cell_ref = f"{col_letter}{r_idx}"
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    lines.append(f'<c r="{cell_ref}"><v>{val}</v></c>')
                else:
                    s = escape(str(val if val is not None else ""))
                    lines.append(f'<c r="{cell_ref}" t="inlineStr"><is><t>{s}</t></is></c>')
            lines.append("</row>")
        lines.append("</sheetData></worksheet>")
        return "".join(lines)

    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '</Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>'
    )
    wb_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets>'
        '<sheet name="Video Prompts" sheetId="1" r:id="rId1"/>'
        '<sheet name="Anh Nhan Vat Mau" sheetId="2" r:id="rId2"/>'
        '</sheets></workbook>'
    )
    wb_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>'
        '</Relationships>'
    )
    with zipfile.ZipFile(file_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("xl/workbook.xml", wb_xml)
        zf.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        zf.writestr("xl/worksheets/sheet1.xml", _sheet_xml(sheet1_rows))
        zf.writestr("xl/worksheets/sheet2.xml", _sheet_xml(sheet2_rows))


class Veo3PromptToolFrame(ctk.CTkFrame):
    """Giao diện chính của công cụ Biên Kịch & Phân Cảnh AI."""

    def __init__(self, master, openai_client=None, gemini_model=None, pipeline=None, **kwargs):
        super().__init__(master, fg_color="#0f1419", **kwargs)
        self.openai_client = openai_client
        self.gemini_model = gemini_model
        self.pipeline = pipeline
        self.q = queue.Queue()
        self.last_result = None

        self.grid_columnconfigure(0, weight=0, minsize=395)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # === CỘT TRÁI: CẤU HÌNH ===
        self.left_frame = ctk.CTkScrollableFrame(
            self, width=385, corner_radius=10, fg_color="#17202a", border_width=1, border_color="#263445"
        )
        self.left_frame.grid(row=0, column=0, sticky="nsew", padx=(10, 6), pady=10)
        self.left_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self.left_frame,
            text="📝 THIẾT LẬP KỊCH BẢN & PHONG CÁCH",
            text_color="#7ce8ff",
            font=ctk.CTkFont(size=14, weight="bold"),
        ).grid(row=0, column=0, sticky="w", padx=10, pady=(8, 6))

        # Nguồn AI
        ctk.CTkLabel(self.left_frame, text="Bộ não AI biên kịch:", anchor="w").grid(row=1, column=0, sticky="w", padx=10)
        self.source_var = ctk.StringVar(value="API Đa Hãng (Theo cài đặt chung)")
        self.cbo_source = ctk.CTkOptionMenu(
            self.left_frame,
            variable=self.source_var,
            values=[
                "API Đa Hãng (Theo cài đặt chung)",
                "✨ Google Gemini",
                "🟢 OpenAI (ChatGPT)",
                "🟠 Anthropic (Claude)",
                "🐋 DeepSeek (V3 / R1)",
                "⚡ Groq (Llama / Qwen)",
                "✖️ xAI (Grok)",
                "🌐 OpenRouter",
                "9Router (Localhost)",
                "Biên Kịch Nhanh Nội Bộ (Không cần Key)",
            ],
            fg_color="#10171f",
            button_color="#00b4d8",
            command=self._on_source_change,
        )
        self.cbo_source.grid(row=2, column=0, sticky="ew", padx=10, pady=(2, 6))

        # Khung cấu hình 9Router
        self.router9_frame = ctk.CTkFrame(self.left_frame, fg_color="#10171f", corner_radius=8)
        self.router9_frame.grid(row=3, column=0, sticky="ew", padx=10, pady=4)
        self.router9_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(self.router9_frame, text="Khóa 9Router:", anchor="w").grid(row=0, column=0, sticky="w", padx=8, pady=(6, 0))
        self.entry_r9_key = ctk.CTkEntry(self.router9_frame, placeholder_text="sk-...")
        self.entry_r9_key.grid(row=1, column=0, sticky="ew", padx=8, pady=2)

        ctk.CTkLabel(self.router9_frame, text="Mô hình 9Router:", anchor="w").grid(row=2, column=0, sticky="w", padx=8, pady=(4, 0))
        self.cbo_r9_model = ctk.CTkComboBox(
            self.router9_frame,
            values=["ag/gemini-3.8-flash-high", "ag/gemini-2.5-pro", "ag/claude-3-7-sonnet"],
        )
        self.cbo_r9_model.grid(row=3, column=0, sticky="ew", padx=8, pady=2)

        self.btn_load_r9 = ctk.CTkButton(
            self.router9_frame, text="🔄 Nạp danh sách mô hình", height=28, command=self._load_router9_models
        )
        self.btn_load_r9.grid(row=4, column=0, sticky="ew", padx=8, pady=(4, 8))

        # Ý tưởng câu chuyện + nút mẫu
        idea_head = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        idea_head.grid(row=4, column=0, sticky="ew", padx=10, pady=(6, 0))
        idea_head.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(idea_head, text="1. Nhập ý tưởng câu chuyện / chủ đề video:", anchor="w", font=ctk.CTkFont(size=12, weight="bold")).grid(
            row=0, column=0, sticky="w"
        )
        ctk.CTkButton(
            idea_head,
            text="🧹 Làm sạch",
            width=82,
            height=24,
            fg_color="#1c2633",
            hover_color="#3a2029",
            font=ctk.CTkFont(size=11),
            command=lambda: self.clear_previous_session(ask_confirm=False),
        ).grid(row=0, column=1, sticky="e", padx=(0, 4))
        ctk.CTkButton(
            idea_head,
            text="💡 Nạp mẫu thử",
            width=96,
            height=24,
            fg_color="#1c2633",
            hover_color="#263344",
            font=ctk.CTkFont(size=11),
            command=self._fill_sample_idea,
        ).grid(row=0, column=2, sticky="e")

        self.txt_idea = ctk.CTkTextbox(self.left_frame, height=96, wrap="word", fg_color="#10171f", border_width=1, border_color="#263445")
        self.txt_idea.grid(row=5, column=0, sticky="ew", padx=10, pady=4)

        # Ngoại hình nhân vật cố định (tuỳ chọn)
        ctk.CTkLabel(self.left_frame, text="2. Mô tả nhân vật chính (Để trống AI tự thiết kế):", anchor="w").grid(
            row=6, column=0, sticky="w", padx=10, pady=(4, 0)
        )
        self.txt_char = ctk.CTkTextbox(self.left_frame, height=62, wrap="word", fg_color="#10171f", border_width=1, border_color="#263445")
        self.txt_char.grid(row=7, column=0, sticky="ew", padx=10, pady=4)

        # Phong cách & Thể loại
        ctk.CTkLabel(
            self.left_frame,
            text="3. Phong cách (Tự nhận diện / Chọn hoặc gõ từ bàn phím):",
            anchor="w",
        ).grid(row=8, column=0, sticky="w", padx=10)
        self.cbo_style = ctk.CTkComboBox(self.left_frame, values=STYLE_OPTIONS)
        self.cbo_style.set(STYLE_OPTIONS[0])
        self.cbo_style.grid(row=9, column=0, sticky="ew", padx=10, pady=4)

        ctk.CTkLabel(self.left_frame, text="4. Thể loại nội dung:", anchor="w").grid(row=10, column=0, sticky="w", padx=10)
        self.cbo_genre = ctk.CTkComboBox(self.left_frame, values=GENRE_OPTIONS)
        self.cbo_genre.set(GENRE_OPTIONS[0])
        self.cbo_genre.grid(row=11, column=0, sticky="ew", padx=10, pady=4)

        # Ngôn ngữ hội thoại & thuyết minh
        ctk.CTkLabel(self.left_frame, text="5. Ngôn ngữ lời thoại nhân vật:", anchor="w").grid(row=12, column=0, sticky="w", padx=10)
        self.cbo_dialogue_lang = ctk.CTkOptionMenu(self.left_frame, values=DIALOGUE_LANGUAGE_OPTIONS, fg_color="#10171f", button_color="#1c2633")
        self.cbo_dialogue_lang.set(DIALOGUE_LANGUAGE_OPTIONS[0])
        self.cbo_dialogue_lang.grid(row=13, column=0, sticky="ew", padx=10, pady=4)

        ctk.CTkLabel(self.left_frame, text="6. Ngôn ngữ thuyết minh (Voiceover):", anchor="w").grid(row=14, column=0, sticky="w", padx=10)
        self.cbo_voice_lang = ctk.CTkOptionMenu(self.left_frame, values=VOICE_LANGUAGE_OPTIONS, fg_color="#10171f", button_color="#1c2633")
        self.cbo_voice_lang.set(VOICE_LANGUAGE_OPTIONS[0])
        self.cbo_voice_lang.grid(row=15, column=0, sticky="ew", padx=10, pady=4)

        # Số lượng phân cảnh (Slider + Entry)
        num_row = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        num_row.grid(row=16, column=0, sticky="ew", padx=10, pady=(6, 2))
        num_row.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(num_row, text="7. Số lượng cảnh quay (8 giây/cảnh):", anchor="w", font=ctk.CTkFont(size=12, weight="bold")).grid(row=0, column=0, sticky="w")
        self.entry_num = ctk.CTkEntry(num_row, width=60)
        self.entry_num.insert(0, "5")
        self.entry_num.grid(row=0, column=1, sticky="e")
        self.entry_num.bind("<Return>", self.update_num_slider_from_entry)
        self.entry_num.bind("<FocusOut>", self.update_num_slider_from_entry)

        self.slider_num = ctk.CTkSlider(
            self.left_frame, from_=1, to=100, number_of_steps=99, command=self.update_num_entry_from_slider, progress_color="#00b4d8"
        )
        self.slider_num.set(5)
        self.slider_num.grid(row=17, column=0, sticky="ew", padx=10, pady=(0, 8))

        # Nút Tạo & Lưu
        self.btn_generate = ctk.CTkButton(
            self.left_frame,
            text="✨ VIẾT KỊCH BẢN & TẠO CÂU LỆNH CẢNH QUAY",
            height=40,
            fg_color="#00b4d8",
            hover_color="#22c5e8",
            text_color="#ffffff",
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self.start_generation,
        )
        self.btn_generate.grid(row=18, column=0, sticky="ew", padx=10, pady=(6, 4))

        self.btn_save = ctk.CTkButton(
            self.left_frame,
            text="💾 Xuất Kịch Bản Ra File Excel (.xlsx) / Văn Bản (.txt)",
            height=34,
            fg_color="#1c2633",
            hover_color="#263344",
            border_width=1,
            border_color="#2e3e52",
            command=self.save_to_file,
        )
        self.btn_save.grid(row=19, column=0, sticky="ew", padx=10, pady=4)

        self.lbl_status = ctk.CTkLabel(self.left_frame, text="● Sẵn sàng biên kịch", text_color="#34d399", anchor="w")
        self.lbl_status.grid(row=20, column=0, sticky="ew", padx=10, pady=(4, 8))

        # === CỘT PHẢI: KẾT QUẢ ===
        self.right_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#17202a", border_width=1, border_color="#263445")
        self.right_frame.grid(row=0, column=1, sticky="nsew", padx=(4, 10), pady=10)
        self.right_frame.grid_columnconfigure(0, weight=1)
        self.right_frame.grid_rowconfigure(1, weight=2)
        self.right_frame.grid_rowconfigure(3, weight=3)

        info_bar = ctk.CTkFrame(self.right_frame, fg_color="transparent")
        info_bar.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 4))
        ctk.CTkLabel(
            info_bar,
            text="👤 HỒ SƠ NHÂN VẬT & CÂU LỆNH TẠO ẢNH MẪU (CHARACTER SHEET)",
            text_color="#f8fbff",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).pack(side="left")
        ctk.CTkButton(
            info_bar,
            text="🧹 Làm sạch toàn bộ",
            height=26,
            width=136,
            fg_color="#1c2633",
            hover_color="#3a2029",
            font=ctk.CTkFont(size=11),
            command=lambda: self.clear_previous_session(ask_confirm=False),
        ).pack(side="right")

        self.txt_info = ctk.CTkTextbox(self.right_frame, wrap="word", fg_color="#10171f", border_width=1, border_color="#1f2c3a")
        self.txt_info.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 8))

        out_bar = ctk.CTkFrame(self.right_frame, fg_color="transparent")
        out_bar.grid(row=2, column=0, sticky="ew", padx=12, pady=(4, 4))
        ctk.CTkLabel(
            out_bar,
            text="🎬 DANH SÁCH CÂU LỆNH QUAY VIDEO (MỖI DÒNG 1 CẢNH 8 GIÂY)",
            text_color="#7ce8ff",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).pack(side="left")

        self.push_target_options = [
            "🎨 Đẩy sang Image đồng nhất (Tự tách NV & Cảnh)",
            "🌐 Đẩy sang TẤT CẢ chức năng Bước 2",
            "✨ Đẩy sang Chuẩn hóa prompt (Làm sạch từ cấm)",
            "🎬 Đẩy sang Text to video",
            "🎭 Đẩy sang Video đồng nhất",
            "🎞 Đẩy sang Video Muse",
            "📷 Đẩy sang Image to video",
        ]
        ctk.CTkButton(
            out_bar,
            text="📤 Đẩy ngay ➔",
            height=28,
            width=118,
            fg_color="#8b5cf6",
            hover_color="#a78bfa",
            font=ctk.CTkFont(size=11, weight="bold"),
            command=self._execute_selected_push,
        ).pack(side="right", padx=(6, 0))

        self.cbo_push_target = ctk.CTkOptionMenu(
            out_bar,
            values=self.push_target_options,
            width=285,
            height=28,
            fg_color="#1c2633",
            button_color="#00b4d8",
            button_hover_color="#22c5e8",
            font=ctk.CTkFont(size=11, weight="bold"),
        )
        self.cbo_push_target.set(self.push_target_options[0])
        self.cbo_push_target.pack(side="right")

        self.txt_output = ctk.CTkTextbox(self.right_frame, wrap="word", fg_color="#10171f", border_width=1, border_color="#1f2c3a")
        self.txt_output.grid(row=3, column=0, sticky="nsew", padx=12, pady=(0, 12))

        self._load_router9_cfg()
        self._on_source_change(self.source_var.get())

    def _fill_sample_idea(self):
        self.txt_idea.delete("1.0", "end")
        self.txt_idea.insert(
            "1.0",
            "Chú mèo máy thông minh Astro khám phá khu rừng phát sáng kỳ diệu vào ban đêm, "
            "kết bạn với một chú đom đóm khổng lồ và cùng nhau mở cánh cổng cổ đại dẫn tới thành phố trên mây.",
        )
        self.txt_char.delete("1.0", "end")
        self.txt_char.insert(
            "1.0",
            "CHAR_01: Cute robotic white cat with glowing cyan eyes, wearing a sleek silver explorer backpack.",
        )
        self.show_status("💡 Đã nạp ý tưởng mẫu! Hãy bấm '✨ VIẾT KỊCH BẢN & TẠO CÂU LỆNH CẢNH QUAY'.")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch toàn bộ ý tưởng, mô tả nhân vật, hồ sơ nhân vật và danh sách câu lệnh cũ."""
        if ask_confirm:
            if not messagebox.askyesno("Làm sạch kịch bản cũ", "Bạn có muốn xoá sạch Ý tưởng, Hồ sơ nhân vật & Danh sách câu lệnh cũ không?"):
                return
        self.txt_idea.delete("1.0", "end")
        self.txt_char.delete("1.0", "end")
        self.txt_info.delete("1.0", "end")
        self.txt_output.delete("1.0", "end")
        self.last_result = None
        self.show_status("🧹 Đã làm sạch toàn bộ ý tưởng & câu lệnh cũ.")

    def _execute_selected_push(self):
        choice = self.cbo_push_target.get() if hasattr(self, "cbo_push_target") else ""
        ch = str(choice or "")
        if "Chuẩn hóa prompt" in ch:
            self._send_prompts_to_video_tab("prompt_review")
        elif "TẤT CẢ chức năng Bước 2" in ch:
            self._send_prompts_to_video_tab("all_step2")
        elif "Image đồng nhất" in ch:
            self._send_prompts_to_video_tab("image_consist")
        elif "Video đồng nhất" in ch:
            self._send_prompts_to_video_tab("veo3_consist")
        elif "Video Muse" in ch:
            self._send_prompts_to_video_tab("muse_video")
        elif "Image to video" in ch:
            self._send_prompts_to_video_tab("veo3_i2v")
        else:
            self._send_prompts_to_video_tab("veo3_t2v")

    def apply_reviewed_prompt(self, row_id: int, new_prompt: str) -> bool:
        raw = self.txt_output.get("1.0", "end").strip()
        lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        idx = int(row_id) - 1
        if 0 <= idx < len(lines):
            lines[idx] = f"Prompt {row_id}: {new_prompt.strip()}" if not new_prompt.strip().lower().startswith("prompt ") else new_prompt.strip()
            self.txt_output.delete("1.0", "end")
            self.txt_output.insert("1.0", "\n\n".join(lines))
            return True
        return False

    def _send_prompts_to_video_tab(self, target_tab_key: str):
        import flowkit_engine

        raw = self.txt_output.get("1.0", "end").strip()
        if not raw:
            messagebox.showwarning("Chưa có câu lệnh", "Hãy tạo kịch bản hoặc nhập danh sách câu lệnh trước khi đẩy sang xưởng quay!")
            return

        char_info_txt = self.txt_info.get("1.0", "end").strip()
        user_char_txt = self.txt_char.get("1.0", "end").strip()
        user_char_lines = [ln.strip() for ln in user_char_txt.splitlines() if ln.strip()]

        # Phân tích toàn bộ câu lệnh + hồ sơ nhân vật để nhận diện chính xác bao nhiêu nhân vật duy nhất
        # và gắn đúng mã CHAR_01, CHAR_02, CHAR_03... cho từng phân cảnh
        analysis = flowkit_engine.analyze_prompts_and_extract_entities(
            raw_lines_or_text=raw,
            character_bible_text=char_info_txt,
            existing_ref_lines=user_char_lines,
        )

        tagged_lines = []
        raw_vid_scenes = analysis.get("video_scene_lines") or analysis["scene_lines"]
        for sc in raw_vid_scenes:
            if "|" in sc:
                left, right = sc.split("|", 1)
                clean_right = re.sub(r"^Prompt\s*\d+\s*:\s*", "", right.strip(), flags=re.I).strip()
                tagged_lines.append(f"{left.strip()} | {clean_right}")
            else:
                tagged_lines.append(sc)

        plain_lines = []
        for ln in raw.splitlines():
            s = ln.strip()
            if not s:
                continue
            clean_p = re.sub(r"^Prompt\s*\d+\s*:\s*", "", s, flags=re.IGNORECASE).strip()
            if clean_p:
                plain_lines.append(clean_p)

        top = self.pipeline or self.winfo_toplevel()
        if target_tab_key == "prompt_review":
            if hasattr(top, "push_prompts_to_review"):
                items = [(i, p, "Kiểm tra & Chuẩn hóa từ Bước 1") for i, p in enumerate(plain_lines, start=1)]
                top.push_prompts_to_review("prompt1", items)
            return

        if target_tab_key == "all_step2":
            if hasattr(top, "push_to_all_step2_tabs"):
                top.push_to_all_step2_tabs(
                    prompts_tagged=tagged_lines,
                    prompts_plain=plain_lines,
                    ref_paths=None,
                    ref_lines=analysis["ref_lines"],
                    character_bible_text=char_info_txt,
                    scene_lines_for_img_consist=analysis["scene_lines"],
                )
            return

        if target_tab_key == "image_consist":
            lines = analysis["scene_lines"]
            ref_lines = analysis["ref_lines"]
        elif target_tab_key in ("veo3_consist", "muse_video"):
            lines = tagged_lines
            ref_lines = analysis["ref_lines"]
        else:
            lines = plain_lines
            ref_lines = None

        if not lines:
            return
        if hasattr(top, "push_prompts_to_tab"):
            top.push_prompts_to_tab(
                target_tab_key,
                lines,
                ref_lines=ref_lines,
                character_bible_text=char_info_txt,
            )
        else:
            self.clipboard_clear()
            self.clipboard_append("\n".join(lines))
            messagebox.showinfo("Đã sao chép", f"Đã chép {len(lines)} câu lệnh vào bộ nhớ tạm!")

    def _load_router9_cfg(self):
        if os.path.exists(ROUTER9_CONFIG_FILE):
            try:
                with open(ROUTER9_CONFIG_FILE, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                if cfg.get("api_key"):
                    self.entry_r9_key.delete(0, "end")
                    self.entry_r9_key.insert(0, cfg["api_key"])
                if cfg.get("model_id"):
                    self.cbo_r9_model.set(cfg["model_id"])
                if cfg.get("source"):
                    self.source_var.set(cfg["source"])
            except Exception:
                pass

    def _save_router9_cfg(self):
        try:
            cfg = {
                "api_key": self.entry_r9_key.get().strip(),
                "model_id": self.cbo_r9_model.get().strip(),
                "source": self.source_var.get(),
            }
            with open(ROUTER9_CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _on_source_change(self, choice: str):
        if "9Router" in str(choice):
            self.router9_frame.grid()
        else:
            self.router9_frame.grid_remove()

    def _load_router9_models(self):
        try:
            headers = {}
            k = self.entry_r9_key.get().strip()
            if k:
                headers["Authorization"] = f"Bearer {k}"
            resp = requests.get(f"{NINEROUTER_URL}/models", headers=headers, timeout=10)
            if resp.status_code == 200:
                data = resp.json().get("data") or []
                models = [m.get("id") for m in data if m.get("id")]
                if models:
                    self.cbo_r9_model.configure(values=models)
                    self.cbo_r9_model.set(models[0])
                    self.show_status(f"Đã nạp {len(models)} models từ 9Router.")
                    return
            self.show_status("Không lấy được danh sách model từ 9Router.", error=True)
        except Exception as e:
            self.show_status(f"Lỗi kết nối 9Router: {e}", error=True)

    def update_num_entry_from_slider(self, value):
        n = max(1, int(round(float(value))))
        self.entry_num.delete(0, "end")
        self.entry_num.insert(0, str(n))

    def update_num_slider_from_entry(self, event=None):
        try:
            n = max(1, min(200, int(self.entry_num.get().strip())))
        except Exception:
            n = 10
        self.entry_num.delete(0, "end")
        self.entry_num.insert(0, str(n))
        self.slider_num.set(min(100, n))

    def show_status(self, message: str, error: bool = False):
        color = "#f0788a" if error else "#3ecf8e"
        self.lbl_status.configure(text=message, text_color=color)

    def set_output_text(self, text: str):
        self.txt_output.delete("1.0", "end")
        self.txt_output.insert("1.0", text)

    def set_info_text(self, text: str):
        self.txt_info.delete("1.0", "end")
        self.txt_info.insert("1.0", text)

    def start_generation(self):
        idea = self.txt_idea.get("1.0", "end").strip()
        if not idea:
            messagebox.showwarning("Thiếu thông tin", "Vui lòng nhập ý tưởng câu chuyện!")
            return

        self.update_num_slider_from_entry()
        num_prompts = int(self.entry_num.get().strip() or "10")
        raw_style = self.cbo_style.get().strip()
        genre = self.cbo_genre.get().strip()
        char_app = self.txt_char.get("1.0", "end").strip()
        import flowkit_engine

        style, _ = flowkit_engine.resolve_effective_style(
            f"{idea} {char_app}",
            raw_style,
            fallback_style=STYLE_OPTIONS[2],
        )
        dialogue_lang = self.cbo_dialogue_lang.get().strip()
        voice_lang = self.cbo_voice_lang.get().strip()

        self._save_router9_cfg()
        src_choice = self.source_var.get()
        if "9Router" in src_choice:
            llm_mgr = Router9Manager(
                api_key=self.entry_r9_key.get().strip(),
                model_id=self.cbo_r9_model.get().strip(),
            )
        elif "Nội Bộ" in src_choice:
            llm_mgr = GeminiAPIManager(filepath=os.path.join(_BASE_DIR, "__offline_mode__.txt"))
        else:
            pref_map = {
                "Gemini": "gemini",
                "OpenAI": "openai",
                "Anthropic": "anthropic",
                "DeepSeek": "deepseek",
                "Groq": "groq",
                "xAI": "xai",
                "OpenRouter": "openrouter",
            }
            pref = next((v for k, v in pref_map.items() if k in src_choice), None)
            llm_mgr = GeminiAPIManager(preferred_provider=pref)

        self.btn_generate.configure(state="disabled", text="⏳ Đang biên kịch & phân cảnh...")
        self.show_status("Đang xử lý kịch bản & tạo câu lệnh cảnh quay...")

        t = threading.Thread(
            target=generate_prompts_from_gemini,
            args=(idea, style, num_prompts, genre, char_app, dialogue_lang, voice_lang, self.q, llm_mgr),
            daemon=True,
        )
        t.start()
        self.after(150, self.check_queue)

    def check_queue(self):
        try:
            while True:
                msg_type, payload = self.q.get_nowait()
                if msg_type == "status":
                    self.show_status(str(payload))
                elif msg_type == "done":
                    self.on_generation_finished(payload)
                    return
                elif msg_type == "error":
                    self.on_generation_error(str(payload))
                    return
        except queue.Empty:
            pass
        self.after(150, self.check_queue)

    def on_generation_finished(self, result: dict):
        self.last_result = result
        self.btn_generate.configure(state="normal", text="✨ VIẾT KỊCH BẢN & TẠO CÂU LỆNH CẢNH QUAY")

        info_parts = [result.get("character_info", "")]
        sheets = result.get("character_sheets") or []
        if sheets:
            info_parts.append("\n" + "=" * 60)
            info_parts.append("🎨 CÂU LỆNH TẠO ẢNH NHÂN VẬT MẪU (CHARACTER SHEET):")
            for sh in sheets:
                info_parts.append(f"\n[{sh['id']} - {sh['name']}]\n{sh['image_prompt']}")

        self.set_info_text("\n".join(info_parts).strip())
        prompts_list = result.get("prompts") or []
        self.set_output_text("\n\n".join(prompts_list))
        self.show_status(f"✅ Hoàn thành! Đã tạo {len(prompts_list)} cảnh quay & {len(sheets)} hồ sơ nhân vật.")

    def on_generation_error(self, err_msg: str):
        self.btn_generate.configure(state="normal", text="✨ VIẾT KỊCH BẢN & TẠO CÂU LỆNH CẢNH QUAY")
        self.show_status(f"❌ Lỗi: {err_msg}", error=True)
        messagebox.showerror("Lỗi tạo kịch bản", err_msg)

    def save_to_file(self):
        out_txt = self.txt_output.get("1.0", "end").strip()
        if not out_txt:
            messagebox.showwarning("Chưa có dữ liệu", "Chưa có câu lệnh nào để lưu!")
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx"), ("Text File", "*.txt")],
            title="Lưu Kịch Bản & Bộ Câu Lệnh Cảnh Quay",
        )
        if not file_path:
            return

        try:
            prompts = (self.last_result or {}).get("prompts") or [
                ln.strip() for ln in out_txt.splitlines() if ln.strip()
            ]
            style_val = (self.last_result or {}).get("style", self.cbo_style.get())
            genre_val = (self.last_result or {}).get("genre", self.cbo_genre.get())
            headers1 = ["STT", "Câu Lệnh Quay Video (Veo 3)", "Phong cách", "Thể loại"]
            headers2 = ["Mã ID", "Tên Nhân Vật", "Mô Tả Ngoại Hình", "Câu Lệnh Tạo Ảnh Mẫu (Character Sheet)"]

            if file_path.lower().endswith(".xlsx") and openpyxl is not None:
                wb = openpyxl.Workbook()
                ws1 = wb.active
                ws1.title = "Video Prompts"
                ws1.append(headers1)

                header_fill = PatternFill(start_color="00A99D", end_color="00A99D", fill_type="solid")
                header_font = Font(bold=True, color="FFFFFF")
                for col_idx in range(1, len(headers1) + 1):
                    cell = ws1.cell(row=1, column=col_idx)
                    cell.fill = header_fill
                    cell.font = header_font
                    cell.alignment = Alignment(horizontal="center", vertical="center")

                for idx, p in enumerate(prompts, start=1):
                    clean_p = re.sub(r"^Prompt\s*\d+\s*:\s*", "", p, flags=re.IGNORECASE)
                    ws1.append([idx, clean_p, style_val, genre_val])

                ws1.column_dimensions["A"].width = 8
                ws1.column_dimensions["B"].width = 95
                ws1.column_dimensions["C"].width = 28
                ws1.column_dimensions["D"].width = 24

                ws2 = wb.create_sheet(title="Anh Nhan Vat Mau")
                ws2.append(headers2)
                for col_idx in range(1, len(headers2) + 1):
                    cell = ws2.cell(row=1, column=col_idx)
                    cell.fill = header_fill
                    cell.font = header_font

                for sh in (self.last_result or {}).get("character_sheets") or []:
                    ws2.append([sh.get("id"), sh.get("name"), sh.get("appearance"), sh.get("image_prompt")])

                ws2.column_dimensions["A"].width = 14
                ws2.column_dimensions["B"].width = 24
                ws2.column_dimensions["C"].width = 50
                ws2.column_dimensions["D"].width = 80

                wb.save(file_path)
            elif file_path.lower().endswith(".xlsx"):
                rows1 = [headers1]
                for idx, p in enumerate(prompts, start=1):
                    clean_p = re.sub(r"^Prompt\s*\d+\s*:\s*", "", p, flags=re.IGNORECASE)
                    rows1.append([idx, clean_p, style_val, genre_val])
                rows2 = [headers2]
                for sh in (self.last_result or {}).get("character_sheets") or []:
                    rows2.append([sh.get("id"), sh.get("name"), sh.get("appearance"), sh.get("image_prompt")])
                _write_xlsx_native(file_path, rows1, rows2)
            else:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(out_txt + "\n")

            self.show_status(f"💾 Đã lưu: {os.path.basename(file_path)}")
        except Exception as e:
            messagebox.showerror("Lỗi lưu file", str(e))


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Prompt — Film studio")
        self.geometry("1280x800")
        self.frame = Veo3PromptToolFrame(self)
        self.frame.pack(fill="both", expand=True)


def build_tab(parent, openai_client=None, gemini_model=None, *args, **kwargs):
    """Điểm vào cho Film studio."""
    frame = Veo3PromptToolFrame(
        parent,
        openai_client=openai_client,
        gemini_model=gemini_model,
        pipeline=kwargs.get("pipeline"),
    )
    frame.pack(fill="both", expand=True)
    return frame


if __name__ == "__main__":
    ctk.set_appearance_mode("Dark")
    app = App()
    app.mainloop()
