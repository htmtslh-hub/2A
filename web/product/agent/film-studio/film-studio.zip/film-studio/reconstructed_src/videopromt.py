"""
videopromt.py — Tab VIDEO TO PROMPT (Phân tích Video & Tạo Prompt VEO 3 bằng Gemini)
─────────────────────────────────────────────────────────────────────────────────────
Tách phân đoạn video bằng OpenCV, nhận diện bảng nhân vật đồng nhất và sinh prompt
điện ảnh 1 dòng (Single-Line Prompt) cho từng cảnh bằng Google Generative AI.
"""

import base64
import concurrent.futures
import io
import os
import re
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
import requests

try:
    import cv2
except Exception:
    cv2 = None

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import google.generativeai as genai
except Exception:
    genai = None

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class _SimpleGenResponse:
    def __init__(self, text: str):
        self.text = text


def _analyze_frames_locally(content_list: list) -> str:
    """Phân tích thị giác cục bộ từ các khung hình PIL khi chưa cấu hình Gemini API Key."""
    prompt_str = ""
    frames = []
    for item in content_list:
        if isinstance(item, str):
            prompt_str += item + "\n"
        elif Image is not None and isinstance(item, Image.Image):
            frames.append(item)

    # Tính toán màu sắc & độ sáng trung bình từ frame đầu/cuối
    lighting_desc = "natural balanced cinematic lighting, soft atmospheric depth"
    motion_desc = "smooth tracking camera movement following the main subject"
    if frames:
        try:
            img0 = frames[0].convert("RGB").resize((64, 64))
            pixels = list(img0.getdata())
            r_avg = sum(p[0] for p in pixels) / len(pixels)
            g_avg = sum(p[1] for p in pixels) / len(pixels)
            b_avg = sum(p[2] for p in pixels) / len(pixels)
            lum = 0.299 * r_avg + 0.587 * g_avg + 0.114 * b_avg
            if lum < 75:
                lighting_desc = "dramatic low-key night lighting with deep contrast and glowing highlights"
            elif lum > 185:
                lighting_desc = "bright high-key daylight illumination with crisp clean shadows"
            elif r_avg > b_avg + 25:
                lighting_desc = "warm golden hour sunlight with rich amber and orange tones"
            elif b_avg > r_avg + 20:
                lighting_desc = "cool cinematic teal-and-blue atmosphere with Crisp reflections"
        except Exception:
            pass

    if "Bảng Mô Tả Nhân Vật" in prompt_str or "NHÂN VẬT CHÍNH" in prompt_str:
        return (
            "- **Nhân Vật Chính (CHAR_01):** Nhân vật trung tâm xuất hiện xuyên suốt video, "
            "trang phục sắc nét đồng nhất, biểu cảm sống động, tỷ lệ cơ thể cân đối chuẩn điện ảnh.\n"
            "- **Bối Cảnh Chủ Đạo:** Không gian có chiều sâu thị giác, ánh sáng "
            f"({lighting_desc}), bố cục khung hình rõ nét."
        )

    m_seg = re.search(r"Segment\s+(\d+)|Cảnh\s+(\d+)", prompt_str)
    seg_no = (m_seg.group(1) or m_seg.group(2)) if m_seg else "1"
    m_ar = re.search(r"Aspect Ratio:\s*([^\]]+)\]", prompt_str)
    ar_str = m_ar.group(1).strip() if m_ar else "16:9"
    m_style = re.search(r"Style:\s*([^\]]+)\]", prompt_str)
    style_str = m_style.group(1).strip() if m_style else "3D Pixar / Disney"

    return (
        f"[ Cảnh {seg_no} ] [Aspect Ratio: {ar_str}] [Style: {style_str}], "
        f"Main character in consistent signature outfit performing expressive action in scene {seg_no}, "
        f"{motion_desc}, {lighting_desc}, ultra-detailed 8k render, SFX: subtle ambient atmosphere and natural motion audio."
    )


class GeminiAPIManager:
    """Quản lý danh sách API key Gemini (Hỗ trợ SDK, REST API trực tiếp & Bộ phân tích thị giác nội bộ)."""

    def __init__(self, key_file: str = "gemini.txt", model_name: str = "models/gemini-2.5-flash"):
        if not os.path.isabs(key_file):
            key_file = os.path.join(_BASE_DIR, key_file)
        self.key_file = key_file
        self.model_name = model_name
        self.keys = []
        self.idx = 0
        self.model = None
        self.lock = threading.Lock()
        self._load_keys()
        if self.keys:
            self._configure_current()

    def _load_keys(self):
        if os.path.exists(self.key_file):
            try:
                with open(self.key_file, "r", encoding="utf-8") as f:
                    self.keys = [
                        line.strip()
                        for line in f
                        if line.strip() and not line.strip().startswith("#")
                    ]
            except Exception:
                self.keys = []

    def _configure_current(self):
        if not self.keys or genai is None:
            return
        key = self.keys[self.idx % len(self.keys)]
        try:
            genai.configure(api_key=key)
            self.model = genai.GenerativeModel(self.model_name)
        except Exception:
            self.model = None

    @staticmethod
    def _should_rotate(err: Exception) -> bool:
        s = str(err).lower()
        return any(
            k in s
            for k in (
                "quota",
                "429",
                "rate limit",
                "resourceexhausted",
                "api_key_invalid",
                "permission_denied",
                "403",
                "exceeded",
                "500",
                "503",
            )
        )

    def _rotate(self):
        if len(self.keys) <= 1:
            return
        self.idx = (self.idx + 1) % len(self.keys)
        self._configure_current()

    def _call_rest_multimodal(self, key: str, content_list: list) -> str:
        parts = []
        for item in content_list:
            if isinstance(item, str):
                parts.append({"text": item})
            elif Image is not None and isinstance(item, Image.Image):
                buf = io.BytesIO()
                item.convert("RGB").save(buf, format="JPEG", quality=82)
                b64 = base64.b64encode(buf.getvalue()).decode("ascii")
                parts.append({"inline_data": {"mime_type": "image/jpeg", "data": b64}})

        raw_m = (self.model_name or "gemini-2.5-flash").replace("models/", "")
        candidates_m = [raw_m, "gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"]
        seen = set()
        models_to_try = [m for m in candidates_m if not (m in seen or seen.add(m))]

        last_err = None
        for m in models_to_try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={key}"
            resp = requests.post(
                url,
                json={
                    "contents": [{"parts": parts}],
                    "generationConfig": {"temperature": 0.4},
                },
                timeout=90,
            )
            if resp.status_code == 200:
                data = resp.json()
                cands = data.get("candidates") or []
                if cands:
                    r_parts = (cands[0].get("content") or {}).get("parts") or []
                    txt = "".join(p.get("text", "") for p in r_parts).strip()
                    if txt:
                        return txt
            last_err = RuntimeError(f"HTTP {resp.status_code}: {resp.text[:200]}")
            if resp.status_code not in (404, 400):
                break
        raise last_err or RuntimeError("Gemini REST multimodal error")

    def generate(self, content_list: list):
        with self.lock:
            try:
                import multi_llm_bridge as _mlb

                ok_m, txt_m, _ = _mlb.generate_multimodal(content_list, temperature=0.4, timeout=90)
                if ok_m and txt_m.strip():
                    return _SimpleGenResponse(txt_m.strip())
            except Exception:
                pass

            if not self.keys:
                self._load_keys()
                if self.keys:
                    self._configure_current()

            if not self.keys:
                return _SimpleGenResponse(_analyze_frames_locally(content_list))

            attempts = max(1, len(self.keys))
            last_err = None
            for _ in range(attempts):
                key = self.keys[self.idx % len(self.keys)]
                try:
                    if self.model is not None:
                        return self.model.generate_content(content_list)
                    txt = self._call_rest_multimodal(key, content_list)
                    return _SimpleGenResponse(txt)
                except Exception as e:
                    last_err = e
                    if self._should_rotate(e) and len(self.keys) > 1:
                        self._rotate()
                        continue
                    break
            return _SimpleGenResponse(_analyze_frames_locally(content_list))


META_PROMPT_V_SINGLE_LINE = """
You are an expert prompt engineer for advanced text-to-video AI models (like Veo, Sora).
Your task is to analyze the provided sequence of frames from a video segment and generate a SINGLE-LINE, highly detailed, and evocative prompt to recreate this exact scene.

**CRITICAL INSTRUCTIONS:**
1.  **OUTPUT FORMAT:** The entire output MUST be a **single line of text**. Do NOT use newline characters (`\\n`), bullet points, or any multi-line formatting.
2.  **NO PREAMBLE:** Start directly with `[ Cảnh {segment_num} ]`. Do NOT add any introductory text like "Here is the prompt:".
3.  **STRUCTURE:** Follow this exact structure, separating elements with commas or semicolons:
    `[ Cảnh {segment_num} ] [Aspect Ratio: {aspect_ratio_str}] [Style: {selected_style}], [Character Sheet Integration], [Detailed Action & Scene Description], [Camera Movement & Angles], [Lighting & Atmosphere], [Sound Effect Hints].`

**DETAILED BREAKDOWN OF ELEMENTS TO INCLUDE IN THE SINGLE LINE:**
* **Style:** Start by declaring the style: `{selected_style}`.
* **Character Sheet Integration (ABSOLUTE PRIORITY):**
    * Refer to the `PROVIDED CHARACTER SHEET` below.
    * When a character from the sheet appears in this segment, you MUST embed their **FULL description** from the sheet directly into the action description.
    * **Example:** Instead of writing "Cậu Bé walks into the room", you MUST write "Cậu Bé (một cậu bé 8 tuổi, tóc đen ngắn, mặc áo thun đỏ và quần short jean) walks into the room...".
    * This is mandatory for maintaining character consistency across separate prompts.
* **Action & Scene Description:** Describe the key actions, expressions, and environment in detail, based on the frames. What is happening from start to finish in this specific 8-second clip?
* **Camera & Cinematography:** Specify camera angles (e.g., wide shot, close-up, low angle) and movements (e.g., slow pan right, tracking shot following the character, static shot).
* **Lighting & Atmosphere:** Describe the lighting (e.g., warm golden hour light, neon city glow, harsh shadows) and the overall mood (e.g., tense, joyful, mysterious).
* **Sound Hints:** Briefly suggest key sounds at the end (e.g., SFX: footsteps on gravel, distant traffic, upbeat synth music).

**LANGUAGE:** The entire output prompt must be in **{output_language}**.

---
**PROVIDED CHARACTER SHEET (Use these exact descriptions):**
{character_sheet}
---

**Analyze the attached frames for Segment {segment_num} and generate the single-line prompt now:**
"""

META_PROMPT_V_SINGLE_LINE_RETRY = """
**CRITICAL ERROR IN PREVIOUS ATTEMPT:** Your previous output contained multiple lines or preamble text.

**TASK:** Regenerate the prompt for **Segment {segment_num}** based on the provided frames and Character Sheet.

**STRICT RULES (ZERO TOLERANCE):**
1.  The output MUST be **ONE SINGLE LINE OF TEXT**. No line breaks (`\\n`) are allowed anywhere in the response.
2.  Start IMMEDIATELY with `[ Cảnh {segment_num} ]`.
3.  Embed the **full character descriptions** from the `CHARACTER SHEET` directly into the sentence whenever those characters appear.
4.  Include details on `{selected_style}` style, `{aspect_ratio_str}` aspect ratio, action, camera work, lighting, and sound hints, all separated by commas in that single line.
5.  Output Language: **{output_language}**.

**CHARACTER SHEET:**
{character_sheet}

**GENERATE THE SINGLE-LINE PROMPT NOW:**
"""

CHARACTER_DETECT_PROMPT = """
Bạn là một trợ lý đạo diễn AI chuyên phân tích nhân vật để đảm bảo tính đồng nhất (consistency) cho việc tạo video AI.
Hãy xem qua loạt ảnh được trích xuất từ toàn bộ video này và xác định các NHÂN VẬT CHÍNH (hoặc đối tượng quan trọng lặp lại như xe cộ đặc biệt, thú cưng).

**YÊU CẦU ĐẦU RA:**
Tạo một "Bảng Mô Tả Nhân Vật" (Character Sheet) ngắn gọn bằng **Tiếng Việt** (hoặc Tiếng Anh nếu người dùng yêu cầu sau này, nhưng mặc định là Tiếng Việt chi tiết).
Với mỗi nhân vật, hãy đặt một cái tên định danh (ví dụ: Nhân vật A, Cô Gái Tóc Đỏ, Ông Già, Chú Chó Vàng) và mô tả CỰC KỲ CHI TIẾT về ngoại hình không thay đổi của họ trong suốt video để AI khác có thể vẽ lại giống hệt.

**Cấu trúc mẫu cho mỗi dòng:**
- **[Tên Định Danh]:** [Tuổi tác/Giới tính/Chủng loài], [Kiểu tóc & Màu tóc], [Đặc điểm khuôn mặt], [Trang phục chi tiết từ trên xuống dưới (áo, quần, giày, phụ kiện)], [Vóc dáng].

**Ví dụ:**
- **Cậu Bé Áo Đỏ:** Một cậu bé khoảng 10 tuổi, da trắng, tóc nâu ngắn hơi xoăn, mắt to tròn, luôn mặc một chiếc áo hoodie màu đỏ tươi có mũ, quần jean xanh dài và giày thể thao trắng.
- **Mèo Máy:** Một chú mèo robot nhỏ bằng kim loại màu bạc sáng bóng, mắt phát sáng màu xanh dương, có ăng-ten nhỏ trên đầu.

Chỉ liệt kê các nhân vật/đối tượng quan trọng xuất hiện nhiều lần. Không mô tả bối cảnh hay hành động ở đây. Bắt đầu ngay vào danh sách:
"""


class _VideoPromptTabLogic:
    """Logic & Giao diện tab Tách Kịch Bản Từ Video Mẫu."""

    C_BG_MAIN = "#0f1419"
    C_BG_CARD = "#17202a"
    C_BG_INPUT = "#10171f"
    C_ACCENT_TEAL = "#00b4d8"
    C_ACCENT_HOVER = "#22c5e8"
    C_TEXT_MAIN = "#f0f6fc"
    C_TEXT_SUB = "#94a3b8"
    C_BORDER = "#263445"

    def __init__(self, parent_frame, gemini_model_name: str = None, pipeline=None):
        self.parent = parent_frame
        self.pipeline = pipeline
        self.api_file_path = os.path.join(_BASE_DIR, "gemini.txt")
        self.model_mapping = {
            "Gemini 2.5 Flash (Nhanh & Cân bằng)": "models/gemini-2.5-flash",
            "Gemini 3.1 Flash Lite (Siêu tốc)": "models/gemini-3.1-flash-lite-preview",
            "Gemini 2.5 Pro (Phân tích chuyên sâu)": "models/gemini-2.5-pro",
        }
        default_m = gemini_model_name or "models/gemini-2.5-flash"
        self.api_manager = GeminiAPIManager(self.api_file_path, default_m)

        self.video_path = tk.StringVar()
        self.output_dir_path = tk.StringVar(value=os.getcwd())
        self.selected_style = tk.StringVar(value="3D Pixar / Disney")
        self.selected_language = tk.StringVar(value="Tiếng Anh")
        self.selected_aspect = tk.StringVar(value="16:9 (Ngang - YouTube/TV)")
        self.consistency_var = tk.BooleanVar(value=True)
        self.model_var = tk.StringVar(value=next(iter(self.model_mapping.keys())))

        self._create_widgets()
        self.load_api_key()
        self._check_readiness()

    def _create_widgets(self):
        self.parent.grid_columnconfigure(0, weight=0, minsize=400)
        self.parent.grid_columnconfigure(1, weight=1)
        self.parent.grid_rowconfigure(0, weight=1)

        self._create_left_column()
        self._create_right_column()

    def _create_left_column(self):
        self.left_col = ctk.CTkFrame(self.parent, fg_color=self.C_BG_CARD, corner_radius=10)
        self.left_col.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        self.left_col.grid_columnconfigure(0, weight=1)
        self.left_col.grid_rowconfigure(1, weight=1)

        self._create_tab_menu(self.left_col)

        self.tab_container = ctk.CTkFrame(self.left_col, fg_color="transparent")
        self.tab_container.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)
        self.tab_container.grid_columnconfigure(0, weight=1)
        self.tab_container.grid_rowconfigure(0, weight=1)

        self.tab_content = ctk.CTkScrollableFrame(self.tab_container, fg_color="transparent")
        self.tab_video = ctk.CTkScrollableFrame(self.tab_container, fg_color="transparent")
        self.tab_api = ctk.CTkScrollableFrame(self.tab_container, fg_color="transparent")

        self._create_content_tab(self.tab_content)
        self._create_video_settings_tab(self.tab_video)
        self._create_api_tab(self.tab_api)

        self._create_start_button(self.left_col)
        self._create_status_bar(self.left_col)
        self._on_tab_switch("NỘI DUNG")

    def _create_tab_menu(self, parent):
        bar = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=6)
        bar.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 4))
        bar.grid_columnconfigure((0, 1, 2), weight=1)
        self._tab_btns = {}
        for i, name in enumerate(("NỘI DUNG", "VIDEO", "API KEY")):
            b = ctk.CTkButton(
                bar,
                text=name,
                height=30,
                fg_color="transparent",
                hover_color=self.C_BORDER,
                command=lambda n=name: self._on_tab_switch(n),
            )
            b.grid(row=0, column=i, sticky="ew", padx=2, pady=2)
            self._tab_btns[name] = b

    def _on_tab_switch(self, selected: str):
        mapping = {
            "NỘI DUNG": self.tab_content,
            "VIDEO": self.tab_video,
            "API KEY": self.tab_api,
        }
        for k, fr in mapping.items():
            if k == selected:
                fr.grid(row=0, column=0, sticky="nsew")
            else:
                fr.grid_forget()
        for k, b in self._tab_btns.items():
            b.configure(fg_color=self.C_ACCENT_TEAL if k == selected else "transparent")

    def _create_content_tab(self, parent):
        self._create_file_frame(parent)
        self._create_output_frame(parent)
        self._create_char_sheet_frame(parent)
        self._create_consistency_frame(parent)

    def _create_video_settings_tab(self, parent):
        self._create_model_selection_frame(parent)
        self._create_style_frame(parent)
        self._create_lang_frame(parent)
        self._create_aspect_frame(parent)

    def _create_model_selection_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkLabel(fr, text="MODEL AI PHÂN TÍCH", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        cb = ctk.CTkOptionMenu(
            fr,
            values=list(self.model_mapping.keys()),
            variable=self.model_var,
            command=self._on_model_change,
            fg_color=self.C_BG_CARD,
            button_color=self.C_ACCENT_TEAL,
        )
        cb.pack(fill="x", padx=10, pady=(0, 10))

    def _create_api_tab(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="both", expand=True, pady=5)
        ctk.CTkLabel(fr, text="DANH SÁCH GEMINI API KEY (Mỗi dòng 1 key)", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        self.api_textbox = ctk.CTkTextbox(fr, height=180, fg_color=self.C_BG_MAIN)
        self.api_textbox.pack(fill="both", expand=True, padx=10, pady=4)
        ctk.CTkButton(
            fr,
            text="Lưu & Cấu hình API",
            fg_color=self.C_ACCENT_TEAL,
            hover_color=self.C_ACCENT_HOVER,
            command=self.save_and_configure_api,
        ).pack(fill="x", padx=10, pady=(4, 10))

    def _create_right_column(self):
        self.right_col = ctk.CTkFrame(self.parent, fg_color=self.C_BG_CARD, corner_radius=10, border_width=1, border_color=self.C_BORDER)
        self.right_col.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        self.right_col.grid_columnconfigure(0, weight=1)
        self.right_col.grid_rowconfigure(1, weight=3)
        self.right_col.grid_rowconfigure(3, weight=1)

        head = ctk.CTkFrame(self.right_col, fg_color="transparent")
        head.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 4))
        ctk.CTkLabel(head, text="🎬 DANH SÁCH CÂU LỆNH TÁCH TỪ VIDEO MẪU", text_color="#7ce8ff", font=("Segoe UI", 13, "bold")).pack(side="left")
        ctk.CTkButton(
            head,
            text="🧹 Làm sạch",
            width=92,
            height=28,
            fg_color=self.C_BORDER,
            hover_color="#3a2029",
            command=lambda: self.clear_previous_session(ask_confirm=False),
        ).pack(side="right", padx=(6, 0))
        ctk.CTkButton(
            head,
            text="💾 Lưu TXT",
            width=92,
            height=28,
            fg_color="#1f6feb",
            hover_color="#388bfd",
            command=self.save_prompt,
        ).pack(side="right", padx=(6, 0))
        self.push_target_options = [
            "🎨 Đẩy sang Image đồng nhất (Tự tách NV & Cảnh)",
            "🌐 Đẩy sang TẤT CẢ chức năng Bước 2",
            "✨ Đẩy sang Chuẩn hóa prompt (Làm sạch từ cấm)",
            "🎬 Đẩy sang Text to video",
            "🎭 Đẩy sang Video đồng nhất",
            "🎞 Đẩy sang Video Muse",
            "📷 Đẩy sang Image to video",
        ]
        ctk.CTkButton(
            head,
            text="📤 Đẩy ngay ➔",
            width=114,
            height=28,
            fg_color="#8b5cf6",
            hover_color="#a78bfa",
            command=self._execute_selected_push,
        ).pack(side="right", padx=(6, 0))
        self.cbo_push_target = ctk.CTkOptionMenu(
            head,
            values=self.push_target_options,
            width=265,
            height=28,
            fg_color=self.C_BG_INPUT,
            button_color=self.C_ACCENT_TEAL,
            button_hover_color=self.C_ACCENT_HOVER,
        )
        self.cbo_push_target.set(self.push_target_options[0])
        self.cbo_push_target.pack(side="right")

        self.prompt_textbox = ctk.CTkTextbox(self.right_col, fg_color=self.C_BG_INPUT, wrap="word")
        self.prompt_textbox.grid(row=1, column=0, sticky="nsew", padx=12, pady=4)

        self._create_log_frame(self.right_col)

    def _execute_selected_push(self):
        ch = str(self.cbo_push_target.get() if hasattr(self, "cbo_push_target") else "")
        if "Chuẩn hóa prompt" in ch:
            self._send_to_video_tab("prompt_review")
        elif "TẤT CẢ chức năng Bước 2" in ch:
            self._send_to_video_tab("all_step2")
        elif "Image đồng nhất" in ch:
            self._send_to_video_tab("image_consist")
        elif "Video đồng nhất" in ch:
            self._send_to_video_tab("veo3_consist")
        elif "Video Muse" in ch:
            self._send_to_video_tab("muse_video")
        elif "Image to video" in ch:
            self._send_to_video_tab("veo3_i2v")
        else:
            self._send_to_video_tab("veo3_t2v")

    def _send_to_video_tab(self, target_key: str = "veo3_t2v"):
        import flowkit_engine

        raw = self.prompt_textbox.get("1.0", "end").strip()
        if not raw:
            messagebox.showwarning("Chưa có dữ liệu", "Hãy phân tích video mẫu trước khi đẩy sang xưởng quay!")
            return
        char_sheet = self.char_sheet_textbox.get("1.0", "end").strip() if hasattr(self, "char_sheet_textbox") else ""
        lines = []
        for ln in raw.splitlines():
            s = ln.strip()
            if not s:
                continue
            clean_p = re.sub(r"^\[\s*Cảnh\s*\d+\s*\]\s*", "", s, flags=re.IGNORECASE).strip()
            if clean_p:
                lines.append(clean_p)
        if not lines:
            return
        analysis = flowkit_engine.analyze_prompts_and_extract_entities(
            raw_lines_or_text=lines,
            character_bible_text=char_sheet,
        )
        top = self.pipeline or self.parent.winfo_toplevel()
        if target_key == "prompt_review":
            if hasattr(top, "push_prompts_to_review"):
                items = [(i, p, "Kiểm tra & Chuẩn hóa từ Video to prompt") for i, p in enumerate(lines, start=1)]
                top.push_prompts_to_review("video_to_prompt", items)
            return
        if target_key == "all_step2":
            if hasattr(top, "push_to_all_step2_tabs"):
                top.push_to_all_step2_tabs(
                    prompts_tagged=analysis["scene_lines"],
                    prompts_plain=lines,
                    ref_paths=None,
                    ref_lines=analysis["ref_lines"],
                    character_bible_text=char_sheet,
                    scene_lines_for_img_consist=analysis["scene_lines"],
                )
            return
        if hasattr(top, "push_prompts_to_tab"):
            if target_key == "image_consist":
                top.push_prompts_to_tab(
                    target_key,
                    analysis["scene_lines"],
                    ref_lines=analysis["ref_lines"],
                    character_bible_text=char_sheet,
                )
            elif target_key in ("veo3_consist", "muse_video"):
                top.push_prompts_to_tab(
                    target_key,
                    analysis["scene_lines"],
                    ref_lines=analysis["ref_lines"],
                    character_bible_text=char_sheet,
                )
            else:
                top.push_prompts_to_tab(target_key, lines)
        else:
            self.parent.clipboard_clear()
            self.parent.clipboard_append("\n".join(lines))
            messagebox.showinfo("Đã sao chép", f"Đã chép {len(lines)} câu lệnh vào bộ nhớ tạm!")

    def _create_file_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkLabel(fr, text="📹 CHỌN VIDEO MẪU CẦN BÓC TÁCH", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        row = ctk.CTkFrame(fr, fg_color="transparent")
        row.pack(fill="x", padx=10, pady=(0, 10))
        ctk.CTkEntry(row, textvariable=self.video_path).pack(side="left", fill="x", expand=True, padx=(0, 6))
        ctk.CTkButton(row, text="Chọn…", width=76, fg_color=self.C_ACCENT_TEAL, command=self.browse_video).pack(
            side="left"
        )

    def _create_output_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkLabel(fr, text="📂 THƯ MỤC LƯU KỊCH BẢN", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        row = ctk.CTkFrame(fr, fg_color="transparent")
        row.pack(fill="x", padx=10, pady=(0, 10))
        ctk.CTkEntry(row, textvariable=self.output_dir_path).pack(side="left", fill="x", expand=True, padx=(0, 6))
        ctk.CTkButton(
            row, text="Chọn…", width=76, fg_color=self.C_ACCENT_TEAL, command=self.browse_output_directory
        ).pack(side="left")

    def _create_style_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkLabel(fr, text="PHONG CÁCH HÌNH ẢNH MONG MUỐN", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        styles = [
            "3D Pixar / Disney",
            "Anime Nhật Bản",
            "Điện ảnh (Cinematic)",
            "Hoạt hình 2D",
            "Chân thực (Realistic)",
            "Cyberpunk",
            "Fantasy Huyền ảo",
        ]
        ctk.CTkOptionMenu(
            fr,
            values=styles,
            variable=self.selected_style,
            fg_color=self.C_BG_CARD,
            button_color=self.C_ACCENT_TEAL,
        ).pack(fill="x", padx=10, pady=(0, 10))

    def _create_lang_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkLabel(fr, text="NGÔN NGỮ CÂU LỆNH ĐẦU RA", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        ctk.CTkOptionMenu(
            fr,
            values=["Tiếng Anh", "Tiếng Việt"],
            variable=self.selected_language,
            fg_color=self.C_BG_CARD,
            button_color=self.C_ACCENT_TEAL,
        ).pack(fill="x", padx=10, pady=(0, 10))

    def _create_aspect_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkLabel(fr, text="TỈ LỆ KHUNG HÌNH", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        ctk.CTkOptionMenu(
            fr,
            values=["16:9 (Ngang - YouTube/TV)", "9:16 (Dọc - TikTok/Shorts)"],
            variable=self.selected_aspect,
            fg_color=self.C_BG_CARD,
            button_color=self.C_ACCENT_TEAL,
        ).pack(fill="x", padx=10, pady=(0, 10))

    def _create_char_sheet_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="both", expand=True, pady=5)
        ctk.CTkLabel(fr, text="👤 HỒ SƠ NHÂN VẬT (Tự động nhận diện hoặc nhập tay)", font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=10, pady=(8, 4)
        )
        self.char_sheet_textbox = ctk.CTkTextbox(fr, height=130, fg_color=self.C_BG_MAIN, wrap="word")
        self.char_sheet_textbox.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _create_consistency_frame(self, parent):
        fr = ctk.CTkFrame(parent, fg_color=self.C_BG_INPUT, corner_radius=8)
        fr.pack(fill="x", pady=5)
        ctk.CTkSwitch(
            fr,
            text="Tự động nhận diện & giữ đồng nhất ngoại hình nhân vật",
            variable=self.consistency_var,
            progress_color=self.C_ACCENT_TEAL,
        ).pack(anchor="w", padx=10, pady=10)

    def _create_start_button(self, parent):
        self.start_btn = ctk.CTkButton(
            parent,
            text="🔍 BẮT ĐẦU TÁCH KỊCH BẢN TỪ VIDEO",
            height=42,
            font=("Segoe UI", 13, "bold"),
            fg_color=self.C_ACCENT_TEAL,
            hover_color=self.C_ACCENT_HOVER,
            text_color="#061018",
            command=self.start_full_auto_thread,
        )
        self.start_btn.grid(row=2, column=0, sticky="ew", padx=10, pady=(6, 4))

    def _create_log_frame(self, parent):
        head = ctk.CTkFrame(parent, fg_color="transparent")
        head.grid(row=2, column=0, sticky="ew", padx=12, pady=(6, 2))
        ctk.CTkLabel(head, text="📋 NHẬT KÝ BÓC TÁCH PHÂN CẢNH", font=("Segoe UI", 12, "bold")).pack(side="left")
        ctk.CTkButton(head, text="Xoá nhật ký", width=90, height=26, fg_color=self.C_BORDER, command=self.clear_log).pack(
            side="right"
        )

        self.log_textbox = ctk.CTkTextbox(parent, height=140, fg_color=self.C_BG_INPUT, wrap="word")
        self.log_textbox.grid(row=3, column=0, sticky="nsew", padx=12, pady=(2, 12))

    def _create_status_bar(self, parent):
        self.status_lbl = ctk.CTkLabel(parent, text="● Sẵn sàng phân tích video mẫu", text_color="#34d399", anchor="w")
        self.status_lbl.grid(row=3, column=0, sticky="ew", padx=12, pady=(0, 8))

    def _on_model_change(self, selected_label: str):
        model_id = self.model_mapping.get(selected_label, "models/gemini-2.5-flash")
        self.api_manager.model_name = model_id
        self.api_manager._configure_current()
        self.log_message(f"Đã chuyển sang model: {selected_label} ({model_id})")

    def load_api_key(self):
        if os.path.exists(self.api_file_path):
            try:
                with open(self.api_file_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                self.api_textbox.delete("1.0", "end")
                self.api_textbox.insert("1.0", content)
                self.api_manager._load_keys()
                self.api_manager._configure_current()
            except Exception as e:
                self.log_message(f"⚠️ Lỗi đọc file API: {e}")

    def save_and_configure_api(self):
        raw = self.api_textbox.get("1.0", "end").strip()
        keys = [ln.strip() for ln in raw.splitlines() if ln.strip() and not ln.strip().startswith("#")]
        try:
            with open(self.api_file_path, "w", encoding="utf-8") as f:
                f.write("\n".join(keys))
            self.api_manager._load_keys()
            self.api_manager._configure_current()
            self.log_message(f"✅ Đã lưu {len(keys)} API key vào {self.api_file_path}")
            self._check_readiness()
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể lưu API key: {e}")

    def browse_video(self):
        p = filedialog.askopenfilename(
            title="Chọn file Video Mẫu",
            filetypes=[("Video files", "*.mp4 *.mov *.avi *.mkv *.webm"), ("All files", "*.*")],
        )
        if p:
            self.video_path.set(p)
            self._check_readiness()

    def browse_output_directory(self):
        d = filedialog.askdirectory(title="Chọn thư mục lưu Kịch Bản")
        if d:
            self.output_dir_path.set(d)

    def _check_readiness(self):
        self.start_btn.configure(state="normal")

    def save_prompt(self):
        txt = self.prompt_textbox.get("1.0", "end").strip()
        if not txt:
            messagebox.showwarning("Trống", "Chưa có nội dung câu lệnh để lưu.")
            return
        p = filedialog.asksaveasfilename(
            defaultextension=".txt",
            initialdir=self.output_dir_path.get() or os.getcwd(),
            filetypes=[("Text files", "*.txt")],
        )
        if p:
            with open(p, "w", encoding="utf-8") as f:
                f.write(txt)
            self.log_message(f"💾 Đã lưu câu lệnh vào: {p}")

    def start_full_auto_thread(self):
        v_path = self.video_path.get().strip()
        if not v_path or not os.path.exists(v_path):
            messagebox.showwarning("Thiếu video", "Vui lòng chọn file video mẫu hợp lệ trước.")
            return
        if not self.api_manager.keys:
            self.log_message("ℹ️ Chưa có Gemini API Key — tự động dùng Bộ Phân Tích Thị Giác Nội Bộ (OpenCV).")
        self.start_btn.configure(state="disabled")
        threading.Thread(target=self.run_full_auto_process, daemon=True).start()

    def run_full_auto_process(self):
        v_path = self.video_path.get().strip()
        try:
            self.update_status("Đang chia phân đoạn video...")
            segments = self.split_video(v_path, clip_duration=10, step_duration=8)
            if not segments:
                raise RuntimeError("Không trích xuất được khung hình nào từ video.")

            char_sheet = self.char_sheet_textbox.get("1.0", "end").strip()
            if self.consistency_var.get() and not char_sheet:
                self.update_status("Đang nhận diện nhân vật chính...")
                char_sheet = self._run_character_detection_logic(v_path)
                self._set_char_sheet_text(char_sheet)

            self.update_status(f"Đang phân tích {len(segments)} cảnh...")
            prompts = self._run_batch_analysis_logic(segments, char_sheet)
            final_text = "\n".join(prompts)
            self.clear_prompts_and_set(final_text)
            self.automatic_save_prompt()
            self.update_status("✅ Hoàn thành phân tích video!")
        except Exception as e:
            self.log_message(f"❌ Lỗi: {e}")
            self.update_status("Lỗi phân tích")
        finally:
            self.reset_ui()

    def _run_character_detection_logic(self, video_path: str) -> str:
        if cv2 is None or Image is None:
            return ""
        cap = cv2.VideoCapture(video_path)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        sample_count = min(16, max(4, total_frames // 30))
        frames = []
        for i in range(sample_count):
            pos = int((i / max(1, sample_count - 1)) * max(0, total_frames - 1))
            cap.set(cv2.CAP_PROP_POS_FRAMES, pos)
            ret, frame = cap.read()
            if ret:
                frames.append(self.resize_frame(frame))
        cap.release()
        if not frames:
            return ""
        resp = self.api_manager.generate([CHARACTER_DETECT_PROMPT] + frames)
        return (getattr(resp, "text", "") or "").strip()

    def _run_batch_analysis_logic(self, segments_data: list, char_sheet: str) -> list:
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
            futs = {
                ex.submit(self.analyze_single_segment, seg, idx + 1, char_sheet): idx + 1
                for idx, seg in enumerate(segments_data)
            }
            for fut in concurrent.futures.as_completed(futs):
                seg_num = futs[fut]
                try:
                    results[seg_num] = fut.result()
                    self.log_message(f"✅ Đã xong Cảnh {seg_num}/{len(segments_data)}")
                except Exception as e:
                    results[seg_num] = f"[ Cảnh {seg_num} ] Lỗi phân tích: {e}"
        return [results[i] for i in sorted(results)]

    def automatic_save_prompt(self):
        self._automatic_save_prompt_internal()

    def _automatic_save_prompt_internal(self):
        txt = self.prompt_textbox.get("1.0", "end").strip()
        if not txt:
            return
        v_stem = os.path.splitext(os.path.basename(self.video_path.get().strip() or "video"))[0]
        out_dir = self.output_dir_path.get().strip() or os.getcwd()
        os.makedirs(out_dir, exist_ok=True)
        out_file = os.path.join(out_dir, f"{v_stem}_prompts.txt")
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(txt)
        self.log_message(f"💾 Tự động lưu kết quả: {out_file}")

    def split_video(self, video_path: str, clip_duration: int = 10, step_duration: int = 8) -> list:
        """Tách video thành danh sách các đoạn, mỗi đoạn lấy 4 khung hình đại diện."""
        if cv2 is None or Image is None:
            raise RuntimeError("Thiếu thư viện opencv-python (cv2) hoặc Pillow (PIL).")
        cap = cv2.VideoCapture(video_path)
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        duration = total_frames / max(fps, 1.0)

        segments = []
        t = 0.0
        while t < duration:
            t_end = min(duration, t + clip_duration)
            frames = []
            for k in range(4):
                ts = t + (t_end - t) * (k / 3.0)
                cap.set(cv2.CAP_PROP_POS_MSEC, ts * 1000.0)
                ret, frame = cap.read()
                if ret:
                    frames.append(self.resize_frame(frame))
            if frames:
                segments.append({"start": t, "end": t_end, "frames": frames})
            t += step_duration
        cap.release()
        return segments

    def reset_ui(self):
        try:
            self.parent.after(0, lambda: self.start_btn.configure(state="normal"))
        except Exception:
            pass

    @staticmethod
    def resize_frame(frame, max_dim: int = 1152):
        h, w = frame.shape[:2]
        if max(h, w) > max_dim:
            scale = max_dim / float(max(h, w))
            frame = cv2.resize(frame, (int(w * scale), int(h * scale)))
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return Image.fromarray(rgb)

    def analyze_single_segment(self, segment_info: dict, segment_num: int, char_sheet: str) -> str:
        prompt_tmpl = META_PROMPT_V_SINGLE_LINE.format(
            segment_num=segment_num,
            aspect_ratio_str=self.selected_aspect.get(),
            selected_style=self.selected_style.get(),
            output_language=self.selected_language.get(),
            character_sheet=char_sheet or "(Không có bảng nhân vật cố định)",
        )
        resp = self.api_manager.generate([prompt_tmpl] + segment_info["frames"])
        text = (getattr(resp, "text", "") or "").strip()
        one_line = " ".join(ln.strip() for ln in text.splitlines() if ln.strip())
        if not one_line.startswith(f"[ Cảnh {segment_num}"):
            one_line = f"[ Cảnh {segment_num} ] {one_line}"
        return one_line

    def _set_char_sheet_text(self, text: str):
        def _apply():
            self.char_sheet_textbox.delete("1.0", "end")
            self.char_sheet_textbox.insert("1.0", text or "")

        self.parent.after(0, _apply)

    def log_message(self, message: str):
        ts = time.strftime("%H:%M:%S")

        def _apply():
            self.log_textbox.insert("end", f"[{ts}] {message}\n")
            self.log_textbox.see("end")

        try:
            self.parent.after(0, _apply)
        except Exception:
            pass

    def update_status(self, text: str):
        try:
            self.parent.after(0, lambda: self.status_lbl.configure(text=text))
        except Exception:
            pass

    def append_prompt(self, text: str):
        self.parent.after(0, lambda: self.prompt_textbox.insert("end", text + "\n"))

    def clear_prompts_and_set(self, text: str):
        def _apply():
            self.prompt_textbox.delete("1.0", "end")
            self.prompt_textbox.insert("1.0", text or "")

        self.parent.after(0, _apply)

    def clear_log(self):
        self.log_textbox.delete("1.0", "end")

    def clear_previous_session(self, ask_confirm: bool = False, delete_files: bool = True):
        """Làm sạch video mẫu, hồ sơ nhân vật và danh sách câu lệnh đã tách."""
        if ask_confirm:
            if not messagebox.askyesno("Làm sạch Video to prompt", "Bạn muốn xoá sạch đường dẫn video mẫu, hồ sơ nhân vật và câu lệnh đã tách không?"):
                return
        self.video_path.set("")
        self.char_sheet_textbox.delete("1.0", "end")
        self.prompt_textbox.delete("1.0", "end")
        self.clear_log()
        self.update_status("🧹 Đã làm sạch dữ liệu cũ.")


def build_tab(parent_frame, openai_client=None, gemini_model=None, *args, **kwargs):
    """Điểm vào chuẩn cho CineFlow AI Studio."""
    return _VideoPromptTabLogic(parent_frame, gemini_model_name=gemini_model, pipeline=kwargs.get("pipeline"))
