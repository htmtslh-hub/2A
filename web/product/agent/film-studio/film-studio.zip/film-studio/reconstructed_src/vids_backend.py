"""
vids_backend.py — Gọi API genai của Google (Docs / Vids) bằng cookie Google.
─────────────────────────────────────────────────────────────────────
Khác hẳn cách cũ của tool5 (labs.google):
  • KHÔNG dùng Bearer token, KHÔNG cần captcha NestJS.
  • Đăng nhập bằng cookie Google + header "SAPISIDHASH" tự tính theo giờ.

Cookie: xuất bằng extension Vids / Cookie-Editor (định dạng JSON) khi đang mở
docs.google.com, lưu thành file .json trong thư mục vids_cookies/
(mỗi file = 1 tài khoản), hoặc tự động đọc từ trình duyệt Chrome trên máy.
"""

import hashlib
import json
import os
import random
import re
import sys
import time
import uuid
from pathlib import Path

try:
    from curl_cffi import requests as cffi_requests
    _HAS_CFFI = True
except Exception:
    import requests as cffi_requests
    _HAS_CFFI = False

API_KEY = "AIzaSyA-njTXslyyMKk1VOogRfVP59F6fNGeNW8"
BASE = "https://appsgenaiserver-pa.clients6.google.com/v1/genai"
ORIGIN = "https://docs.google.com"
_IMPERSONATE = "chrome131"
VIDS_MODEL_NAME = "generate_videos_omni_t2v"

DEFAULT_CONFIG = {
    "authuser": "0",
    "x_server_token": "CAMSGhUR9NL9N67auQayvgSuUb6_BqcGt6CSAB0H",
    "x_browser_validation": "Nvr5k+iFMPN1OOuTAQHMfJ+Q6a8=",
    "x_client_data": "CKmdygEIlqHLAQiFoM0BCLDilDAIlueUMAjW6JQwCP7plDAYqN6UMA==",
    "quota_body": [None, 1, [9, 343], None, [None, "1", 1241]],
    "doc_id": "",
    "doc_ids": {},
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36",
}

_CHAR_TAG_IN_PROMPT = re.compile(r"\[([A-Za-z0-9_\-]{1,32})\]")
_CHAR_PREFIX = re.compile(r"^\s*([A-Za-z0-9_\-]+(?:\s*,\s*[A-Za-z0-9_\-]+)*)\s*\|\s*(.*)$", re.DOTALL)
_VIDEO_CODE = {}


def _app_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def url_with_filename(url: str, name: str) -> str:
    """Đổi tham số filename= trong link tải sang tên mình muốn."""
    if re.search(r"[?&]filename=", url):
        return re.sub(r"([?&]filename=)[^&]*", lambda m: m.group(1) + name, url)
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}filename={name}"


def doc_id_of(value: str) -> str:
    """Nhận id trần hoặc cả link docs.google.com/videos/d/<id>/edit…"""
    v = (value or "").strip()
    m = re.search(r"/d/([A-Za-z0-9_-]{20,})", v)
    return m.group(1) if m else v


class CharacterStore:
    def __init__(self):
        self.path = os.path.join(_app_dir(), "vids_characters.json")
        self.data = {}
        self.load()

    def load(self):
        try:
            if os.path.isfile(self.path):
                with open(self.path, "r", encoding="utf-8") as f:
                    self.data = json.load(f) or {}
        except Exception:
            self.data = {}

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def put(self, tag: str, image_path: str, blob: str, name: str = ""):
        t = tag.strip().upper()
        self.data[t] = {
            "uuid": str(uuid.uuid4()),
            "blob": blob,
            "name": name or f"Hình ảnh {t}",
            "image_path": image_path,
            "ts": int(time.time()),
        }
        self.save()

    def get(self, tag: str):
        return self.data.get(tag.strip().upper())

    def delete(self, tag: str):
        self.data.pop(tag.strip().upper(), None)
        self.save()

    def all_tags(self):
        return sorted(self.data.keys())


def resolve_tags(prompt: str):
    """Tách nhân vật khỏi prompt, nhận CẢ 2 kiểu:
      • Prefix:  'CHAR_01,CHAR_03 | nội dung'   (NOCHAR = không gắn ảnh)
      • Ngoặc:   '[CHAR_01] nội dung'
    Trả (prompt_sạch, [TAG…]) — giữ thứ tự, bỏ trùng, bỏ NOCHAR."""
    text = (prompt or "").strip()
    tags = []
    m = _CHAR_PREFIX.match(text)
    if m:
        raw_tags, text = m.group(1), m.group(2).strip()
        for t in raw_tags.split(","):
            tu = t.strip().upper()
            if tu and tu != "NOCHAR" and tu not in tags:
                tags.append(tu)
    for mm in _CHAR_TAG_IN_PROMPT.finditer(text):
        tu = mm.group(1).strip().upper()
        if tu and tu != "NOCHAR" and tu not in tags:
            tags.append(tu)
    clean = _CHAR_TAG_IN_PROMPT.sub(lambda x: x.group(1), text).strip()
    return clean, tags


def load_config() -> dict:
    """Đọc vids_config.json (tạo mới từ giá trị mặc định nếu chưa có)."""
    path = os.path.join(_app_dir(), "vids_config.json")
    cfg = dict(DEFAULT_CONFIG)
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                saved = json.load(f) or {}
            for k, v in saved.items():
                if v is not None:
                    cfg[k] = v
        except Exception as e:
            print(f"[VIDS] ⚠️ vids_config.json lỗi, dùng mặc định: {e}")
    else:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=2, ensure_ascii=False)
        except Exception:
            pass
    return cfg


def parse_cookies(text: str) -> dict:
    """Nhận JSON của Cookie-Editor / Vids Extension, hoặc chuỗi 'a=1; b=2' (header Cookie)."""
    t = (text or "").strip()
    out = {}
    if not t:
        return out
    if t.startswith("[") or t.startswith("{"):
        data = json.loads(t)
        if isinstance(data, dict):
            if "cookies" in data and isinstance(data["cookies"], list):
                data = data["cookies"]
            else:
                return {str(k): str(v) for k, v in data.items()}
        if isinstance(data, list):
            for c in data:
                if isinstance(c, dict) and c.get("name"):
                    dom = str(c.get("domain") or "")
                    if not dom or "google.com" in dom:
                        out[str(c["name"])] = str(c.get("value") or "")
            return out
    for part in t.split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            k = k.strip()
            if k:
                out[k] = v.strip()
    return out


def cookies_from_chrome(log=print) -> dict:
    """Đọc thẳng cookie google.com từ Chrome đang cài trên máy."""
    try:
        import browser_cookie3
    except ImportError:
        return {}
    for name in ("chrome", "edge", "brave", "chromium"):
        loader = getattr(browser_cookie3, name, None)
        if not loader:
            continue
        try:
            jar = loader(domain_name="google.com")
            got = {c.name: c.value for c in jar if "google.com" in (c.domain or "")}
            if got.get("SAPISID") or got.get("__Secure-3PAPISID"):
                log(f"🍪 Lấy được {len(got)} cookie google.com từ {name}")
                return got
        except Exception:
            pass
    return {}


def load_accounts(log=print) -> dict[str, dict]:
    """Nguồn cookie, theo thứ tự ưu tiên:
      1. Các file trong vids_cookies/  (mỗi file = 1 tài khoản)
      2. Nếu không có file nào → đọc thẳng từ Chrome trên máy."""
    folder = Path(_app_dir()) / "vids_cookies"
    folder.mkdir(exist_ok=True)
    accs = {}
    for p in sorted(folder.iterdir()):
        if p.suffix.lower() in (".json", ".txt"):
            try:
                ck = parse_cookies(p.read_text(encoding="utf-8", errors="ignore"))
                if ck.get("SAPISID") or ck.get("__Secure-3PAPISID"):
                    accs[p.stem] = ck
            except Exception as e:
                log(f"⚠️ Bỏ qua {p.name}: {e}")
    if not accs:
        ck = cookies_from_chrome(log=log)
        if ck:
            accs["Chrome"] = ck
    return accs


def load_account(name: str) -> dict:
    accs = load_accounts(log=lambda _x: None)
    return accs.get(name, {})


def playwright_cookies(name: str) -> list[dict]:
    """Đọc file cookie gốc vids_cookies/<name>.json → định dạng Playwright."""
    folder = Path(_app_dir()) / "vids_cookies"
    for ext in (".json", ".txt"):
        p = folder / f"{name}{ext}"
        if p.is_file():
            try:
                raw = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
                if isinstance(raw, dict) and "cookies" in raw:
                    raw = raw["cookies"]
                if isinstance(raw, list):
                    ss_map = {
                        "no_restriction": "None",
                        "unspecified": "Lax",
                        "lax": "Lax",
                        "strict": "Strict",
                        "none": "None",
                    }
                    out = []
                    for item in raw:
                        if not isinstance(item, dict) or not item.get("name"):
                            continue
                        c = {
                            "name": str(item["name"]),
                            "value": str(item.get("value") or ""),
                            "domain": str(item.get("domain") or ".google.com"),
                            "path": str(item.get("path") or "/"),
                            "secure": bool(item.get("secure", True)),
                            "httpOnly": bool(item.get("httpOnly", False)),
                        }
                        ss = str(item.get("sameSite") or "Lax").lower()
                        c["sameSite"] = ss_map.get(ss, "Lax")
                        exp = item.get("expirationDate") or item.get("expires")
                        if exp:
                            c["expires"] = float(exp)
                        out.append(c)
                    return out
            except Exception:
                pass
    return []


def _one_hash(ts: int, secret: str, origin: str) -> str:
    h = hashlib.sha1(f"{ts} {secret} {origin}".encode("utf-8")).hexdigest()
    return f"{ts}_{h}"


def sapisid_authorization(cookies: dict, origin: str = ORIGIN) -> str:
    ts = int(time.time())
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID")
    if not sapisid:
        raise ValueError("Cookie thiếu SAPISID — xuất lại cookie khi ĐÃ đăng nhập Google.")
    parts = [f"SAPISIDHASH {_one_hash(ts, sapisid, origin)}"]
    p1 = cookies.get("__Secure-1PAPISID")
    if p1:
        parts.append(f"SAPISID1PHASH {_one_hash(ts, p1, origin)}")
    p3 = cookies.get("__Secure-3PAPISID")
    if p3:
        parts.append(f"SAPISID3PHASH {_one_hash(ts, p3, origin)}")
    return " ".join(parts)


class VidsBackend:
    def __init__(self, cookies: dict, config: dict = None, name: str = ""):
        self.cookies = cookies or {}
        self.cfg = config or load_config()
        self.name = name

    def _headers(self) -> dict:
        hdr = {
            "accept": "*/*",
            "accept-language": "en",
            "authorization": sapisid_authorization(self.cookies, ORIGIN),
            "content-type": "application/json+protobuf",
            "origin": ORIGIN,
            "referer": f"{ORIGIN}/",
            "priority": "u=1, i",
            "x-browser-channel": "stable",
            "x-browser-copyright": "Copyright 2026 Google LLC. All Rights Reserved.",
            "x-browser-year": "2026",
            "x-goog-authuser": str(self.cfg.get("authuser", "0")),
            "sec-ch-ua": '"Google Chrome";v="153", "Not_A Brand";v="8", "Chromium";v="153"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": self.cfg.get("user_agent", DEFAULT_CONFIG["user_agent"]),
        }
        for k, hk in (
            ("x_server_token", "x-server-token"),
            ("x_browser_validation", "x-browser-validation"),
            ("x_client_data", "x-client-data"),
        ):
            val = self.cfg.get(k)
            if val:
                hdr[hk] = str(val)
        return hdr

    def _post(self, path: str, body: list, timeout: int = 60):
        url = f"{BASE}/{path}?key={API_KEY}"
        data = json.dumps(body, separators=(",", ":"), ensure_ascii=False)
        kw = {
            "data": data.encode("utf-8"),
            "headers": self._headers(),
            "cookies": self.cookies,
            "timeout": timeout,
        }
        if _HAS_CFFI:
            kw["impersonate"] = _IMPERSONATE
        r = cffi_requests.post(url, **kw)
        return r.status_code, r.text

    def quota_summary(self):
        """Trả (ok, status_code, text)."""
        code, text = self._post("quotaSummary", self.cfg.get("quota_body", DEFAULT_CONFIG["quota_body"]), timeout=25)
        return code == 200, code, text

    def doc_id(self) -> str:
        ids = self.cfg.get("doc_ids") or {}
        if self.name and self.name in ids:
            return doc_id_of(ids[self.name])
        return doc_id_of(self.cfg.get("doc_id") or "")

    @staticmethod
    def _find_download_url(obj):
        if isinstance(obj, str):
            if obj.startswith("https://contribution-") and "usercontent.google.com/download" in obj:
                return obj
        elif isinstance(obj, list):
            for x in obj:
                r = VidsBackend._find_download_url(x)
                if r:
                    return r
        elif isinstance(obj, dict):
            for x in obj.values():
                r = VidsBackend._find_download_url(x)
                if r:
                    return r
        return None

    def _audio_ctx(self) -> list:
        """ctx dùng chung cho audio (254 voice + 326 chèn thẻ). Không có doc_id,
        ctx[11]=[16,0] (audio)."""
        req_id = f"goog_{random.randint(1000000000, 1999999999)}"
        ctx = [None] * 24
        ctx[1] = req_id
        ctx[9] = [1, None, [[None, "1", 1241]]]
        ctx[11] = [16, 0]
        return ctx

    def _voice_body(self, text: str, voice: str = "Kore") -> list:
        """Body tạo voice (số đầu 254). opts cuối = [tên giọng]. Khớp request thật."""
        return [254, self._audio_ctx(), [[text]], None, [voice]]

    def add_emotion_tags(self, text: str, timeout: int = 45) -> str:
        """Lệnh 326 — Google tự chèn [happy]/[serious]/[admiration]… vào text.
        Trả text ĐÃ chèn thẻ, hoặc text gốc nếu lỗi."""
        body = [326, self._audio_ctx(), [[text]]]
        try:
            code, resp = self._post("generate", body, timeout=timeout)
            if code != 200:
                return text
            data = json.loads(resp)

            def _first_str(o):
                if isinstance(o, str) and len(o.strip()) >= max(4, len(text.strip()) // 2):
                    return o.strip()
                if isinstance(o, list):
                    for x in o:
                        r = _first_str(x)
                        if r:
                            return r
                return None

            out = _first_str(data)
            return out or text
        except Exception:
            return text

    def generate_voice(self, text: str, voice: str = "Kore", timeout: int = 90):
        """Tạo voice từ text (có thể chèn [happy]/[serious]… để đổi cảm xúc).
        Trả ("OK", url_music_wav) hoặc ("FAIL", lý_do)."""
        body = self._voice_body(text, voice)
        try:
            code, resp = self._post("generate", body, timeout=timeout)
        except Exception as e:
            return "FAIL", f"TIMEOUT sau {timeout}s: {e}"
        if code != 200:
            return "FAIL", f"HTTP {code} | {resp[:240]}"
        try:
            data = json.loads(resp)
        except Exception:
            return "FAIL", f"Response lạ: {resp[:200]}"
        url = self._find_download_url(data)
        if not url:
            return "FAIL", f"Không có link voice | {resp[:240]}"
        return "OK", url

    def download(self, url: str, save_path: str, min_size: int = 2000):
        """Tải file âm thanh/video về, ghi .part rồi đổi tên."""
        sep = "&" if "?" in url else "?"
        full_url = url if "authuser=" in url else f"{url}{sep}authuser={self.cfg.get('authuser', '0')}"
        part = save_path + ".part"
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)

        # Thử 1: Playwright Chromium headless nếu có cookie đầy đủ
        cks = playwright_cookies(self.name)
        if cks:
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    ctx = browser.new_context()
                    ctx.add_cookies(cks)
                    page = ctx.new_page()
                    with page.expect_download(timeout=60000) as download_info:
                        page.evaluate(
                            f"const a = document.createElement('a'); a.href = '{full_url}'; a.download = ''; document.body.appendChild(a); a.click();"
                        )
                    dl = download_info.value
                    dl.save_as(part)
                    browser.close()
                if os.path.isfile(part) and os.path.getsize(part) >= min_size:
                    os.replace(part, save_path)
                    return True, save_path
            except Exception:
                pass

        # Thử 2: Tải trực tiếp bằng curl_cffi / requests kèm cookie & SAPISIDHASH
        try:
            kw = {
                "headers": self._headers(),
                "cookies": self.cookies,
                "timeout": 90,
                "allow_redirects": True,
            }
            if _HAS_CFFI:
                kw["impersonate"] = _IMPERSONATE
            r = cffi_requests.get(full_url, **kw)
            if r.status_code == 200 and len(r.content) >= min_size:
                with open(part, "wb") as f:
                    f.write(r.content)
                os.replace(part, save_path)
                return True, save_path
            return False, f"HTTP {r.status_code}, {len(r.content)}B"
        except Exception as e:
            return False, str(e)


def parse_quota(text: str) -> dict | None:
    """Đọc response quotaSummary, dạng:
    [[null,["500",null,"460",1,null,null,["1790838000"],0],"40",[9],...]]"""
    try:
        d = json.loads(text)
        m = re.search(r'\["(\d+)",\s*null,\s*"(\d+)"(?:,\s*\d+,\s*null,\s*null,\s*\["(\d+)"\])?', text)
        if m:
            total = int(m.group(1))
            rem = int(m.group(2))
            rst_ts = int(m.group(3)) if m.group(3) else 0
            rst_str = time.strftime("%d/%m/%Y %H:%M", time.localtime(rst_ts)) if rst_ts else "N/A"
            return {
                "total": total,
                "remaining": rem,
                "used": max(0, total - rem),
                "reset": rst_str,
            }
    except Exception:
        pass
    return None
