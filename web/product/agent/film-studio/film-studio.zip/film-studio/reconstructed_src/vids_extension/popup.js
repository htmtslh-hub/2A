// Popup: bấm nút → gom cookie google.com + link file Vids đang mở → copy clipboard.
// Chỉ chạy khi người dùng bấm, chỉ đọc cookie google.com, chỉ copy vào clipboard.
document.getElementById("open").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://docs.google.com/videos" });
});

document.getElementById("grab").addEventListener("click", async () => {
  const msg = document.getElementById("msg");
  const out = document.getElementById("out");
  msg.textContent = "Đang lấy…";
  try {
    // Tìm tab file Vids trong TẤT CẢ tab đang mở (không cần đang đứng ở đó)
    let doc = "";
    try {
      const tabs = await chrome.tabs.query({ url: "https://docs.google.com/videos/*" });
      for (const t of tabs) {
        const m = (t.url || "").match(/docs\.google\.com\/videos\/d\/([A-Za-z0-9_-]{20,})/);
        if (m) { doc = `https://docs.google.com/videos/d/${m[1]}/edit`; break; }
      }
    } catch (e) {}

    // Lấy cookie của các domain google.com (gồm cả HttpOnly)
    const jars = await Promise.all([
      chrome.cookies.getAll({ domain: "google.com" }),
      chrome.cookies.getAll({ domain: ".google.com" }),
    ]);
    const seen = new Set();
    const cookies = [];
    for (const arr of jars) {
      for (const c of arr) {
        if (seen.has(c.name)) continue;
        seen.add(c.name);
        // Xuất ĐẦY ĐỦ thuộc tính để Chrome nền (tool) đăng nhập được
        cookies.push({
          name: c.name, value: c.value, domain: c.domain,
          path: c.path || "/", secure: !!c.secure, httpOnly: !!c.httpOnly,
          sameSite: c.sameSite || "no_restriction",
          expirationDate: c.expirationDate,
        });
      }
    }
    const blob = JSON.stringify({ doc, cookies });
    out.value = blob;
    await navigator.clipboard.writeText(blob).catch(() => {});
    const hasSap = cookies.some((c) => c.name === "SAPISID");
    msg.textContent = `✅ Đã copy ${cookies.length} cookie` +
      (doc ? " + link Vids." : " (⚠ chưa mở đúng tab file Vids nên THIẾU link).") +
      (hasSap ? "" : " ⚠ thiếu SAPISID — đăng nhập Google trước.");
  } catch (e) {
    msg.textContent = "Lỗi: " + e;
  }
});
