# Aerox Studio 1.1.0

Independent motorcycle showcase inspired by the supplied reference. Plain HTML/CSS/JS, no build or backend. Read CUSTOMISE.md first for ten steps, twelve prompts and the exact edit map. Open index.html directly or use a static server.

## Included

Six standard source/document files plus four local WebP images in assets/img. No external fonts, scripts or network dependency for rendering. System font stacks vary across devices.

## Working behaviour

Responsive menu, section navigation, concept finish switching, three-image gallery, arrow-key gallery controls, native enlarge-image dialog, hover feedback and finite scroll reveals. All images are AI-generated. Graphite is a grayscale concept. Dealer links open the manufacturer website; no booking, payments, model database, live pricing or form submission. Navigation and content work without JS; presentation controls are disabled.

## Customise and motion

See CUSTOMISE.md. Motion defaults on by project policy and uses finite RAF fallback; no autoplay. Source metadata, copy, price and brand references must be reviewed before use.

## Status

Candidate for local review. See reviews/1.1.0 outside source for actual browser checks and limitations. No claim of official Yamaha affiliation, image accuracy certification or >95% visual fidelity. Commercial brand/image terms and copyright owner remain to be confirmed.

Concept finish transitions take 1.1 seconds. Adjust the duration in animate(bike, 1100, ...) in assets/js/main.js. Gallery and scroll reveal timings are unchanged.

The hero uses a manual carousel with two concept finishes. Left/right controls slide out the current bike, then slide in the next from the opposite edge over 1.1 seconds. Both directions loop directly at the ends. Nothing advances automatically. Clicking the selected dot does nothing; rapid actions cancel the previous transition. The Graphite variant remains a grayscale visualisation of the same scooter.
