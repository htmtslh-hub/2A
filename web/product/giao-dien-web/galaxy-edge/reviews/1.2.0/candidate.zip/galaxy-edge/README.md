# Galaxy Edge 1.2.0

Static fictional frontier travel template, inspired by the composition of the supplied screenshot and using an AI-generated cinematic hero background.

## Start

Read CUSTOMISE.md for the ten-step guide, twelve AI prompts and exact edit map. Open index.html directly or serve this folder with any static server. No installation, build or account is needed.

## Included

index.html, assets/css/style.css, assets/js/main.js, README.md, CUSTOMISE.md and LICENCE.txt, plus assets/img/galaxy-hero.webp. No remote fonts, images, scripts or tracking. Font stacks use system fonts.

## Working behaviour

Responsive navigation, Escape to close and return focus, section links, skip link and finite scroll reveals. Without JavaScript all content and navigation remain visible. The preview and round arrows link to sections. Packages are illustrative; no video, search, booking, forms or payment processing is included.

## Customise

Edit the copy and remaining SVG in index.html; replace the local hero image at assets/img/galaxy-hero.webp; colours, fonts and layout tokens in assets/css/style.css. See the literal counts in CUSTOMISE.md.

## Motion

Project policy enables finite reveals by default even when the OS requests reduced motion. No continuous animation or saved motion preference.

## Verification

See the internal reviews/1.2.0 report outside the customer source folder for the actual tested browser versions and limitations. Safari, Edge and Cốc Cốc are not claimed as tested. This is a candidate pending verification, not a certified pixel-identical reproduction.

## Hover and scroll motion

Navigation underlines, cyan link feedback, button lift, preview zoom and panel borders provide hover/focus feedback. The hero background moves up to 55px (22px on mobile) and scales up to 1.045 with scroll progress. Section, panel and article reveals run once. Scroll work uses one requestAnimationFrame per event burst and stops when idle; no perpetual loop. These effects default on by project policy. Edit hover styles at the end of assets/css/style.css and travel values in assets/js/main.js.
