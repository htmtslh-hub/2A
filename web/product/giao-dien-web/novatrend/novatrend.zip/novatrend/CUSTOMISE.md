## COD checkout quick start — 1.2.0

Read the **COD setup** section below before accepting orders. The package now includes assets/js/shop-config.js, assets/js/commerce.js and assets/css/commerce.css. Attach the whole current ZIP when asking AI to edit it.

# NovaTrend customisation guide

This guide takes you from the downloaded ZIP file to a website you can publish. Follow the steps in order the first time. Every AI prompt below is complete: copy it, attach the requested files, and replace the information in square brackets.

## Before you begin

Prepare a computer, a modern browser, a text editor, and the ZIP file from your Forge Zone account. Keep the original ZIP unchanged. Never send passwords, API keys, payment details, or private customer data to an AI tool.

Your template is a static website built with HTML, CSS, and JavaScript. It does not include a backend, payment processing, or a working form submission service unless the product page explicitly says so.

## Step 1 - Unzip and open the template

1. Download the ZIP file to a folder you can find easily.
2. Extract the whole ZIP. On Windows choose **Extract All**. On macOS double-click the ZIP.
3. Open the extracted folder until you see `index.html` beside the `assets` folder.
4. Double-click `index.html`. If it opens in a text editor, use **Open with** and choose your browser.
5. Scroll through the full page and try the menu and links before changing anything.
6. Open `README.md` and `CUSTOMISE.md` in a text editor.

Expected structure:

```text
template-folder/
├── index.html
├── assets/
│   ├── css/style.css
│   └── js/main.js
├── CUSTOMISE.md
├── README.md
└── LICENCE.txt
```

**Correct result:** the demo layout, colours, and sample content are visible. A `file:///` address is normal because the page is opening on your computer.

If you only see plain text or a broken page, confirm that you extracted the complete ZIP and that `assets` is still next to `index.html`.

## Step 2 - Keep the original and make a working copy

1. Keep the downloaded ZIP as your clean original.
2. Copy the extracted template folder and name the copy `website-working-copy`.
3. Edit only the working copy. Do not rename `index.html`, `assets/css/style.css`, or `assets/js/main.js`.
4. Before a major change, copy the working folder to a separate folder such as `website-backup-01`.
5. Save files as UTF-8 and keep their real extension. Avoid names such as `index.html.txt`.

**Correct result:** you have an untouched original and a separate working copy. Save each change, then refresh the browser to see it.

## Step 3 - Prepare your business information

Collect the information below. You may give it directly to AI in plain language.

| Information | What to prepare |
|---|---|
| Brand name | The name shown in the header and browser tab |
| Main activity | What you sell or provide |
| Audience | The people you want to reach |
| Main benefit | A specific reason to choose your business |
| Products or services | Names, descriptions, and public prices if applicable |
| Contact details | Public email, phone number, and address |
| Main action | Email, phone call, booking page, or another real URL |
| Language | English, Vietnamese, Chinese, or another language |
| Brand assets | Logo, brand colours, and images you may legally use |
| Evidence | Real statistics, testimonials, and certifications only |

It is fine to leave an item undecided while editing, but resolve it before publication. Do not present demo statistics or testimonials as your own.

## Step 4 - Start working with AI

### Send the files

In a chat tool, attach the working ZIP if the tool can read ZIP files. Otherwise attach `index.html`, `style.css`, `main.js`, `CUSTOMISE.md`, `README.md`, and `LICENCE.txt`. Explain that CSS is at `assets/css/style.css` and JavaScript is at `assets/js/main.js`.

If the AI works directly in a folder, open or grant access to `website-working-copy`. Ask it to read the files before editing. A screenshot helps explain a visual problem, but it does not replace the source files.

**Prompt 01 - Set up my website editing assistant**

```text
I bought a static website template from Forge Zone and want to turn it into
my own website. I am not a developer. Guide me in clear, small steps.

First read every file I provide: index.html, assets/css/style.css,
assets/js/main.js, CUSTOMISE.md, README.md, and LICENCE.txt. If I send CSS or
JavaScript as separate files, use the paths above. Tell me which files you
read and which are missing. Do not guess the contents of a missing file and
do not edit anything yet.

Summarise the current sections, working buttons, demo-only elements, and all
sample information that I must replace. Then ask me for the missing business
information in small groups: brand, services, contact details, language, and
the website goal. Let me answer "not decided" when needed.

Throughout this task:
- Keep the current plain HTML, CSS, and JavaScript structure, relative paths,
  and the ability to open index.html directly. Do not introduce a framework,
  package manager, build process, or new dependency.
- Preserve the template style unless I request a change. Keep responsive
  behaviour, keyboard navigation, visible focus, readable text, and reduced
  motion support.
- Never invent facts, statistics, reviews, certifications, prices, addresses,
  or business URLs.
- Do not add tracking, a backend, payments, or hidden form submission.
- If you can edit the folder, edit only the working copy. Otherwise return
  complete replacement files and state the exact destination of each file.
  Never use ellipses or say "keep the rest unchanged" inside file contents.
- After every edit, list what changed, how I can view it, and what you tested.
- Do not publish, overwrite a live site, or change domain settings.

Begin by reading the files and asking for the first group of information.
```

**Correct result:** AI identifies the actual template files and asks for your information. If it suggests rebuilding with a framework, repeat the instruction to preserve the current structure.

## Step 5 - Replace the brand, copy, and contact actions

Give AI verified business information. If something is missing, ask it to remove the claim or mark it clearly for later review. Then use these prompts in the same conversation.

**Prompt 02 - Personalise all website content**

```text
Use the latest website files in this conversation. Replace the demo brand and
copy with the verified information below:

Brand: information you provide (ask me if missing)
What we offer: information you provide (ask me if missing)
Audience: information you provide (ask me if missing)
Main benefit: information you provide (ask me if missing)
Tone: information you provide (ask me if missing)
Public contact details: information you provide (ask me if missing)
Main action: information you provide (ask me if missing)
Required language: information you provide (ask me if missing)

Before editing, list any information still missing and any demo claim that
cannot be supported. Then update the page title, metadata, navigation, hero,
sections, calls to action, contact details, footer, image alt text, and any
accessible labels. Keep the existing layout and responsive behaviour. Remove
unsupported statistics, testimonials, prices, certifications, and locations
instead of inventing replacements. Return complete changed files and a list
of every demo item you removed or still need me to confirm.
```

**Prompt 03 - Connect every button to the right destination**

```text
Audit every button, text link, menu item, email link, phone link, and form in
the latest files. Create a table with its visible label, current destination,
whether it works, and the destination it should use.

Use only these verified destinations:
Primary action: information you provide (ask me if missing)
Secondary action: information you provide (ask me if missing)
Social links: information you provide (ask me if missing)

Then update the files. Use mailto: for email, tel: for phone, and secure https
URLs for external pages. Keep internal section links working. If a form has no
real submission service, label it as a demo or replace it with a working
contact link. Do not simulate success. Return complete changed files and a
short click-test checklist.
```

## Step 6 - Change colours, fonts, images, or sections when needed

Make one type of visual change at a time and refresh the page after each one. Attach the latest files every time you start a new AI chat.

**Prompt 04 - Apply my colours and fonts safely**

```text
Read the latest HTML and CSS first. Apply this brand system while preserving
the template layout and responsive behaviour:

Primary colour: information you provide (ask me if missing)
Accent colour: information you provide (ask me if missing)
Background colour: information you provide (ask me if missing)
Text colour: information you provide (ask me if missing)
Heading font: information you provide (ask me if missing)
Body font: information you provide (ask me if missing)

Reuse existing CSS variables where possible. Check text contrast, buttons,
links, focus states, hover states, borders, dark sections, and mobile views.
Use sensible fallback fonts and do not add a paid font unless I confirm a
licence. Return the complete CSS file, any required HTML changes, and note any
colour pair that still needs review.
```

**Prompt 05 - Replace the logo or illustration with my image**

```text
I will attach the latest website files and my image. The image is intended for
information you provide (ask me if missing) and I have permission to use it.

Inspect the current image container before editing. Tell me the recommended
file name, format, dimensions, and exact folder. Then update the relevant HTML
and CSS using a relative path. Preserve aspect ratio, prevent layout shift,
write accurate alt text, and keep the result readable on desktop, tablet, and
mobile. Do not crop important content without telling me. Return complete
changed files and exact instructions for where I should place the image.
```

**Prompt 06 - Translate the whole website**

```text
Translate every visitor-facing string in the latest website into information you provide (ask me if missing).
This includes metadata, navigation, headings, paragraphs, buttons, labels,
form messages, image alt text, accessibility labels, and footer text.

Keep brand names, registered product names, email addresses, phone numbers,
and URLs unchanged unless I provide replacements. Preserve HTML structure,
class names, IDs, paths, and JavaScript behaviour. Adapt wording naturally
rather than translating word by word. After editing, check for text overflow
at 360 px and on desktop. Return complete changed files and list any phrase
whose meaning needs my confirmation.
```

**Prompt 07 - Add or remove a service or section**

```text
Use the latest website files. I want to information you provide (ask me if missing) this item or section:
information you provide (ask me if missing).

First identify the complete HTML block and any matching CSS or JavaScript.
Explain the smallest safe change. Then edit without leaving empty wrappers,
broken anchors, unused navigation links, or JavaScript errors. Keep spacing,
visual hierarchy, responsive behaviour, keyboard access, and keyboard navigation.
If adding an item would make the layout uneven, adjust the existing grid
rules instead of duplicating arbitrary styles. Return complete changed files
and a checklist for desktop and mobile.
```

## Step 7 - Test before publishing

Test the website at a narrow phone width, a tablet width, and a wide desktop. Check navigation, all links, readable text, image loading, keyboard focus, and keyboard navigation.

**Prompt 08 - Audit the final website**

```text
Audit the latest website files as a final pre-publication review. Do not make
changes until you report the findings.

Check: missing files and broken relative paths; leftover demo names, sample
text, placeholder prices, fake reviews, and placeholder URLs; page title and
description; heading order; alt text; labels; keyboard navigation and visible
focus; colour contrast; menu and button behaviour; horizontal overflow at
360 px; tablet and desktop layout; keyboard navigation; console errors; external
links; mailto and tel links; and whether any form only pretends to submit.

Group findings as Blocker, Should fix, or Optional. For each finding name the
file and exact text or selector. After I approve the list, fix the Blocker and
Should fix items, return complete changed files, and provide a manual test
checklist. Do not publish the website.
```

## Step 8 - Publish by uploading the website folder

Choose a host that supports static websites. Upload the contents of the working folder so `index.html` is at the published root. Do not upload only the HTML file; the `assets` folder must travel with it.

**Prompt 09 - Guide me through publishing**

```text
Guide me through publishing this static HTML/CSS/JavaScript website on
information you provide (ask me if missing). I am not a developer. Use the provider's current screen
labels only when you are sure of them; otherwise tell me what concept to look
for instead of guessing.

My website folder contains index.html and an assets folder. First ask what I
can see in my hosting dashboard and whether I am uploading manually, using a
Git repository, or using the provider's command line. Then give one small step
at a time. Explain exactly which folder contents to upload, how to recognise a
successful deployment, and how to find the public URL. Do not ask for my
password, API key, recovery code, or payment details. Do not change domain
settings until I request it. Finish with checks for the home page, CSS,
JavaScript, images, links, mobile layout, and HTTPS.
```

**Correct result:** the public URL opens the same page as your local working copy, including CSS, JavaScript, and images.

## Step 9 - Connect a custom domain if needed

Publish successfully on the host's temporary URL first. Then connect your domain. DNS changes may take time, so keep the working deployment available while waiting.

**Prompt 10 - Connect my domain using the real configuration**

```text
Help me connect my custom domain to the static website already published on
information you provide (ask me if missing). My domain is managed at information you provide (ask me if missing).

Do not invent DNS values. First ask me to copy the exact domain instructions
shown by my hosting provider, including record type, name/host, target/value,
and whether a www record is required. Ask me to hide account IDs or private
tokens. Compare those instructions with the records I can see and explain one
change at a time. Warn me before replacing an existing record and do not tell
me to remove email-related MX or TXT records. After the change, show me how to
verify the root domain, www version, HTTPS certificate, and redirect behaviour.
```

## Step 10 - Update and recover safely

Keep one known-good backup for every published version. Make changes in a fresh working copy, test locally, and publish only the changed website files.

**Prompt 11 - Update one part and preserve everything else**

```text
Read the latest published-source files I attach. Change only this item:
information you provide (ask me if missing).

Preserve all other approved copy, links, layout, colours, responsive rules,
accessibility behaviour, and file paths. Before editing, name the file and the
smallest block that needs to change. After editing, return complete changed
files, summarise the exact difference, and tell me how to test it locally.
Do not publish or alter domain settings.
```

**Prompt 12 - Find and fix a website problem**

```text
Help me diagnose a problem in my static website. I will attach the latest
files and provide:
- What I expected: information you provide (ask me if missing)
- What happened: information you provide (ask me if missing)
- Where it happens: information you provide (ask me if missing)
- When it started: information you provide (ask me if missing)
- Any browser error: information you provide (ask me if missing)

Read the files before suggesting a fix. Identify the most likely cause and
show the evidence in the code. Prefer the smallest fix and do not rewrite the
site or add dependencies. Preserve the current design and responsive rules.
Return complete changed files and give me a short test to confirm the problem
is fixed. If the evidence is insufficient, ask for one specific screenshot,
console message, or file instead of guessing.
```

## Quick troubleshooting

| Problem | First check |
|---|---|
| Page has no styling | Confirm `assets/css/style.css` exists and the HTML path is unchanged |
| Images do not appear | Check file name, extension, letter case, and relative path |
| A button does nothing | Inspect its real `href` or JavaScript and remove demo behaviour |
| Mobile layout is too wide | Look for fixed widths and test at 360 px |
| Changes are not visible | Save the correct file and hard refresh the browser |
| Published site shows 404 | Put `index.html` at the publish root and check host settings |
| AI changed too much | Restore the backup and use Prompt 11 with a narrower request |

## Final checklist

- [ ] The original ZIP and a known-good backup are stored safely.
- [ ] All demo brands, copy, statistics, testimonials, prices, and URLs are replaced or removed.
- [ ] The page title, description, contact details, links, and calls to action are correct.
- [ ] Every image loads and has suitable alt text.
- [ ] The site works at 360 px, tablet size, and desktop size without horizontal overflow.
- [ ] Menu, buttons, keyboard focus, and keyboard navigation work correctly.
- [ ] No form pretends to submit and no unsupported feature is promised.
- [ ] The public URL loads HTML, CSS, JavaScript, images, and HTTPS correctly.
- [ ] The latest published source is backed up before the next change.


## NovaTrend specifics

The catalog has trending products across multiple lifestyle categories (Fashion, Electronics, Beauty, Fitness, Home Decor, Accessories). Cart, wishlist, category filtering, and search run locally with JavaScript; payments, stock, and backend accounts are simulated for client presentation.

Product names, USD prices, and image paths can be updated in both `index.html` and `assets/js/main.js`.
- In `index.html`, product cards specify data attributes such as `data-id`, `data-category`, and `data-price` (in integer cents, e.g. 5999 for $59.99).
- In `assets/js/main.js`, the `PRODUCTS` dictionary holds the catalog definitions for the interactive cart and search modals.
- Shipping threshold is set to $50.00 (`FREE_SHIPPING_THRESHOLD = 5000`).
- Storage keys: `novatrend-cart-v1` and `novatrend-wishlist-v1`.

Images are in `assets/img/` in modern WebP format:
- `hero-fashion.webp` and `hero-casual.webp`: transparent hero lookbook models. Keep alpha transparency; the orange backdrop and floating product cards are separate HTML/CSS layers. Both images use a 900×1350 canvas. The two hero buttons switch images with a finite 620ms animation and support Left/Right/Home/End keys.
- `cat-*.webp`: Category thumbnail cards
- `prod-*.webp`: Product catalog images
- `banner-*.webp`: Promotional banners

## Exact edit map

Counts are literal and case-sensitive in version 1.1.0.

| File | Search literally | Count | What to do |
|---|---|---:|---|
| `index.html` | `NovaTrend` | 5 | Brand name in metadata, home label, and footer |
| `index.html` | `Discover Products You'll Love` | 2 | Hero headline and aria-label |
| `index.html` | `Free Worldwide Shipping Over $50` | 1 | Top announcement bar promotion |
| `index.html` | `Up To 70% Off` | 2 | Flash sale promotional banner headings |
| `assets/css/style.css` | `--primary: #ff5722;` | 1 | Primary brand orange accent token |
| `assets/css/style.css` | `--dark: #111114;` | 1 | Dark text and background surface token |
| `assets/js/main.js` | `const FREE_SHIPPING_THRESHOLD = window.ForgeShopConfig.freeShippingAt;` | 1 | Free shipping threshold in cents ($50) |
| `assets/js/main.js` | `const STANDARD_SHIPPING_FEE = window.ForgeShopConfig.shippingCents;` | 1 | Standard shipping fee in cents ($4.99) |


## COD setup

The checkout is ready to configure; it does not come with a merchant account or a live order inbox. Use the original design documentation for visual edits and this section for the current checkout.

### The shortest path to accepting COD

1. Open `assets/js/shop-config.js`. Change `name` to your shop name. Keep `slug` stable so existing bags remain accessible.
2. Replace fictional products and prices in HTML and the original `assets/js/main.js` catalogue. Showcase templates use `products` in `shop-config.js` for their new bag; update the original visual prices to match. Prices and delivery amounts use integer USD cents in checkout: 3800 means $38.00. Do not change only the currency symbol.
3. Set `shippingCents` and `freeShippingAt`. A zero delivery fee is free delivery. A zero free-delivery threshold means all orders qualify for free delivery; use a high threshold if every order must pay the configured fee. Publish your shipping areas, taxes, returns and COD conditions in the page copy. Tax is not calculated by this static kit; confirm the final amount before fulfilment.
4. Create an order form in your own [Formspree account](https://formspree.io/). Verify the receiving email and enable the service's spam protection. Copy its public form URL into `orderEndpoint`, for example the URL supplied by your dashboard under `https://formspree.io/f/`. No password or API secret is needed in this file. A form-service subscription and its submission limits are separate from this template.
5. Publish the full website folder to an HTTPS static host. Test from the published URL, not only file://. Allow that domain in your service if domain restrictions are enabled.
6. Submit one clearly labelled test order using your own details. Confirm the exact product, selected size/finish, quantities, delivery fee, total, customer details and order reference appear in your order inbox. Confirm the bag clears only after a real service acknowledgement. Check spam/junk. Do not launch if your inbox does not receive the test.
7. Review each COD request manually, confirm stock, delivery area and price, then contact the customer before shipping. The form service stores order submissions, not inventory or verified payments. An order reference is a traceable request reference; it is not a payment receipt.

Official Formspree documentation: [JavaScript submission](https://help.formspree.io/articles/building-your-form/submit-forms-with-javascript-ajax/), [domain restriction](https://help.formspree.io/articles/form-and-project-settings/restrict-to-domain). Dashboard labels can change; use the actual endpoint your account provides. The bundled implementation uses native fetch, with no CDN/library.

If `orderEndpoint` is blank, visitors see **Preview COD order**. This produces a local summary; it never sends an order or clears their bag. A failed request or timeout keeps the bag and asks the customer to check with your shop using the reference before retrying, because a timed-out request may have arrived. Delivery fields are held only in the open form and receipt; closing/reloading does not save them. No analytics or tracking has been added.

### Public settings edit map

Search the quoted setting including its colon in `assets/js/shop-config.js`. Each setting below has one definition:

| Search | Purpose |
|---|---|
| `"orderEndpoint":` | Public HTTPS order-form endpoint; blank means preview |
| `"shippingCents":` | Flat delivery fee in USD cents |
| `"freeShippingAt":` | Free-delivery threshold in USD cents |
| `"onlineCheckoutEndpoint":` | Optional merchant-owned server endpoint; blank disables online payment |
| `"checkoutHosts":` | Exact trusted hostnames for the server's payment redirect |

`products` is present only in showcase templates. Every product has a unique `id`, a name and integer-cent price. Keep IDs stable; changing prices recalculates the current local bag from the catalogue, never from a stored customer-supplied price. Velora also records the current bike configuration as the variant. The other storefronts retain their existing size/colour/cart controls, storage and animations.

### Optional online checkout

Use the gateway available to your business and country. You need your own merchant account. For a cart with multiple products, [Stripe Checkout](https://docs.stripe.com/payments/checkout/how-checkout-works) is one integration option where supported. [Payment Links](https://docs.stripe.com/payment-links) are useful for a fixed offering, but a single fixed-price link does not replace a cart that contains arbitrary products and quantities.

The server, hosted separately from this static template, must:

- Receive the selected product IDs, variants and quantities; look up prices, delivery rules and stock itself. Never trust prices or totals from the browser.
- Validate customer details, restrict allowed origins and rate-limit requests. Store the order reference and prevent duplicate creation on retries.
- Create the checkout session with secret keys on the server only. Return `{"ok":true,"checkoutUrl":"https://trusted-payment-host/..."}`.
- Verify the gateway's signed webhook before marking an order paid. A redirect, query parameter or screenshot is not payment confirmation. Arrange fulfilment and notifications from verified server records.

Then fill `onlineCheckoutEndpoint` with that server's HTTPS URL and `checkoutHosts` with the gateway's exact checkout hostnames. The online button appears only when an endpoint is configured. The bag stays intact while redirecting; the gateway/server manages paid status. Do not connect the template's physical-goods checkout to Forge Zone's digital-template purchase endpoint or reuse Forge Zone's payment credentials.

A custom COD receiver may use the same JSON order contract. Return `{"ok":true}` only after reliably accepting/storing the order. JSON amounts are integer USD cents. Include the reference in replies and staff notifications. Formspree receives a readable `message`, public customer contact fields and `orderId` instead of the nested JSON contract. Manual stock/price confirmation is required for that simple route.

### Checkout checklist

- Add two different products; confirm separate sizes/finishes stay separate. Increase, decrease and remove quantities. Reload the bag.
- Test delivery just below, at and above the free-delivery threshold.
- Verify blank/invalid delivery fields cannot submit. Phone accepts common international number formatting.
- Try blocked storage, malformed cart data, offline mode, rejected/invalid responses and slow requests. No false success; bag stays intact.
- Confirm the loading button prevents a second submission. Confirm Escape, Tab, Shift+Tab and Close behave correctly on desktop and at 320px.
- Replace every fictional claim and placeholder contact. Confirm the receiving service stores the test order before accepting real customers.
- Keep the complete working folder and original ZIP. Change the asset version query when publishing a new revision.

### AI prompt for COD configuration

Attach the complete latest ZIP. Copy this prompt:

```text
Read my template's README.md, CUSTOMISE.md, index.html and all files in assets
before editing. Help me configure the existing COD checkout without changing
the visual design, animations or framework-free structure. Ask for my real shop
name, public order-form endpoint, products, USD prices, delivery fee, delivery
areas and free-delivery threshold. Do not request passwords or secret keys.
Update shop-config.js and matching HTML/main.js product data consistently.
Do not simulate success, add tracking or publish the site. Return complete
changed files with their relative paths, then guide me through one test order
and confirming it in my own order inbox. Keep preview mode until I provide a
real endpoint. Preserve the licence and unrelated features.
```

### AI prompt for online payment integration

```text
Read the complete latest template ZIP and the COD setup section first. Ask
which payment gateway is available to my business, where my server is hosted,
and whether I already have a merchant account. Do not ask me to paste secrets
into chat or browser code. Propose a server integration that validates product
IDs/prices/variants/quantities, delivery and stock, uses idempotent order
creation, creates a hosted checkout and verifies signed payment webhooks.
The static frontend already supports onlineCheckoutEndpoint and checkoutHosts.
Explain the required server files, private environment variables and tests.
Keep online payment disabled until the server exists. Do not claim a payment
succeeded from its redirect. Return complete changed files and setup steps;
do not deploy or change my merchant settings without my explicit instruction.
```
